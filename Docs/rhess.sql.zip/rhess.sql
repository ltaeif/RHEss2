-- phpMyAdmin SQL Dump
-- version 4.0.10.10
-- http://www.phpmyadmin.net
--
-- Client: localhost
-- Généré le: Mer 19 Août 2015 à 13:13
-- Version du serveur: 5.1.50-community
-- Version de PHP: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `rhess`
--

DELIMITER $$
--
-- Fonctions
--
CREATE DEFINER=`root`@`localhost` FUNCTION `dashboard_get_subunit_parent_id`(
                  id INT
                ) RETURNS int(11)
    READS SQL DATA
    DETERMINISTIC
BEGIN
                SELECT (SELECT t2.id 
                               FROM ohrm_subunit t2 
                               WHERE t2.lft < t1.lft AND t2.rgt > t1.rgt    
                               ORDER BY t2.rgt-t1.rgt ASC LIMIT 1) INTO @parent
                FROM ohrm_subunit t1 WHERE t1.id = id;

                RETURN @parent;

                END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Structure de la table `abstract_display_field`
--

CREATE TABLE IF NOT EXISTS `abstract_display_field` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `report_group_id` bigint(20) NOT NULL,
  `name` varchar(255) NOT NULL,
  `label` varchar(255) NOT NULL,
  `field_alias` varchar(255) DEFAULT NULL,
  `is_sortable` varchar(10) NOT NULL,
  `sort_order` varchar(255) DEFAULT NULL,
  `sort_field` varchar(255) DEFAULT NULL,
  `element_type` varchar(255) NOT NULL,
  `element_property` text NOT NULL,
  `width` varchar(255) NOT NULL,
  `is_exportable` varchar(10) DEFAULT NULL,
  `text_alignment_style` varchar(20) DEFAULT NULL,
  `is_value_list` tinyint(1) NOT NULL,
  `display_field_group_id` bigint(20) unsigned DEFAULT NULL,
  `default_value` varchar(255) DEFAULT NULL,
  `is_encrypted` tinyint(1) NOT NULL,
  `is_meta` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `hs_hr_config`
--

CREATE TABLE IF NOT EXISTS `hs_hr_config` (
  `key` varchar(100) NOT NULL DEFAULT '',
  `value` varchar(512) NOT NULL DEFAULT '',
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `hs_hr_config`
--

INSERT INTO `hs_hr_config` (`key`, `value`) VALUES
('admin.default_workshift_end_time', '17:00'),
('admin.default_workshift_start_time', '09:00'),
('admin.localization.default_date_format', 'd-m-Y'),
('admin.localization.default_language', 'fr_FR'),
('admin.localization.use_browser_language', 'Yes'),
('admin.product_type', 'os'),
('attendanceEmpEditSubmitted', 'No'),
('attendanceSupEditSubmitted', 'No'),
('authorize_user_role_manager_class', 'BasicUserRoleManager'),
('beacon.activation_acceptance_status', 'off'),
('beacon.activiation_status', 'on'),
('beacon.company_name', ''),
('beacon.flash_period', '120'),
('beacon.lock', 'unlocked'),
('beacon.next_flash_time', '0000-00-00'),
('beacon.uuid', 'fNVGCVRXX1RXDw=='),
('csrf_secret', 'hmbh705okjrmm1srki9qtn2lmn9i6a1p2o1t70qvskaamivut29k5'),
('domain.name', 'localhost'),
('hsp_accrued_last_updated', '0000-00-00'),
('hsp_current_plan', '0'),
('hsp_used_last_updated', '0000-00-00'),
('include_supervisor_chain', 'No'),
('ldap_domain_name', ''),
('ldap_port', ''),
('ldap_server', ''),
('ldap_status', ''),
('leave.entitlement_consumption_algorithm', 'FIFOEntitlementConsumptionStrategy'),
('leave.include_pending_leave_in_balance', '1'),
('leave.leavePeriodStatus', '1'),
('leave.work_schedule_implementation', 'BasicWorkSchedule'),
('openId.provider.added', 'on'),
('pim_show_deprecated_fields', '0'),
('report.mysql_group_concat_max_len', '2048'),
('showSIN', '0'),
('showSSN', '0'),
('showTaxExemptions', '0'),
('themeName', 'default'),
('timesheet_period_and_start_date', '<TimesheetPeriod><PeriodType>Weekly</PeriodType><ClassName>WeeklyTimesheetPeriod</ClassName><StartDate>1</StartDate><Heading>Week</Heading></TimesheetPeriod>'),
('timesheet_period_set', 'Yes'),
('timesheet_time_format', '1');

-- --------------------------------------------------------

--
-- Structure de la table `hs_hr_country`
--

CREATE TABLE IF NOT EXISTS `hs_hr_country` (
  `cou_code` char(2) NOT NULL DEFAULT '',
  `name` varchar(80) NOT NULL DEFAULT '',
  `cou_name` varchar(80) NOT NULL DEFAULT '',
  `iso3` char(3) DEFAULT NULL,
  `numcode` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`cou_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `hs_hr_country`
--

INSERT INTO `hs_hr_country` (`cou_code`, `name`, `cou_name`, `iso3`, `numcode`) VALUES
('AD', 'ANDORRA', 'Andorra', 'AND', 20),
('AE', 'UNITED ARAB EMIRATES', 'United Arab Emirates', 'ARE', 784),
('AF', 'AFGHANISTAN', 'Afghanistan', 'AFG', 4),
('AG', 'ANTIGUA AND BARBUDA', 'Antigua and Barbuda', 'ATG', 28),
('AI', 'ANGUILLA', 'Anguilla', 'AIA', 660),
('AL', 'ALBANIA', 'Albania', 'ALB', 8),
('AM', 'ARMENIA', 'Armenia', 'ARM', 51),
('AN', 'NETHERLANDS ANTILLES', 'Netherlands Antilles', 'ANT', 530),
('AO', 'ANGOLA', 'Angola', 'AGO', 24),
('AQ', 'ANTARCTICA', 'Antarctica', NULL, NULL),
('AR', 'ARGENTINA', 'Argentina', 'ARG', 32),
('AS', 'AMERICAN SAMOA', 'American Samoa', 'ASM', 16),
('AT', 'AUSTRIA', 'Austria', 'AUT', 40),
('AU', 'AUSTRALIA', 'Australia', 'AUS', 36),
('AW', 'ARUBA', 'Aruba', 'ABW', 533),
('AZ', 'AZERBAIJAN', 'Azerbaijan', 'AZE', 31),
('BA', 'BOSNIA AND HERZEGOVINA', 'Bosnia and Herzegovina', 'BIH', 70),
('BB', 'BARBADOS', 'Barbados', 'BRB', 52),
('BD', 'BANGLADESH', 'Bangladesh', 'BGD', 50),
('BE', 'BELGIUM', 'Belgium', 'BEL', 56),
('BF', 'BURKINA FASO', 'Burkina Faso', 'BFA', 854),
('BG', 'BULGARIA', 'Bulgaria', 'BGR', 100),
('BH', 'BAHRAIN', 'Bahrain', 'BHR', 48),
('BI', 'BURUNDI', 'Burundi', 'BDI', 108),
('BJ', 'BENIN', 'Benin', 'BEN', 204),
('BM', 'BERMUDA', 'Bermuda', 'BMU', 60),
('BN', 'BRUNEI DARUSSALAM', 'Brunei Darussalam', 'BRN', 96),
('BO', 'BOLIVIA', 'Bolivia', 'BOL', 68),
('BR', 'BRAZIL', 'Brazil', 'BRA', 76),
('BS', 'BAHAMAS', 'Bahamas', 'BHS', 44),
('BT', 'BHUTAN', 'Bhutan', 'BTN', 64),
('BV', 'BOUVET ISLAND', 'Bouvet Island', NULL, NULL),
('BW', 'BOTSWANA', 'Botswana', 'BWA', 72),
('BY', 'BELARUS', 'Belarus', 'BLR', 112),
('BZ', 'BELIZE', 'Belize', 'BLZ', 84),
('CA', 'CANADA', 'Canada', 'CAN', 124),
('CC', 'COCOS (KEELING) ISLANDS', 'Cocos (Keeling) Islands', NULL, NULL),
('CD', 'CONGO, THE DEMOCRATIC REPUBLIC OF THE', 'Congo, the Democratic Republic of the', 'COD', 180),
('CF', 'CENTRAL AFRICAN REPUBLIC', 'Central African Republic', 'CAF', 140),
('CG', 'CONGO', 'Congo', 'COG', 178),
('CH', 'SWITZERLAND', 'Switzerland', 'CHE', 756),
('CI', 'COTE D''IVOIRE', 'Cote D''Ivoire', 'CIV', 384),
('CK', 'COOK ISLANDS', 'Cook Islands', 'COK', 184),
('CL', 'CHILE', 'Chile', 'CHL', 152),
('CM', 'CAMEROON', 'Cameroon', 'CMR', 120),
('CN', 'CHINA', 'China', 'CHN', 156),
('CO', 'COLOMBIA', 'Colombia', 'COL', 170),
('CR', 'COSTA RICA', 'Costa Rica', 'CRI', 188),
('CS', 'SERBIA AND MONTENEGRO', 'Serbia and Montenegro', NULL, NULL),
('CU', 'CUBA', 'Cuba', 'CUB', 192),
('CV', 'CAPE VERDE', 'Cape Verde', 'CPV', 132),
('CX', 'CHRISTMAS ISLAND', 'Christmas Island', NULL, NULL),
('CY', 'CYPRUS', 'Cyprus', 'CYP', 196),
('CZ', 'CZECH REPUBLIC', 'Czech Republic', 'CZE', 203),
('DE', 'GERMANY', 'Germany', 'DEU', 276),
('DJ', 'DJIBOUTI', 'Djibouti', 'DJI', 262),
('DK', 'DENMARK', 'Denmark', 'DNK', 208),
('DM', 'DOMINICA', 'Dominica', 'DMA', 212),
('DO', 'DOMINICAN REPUBLIC', 'Dominican Republic', 'DOM', 214),
('DZ', 'ALGERIA', 'Algeria', 'DZA', 12),
('EC', 'ECUADOR', 'Ecuador', 'ECU', 218),
('EE', 'ESTONIA', 'Estonia', 'EST', 233),
('EG', 'EGYPT', 'Egypt', 'EGY', 818),
('EH', 'WESTERN SAHARA', 'Western Sahara', 'ESH', 732),
('ER', 'ERITREA', 'Eritrea', 'ERI', 232),
('ES', 'SPAIN', 'Spain', 'ESP', 724),
('ET', 'ETHIOPIA', 'Ethiopia', 'ETH', 231),
('FI', 'FINLAND', 'Finland', 'FIN', 246),
('FJ', 'FIJI', 'Fiji', 'FJI', 242),
('FK', 'FALKLAND ISLANDS (MALVINAS)', 'Falkland Islands (Malvinas)', 'FLK', 238),
('FM', 'MICRONESIA, FEDERATED STATES OF', 'Micronesia, Federated States of', 'FSM', 583),
('FO', 'FAROE ISLANDS', 'Faroe Islands', 'FRO', 234),
('FR', 'FRANCE', 'France', 'FRA', 250),
('GA', 'GABON', 'Gabon', 'GAB', 266),
('GB', 'UNITED KINGDOM', 'United Kingdom', 'GBR', 826),
('GD', 'GRENADA', 'Grenada', 'GRD', 308),
('GE', 'GEORGIA', 'Georgia', 'GEO', 268),
('GF', 'FRENCH GUIANA', 'French Guiana', 'GUF', 254),
('GH', 'GHANA', 'Ghana', 'GHA', 288),
('GI', 'GIBRALTAR', 'Gibraltar', 'GIB', 292),
('GL', 'GREENLAND', 'Greenland', 'GRL', 304),
('GM', 'GAMBIA', 'Gambia', 'GMB', 270),
('GN', 'GUINEA', 'Guinea', 'GIN', 324),
('GP', 'GUADELOUPE', 'Guadeloupe', 'GLP', 312),
('GQ', 'EQUATORIAL GUINEA', 'Equatorial Guinea', 'GNQ', 226),
('GR', 'GREECE', 'Greece', 'GRC', 300),
('GS', 'SOUTH GEORGIA AND THE SOUTH SANDWICH ISLANDS', 'South Georgia and the South Sandwich Islands', NULL, NULL),
('GT', 'GUATEMALA', 'Guatemala', 'GTM', 320),
('GU', 'GUAM', 'Guam', 'GUM', 316),
('GW', 'GUINEA-BISSAU', 'Guinea-Bissau', 'GNB', 624),
('GY', 'GUYANA', 'Guyana', 'GUY', 328),
('HK', 'HONG KONG', 'Hong Kong', 'HKG', 344),
('HM', 'HEARD ISLAND AND MCDONALD ISLANDS', 'Heard Island and Mcdonald Islands', NULL, NULL),
('HN', 'HONDURAS', 'Honduras', 'HND', 340),
('HR', 'CROATIA', 'Croatia', 'HRV', 191),
('HT', 'HAITI', 'Haiti', 'HTI', 332),
('HU', 'HUNGARY', 'Hungary', 'HUN', 348),
('ID', 'INDONESIA', 'Indonesia', 'IDN', 360),
('IE', 'IRELAND', 'Ireland', 'IRL', 372),
('IL', 'ISRAEL', 'Israel', 'ISR', 376),
('IN', 'INDIA', 'India', 'IND', 356),
('IO', 'BRITISH INDIAN OCEAN TERRITORY', 'British Indian Ocean Territory', NULL, NULL),
('IQ', 'IRAQ', 'Iraq', 'IRQ', 368),
('IR', 'IRAN, ISLAMIC REPUBLIC OF', 'Iran, Islamic Republic of', 'IRN', 364),
('IS', 'ICELAND', 'Iceland', 'ISL', 352),
('IT', 'ITALY', 'Italy', 'ITA', 380),
('JM', 'JAMAICA', 'Jamaica', 'JAM', 388),
('JO', 'JORDAN', 'Jordan', 'JOR', 400),
('JP', 'JAPAN', 'Japan', 'JPN', 392),
('KE', 'KENYA', 'Kenya', 'KEN', 404),
('KG', 'KYRGYZSTAN', 'Kyrgyzstan', 'KGZ', 417),
('KH', 'CAMBODIA', 'Cambodia', 'KHM', 116),
('KI', 'KIRIBATI', 'Kiribati', 'KIR', 296),
('KM', 'COMOROS', 'Comoros', 'COM', 174),
('KN', 'SAINT KITTS AND NEVIS', 'Saint Kitts and Nevis', 'KNA', 659),
('KP', 'KOREA, DEMOCRATIC PEOPLE''S REPUBLIC OF', 'Korea, Democratic People''s Republic of', 'PRK', 408),
('KR', 'KOREA, REPUBLIC OF', 'Korea, Republic of', 'KOR', 410),
('KW', 'KUWAIT', 'Kuwait', 'KWT', 414),
('KY', 'CAYMAN ISLANDS', 'Cayman Islands', 'CYM', 136),
('KZ', 'KAZAKHSTAN', 'Kazakhstan', 'KAZ', 398),
('LA', 'LAO PEOPLE''S DEMOCRATIC REPUBLIC', 'Lao People''s Democratic Republic', 'LAO', 418),
('LB', 'LEBANON', 'Lebanon', 'LBN', 422),
('LC', 'SAINT LUCIA', 'Saint Lucia', 'LCA', 662),
('LI', 'LIECHTENSTEIN', 'Liechtenstein', 'LIE', 438),
('LK', 'SRI LANKA', 'Sri Lanka', 'LKA', 144),
('LR', 'LIBERIA', 'Liberia', 'LBR', 430),
('LS', 'LESOTHO', 'Lesotho', 'LSO', 426),
('LT', 'LITHUANIA', 'Lithuania', 'LTU', 440),
('LU', 'LUXEMBOURG', 'Luxembourg', 'LUX', 442),
('LV', 'LATVIA', 'Latvia', 'LVA', 428),
('LY', 'LIBYAN ARAB JAMAHIRIYA', 'Libyan Arab Jamahiriya', 'LBY', 434),
('MA', 'MOROCCO', 'Morocco', 'MAR', 504),
('MC', 'MONACO', 'Monaco', 'MCO', 492),
('MD', 'MOLDOVA, REPUBLIC OF', 'Moldova, Republic of', 'MDA', 498),
('MG', 'MADAGASCAR', 'Madagascar', 'MDG', 450),
('MH', 'MARSHALL ISLANDS', 'Marshall Islands', 'MHL', 584),
('MK', 'MACEDONIA, THE FORMER YUGOSLAV REPUBLIC OF', 'Macedonia, the Former Yugoslav Republic of', 'MKD', 807),
('ML', 'MALI', 'Mali', 'MLI', 466),
('MM', 'MYANMAR', 'Myanmar', 'MMR', 104),
('MN', 'MONGOLIA', 'Mongolia', 'MNG', 496),
('MO', 'MACAO', 'Macao', 'MAC', 446),
('MP', 'NORTHERN MARIANA ISLANDS', 'Northern Mariana Islands', 'MNP', 580),
('MQ', 'MARTINIQUE', 'Martinique', 'MTQ', 474),
('MR', 'MAURITANIA', 'Mauritania', 'MRT', 478),
('MS', 'MONTSERRAT', 'Montserrat', 'MSR', 500),
('MT', 'MALTA', 'Malta', 'MLT', 470),
('MU', 'MAURITIUS', 'Mauritius', 'MUS', 480),
('MV', 'MALDIVES', 'Maldives', 'MDV', 462),
('MW', 'MALAWI', 'Malawi', 'MWI', 454),
('MX', 'MEXICO', 'Mexico', 'MEX', 484),
('MY', 'MALAYSIA', 'Malaysia', 'MYS', 458),
('MZ', 'MOZAMBIQUE', 'Mozambique', 'MOZ', 508),
('NA', 'NAMIBIA', 'Namibia', 'NAM', 516),
('NC', 'NEW CALEDONIA', 'New Caledonia', 'NCL', 540),
('NE', 'NIGER', 'Niger', 'NER', 562),
('NF', 'NORFOLK ISLAND', 'Norfolk Island', 'NFK', 574),
('NG', 'NIGERIA', 'Nigeria', 'NGA', 566),
('NI', 'NICARAGUA', 'Nicaragua', 'NIC', 558),
('NL', 'NETHERLANDS', 'Netherlands', 'NLD', 528),
('NO', 'NORWAY', 'Norway', 'NOR', 578),
('NP', 'NEPAL', 'Nepal', 'NPL', 524),
('NR', 'NAURU', 'Nauru', 'NRU', 520),
('NU', 'NIUE', 'Niue', 'NIU', 570),
('NZ', 'NEW ZEALAND', 'New Zealand', 'NZL', 554),
('OM', 'OMAN', 'Oman', 'OMN', 512),
('PA', 'PANAMA', 'Panama', 'PAN', 591),
('PE', 'PERU', 'Peru', 'PER', 604),
('PF', 'FRENCH POLYNESIA', 'French Polynesia', 'PYF', 258),
('PG', 'PAPUA NEW GUINEA', 'Papua New Guinea', 'PNG', 598),
('PH', 'PHILIPPINES', 'Philippines', 'PHL', 608),
('PK', 'PAKISTAN', 'Pakistan', 'PAK', 586),
('PL', 'POLAND', 'Poland', 'POL', 616),
('PM', 'SAINT PIERRE AND MIQUELON', 'Saint Pierre and Miquelon', 'SPM', 666),
('PN', 'PITCAIRN', 'Pitcairn', 'PCN', 612),
('PR', 'PUERTO RICO', 'Puerto Rico', 'PRI', 630),
('PS', 'PALESTINIAN TERRITORY, OCCUPIED', 'Palestinian Territory, Occupied', NULL, NULL),
('PT', 'PORTUGAL', 'Portugal', 'PRT', 620),
('PW', 'PALAU', 'Palau', 'PLW', 585),
('PY', 'PARAGUAY', 'Paraguay', 'PRY', 600),
('QA', 'QATAR', 'Qatar', 'QAT', 634),
('RE', 'REUNION', 'Reunion', 'REU', 638),
('RO', 'ROMANIA', 'Romania', 'ROM', 642),
('RU', 'RUSSIAN FEDERATION', 'Russian Federation', 'RUS', 643),
('RW', 'RWANDA', 'Rwanda', 'RWA', 646),
('SA', 'SAUDI ARABIA', 'Saudi Arabia', 'SAU', 682),
('SB', 'SOLOMON ISLANDS', 'Solomon Islands', 'SLB', 90),
('SC', 'SEYCHELLES', 'Seychelles', 'SYC', 690),
('SD', 'SUDAN', 'Sudan', 'SDN', 736),
('SE', 'SWEDEN', 'Sweden', 'SWE', 752),
('SG', 'SINGAPORE', 'Singapore', 'SGP', 702),
('SH', 'SAINT HELENA', 'Saint Helena', 'SHN', 654),
('SI', 'SLOVENIA', 'Slovenia', 'SVN', 705),
('SJ', 'SVALBARD AND JAN MAYEN', 'Svalbard and Jan Mayen', 'SJM', 744),
('SK', 'SLOVAKIA', 'Slovakia', 'SVK', 703),
('SL', 'SIERRA LEONE', 'Sierra Leone', 'SLE', 694),
('SM', 'SAN MARINO', 'San Marino', 'SMR', 674),
('SN', 'SENEGAL', 'Senegal', 'SEN', 686),
('SO', 'SOMALIA', 'Somalia', 'SOM', 706),
('SR', 'SURINAME', 'Suriname', 'SUR', 740),
('ST', 'SAO TOME AND PRINCIPE', 'Sao Tome and Principe', 'STP', 678),
('SV', 'EL SALVADOR', 'El Salvador', 'SLV', 222),
('SY', 'SYRIAN ARAB REPUBLIC', 'Syrian Arab Republic', 'SYR', 760),
('SZ', 'SWAZILAND', 'Swaziland', 'SWZ', 748),
('TC', 'TURKS AND CAICOS ISLANDS', 'Turks and Caicos Islands', 'TCA', 796),
('TD', 'CHAD', 'Chad', 'TCD', 148),
('TF', 'FRENCH SOUTHERN TERRITORIES', 'French Southern Territories', NULL, NULL),
('TG', 'TOGO', 'Togo', 'TGO', 768),
('TH', 'THAILAND', 'Thailand', 'THA', 764),
('TJ', 'TAJIKISTAN', 'Tajikistan', 'TJK', 762),
('TK', 'TOKELAU', 'Tokelau', 'TKL', 772),
('TL', 'TIMOR-LESTE', 'Timor-Leste', NULL, NULL),
('TM', 'TURKMENISTAN', 'Turkmenistan', 'TKM', 795),
('TN', 'TUNISIA', 'Tunisia', 'TUN', 788),
('TO', 'TONGA', 'Tonga', 'TON', 776),
('TR', 'TURKEY', 'Turkey', 'TUR', 792),
('TT', 'TRINIDAD AND TOBAGO', 'Trinidad and Tobago', 'TTO', 780),
('TV', 'TUVALU', 'Tuvalu', 'TUV', 798),
('TW', 'TAIWAN, PROVINCE OF CHINA', 'Taiwan', 'TWN', 158),
('TZ', 'TANZANIA, UNITED REPUBLIC OF', 'Tanzania, United Republic of', 'TZA', 834),
('UA', 'UKRAINE', 'Ukraine', 'UKR', 804),
('UG', 'UGANDA', 'Uganda', 'UGA', 800),
('UM', 'UNITED STATES MINOR OUTLYING ISLANDS', 'United States Minor Outlying Islands', NULL, NULL),
('US', 'UNITED STATES', 'United States', 'USA', 840),
('UY', 'URUGUAY', 'Uruguay', 'URY', 858),
('UZ', 'UZBEKISTAN', 'Uzbekistan', 'UZB', 860),
('VA', 'HOLY SEE (VATICAN CITY STATE)', 'Holy See (Vatican City State)', 'VAT', 336),
('VC', 'SAINT VINCENT AND THE GRENADINES', 'Saint Vincent and the Grenadines', 'VCT', 670),
('VE', 'VENEZUELA', 'Venezuela', 'VEN', 862),
('VG', 'VIRGIN ISLANDS, BRITISH', 'Virgin Islands, British', 'VGB', 92),
('VI', 'VIRGIN ISLANDS, U.S.', 'Virgin Islands, U.s.', 'VIR', 850),
('VN', 'VIET NAM', 'Viet Nam', 'VNM', 704),
('VU', 'VANUATU', 'Vanuatu', 'VUT', 548),
('WF', 'WALLIS AND FUTUNA', 'Wallis and Futuna', 'WLF', 876),
('WS', 'SAMOA', 'Samoa', 'WSM', 882),
('YE', 'YEMEN', 'Yemen', 'YEM', 887),
('YT', 'MAYOTTE', 'Mayotte', NULL, NULL),
('ZA', 'SOUTH AFRICA', 'South Africa', 'ZAF', 710),
('ZM', 'ZAMBIA', 'Zambia', 'ZMB', 894),
('ZW', 'ZIMBABWE', 'Zimbabwe', 'ZWE', 716);

-- --------------------------------------------------------

--
-- Structure de la table `hs_hr_currency_type`
--

CREATE TABLE IF NOT EXISTS `hs_hr_currency_type` (
  `code` int(11) NOT NULL DEFAULT '0',
  `currency_id` char(3) NOT NULL DEFAULT '',
  `currency_name` varchar(70) NOT NULL DEFAULT '',
  PRIMARY KEY (`currency_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `hs_hr_currency_type`
--

INSERT INTO `hs_hr_currency_type` (`code`, `currency_id`, `currency_name`) VALUES
(3, 'AED', 'Utd. Arab Emir. Dirham'),
(4, 'AFN', 'Afghanistan Afghani'),
(5, 'ALL', 'Albanian Lek'),
(6, 'ANG', 'NL Antillian Guilder'),
(7, 'AOR', 'Angolan New Kwanza'),
(177, 'ARP', 'Argentina Pesos'),
(8, 'ARS', 'Argentine Peso'),
(10, 'AUD', 'Australian Dollar'),
(11, 'AWG', 'Aruban Florin'),
(12, 'BBD', 'Barbados Dollar'),
(13, 'BDT', 'Bangladeshi Taka'),
(15, 'BGL', 'Bulgarian Lev'),
(16, 'BHD', 'Bahraini Dinar'),
(17, 'BIF', 'Burundi Franc'),
(18, 'BMD', 'Bermudian Dollar'),
(19, 'BND', 'Brunei Dollar'),
(20, 'BOB', 'Bolivian Boliviano'),
(21, 'BRL', 'Brazilian Real'),
(22, 'BSD', 'Bahamian Dollar'),
(23, 'BTN', 'Bhutan Ngultrum'),
(24, 'BWP', 'Botswana Pula'),
(25, 'BZD', 'Belize Dollar'),
(26, 'CAD', 'Canadian Dollar'),
(27, 'CHF', 'Swiss Franc'),
(28, 'CLP', 'Chilean Peso'),
(29, 'CNY', 'Chinese Yuan Renminbi'),
(30, 'COP', 'Colombian Peso'),
(31, 'CRC', 'Costa Rican Colon'),
(32, 'CUP', 'Cuban Peso'),
(33, 'CVE', 'Cape Verde Escudo'),
(34, 'CYP', 'Cyprus Pound'),
(171, 'CZK', 'Czech Koruna'),
(37, 'DJF', 'Djibouti Franc'),
(38, 'DKK', 'Danish Krona'),
(39, 'DOP', 'Dominican Peso'),
(40, 'DZD', 'Algerian Dinar'),
(41, 'ECS', 'Ecuador Sucre'),
(43, 'EEK', 'Estonian Krona'),
(44, 'EGP', 'Egyptian Pound'),
(46, 'ETB', 'Ethiopian Birr'),
(42, 'EUR', 'Euro'),
(48, 'FJD', 'Fiji Dollar'),
(49, 'FKP', 'Falkland Islands Pound'),
(51, 'GBP', 'Pound Sterling'),
(52, 'GHC', 'Ghanaian Cedi'),
(53, 'GIP', 'Gibraltar Pound'),
(54, 'GMD', 'Gambian Dalasi'),
(55, 'GNF', 'Guinea Franc'),
(57, 'GTQ', 'Guatemalan Quetzal'),
(58, 'GYD', 'Guyanan Dollar'),
(59, 'HKD', 'Hong Kong Dollar'),
(60, 'HNL', 'Honduran Lempira'),
(61, 'HRK', 'Croatian Kuna'),
(62, 'HTG', 'Haitian Gourde'),
(63, 'HUF', 'Hungarian Forint'),
(64, 'IDR', 'Indonesian Rupiah'),
(66, 'ILS', 'Israeli New Shekel'),
(67, 'INR', 'Indian Rupee'),
(68, 'IQD', 'Iraqi Dinar'),
(69, 'IRR', 'Iranian Rial'),
(70, 'ISK', 'Iceland Krona'),
(72, 'JMD', 'Jamaican Dollar'),
(73, 'JOD', 'Jordanian Dinar'),
(74, 'JPY', 'Japanese Yen'),
(75, 'KES', 'Kenyan Shilling'),
(76, 'KHR', 'Kampuchean Riel'),
(77, 'KMF', 'Comoros Franc'),
(78, 'KPW', 'North Korean Won'),
(79, 'KRW', 'Korean Won'),
(80, 'KWD', 'Kuwaiti Dinar'),
(81, 'KYD', 'Cayman Islands Dollar'),
(82, 'KZT', 'Kazakhstan Tenge'),
(83, 'LAK', 'Lao Kip'),
(84, 'LBP', 'Lebanese Pound'),
(85, 'LKR', 'Sri Lanka Rupee'),
(86, 'LRD', 'Liberian Dollar'),
(87, 'LSL', 'Lesotho Loti'),
(88, 'LTL', 'Lithuanian Litas'),
(90, 'LVL', 'Latvian Lats'),
(91, 'LYD', 'Libyan Dinar'),
(92, 'MAD', 'Moroccan Dirham'),
(93, 'MGF', 'Malagasy Franc'),
(94, 'MMK', 'Myanmar Kyat'),
(95, 'MNT', 'Mongolian Tugrik'),
(96, 'MOP', 'Macau Pataca'),
(97, 'MRO', 'Mauritanian Ouguiya'),
(98, 'MTL', 'Maltese Lira'),
(99, 'MUR', 'Mauritius Rupee'),
(100, 'MVR', 'Maldive Rufiyaa'),
(101, 'MWK', 'Malawi Kwacha'),
(102, 'MXN', 'Mexican New Peso'),
(172, 'MXP', 'Mexican Peso'),
(103, 'MYR', 'Malaysian Ringgit'),
(104, 'MZM', 'Mozambique Metical'),
(105, 'NAD', 'Namibia Dollar'),
(106, 'NGN', 'Nigerian Naira'),
(107, 'NIO', 'Nicaraguan Cordoba Oro'),
(109, 'NOK', 'Norwegian Krona'),
(110, 'NPR', 'Nepalese Rupee'),
(111, 'NZD', 'New Zealand Dollar'),
(112, 'OMR', 'Omani Rial'),
(113, 'PAB', 'Panamanian Balboa'),
(114, 'PEN', 'Peruvian Nuevo Sol'),
(115, 'PGK', 'Papua New Guinea Kina'),
(116, 'PHP', 'Philippine Peso'),
(117, 'PKR', 'Pakistan Rupee'),
(118, 'PLN', 'Polish Zloty'),
(120, 'PYG', 'Paraguay Guarani'),
(121, 'QAR', 'Qatari Rial'),
(122, 'ROL', 'Romanian Leu'),
(123, 'RUB', 'Russian Rouble'),
(180, 'RUR', 'Russia Rubles'),
(173, 'SAR', 'Saudi Arabia Riyal'),
(125, 'SBD', 'Solomon Islands Dollar'),
(126, 'SCR', 'Seychelles Rupee'),
(127, 'SDD', 'Sudanese Dinar'),
(128, 'SDP', 'Sudanese Pound'),
(129, 'SEK', 'Swedish Krona'),
(131, 'SGD', 'Singapore Dollar'),
(132, 'SHP', 'St. Helena Pound'),
(130, 'SKK', 'Slovak Koruna'),
(135, 'SLL', 'Sierra Leone Leone'),
(136, 'SOS', 'Somali Shilling'),
(137, 'SRD', 'Surinamese Dollar'),
(138, 'STD', 'Sao Tome/Principe Dobra'),
(139, 'SVC', 'El Salvador Colon'),
(140, 'SYP', 'Syrian Pound'),
(141, 'SZL', 'Swaziland Lilangeni'),
(142, 'THB', 'Thai Baht'),
(143, 'TND', 'Tunisian Dinar'),
(144, 'TOP', 'Tongan Pa''anga'),
(145, 'TRL', 'Turkish Lira'),
(146, 'TTD', 'Trinidad/Tobago Dollar'),
(147, 'TWD', 'Taiwan Dollar'),
(148, 'TZS', 'Tanzanian Shilling'),
(149, 'UAH', 'Ukraine Hryvnia'),
(150, 'UGX', 'Uganda Shilling'),
(151, 'USD', 'United States Dollar'),
(152, 'UYP', 'Uruguayan Peso'),
(153, 'VEB', 'Venezuelan Bolivar'),
(154, 'VND', 'Vietnamese Dong'),
(155, 'VUV', 'Vanuatu Vatu'),
(156, 'WST', 'Samoan Tala'),
(158, 'XAF', 'CFA Franc BEAC'),
(159, 'XAG', 'Silver (oz.)'),
(160, 'XAU', 'Gold (oz.)'),
(161, 'XCD', 'Eastern Caribbean Dollars'),
(179, 'XDR', 'IMF Special Drawing Right'),
(162, 'XOF', 'CFA Franc BCEAO'),
(163, 'XPD', 'Palladium (oz.)'),
(164, 'XPF', 'CFP Franc'),
(165, 'XPT', 'Platinum (oz.)'),
(166, 'YER', 'Yemeni Riyal'),
(167, 'YUM', 'Yugoslavian Dinar'),
(175, 'YUN', 'Yugoslav Dinar'),
(168, 'ZAR', 'South African Rand'),
(176, 'ZMK', 'Zambian Kwacha'),
(169, 'ZRN', 'New Zaire'),
(170, 'ZWD', 'Zimbabwe Dollar');

-- --------------------------------------------------------

--
-- Structure de la table `hs_hr_custom_export`
--

CREATE TABLE IF NOT EXISTS `hs_hr_custom_export` (
  `export_id` int(11) NOT NULL,
  `name` varchar(250) NOT NULL,
  `fields` text,
  `headings` text,
  PRIMARY KEY (`export_id`),
  KEY `emp_number` (`export_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `hs_hr_custom_fields`
--

CREATE TABLE IF NOT EXISTS `hs_hr_custom_fields` (
  `field_num` int(11) NOT NULL,
  `name` varchar(250) NOT NULL,
  `type` int(11) NOT NULL,
  `screen` varchar(100) DEFAULT NULL,
  `extra_data` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`field_num`),
  KEY `emp_number` (`field_num`),
  KEY `screen` (`screen`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `hs_hr_custom_fields`
--

INSERT INTO `hs_hr_custom_fields` (`field_num`, `name`, `type`, `screen`, `extra_data`) VALUES
(1, 'Tel', 0, 'personal', '');

-- --------------------------------------------------------

--
-- Structure de la table `hs_hr_custom_import`
--

CREATE TABLE IF NOT EXISTS `hs_hr_custom_import` (
  `import_id` int(11) NOT NULL,
  `name` varchar(250) NOT NULL,
  `fields` text,
  `has_heading` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`import_id`),
  KEY `emp_number` (`import_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `hs_hr_district`
--

CREATE TABLE IF NOT EXISTS `hs_hr_district` (
  `district_code` varchar(13) NOT NULL DEFAULT '',
  `district_name` varchar(50) DEFAULT NULL,
  `province_code` varchar(13) DEFAULT NULL,
  PRIMARY KEY (`district_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `hs_hr_employee`
--

CREATE TABLE IF NOT EXISTS `hs_hr_employee` (
  `emp_number` int(7) NOT NULL DEFAULT '0',
  `employee_id` varchar(50) DEFAULT NULL,
  `emp_lastname` varchar(100) NOT NULL DEFAULT '',
  `emp_firstname` varchar(100) NOT NULL DEFAULT '',
  `emp_middle_name` varchar(100) NOT NULL DEFAULT '',
  `emp_nick_name` varchar(100) DEFAULT '',
  `emp_smoker` smallint(6) DEFAULT '0',
  `ethnic_race_code` varchar(13) DEFAULT NULL,
  `emp_birthday` date DEFAULT NULL,
  `nation_code` int(4) DEFAULT NULL,
  `emp_gender` smallint(6) DEFAULT NULL,
  `emp_marital_status` varchar(20) DEFAULT NULL,
  `emp_ssn_num` varchar(100) CHARACTER SET latin1 DEFAULT '',
  `emp_sin_num` varchar(100) DEFAULT '',
  `emp_other_id` varchar(100) DEFAULT '',
  `emp_dri_lice_num` varchar(100) DEFAULT '',
  `emp_dri_lice_exp_date` date DEFAULT NULL,
  `emp_military_service` varchar(100) DEFAULT '',
  `emp_status` int(13) DEFAULT NULL,
  `job_title_code` int(7) DEFAULT NULL,
  `eeo_cat_code` int(11) DEFAULT NULL,
  `work_station` int(6) DEFAULT NULL,
  `emp_street1` varchar(100) DEFAULT '',
  `emp_street2` varchar(100) DEFAULT '',
  `city_code` varchar(100) DEFAULT '',
  `coun_code` varchar(100) DEFAULT '',
  `provin_code` varchar(100) DEFAULT '',
  `emp_zipcode` varchar(20) DEFAULT NULL,
  `emp_hm_telephone` varchar(50) DEFAULT NULL,
  `emp_mobile` varchar(50) DEFAULT NULL,
  `emp_work_telephone` varchar(50) DEFAULT NULL,
  `emp_work_email` varchar(50) DEFAULT NULL,
  `sal_grd_code` varchar(13) DEFAULT NULL,
  `joined_date` date DEFAULT NULL,
  `emp_oth_email` varchar(50) DEFAULT NULL,
  `termination_id` int(4) DEFAULT NULL,
  `custom1` varchar(250) DEFAULT NULL,
  `custom2` varchar(250) DEFAULT NULL,
  `custom3` varchar(250) DEFAULT NULL,
  `custom4` varchar(250) DEFAULT NULL,
  `custom5` varchar(250) DEFAULT NULL,
  `custom6` varchar(250) DEFAULT NULL,
  `custom7` varchar(250) DEFAULT NULL,
  `custom8` varchar(250) DEFAULT NULL,
  `custom9` varchar(250) DEFAULT NULL,
  `custom10` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`emp_number`),
  KEY `work_station` (`work_station`),
  KEY `nation_code` (`nation_code`),
  KEY `job_title_code` (`job_title_code`),
  KEY `emp_status` (`emp_status`),
  KEY `eeo_cat_code` (`eeo_cat_code`),
  KEY `termination_id` (`termination_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `hs_hr_employee`
--

INSERT INTO `hs_hr_employee` (`emp_number`, `employee_id`, `emp_lastname`, `emp_firstname`, `emp_middle_name`, `emp_nick_name`, `emp_smoker`, `ethnic_race_code`, `emp_birthday`, `nation_code`, `emp_gender`, `emp_marital_status`, `emp_ssn_num`, `emp_sin_num`, `emp_other_id`, `emp_dri_lice_num`, `emp_dri_lice_exp_date`, `emp_military_service`, `emp_status`, `job_title_code`, `eeo_cat_code`, `work_station`, `emp_street1`, `emp_street2`, `city_code`, `coun_code`, `provin_code`, `emp_zipcode`, `emp_hm_telephone`, `emp_mobile`, `emp_work_telephone`, `emp_work_email`, `sal_grd_code`, `joined_date`, `emp_oth_email`, `termination_id`, `custom1`, `custom2`, `custom3`, `custom4`, `custom5`, `custom6`, `custom7`, `custom8`, `custom9`, `custom10`) VALUES
(1, '0001', 'Kortas', 'Abdellatif', '', '', 0, NULL, NULL, NULL, NULL, '', '', '', '', '', NULL, '', NULL, NULL, 2, NULL, '', '', '', '0', '', '', '', '', '', '', NULL, '2015-08-12', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(2, '0002', 'Ben Ahmed', 'Mohamed', '', '', 0, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, '', '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(3, '0003', 'Zouari Ben Saad', 'Saida', '', '', 0, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, '', '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `hs_hr_emp_attachment`
--

CREATE TABLE IF NOT EXISTS `hs_hr_emp_attachment` (
  `emp_number` int(7) NOT NULL DEFAULT '0',
  `eattach_id` int(11) NOT NULL DEFAULT '0',
  `eattach_desc` varchar(200) DEFAULT NULL,
  `eattach_filename` varchar(100) DEFAULT NULL,
  `eattach_size` int(11) DEFAULT '0',
  `eattach_attachment` mediumblob,
  `eattach_type` varchar(200) DEFAULT NULL,
  `screen` varchar(100) DEFAULT '',
  `attached_by` int(11) DEFAULT NULL,
  `attached_by_name` varchar(200) DEFAULT NULL,
  `attached_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`emp_number`,`eattach_id`),
  KEY `screen` (`screen`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `hs_hr_emp_attachment`
--

INSERT INTO `hs_hr_emp_attachment` (`emp_number`, `eattach_id`, `eattach_desc`, `eattach_filename`, `eattach_size`, `eattach_attachment`, `eattach_type`, `screen`, `attached_by`, `attached_by_name`, `attached_time`) VALUES
(1, 1, 'CV', 'd-169_2.pdf', 127729, 0x255044462d312e360d25e2e3cfd30d0a3830342030206f626a0d3c3c2f4c696e656172697a656420312f4c203132373732392f4f203830362f45203130303333372f4e20332f54203132373332382f48205b20353337203233345d3e3e0d656e646f626a0d202020202020202020202020200d0a3832322030206f626a0d3c3c2f4465636f64655061726d733c3c2f436f6c756d6e7320352f507265646963746f722031323e3e2f46696c7465722f466c6174654465636f64652f49445b3c32363043333946373432443545343430414231423233303237433535443439453e3c34343730423839393638353545413430393833324337393241343837453038393e5d2f496e6465785b3830342035355d2f496e666f20383033203020522f4c656e6774682039382f50726576203132373332392f526f6f7420383035203020522f53697a65203835392f547970652f585265662f575b31203320315d3e3e73747265616d0d0a68de62626460106060626060fe0c22190a4024930e8864df0d2259324024a33a886495028b6882d5ff02930160914ab0ae0760f65d30c903224dae0349461651b009c781e4ff999c0c4c8c0ccc9bc17631300e13f23fc3ff4ff700020c00b49e0f8b0d0a656e6473747265616d0d656e646f626a0d7374617274787265660d0a300d0a2525454f460d0a20202020202020202020202020202020202020202020202020202020202020202020202020200d0a3835382030206f626a0d3c3c2f43203133362f46696c7465722f466c6174654465636f64652f49203135392f4c656e677468203134362f532037323e3e73747265616d0d0a68de6260606002a24e06160606b17d0c820c0820c8c0ccc00a14e778c8b0ed01c3750706865d206196026f6986de06c68c06068f06c606a81410b031306e7f00a405c07a41e03890ded458cb50a2c0c6203583b783258da993f126839b43d20193c0192dbc160c0cf2fb19641a20f6b13330ee00e9e7606050af02d28c0c8c0d60a318df7782b90c0cef00020c0012111eed0d0a656e6473747265616d0d656e646f626a0d3830352030206f626a0d3c3c2f4d61726b496e666f3c3c2f4d61726b656420747275653e3e2f4d65746164617461203135203020522f506167657320383032203020522f53747275637454726565526f6f74203233203020522f547970652f436174616c6f673e3e0d656e646f626a0d3830362030206f626a0d3c3c2f416e6e6f74735b383233203020522038323420302052203832352030205220383236203020522038323720302052203832382030205220383239203020522038333020302052203833312030205220383332203020522038333320302052203833342030205220383335203020522038333620302052203833372030205220383338203020525d2f436f6e74656e74735b3830382030205220383130203020522038313120302052203831322030205220383133203020522038313420302052203831362030205220383137203020525d2f43726f70426f785b302030203539352e3332203834312e39325d2f47726f75703c3c2f43532f4465766963655247422f532f5472616e73706172656e63792f547970652f47726f75703e3e2f4d65646961426f785b302030203539352e3332203834312e39325d2f506172656e7420383032203020522f5265736f75726365733c3c2f4578744753746174653c3c2f47533720383339203020523e3e2f466f6e743c3c2f463120383432203020522f463220383435203020522f463320383531203020522f463420383537203020523e3e2f50726f635365745b2f5044462f546578742f496d616765422f496d616765432f496d616765495d2f584f626a6563743c3c2f496d6167653338353320383231203020523e3e3e3e2f526f7461746520302f537472756374506172656e747320302f546162732f532f547970652f506167653e3e0d656e646f626a0d3830372030206f626a0d3c3c2f46696c7465722f466c6174654465636f64652f4669727374203330362f4c656e67746820313632342f4e2033352f547970652f4f626a53746d3e3e73747265616d0d0a68dec4586d6fdb3610fe2bfcd8628bc47751439721af5d80b62b9a74192018856a2bb6304736247979f9f57b8e926cd7b153c75d32083429f2787cc8bbe778b2938a71e6a466c248d4864917a1b64c2b833a622656a81d8b0cc9c52ce678579c09ae1d1a820911514332a10444942255d0a5a0d35a8d8661c2718b866522d650af2226794c438e4909a54ec54caa18b33467526379a705939686b4644a5a6a28a6b42019cd9495584b1ba685a321c20bad0edab5f23d8e69cbb1051da3210573c0af230bcd46a01161083bd62ea621c5740cf5ce686604613686191b61096399719c7a70144e28f6e64d7880721e7efe74165edc4db3f0a05fe79382de5f8dea7afa4b18dedcdc04b322ff9a56417f14e6c520bb0dfa57d7bf4dbe8cd362f8251ffc2a5fefef8787e75074c9389aa74c879fb27e9d486102c0e23688b05d2e03422b62bcf5c2f3ba9cf5eb8f6999153553e1f9ec6b4debbfcb8bbff7f79f822b235859310c37a150581ff6eb6038ac6fd7c3d0bbc3b82a09c668729d8537d9b88ffa24988ea61b31c52a30718749e30dbeb01693d91dd3306b2c56676591924c3a6eecf7252b82517d3dde844ec736886d87ce181528b31e9dfd1fd0355e45270870d29ac075c65d0117ed0e6e4cd8fa505202d5341d6652c4f2bbc06c1c58d721539109e2f5c0dc0f009b75ee5ed569593f8a4745b098eef0e8c805225a0f28de0d90244485b7e34657727353757eb40e80e0cf86a07517c71b77d1de361ed12a06b1bb59aa616316689c0df2d9757830837d66557f342d27c332bd465c382b1016f262f871de733883bf577b27b7f7d9789c15f77be7753ecd8a410e474babe9ed664773016279bb2715614fd1863dc95df7743f9a87fbeff9bd8267cdd168609b936015cdce71becadbf36dee1fa0d9e87091bf665a34adcfad47a39f1f4deb7c36f2ce07303c6aa1ad82d935ce67d3ab7177f5ec8df3aadedb2e7c6ad1582b0a905828a3d740da35b867f5e87ee13c271fbe83443a8fc474a05661ec12c641b0c12cadb3bca8eabc9ed53e42f427e57452a2b78de85b5e34c85bc893a408905a29f43d84b826a01fbe0f3f4cca6b5c1f1ee2c96dfdf6bca6b5fb2913cd26aabe8fbddc8407ff0c2ff3413d625a8bf0289dfe9ee5c3112e30e9c2e3ac11db938891a7e37458e1c4c2d349511f1e4e6e933d6b8d1f4312ca39cde8f9c10f29e2cb4199637d7abd6c146acec3b33a1de7fd836238ce180fdf65e90031892915be4f6f1b10123ab1c1ecfa4fe069e0930e4252e6d37a52867fb500a5c18125123933870f21cd4454e278ac8d901d838548a0a970a49b9a911cbd514d85a4b7299d3c6f1fc185f14b5089909e53f1ef42b00882f4ee17e00d145242b9bc9745bf9fd7cacde7b5ed180979a79bfa9b859bdf667b73689c7f0371dea6d551685cfa8f07f5604b740c7ebc9be76dd7cce9ca733f9db17e44e269abad16dfbf748a8de4c2d42be7fd8dd47cac47644bab8c5cb4f5f813dcb4e4d5e1655e1c14553e7f3fcdcbaa3e1aa565c7a1854ffbaf35ce3e85efd256441a197a1a9d2e12838b72967942cc59117ace54fe1b0fd337333b8a9fca6c7ca83ecaec9f0f27e3c132bda32de98dc55b7a475bd37bf148e596884dcf2ea45ecc6e9e8ec78ff219f3fc18fab7e573178ea86fd51fa96fb9264cd4ee78dfad49b5c3877837d615fa385f9ee7f12d9fc10bb0f8a59ff53161d547701a0f79d9f8eb8ee4542be4c4cdd490536e454e3d27e71fe5202bb1deabb301d897d777af71db0f91389577af0e0693afd96b289c4ec7d93591932f13dac5f182d02ee6cb848ec49cd012bc7fc867e2b1410a8ccf7e08375c3ecdc7192e08e1fce616ec3e3c3a3e39f9090734a493a91ebfc2e7c426dd2db15dbc05b1790207ed49a113178bdeb7f65a457074767c7e5741f7597135f1ff511162f45e4cde9e1dbf4fa761779ce1f1256e68a07c60c2c8cfe9ac85b9244130e5b2c5fcdf5dde5809fddf85d6e3c89a531fa4384d8c57febf315a67ee571db0bddf179e821f1e5e4c3e17398432e6b85f6801e3473de57992bace5de215777999348f2791e13d45f741cf246dbad78b939564af077ffa0fb2bd9e32c94b277a3dabfdeeac4d686bd6252f94ebf50437c99ac3e8092192a5b5f16e3d42217932ef932a79304fc67e0bc2c60b39271360ec4969da3a6e0280d14ddd6e5b3a9d901da5b3be7f4d82b5120df0e9f6e46860d496d1c0e82e1ac0e31e44030fe76108b04f0f01c2ac86807f05180001958cfe0d0a656e6473747265616d0d656e646f626a0d3830382030206f626a0d3c3c2f46696c7465722f466c6174654465636f64652f4c656e67746820313035363e3e73747265616d0d0a4889ac575b8fda46147e47e23f9c475c95f1dc3c6357512496cb365522ed06a23e447970c18025c0d478d3e6dff79c016fb80d751bb49277187f73ae73be731cf6ca2a9fa7d30adebc097b55954e97d90c3e879362fb259c7cdb66e153bac8376995179b70fcf247455bbf66e92c2bdfbe8587411ffe6cb7a288290956589680d492690d0987326bb77eff0936edd6c3a4dd0a47022c8b60326fb70470fc132045cc620d565ba66398ac11f538b6b0d8b55b1c16f4786cb73e7720f80293dfdaad218a796eb77e40a1e1cc18b02a61423b7db7d5c8c4326b6a3d266271dc4c8fe28ae16e92b0c85ce81905aa93055dd599d1c3adca20eaa4b458013d0781e0fb17db40ef5f94d51dad8b14933eebd64182aa7567435a2bc05541abb9336c88a64febad4dbd58e753dc87de7c5ebb9197bbfb99ab95c11d8fb93fdf534fcc22ed5374ffdb1127a4ee5c0f85d85d8c177a4cebfc57f9f7b0e30302b3dfa72438387ca4aced5eaf548abfcae932e8cabb9a1e63a95e371dba9c7129113f452f7ac38f77cc0cdf1fbc1eb1ffed9ef465c66aa2891b755b972da6c07456980be817b8b95ee7bb3a09c897b88479d0a5bc21166835760584af97b8a0ed158a885cfdd349dacdb7bb1f4adaa5575a7326a5cfadfb87cfa09ecb34cd8bd2f9352ae8666614b97ce16234ae5e66f83fdbdf67bceb3b7a09a33eaec777b42e512cd13ef3ae3419a308f85d51629a5dd7c8248c9b8644e2131247144afeaf2260f8a10fa1a78b3f145555acfd8d7c5414d5712327a55c01b657eca81a6bdd481054d6475e1f60b741e455ed49c209185926a4f3e42204cfaf4251b78e681638884d28e697aa6f618e3547c6326500c70bd140b3d424e920557216dd7648d97a88f0e6d45c6614271e75e5d0b17821454320c5b4113051cd8052260d81580e98ce0648c54553a4b24d915635446aee46bd23a42496e1f410c8dbc6774e4acaffd1b9ae17a9b172bd0aacef183a8bc4d5c405e538e01509586a5449d86543ef199c89e393330e3f792106760344becbdd68e1396f24135eebb0643456ddeb008ee3a4381bc04564a8d790349cb9b5041268ea497f4a93febb75bac8541c291814f07c2032089f88c23ef4df0d8087efd3cd023ad9a6fb691c1c48aa2ead3de15c9497c1e620e22b365f48177ee998f76ba263c56c5df0e3c076fe0aba42602077f0587c0de24e566ed6d9a682e1dfd36cb5ca36d30cc634bf2d8b555aee9639f5ffedeed6e58f4f95dcb45ffaec3f351a5b51d2489eba198ff84a3c224e2dcb497e5a0ed0577494ee14f9eaf553d2b7973c397cd32cfd9fd3a45c5f6a203a6a1641646353cbebd1874e3acb02f7d1e33e89be6191ef07eef2171ffd225dd9f8549297aaad65d234c43a5a6f04dd13fb11d44deb071a915cf878506297b727e61ca8c44787324ace7c3dd3744e88d78b59c68688e252ef190f5de30d734825fc23c0003cd966210d0a656e6473747265616d0d656e646f626a0d3830392030206f626a0d3c3c2f46696c7465722f466c6174654465636f64652f4c656e677468203232343e3e73747265616d0d0a789c5d904d6ac4300c85f73e8596d3c5604f175d85409961208bfed0b407706c25636864a3388bdcbeb21ba650810df27b9f78963e77978e4206fdced1f598610ce41997b8b24318700aa44e067c7079efeaed669b9416b8df968c734763544d03fa43c425f30687671f077c50fa8d3d72a0090e5fe75efa7e4de91b67a40c46b52d781c65d08b4daf7646d0153b765ef490b7a3307f8ecf2d213cd6fef41bc6458f4bb20ed9d284aa31522d3457a95621f97ffa4e0da3bb592eeecb53719baba9eefdbd70e57bf7506e65963c75073548891008ef6b4a3115aa9c1f16cf6f580d0a656e6473747265616d0d656e646f626a0d3831302030206f626a0d3c3c2f46696c7465722f466c6174654465636f64652f4c656e677468203937393e3e73747265616d0d0a4889ac574d6fda4010bd23f11fe66857cab2bbdeb5d755944321895ab56a2ba87aa87aa089014b60121bdae6df77d61fc436bbb6917a0849ec99371f3bf3dec2800185743d1e711e12063e958483e08472601e519046e3d1eacd7804b79fa600932f707d3df9347d3f83e0e606decda6f06e311e4deed09ac362351e69388aa04ae66801510216bbf18802c6f8e14cf7aee71c9343ea5e49e7c565cc79ebfe84c587f1e8766108a26a412a64e6499d5d0dfb87035d20a1114411212e0061d484120484fb97a030134ae8357bd507c20d20d5f1d54016c724cee265279467820a18611d0d7e1e8fbe9ab084012b1f03190a422f4192938fcb640d4e945c7d9bbb56584509af603f3f45498c3efb15b8579e73d844305d6e5de16ceb03d66c7bd806018b69d1dc8629c321548453266d3e0a7d941ddf56bb3fac76dfd7f35bc0ce8fbfb0d05d9c65f13ec1f2b9338b70cd968fdb3889dae54fee587b5739a31aac81696d05b242d0636ba083b283752fa608c61dd0415b285b07035b07f3d2a9268f33a692d223d4bf20881a764c82e2e770d48aaa0a104dcb050c1748c58c0a227c4dcb584183979f0b3bead92cbfbf81046d6ba178c5676171f6b91f1251c04d011a9e15873d776757c43ccdc359dfabc041fe62a75facf5c77d3ed20f9bbddede659a6de2a75ae74c6de3fcff64c444407c654b099a597c7ded3dc341957e1995732d099dadf74cb3330ca748de33258f241b6a675fff7a95dc6b4a67fe4d23f5e1a14eab483d129e6377f484334eaa71f484e8ed89b0f464004e939e027de6f911aa7aa6f33f71869c98c1fdfe77e4fa4e8ac395eca2e400f8f4f6af2b9d87480bc776eb0698c443045ff0d966a6d914e6fa350ee4527b651b6d1723c653a6ff8215bedde38f7e59fc936aaf285e27901d8ef8e031d2d10e59ab5d979727b92c0eb95d9ee5201a2d966557396344a932282ea1a294f52ebd7f62a61329691871da32ae13b3b192c5d430074193960ac79297ce43345c559b053aa3f6121313c326bd5aa5221aee92ecae30ecd9fe0e9ce6f5a5d877262ae11ab493f414418f5b77aa1eed58ca3e20d3560ecdb59104336ba250221f8ae27471219855146da6868a7963fc44a888e2c364d1f35ae3d71db577fc28abeecc7511fabc5a4569f408bf5e7a34d113ff291d865718c16df90c3940e36dfe75e0cbc4b408c9204f8c0517291ea5245443156f40b496e8b5e1db359f176cbcc21b53301f44ab40a15437db3735b7842fd5a473da8d37e58140a6fdc61961f53c17f82d6c8efafa27d6ba896a291db8779583129c263b14c6527f0f9b747f5c6f00adf417377c7217e5b2996a815d6e6dbad99121fc13600032ae68ce0d0a656e6473747265616d0d656e646f626a0d3831312030206f626a0d3c3c2f46696c7465722f466c6174654465636f64652f4c656e677468203939343e3e73747265616d0d0a4889ac575d6f9b48147db7e4ff701fa15a4fe68b6190a23cd469aa565b6d5671d4876a1f883db6691d4880b4da7fbf7700c7800193ad9548413077ceb977cedc7b124f27ef17d309038a3f0c24934480471961b0789c4e286ca6936fce3c7167dc797c8c5ced64993bf39cc8554e12c3da154e92da8f70e77ace728b0b925d9866dbe8c9954e06ee3fb0f83c9d7c408cbfa793e7e984338e08524be273105212ae80fb847148cd74f2f51dc44d469cf9442a0cd084ea3aa77592c20d627b8e893631dce5f8f4b232b13b134eee06887d33bffb6d782128d1ba03be9519fec2872f73808b5bb8bcbcf832ff740d425f5dc1fbeb39e6c0ca4d0a544aa4a694d560d7efbaa2832a9a5940ede189489f111f1895b6224c10da0a7f2ed751d1b7b2ccaf8e22698512202d59c505c2f2ec006844b22af27998dda1a61737b829b5ef17eb4385f7c082047c4481118de98078aac2e39c78c319f28b3fc378038e8967f777ee81f4e96dea42608124812a798e1142a535ba07b05a3b4154f4101db14fd78d19cbb4c141be8ace6e96be2a4ff0c3d98aa057761dcb3a12f59a9af334f1e55e74dc56b95f74aa2dba5ec4938a53940445798a0bc6e0a3add15f0fdfcd328f7eba8c3b266b16ec988d7f06364c32fbaa9bce9823d327f45d70427d730fd5a34910f847bc4417af4af0c84bcb9a8c2e29bd5657edbe3a1aec55a514e579bc7b3be3e37483b1e9769c403b3739743fead7782fed6a62f44adba30377786893ae0b6c15a1ea04170998387cd8d9990799d9e18435cb62de9915e0240ef1c3d3d32eb293388cf36200e709e0df977865d23cc4e9fcc3d80008eddbdbed3544b17d4a30243690ac011ff2adb1bb318a335d38bfa2ac7f8cbf299f66b56f5f1e76d112ee113d8e7e1a3bc8b3288ff0d2a19bf8a3c623ff65d915fe02b9b8339bd50dda0fb332f835c5f870079f6c0259518b28c78f2fb9c9c0c615192dca326d639bea2ed9fc5b542b5e9d272f215b8df6c9a686504bc84db844a86d14238b0d58c8d4d87331615af825cb2e8a8b9c0fc4c96fd112d8df84eca035a29978ac65590ac4bd636937fe46243fb62b2c285a7ae508b8a5d337388e96fa5edf1513cde951461ea6871ee028dbfdba87e1c809c259d5b2475b9612af341b83497a27ba5c6ba336ed76a3b34cd5db5c4b8950d98d41aeea846f69efd447767f9fc6926d90f0bb8d0bc77ad54c291db4b49e6e4a8baab166d80b9aca4249f7218fd416d57b3f5cf703f7b1b526cc3169d52b8787a5a267a3c524febbd2cbebd4d456ac51598145557a5c69153f736945e09d765ac7349a6d4768da6c3b03a655c97367a0b96dce6f4ea1e9bb85f2c7ca5ba97367a082ff2523bf9981278765f49f00030009bd70490d0a656e6473747265616d0d656e646f626a0d3831322030206f626a0d3c3c2f46696c7465722f466c6174654465636f64652f4c656e677468203639313e3e73747265616d0d0a4889b4974b6f9b401485f748fc87bb84481ecf9b1929f2c27954a91a294d88ba88baa00e762ca5b8c54ea5fcfbce60dcf8018549c6b28463f05cbe7bcf991c0cc31b383d1d5e9f5d9d8354a3118ccfcfe07718288108664095460910cc119740184698429987c1b71328c2609c86c1f0929aebf67c3a0d0302d8bc08688c38072624d290feb4e767f6f0290c1e2288bf43fa390c2ecceaaf610017d76700db18bac6a88b7082120a9ad923a148cb8a607ad2b034c1be3be00c2975d0c265fe9897d9335cc5222a96e6b09aaf5e56f972afb5ba065586a0e6679bfb37f313dffc6681a607fc8b29a4f9e4c9d22f9e17b18e66f14044af1dc224d41b1d11ca8ea305afcb2109db75081148aa9e13e6be274c9277783c11bb1d60dadfe3d27707665d83c7d33c9b3ccd8b19c42ccaac5362193d361a7c7dfb7ee34f3cc3534d9a1c749bc7031ad99d9967e5c474f054ef55bb51cdc7557dbd43257fff1089aa14dec2c516b78753f4f04b665488f262707f17bf01114322640d4429a2226903624d409a5b9b71ac90925b40a7189fcbd10e93cbcd36e52966665b1c54ef6c57e1beedb68c7faf3fa6857d7321209e098cf29a3b1150cf045223ad9c08986702fb20e0a602ff20c17f5d5fc53a75777d47b76bd31f14ef6e56781eb78d5537c1a567029b8a6e82274715dc66dcd104df2fdeddacf23bee2a567a087ef72b2bde20da92859a27904dd231cebba760c4e6eb28f90761cf97b3cd5fb75528df173674e77f4cfee6e572be7a354f14b098c63c82b109e76c190fcc95e78ed9e9b68470c5661823c677b19b66f7aed20c9183ca30b04b8cbce9e4211af65048b745913b8f4292ba296414298d223c3a102a2fedb78a2e9dda52cc195e2548a8e3e8a41b2de02e545b5eba0309fbc0f491ad7459ce7f2c8c4a2f954ab32e95da72d6959ceb2a738ea112b73f2ddea5d25f010600816f661a0d0a656e6473747265616d0d656e646f626a0d3831332030206f626a0d3c3c2f46696c7465722f466c6174654465636f64652f4c656e677468203737373e3e73747265616d0d0a4889b457db6adb40107d17e81fe6510a78bdf75d41c8432e0d2949696b8742431f84ab3801576e7d49c9efe64b3abbb6dc4a762dc7de6030ba8c76cfce397b6616babd9f7909c7c7dd9bb3ab73c854f73a2f87901465e7b6979e9cc0e9f919fc8a23ce3811c06d460c082909d7c0042594c3a488a32f4750c6d1693f8e1850fc319059e66224b524b3d0ff11478be7936175f5f9328eee92db32edf0e431d5c9533199faebd933de41fa0dfaefe3e802c7fcf4efc79c1922ddc086300b96136b8112b3c0717f144702a7d4bc0a3038bf6e04648ad8d50878c3783d6085dd074841b246c01ef958c27673239effe7637c0fa94c2e8bb270b978caeb69808b9b3380eec7bf7ce9407c712d88b6757c4307a841c45e436b22e5dad0d071df287c32b84bbab071a1756d9a506b35cc2169e562a9cda75424a8cda52ec7f7c80f5ce773bc99e669472465aa12a4ab85281b08bc30c249f12d881206895ad7c0eb89ca42add5f21d58427acac7857b88a4ced27c504c5aa9619486323d4c205d577a086e241a59006a1865a1d66a2511bbd0536da20c3791bb741b099023e77435bc2b8b9484a1fb6ac21bb6bbdab73e0097424cd3dabd60fc6bfc472aeabe5e41f6014ab9c585f2752c4499dc92860fdecfe76815838797198ab318b5ca9207f3764e94ac630ce6ed0ae39b23ef214b11ccdb29712268e3a3e6ed5e9687db2795c4caf6a96b16d54345ccc8e1734bbad3dc018a04f643ad7ac76d45a9c4a2ef0470998f4645d9aa7619ac40a2daed9ba85d1854fbfa46da43eea1da6c61a9eb657795fb7a9bbd50e1d7f9c4bd1b3cb4b214aadf94d814aa3721496adfbd07202954bf298d24c6bed293b04c62c9dc5e292d234c82c442669b9572e9823e6073a55c0ac747584574b35856a07d80926bc7a8038a2532b4f550783d1fe6e5b8558ba15a6aae28c9eaa836697185deba63a110ee5053cbc80688a13ae16a6ea5b777961b85cc42f5b7150a2c015b85dcfbfd3845114fe15df1ddb53abec0e658e94670857a2e7da73e4381eb643e2b004317c7de7e31706f1edc816a3c1ae393e1f3de86007f041800aa2a6d9b0d0a656e6473747265616d0d656e646f626a0d3831342030206f626a0d3c3c2f46696c7465722f466c6174654465636f64652f4c656e67746820313037333e3e73747265616d0d0a4889ac575b6f9b4a107eb7e4ff308f50291bf6c265a5280f8d93d6552aa5c73eadd4933ea0806d240c2ec66d737efd99e562830d6b4e6b59b231ecce7c33dfb733c38882851f0adc738810c0052752c07c3d1e95f7b3657df5d7bbf1e81fe3d13785b1db9a57dcf04ddb4892109e8dfba707d3331e9f4df31bcc3f8c47f7f3f1e8d37804f71fef00ae9fe0e6e6fae3dd740294d2eb473f59821126577fcfccdb5b783bb983efe311a38c70609e242e6210843940b9452c0659381e7d7903c978f416add670852388c7da70970a1fb42130ea12e1e03a46a800265cc21db0885bda5dbcd9839c6dfca481935d0867ed1fd7484f93d6d9cf686b72630b0f6180090e33f38a15098e616a3a4652243c8f72bcdee521e0d27401b8701ebea8272b45451aa77867f90af8e7eb2e8bf0896dac00994186e6eff1d9d7010cf14b312464c15033721d434c12ea01e3ac66c8b2f831494d9ce2c20ce18f743438bb75625f188525f4c7ef5de62bbe03a478e7a310a68af8521ca634a27c97e38d10d2052aa47c988759e22b35e5519af8b1928e9fa0160298a8a53fc238ddac43a5b15c096aa60cec822844a3c2c0b33d45bbefefa7135c31403dce85f2615389eb5be9d089c7e2ea78738b124f28f150295d9d78dccbd2c624d58bbc038257792d4d299e1945f85ee5dd22c2b32cda74df138bdc1b421b9e4d1095eb10c7038ad9132a801303dfcb8578c0fa9696a1b61c31ab72242dd529aa9d92ab62dae1a3bd971e72ac857848f1f5039a2d629f2f0e09af7d7b446ad2fde91027c56cda4eed8f31629f89b2aff20f30d454069542d59302a9aeac34a02af1597b0f4a7ee7b0ea6af5394b5d321e0ab68d429c28b9a498bb0d8ab9ec9560d7baae68edb6fe9c427995fe9802aed19f73acbf7ea767c5e7d8ea98aa2c15478e4251993ffb3196cf2888b07ee6e6956bbc9e2b01ccbd04288c4dddea41358840ef8ce44b582879666359448d60ad3b86c6bba055674041630d59dd58d6c4b96d01fb5fdef6b2c5b22f4fcd9f2fbe4c0e8eb88387e3f06c36a0f81f9a4b69bbea2efd72e796be47f59be93ad998a376239daf42d8a2605f566a7848636cef7eb6c5ef55b481680b69121783e40f94350e16012cf04f5a8ca5c5e52e8e418d0ad13a8427fc5d4d8a47db5ccd0e68660bf8152530431f3fa3fcdf308b71ecb08d80a82963aab62a37e6b10a7e2bba1306923457830e8247e4e86a9166b08e7e21a43040b8bc86bbc95454cbac7e9d596f71e2417c1bf59693e5fb0823dc728805ff94037a1512f849001bd32d4c9cecba4c885c1e95661fdd08642b0b147878491529499ee1cdd76793fca1577c1b945d5e87d4135e37fb7aa0297dd613cd712768ef65a7d30c134589af4685d34adf68253d4bbb8e176f779372e7b06ec2c571e1d6fa3ddb50b0827bba02d231ce940ecb29441b66df0bca00435db50ea16a07f28e71a6f4500d215aacba97877396bacecc1e2cfc27c000d305824d0d0a656e6473747265616d0d656e646f626a0d3831352030206f626a0d3c3c2f46696c7465722f466c6174654465636f64652f4c656e677468203430393e3e73747265616d0d0a789c85534d6f83300cbdf32b72ec0e154920502484d49656e2b00faddb0fa0e0764823a0941ef8f70b366bbb566b234164fbf9e5398edd659666baea98fb669a62031ddb55ba3470688ea600b6857da51dc9595915dd68e1bfa8f3d6716df2a63f7450677ad73871ccdc771b3c74a6679379d96ce1c9715f4d09a6d27b36f95c6eacbd39b6ed37d4a03bc69d246125ec2cd173debee4353017d3a65969e355d74f6dce19f1d1b7c024da82c4144d0987362fc0e47a0f4ecced4a58bcb62b71409757f1316bbb2bbe728368cfa239971cd1a35ffda2cea40b84f125a167c9e014022d119173454e828814372f42a7f40912e0e60b728e79737206a3827f844ae2f5a34ba1e246a8c7e95c92e6a7f7493daa5ef107a48a4849a992f7497d2a361097a4f286d4a7cb502421f0f04e149da466b8850f4e5224280cefcb5774758a5a12467f48a36bd280dab2a2268554cc2a456b31689643c71d82d898f02559285d84f40cd62bb438e6098e4205e5097a22428d1621d5e2b288e1e50e03761a8be2688c9d089c421c8561082a0da7416d9b76c81abe1f2c9514e30d0a656e6473747265616d0d656e646f626a0d3831362030206f626a0d3c3c2f46696c7465722f466c6174654465636f64652f4c656e677468203931383e3e73747265616d0d0a4889ac57516f9b30107e8f94ffe047a8146263638c54555a9baedbb44a9b9a690feb1e58432852421220d2faef770692c6603059ab54a401fbeebbf3ddf71d238ce2f1e89785ecdf68fe653cba9d8f47dfcb3f747b7f83d0f41bbabc9cdedf7c9e2142fdab2b743dbb410461f864b051780e4124100e178860e6308e5cee6086b2683c5a5ed45676d5424c3b97febc40292c56bc89da5b801dc6904b88e3a3803abe0bcf1cecaa2ed4ad41bd75674058b9bd8698a71fc12c9666e7cbf1a80a901c5d532780076bf92096973b99b27998c591cdac02dd659bbdcdadad9ac3362e86df0917f1a823ba700d394a46a65fc3344656944e7e3cd8afb088081c8f1f80b9aee37a7e098c8a1632aa43163027e02534c14b6855815d623ce3570ab0b3bc1decbb18626e9b6f06ad89d81d1cb1fe249a11622cbf0c10c0be4b5ce758f894319d7d1529ed403ac492922be2976525cb449c22fd94c4cff6845aab179b5a68b7b77d2b5c25cb245a20a8e7ed062e7911677249687bd6620f37c22242b03a2ff68b282de06e8e1e2db891a48db8ff0328c3655bb7816e37791e49af79b249c127da2c010a92ee9f2330b6b327aeb54f325822b1bf15c72161ada35d4471164532e847db9e008225fc9f6dd6327de16a85e057f854a66b01f8a2359041f28420a1ab45eebc1916e5beb9dcf445cfeaea91ec29c4c127b09ac098e8a85addee1d09ffc8f570950c5c31160402a0bab8be63a9aee4b9c2f5f5ce9aecdb3ed4bd7e93547bfd9ac89e085f66ca9ce813eaa81c02757886308581837a0c692848420dd830a8b2e6f0d1832c3a13d6a087854c96344d3518ac82c2c31d2387efc2347038e2f638705285fa959a883da21661b971d8c0e1b9cd1aecf36a2c419fe9747db6cfc242f2a041e93cfa3e6008258ed789c6dc15a5d74a4ffbf3ce0c5dd163c8388848f4670c220657ea14d2b26de8bf4331d694df9f14af7f08e833a4eb3e79880aab51f402aa1585a5cae7484a56f837918ab65f4b65e720f5d5c3224963981090547acf7a88b68594dbf51f39fb66a0871df236142193caa60138881e7843df4aa707793376addf96372f3819c8fb89a563a9ee30d557997ae7406a69bdcbf4fa35720b2790edb3d4adf25789525f941c1bfab8c7904edd24d233ba0b1f3dd49ad48bb5ebfd6788255d7f0d05aba270f5eac6c52b5fc3b105a2ab065b0bbb03a66a09323e7cc2e2ac51827a7c030b9089c37c752a271fd69b7d0a2c53a0306d4ef2f5464ad5aee99b5cb99c5cff093000b9e965aa0d0a656e6473747265616d0d656e646f626a0d3831372030206f626a0d3c3c2f46696c7465722f466c6174654465636f64652f4c656e677468203936353e3e73747265616d0d0a4889b4575b6f9b4a107e47e23fec2344f266ef401521258e7d4eab46ea515c9d87a60f9c1a27480ef860dc36ffbe330bb40d60d50e8e2c5bbbc3ceccf7ed5c3c90abeb29f9df75424d3931210d08678a2a432246a39094a9ebfc7b4672d7b95ab8cef95cc063ca0459ac5c8713061f8e2795225c6a1a91c523caeff1e72fd7f9e425cb655665459eac7de511ff3359bc739d1998fac7751a3dc1a801779206605ca27174ba3a731d32bb991272fe815c5c9cdf4cdf5e136e4c1c939321168286611ff21ab1163e17de377fc2032ff1b5977f4941b87d4e60005f70127c5cc16d84fb0076ae71184878fe3ec9ef8997e6938fb7fe2f543c8ca836352e302f74b007971cc215291a198017d250585c0c717dba60ecdac4cf501deeaa352e988404ead9eed21de01a1dc8b50981388a2ba475a88ee6bac755876bd7f69fb906ec35b962be1d1fd7c3b8766d1fc0958fe3da65c7221a1d8940bce26d47e6d512ab6bfa00a6f2a4771d028a2301a8930208d8d1b1d67b00082ea8acfd4ba57e02e8855a0d845af0003b3f36b5a8136b1930a6aee01b32d830a64dac40ac0c8ae38984b516b09ec706c50ab6da9eb25b549cc256d6caf631ab3574186b54e6f00d50a3b11f58fb78a2d56032b66e5ac546c31a9fc37a6a35ac72eba316a106e26e35c0506b5b453fb71c14aec03b07a01c54b88c27a231284d0df2b2e1617e0115511c5cd46cad4b8e97529f4663bc57228705a80d89969cb281901c9021e6b80cd95ba34d52e0c0647e4730fb0e9346fab8c1818914abfec4f4025f41488d18f0553da4c4975eb5cb2a708a0ed15f9a6efd09b8bdf3d2ef7ee8c1d03391dea622f06855940444b30f707cfefecea763a129110c43fb732082d30602dacaf3549803d7bc00d2f9e8fbd71c53b1ef6232deb2a6520d589e41943e123bb42e81c5680a928594bd0a05c9793b877728cc17973ee71eb92f93bc4aede84d8a1ce7f2a737bef1c80da46e922f134ccfaa289f08b0bdfd966d41bc257fa7c9ba82a30fe3aba74990dee490e55027c2db81db32c1550eabba5ac806ee3fc900e592fcf784358c0506d5369fde8eae1929eb58bc6094d9f742f0b22b8109e379d15e6208d6bbc70dd9ee1ea19770e61525de0c49b212f6dabe4695a915e1b679ea47de2972540baa551fd5f814d5ba9ea73a9d1a62bcb3040aa0b2491348bcdc662bcaaa141e6327856c286089c9b17e8223d057376581f2af196c9798d84b28d5c0abf0fa6c4f3e4dcaf606b0149a41b1c246de74feed1748d187629d94db870cc49b3b1fb18f4f510145fd9201306a7252405780b75eeb90511c33f86f7fe8abb356f987000300301e65520d0a656e6473747265616d0d656e646f626a0d3831382030206f626a0d3c3c2f46696c7465722f466c6174654465636f64652f4c656e6774682031333138342f4c656e677468312032383430303e3e73747265616d0d0a789ce47c09785355daff7beecdd67d5f202cb70d2d4b97a42ddda0404b5bb6b297a54590a6c96d139b2631495beac2002260c181195107661454544091b0a8c0a828e3823a6ee332222a2eb88c631dfc06655cda7cef39f7a64d29c50233df7f9ee77f2fe777ce3de73def79d7734fd2162000108da000a1ac72eae4096ffd251aa0f27700daaae9f32aa72878ee5300a507a93e9f55a9cfce7af5f4f50064273e2f585036a3aaf1e5a60500aac548f391a9d1e8ac59acbe1a206907d22c32357b8447f4bb76018c3a88e363ea9cf58dcf9e1deb05d0e174c5d27aa3dba9d14130aeb71a3b62eb6dad75fa7af22680fe0c809ab3981b97c576de701820b40820ce62118de613e4852f91773ad2e7d18ee898609c4bccf83cccd2e85956324e711480c347de6373988c199bd2da91f42cd23cdf685ce6e4758a9fb1bd0e0904bbb1519c5fbdf45580822700063ee874b83dbeb180bc2a293fc1e9129db35e18be1460780df29b07d4564a80dd2f6f4c581a51f49d46ab017addbfe7b64e5a3f33f16f1680ced9c1a7d459f818cae8e985b53aab733640c80600df6bc1a7ba46fcd7bbace71358021a0847f13988043d14e2d4af154b710c6ff510b20957d7285e55a0c47cbcbf06332f8452b1fab866540a02149f11ce9c51a5911d90a5ce22de155da30a00f6a0929f35e3615ad008d8dc27bbffb24bf329ecf9bf5a4bfd9bffbbb5fe5b2e75d2ff7f3a5fe9456df60b76fb84104ce9f377818b5c1721bd042effe6c9bd98f5e24695a4aa86c2bf343edcdbd4be4e08020d623004f93a200482b11d0a21d80e8350c470861110861809e1885110e1fb19a221123106a21063211a310e6210e321d6f71324401c6222c301108f38101210b590e8fb1106c100c4c130107108681187c220df0f20c060c42486c93004510743118781e0fb17a44012622a24230e071de20818863812527ce76014c33448454c87e188193002311346fabec7bd7b14a201d210b3201d311b327cdf410ec3d19089980b7ac43c3020e64396ef2c1440366221e4208e81d188632117b108f27cff84710cc7433ee20428402c8642dfff40098c419c0863114ba108b10cc62196c378dfb73089e164988038058a11a74209e23498e83b0315508a381dca1067c024c4990c6721fe0366c364c4393005712e4c45ac8469be6f601e5420ce87e9880b6006e24298895885d80ed5300b7111cc46bc0ae6202e86b9884ba0d2f7355c0df31097c27cc41a58806864580b0b7d7f071354219aa11a51844588757095ef2ba887c5881658826885ab11af81a5880d887f031bd420368211d10eb5880e30213ac1ecfb12ae0511d10575886ea847f4306c028bef0b68062b620b5c83b80c1a105bc1e6fb1cae8346c4ebc18e780338106f64b81c9cbecfe057702de20a7021ae0437e22af020de044dbed3b01a9a116f8616c4350cd7c232c475d0eafb146e81eb10dbe07ac4f57003e206b8d1f709dc0acb117f0dbf42dc082b103731fc0dacf47d0cbf855588b7c14d889be166c4db19de016b7c1fc19db016f177b00e710bc3ad700be2efa1cd770afe00eb11ef820d8877c3ad88dbe0d7be0f613b6c44bc073621decbf03ef80de20ef8adef03b81f6e437c0036233e08b723ee843b1077c19dbef76137fc0ef121860fc316c43df007c447104fc25eb80bd10b7723ee836d88fb61bbef3d3800f7201e847b111f85fb101f831d888fc3fdbe137088e1617800f1083c88f847d889f804ecf2bd0b4fc26ec4a7e021c4a3f030e2d3b0c7f75778061e413cc6f04fb017f159f0223e07fb7cefc0f3b01ff1053880781c0e22be088f22be048ff9de869719fe191e477c050e21be0a87115f8323beb7e075f823e21bf004e25fe049c437e129df9bf0161c457c9be13bf034224a81f82e1cf3fd054ec09f10df8367114fc2f388ef33fc005ef0bd011fc271c4530c3f8217113f8697103f81977dafc3a7f067c4d3f00ae267f02ae2e7f09aef35f8025e47fc12de40fc1bc3afe02f887f87377dafc2d7f016623bbc8df80dbc83f80ff82be21978d7f70a7c0b2710ff07de43fc27c3b37012f13b78dff767f81e3e403c071f22fe0b4e21fe001ff95e861fe163c49fe013c49fe153c40e869d70daf712f8e03344c01d17e07448980ab7f690b0febf2842fb1e0abef4d7cebf69722f6681dc42c355f8e20a0deffff48b9823e4b265bad2c9bd9805720b8b50a305c322fa3ffd22e6b8888b7ff9baa2c9bd9805728b88c24845ecfff48b905e4234f4be2e215dfac12c905b64b4062d1819ddffe91721bd8468e87d5d91817a310be416151384168c8ee9fff48b90465eae48f4ba2203f56216c82d263e182d181bdfffe9717d0f5d4234f4be2e215dfac12c905b5c62089a3f3eb1ffd313fa1e8abd6c99e0a2f17119cc02b9256a43d1fc03b4fd9f7e11d28ba8ffcbd745e2e332980572d30ec548854143fb3f7d48df43032f5b26908e24ffb62b3190dbe0a408fcb83924a9ffd385be872e211a7a5f5764a05ecc02b909299168c1a494fe4f1fd6f7d0455cfccbd7e02b99dc8b5920b7a4d4281800c9a9fd9f7e11735c42c4f7befe733aa68c8a8141903aaaffd347f63da4bb6c99f0ba8474e907b3406ea30c7198616986fe4fd7f73d34e27245a2d725a44b3f980572cbcc4d40f3eb73fb3f3da7efa1f4cb96092e1a1f97c12c905b76e1004885d185fd9f5ed0f7d0455cfccb57c6954ceec52c905bde782d5ab0607cffa717f53d741117fff265b892c9bd9805721b3371308658d1c4fe4f2fee7b28ff322562d7e82b99dc8b5920b7d219c9900de533fa3f7d5adf43132e5b26b8687c5c06b3406e150b5231c3662ce8fff4cabe87265fb64c78955ec9e45ecc02b9552e1d05e361c1d2fe4f5fdcf7d0accb96092e1a1f97c12c90db626b2694c3526bffa7d7f53db4f0b265c26bee954ceec52c909bd9950d1550efeaff7447df4397100dbdafea2b99dc8bd979dc38f90775b1c0d38ae0919da820f0170c7aff288f3e2bfafebd805e97e1c2dd153d9ed6f59fdfbfff7afb9df37b14ec15120a1ab490e24cf2991967cc675c67cef87c006792e4a77ff87c119fe2fd45647cc4e7e75ba938bf207f744e7696419f99919e366ae488e1a929c374c949c2d021830769070e484c888f8b8d898e8a8c080f0b0d090ed2a8554a05cf11482fd74daa11bca9355e45aa6eca940cfaac33628731a0a3c62b60d7a49e345ea18691093d298b91b2ee3cca6289b2b88b92440a455094912e94eb04ef2b653ae1105934a70adbb796e9aa056f3b6bcf606d452a7b08c387a4249c2194275aca042fa911cabd939a2d6de53565c86f5f4870a9ae540cce48877dc121d80cc1967792ceb98f4c1a4f58839b543e661f079a3094ca3b4d5756ee9daa2ba32278f99472a3d93b7b4e5579993629a93a23dd4b4a4dba5a2fe8267a23d2180994b265bcaa52af9a2d2358a93ab05ed897fe74db864391505b93166ad6998d8babbcbcb19aae1195e69dac2bf34ebeee746246fa21f2c0bc2a6f50e92102f3aa0ec334df8a7d5357949555d3d5a24babd632f204244fb8eeb4966f2b4fb40af4b1ad6dade0dd3ea72a70348962753532cd48af985b958452ebca3708548db9554c03644a12f52824eda36a4a0a8bba72da53738de00dd24dd459daaea941670d6cf3c2dcd6a4fd03a7151ff67d04d3ca85b67955ba24ef04adaeda5836685f2cb4cd6d3d30b55898da7324237d5f649464e97de1117223342cb021768db11623a72d94da6f6a4225d24dc510f10a260125a9d279b994020a6201b4990a900caf6a8216b5a2fd6ada22c750472853227542db778081a06bffba678f51ee51a5447e07b449c3a52be470dcdff6a6a579478da291a22e45d7a264e3d9736e467ab3b742e78c14bc156832985d8593aac7e8d1e44949d4cbeb0f15432d3e7857cca9929e05a8d5ee87627d5ab597aba1234ffb47e2e6d39115fe91aee9353a0ce7832c91e3bc9ad4ae7f1191f131e596315e127f9161511ac7f42917f62994296db3ab528d6debb5a9356d1baad135933015dbda26e984496d356dc643be15b53a2152d7b6afa2a2cd595ee357e990efe9f55a6ff1866a0b41a37a73246b78634aab782d572db5382d5f9d01c5a13069128a121da5299e221ce2f2f64fc9c6ea26569187a5ea21a9da25553ba5ea41a9ba4faaee91aa6d523555aaa648d564a99a2855c552355eaa8aa4aa50aa5452a5902a5eaa48f12cacdfc77212cb7b58dec1f2272c8f617914cb5e2c7bb03c8c65279607b16cc3723796bbb06cc07213161396a58ce75e89f51ea9da2d550f48d5fd52b543aaee96aa32a92a91aa71525520556aa9524a152755505c8cf5092c6f63398ee5052ccf63790ecbe3580e623980e5112cdbb1fc164b2b16f394ecd8a0d8a0fc4d874873f154f5a67bd49b6e536fba55bdc9a1de64536faa536f12d59b16ab372d526faa566faa520fd3246b04cd10cd20cd404da2265e13ab89d6446ac235a19a608d46a3d228349c065f40de18be82aba89c482abc4f9ba0a256f07e5fa93b4482e72cf22a75138937ba022ae64d4cf416a479b9756c373b447cfb08f9f5cd5aba911d06427c37dfaa956b3c00c4a7f5be127b3c55cc6e7d0286927c5023e61c500f7d564d7b2bb17713ebdd447b37b1de44b27f36645718d7d70c860b30eebec845477b50965ba9bab3abf669606275e962a93ec08504a33e35daa4ea89f191cef14cb9b14989cbb54714f4174743309f43f1051186850e65946494d02105b0a170faee908712978f4dd21e213be5a148ec8e4253fee70f1a9778bdd1e74816de2652c5ade41661ebf7508bb8158b19cb16d80c9bb903120d7ea63781175bd3e00be571fc88e962fd3970036219fc0b0db786f514412d8ed722f573588fc73113d684f1d84c36b0fa46588dbcbfe50e70c7b8636c7402f29d4629a49b3ba03c8efd94df4df0087c489e469aebe1361c3b0c6fd059c87933ec81736404deebc967a49d9b8dbd84ae8f7c1a907a33cafb149c807f9258329eb4912790269a5bc96491565b8134cfe1fd06e342ef19c4461cc4456e419ea7399ecb45ae0e6e1db79df372c7f86ac578e57155b42a5f6d63bff3cae169370a35a4dc66e287cc5abcafede22addaf138ecc21f38885dc41b6a30ccf9176bccf7219dc04b43abd6fe76b14a18a2f950dca7bf13eae9aafbe4ba342de4a50c14010200546a356e5b8c61c94d90cd7c075ecbe1eef1bd096ab601b6c877b6017ec8323f00c5d134ec287700ead138137d52b9f1492857857e3ed22cbc96ab4c7fa80fb56f20772801c41f95e266f7343516be9b6a1f6929437715bb983dccbdc9fb953dc69ee2bee5b1ef8207e295fcbbbf9fbf9ddfc6bfc6b8a298aed8a7b14ef2bde5712a597592a5a15ab5aa25a8ff7067590ba41bd5afd1bf55deac782332101f54a47bda6e1273713b4a22637e0e1bd8d796d1fde07e151bc8fc357540fbc7db226f42e24656412998f77355984278046e226cbba34da411e203bc941d4e56dbcdf2527c9c7e4efe41b769fe3545c3c97d6a5df6cae925bc8357077705bb83f700f61441ee09ee0dee53e441d4f73dfa18e217c341fc70fe1cbf94978cfe3afe297f137f17bf863fc49be1dfd16aa18a718af98af5882ba3faf38adf8123dc92979658a325739066f8bd2ae5cae5cafbc1b23ba5dd9ae0a65568956c5a8c6aad6aab6a90ea84ea83ad471ea787532de99ea2c75a5daa66e56ef569f567fa17938a824c81ae40a4e87ddf8f9e7f1f3b2f751fabb3cdc12951e069293180dd7f2114825d0dce342d5b6202b77804aa7ae2423d0531fc0393e082a14cfc342fe2ab0296bf910f5d7b093b8152bc943fc247818ee57379327f81abe9dbf5f99a21a2bd993dbcaef56b7aa6bd45fa0a467f9db941675262951ae273bb90998d12e3207be27dfc1d5b8b2871b05cfc32db08e34e30b67b3e6611286b9f61c3794ac57decbef576ce7cb95cbc948f4a056799cbf1972210e3f1b8d80648c75257e76a41f0639fafbdefc0acc7e1e5f10bae208f55b44f116b90f3f4bf940e9e30f93cf00f49ded91ed30e11bc42c434e5452544a5254d20a1e3a5670d009cae33f16ac501ca7bf343ecd77527d56d98e9c4390ff40d0c158d8513c42a1d2048544c7260e4cd28570e1517163f9c204ed683e5b290c4b49cd50a541f6aa505268093fc4e5ee4f4be30e919b8bd3810b98a418921aa78f24a1c352468f55e581a01de119921115e9c9532678f41b871ce246efcfcb531c2602cada5ea8efe8682f8c6c2f64252a3a018b544b83d8d9ce7a130ad958426196218190f8182c0929a9c3495e4e769c9a60233e8e217ee4638f092979b9a35375c9ea9ed534324db9f4ebb81fefe21bef4c2144f7fb9fa2a24246107e5c92d09194c99744683b5431d1617c5168f84f118524bf2c2c7cf0e4a2b8f884c91342c3327252c84f8a84c99d3ffef43745c3ec47fe74a8f4e7898ad460eefa01e11d0521066e79d2c00e814445866bb9d634e1e74fa62c2e1a1c1aa22b4c8d8949ce1b1912329cda7d33806633fa3001df10636032cc83c5706f7178c1f85c523d3faf600c3f7374e27cb4eee395c00d183c5e597d88cb3fa0d5af998a27d06261e69a51a56b82b595c12b46c1c2018347e78e598846be6a3819969dc8cd09bf0acf92c5b1d931cbc297150f5b367ce39c49ea8a65c573b2f9bcc3240932f4ed098568527d7b3bfb27d99afd4b28d4c304e686c88eefdb291ddabf50f6875e9f6520eae1a9c387a7e68e468bd30fd66ab52a2e36213e81a72e48202afa1c979010af56e992912a9fda5f994ff0099d119f93cdec8f53089d87cf38ac4b4ec9a61817cb7b6fad886d7afdefad0bae5fb2584138576ccc64c5358307b6adfd6956415cfc028e576fddba7b81fd2132ce424ab7f26f5eefcc18fda3366be2c8d99bab736790999f598b8b57774e482562569681af5f9051947355fdefe6382b2bed1a7d427cc894d1c1219de7b86714f91d9393341aa1326840d6ba152b17962e6c78be64b42a6b71c7abd91a05240e75ce6d9b9633ffe7af374ecc1a31e2d586297fd7e38519bbc77752b305b36504a4412666ee68c847ef8d83bb8a33b42347a51b14fa68080dd70e4fcbcccace191d9292909b575038b648a52221f963c62985550929aba2a313f4345f86a84206eb0d942e2fbfa0704c486ec6c85169638bc6a9d2f990f020fe08998507c9ece290e11bc33307a77b3232c2730f73f32148cf5c87a5e3ec69e6362923503e69847a2d2aa1bb1f9d16a7888a055d32e446a6e4e6e54bcea3dec8a779134b9d331cdd12174ff263627278924094094aa24e8951f3fcf018de46ea3a5f7cff64e78ba42e7bda1ae34d87739f6e1d392e2822b371d2ed1f14de5bb5aa848b19f17d514e229932b2f34b52a1e97c8f542576eecd314c7b57ffa0c2b2eeb79ddbdeef7c89e461f75deb0686c6d5dfba2df37e419932bce88861dd03e1647a52e713a4acf3244919daf99e4aafedfc66e4c79d47a2c8a0ce1ba38887ee787b60b3ea34dbf186c2358f2aa2e3e215ea92607237269216310c2d45db619cb2380862f948156657f011520843c8d8fdcae8c892106c2792b110474464a2a4c899e8d683817e16b71e2c520a5023e2a6498d9865c8cf4d8a237149b94918ca90930d18ef49f898e78fe23daafc9fc777ac2787979101c78e9101cbc8a18ef5f71cbb79cd339b376fe626b56dbe7ecb5324baf39ba7b65cbfb9cdb277f5d1a3abf7326d40d5c4b40982b1c5c11a3c25ad82550a256ea3d38ac3542b14a80abf91dba80802fa115173af42cfb6c78ea84298c05a3467b30c29514931eaa8fca428b572c64fc788e93925ff9c4931eea763b5d8f8b1e339c9720db8d6126a1cb871bf46ad3ec45d571ca4e063150a3e4c7a4a5028f14919a654a915a1411a8e0f5da50a5ac5299f20d341c5e50347a61787f038a6e2376a82376a0e71ebf71326533bddaea9cdce769cc62da35d326121136e6d78669ae2c6c867b14e640d826f2142f05f2ebe8a72554d3fefeb58cbb576c690367ef6cf5e456887b7732fd78a3d7b3bdfed6c7a9eb43d0f3e5f97fc93e16d7532c0d3fe9f38a5caf727e4c9ffc44d05b98cfba3ff57371fff5f7b37f32b2f7c333fa690635ddfe86683ff3b7082999127b739502bbf94db3c68951fca6d45008d1242953fc86d1544a994725b0d2b54f1725b03b1aa3be476b0f2615c4d6a8740b66ab7dc0e233354efd36fe815f4f345a866246babe95ff36972593b08a9cc9a72b94d205ab34f6e73101e1b27b779c88b25725b1140a384c4d87cb9ad82e4d859725b4d20f65ab9ad811171fe767048956697dc0e0173dc16b91dc66d8deb60ed602a67e29dac1d42e54cbc9fb54303fa23a96c723b06dbd1898fb2766c008d96cd7d81b50707f40f6373ff4adb9af8eefe5079dd5d42b6c19027ccb09a5c0eb7a3ce23943a5c4e87cbe8b13aec994289cd26ccb5d65b3c6e61aee8165dcda239739e4514165aedf5662c6ea1ce61c7c116d1250a66d16dadb78b66a1b655a87059ddc21487ad51740b46bb5928b5185d366c4fb4d68b36478b60b50b5985850636868dac4c212c382c98b20e60e87059ebad76a3cdd6cafe50d42c4c6f3259cd4661aac96177a70b252e97a3056bcaa3d26374b9058f4330391a9d36b151b47b040f72936778c4651ec659a833365a911f8a4887ddc8d62fb7cb9d894ab285d20597e870d51bedd6ebe8035dc025da44a31b659024cf168cee00a375d9239db1f5585ca25f13a7cbd16c358b82514013343aec5647931b05e832965bf4088e3ac14a75c2559c2eb4b3dd83bc18275407e730ad1c7691f2435a27caea40bbb0ee268fe812dcad6e8fd828999a4e13251330ea7a97d169b19a90bc093d88f2e3843aa3497477d91c4d6dc4228950e77009b34bd3052aaac7e14a171ac4d65a87d165a65dc8013574194d0db5e89674aa925930bbaccdd86db6ba1b448f8712189d28b9d1ed961e9d2eb6663ada7e59ba207a4c99e9d47a2d220617d6ddcbd6596dd46a3633ea87fc1ca626a6042e6cb4da24ac752c13b1a3c56a3733df9b6c56a72c1dd5bdc58876a83552413285a976c168365b6924a70744acd56eb235a1f9e5855bac1e8b50eb4040bd246a341565d66d5df494b50e4d6837a13aee269385c9efb24a6e72386c92e52d086e1a3b46ba92506fa326908574d21eb7c9ea763ba872b522355fada3b116872da2a94190350b304ca3039d122894b5d1588f727709201ad1d792786c591ba60bba08a3a1b11665a2cc3c2e87cd51cfbc2f93897693d565b261e4d9d1bc2e23a3c328b48926ba0c8d1863238d30aa0c538b79cfe5a835b2f876da7005a4c6ecc06cc25c46524686ed26cc7a8b3fb0663bac521c4b3ccc2884f4885ad5b9c46b9b688ed635d9d9b2d42d0191da1da4686f071df37b92e6b8119d8619d54366a77f35d9099e0bec52a8ab0369ebd06646b67750c62694a7aec94617371b2551905d8b48773d26bad94a675061cd5697284b4b07dc9e561b557612866eb3d165153dad92ae8d4ea3c9433d54db64b3891ec91122daa641dead1c2ebacdb0d05e482d4345ec160edb12bfaecda15e74348a1e97d52448bea356b9b60905a7fe70d85aebd97e885b60bdb41a130e37c4cc6e0bcc15eb9b6c46d7186146e518b6e52fc085a8ed72330d862eb20c992c205bd0d9561666468cb07a2b550405a36129361a5d0da80b8e043cd65df85d424d4d7d321f771591edd71ee9d5a047060eb680c9d1644725a949bb59cc6b753a585cb45a3c1ee718bdbea5a525b3d13f9c8939aaf7b89ad0f44e51cfbcac6ff1cbaeaf7634e1a6d14af73d5cdb2a8501f50b8677a3d5e3915e5554aaf2f9d34bd816441f70c73637a10351e2160c474bc05c6bd7f661a681885b9ed36694bcce7639d40123d78e9b8fe05fdc61c7dd7e8475a42036d6d259ddbcec7eea0b8ac4c8d93e826ea6bef7a789bc3cb3a7cc6b2c9360841557c1d70035b98bbee4708bb4db1cc6c04559f6c81bb2d06579479307773a7c27355b4d22a5b18836e7791a811d1ce0a27fe20936a8040fd6763023ba10778180c73103de79d89a01563061bf03dc58ea9056805236dbc9d0883d566cd9f123b80025c8cf86f55cecab070b8eb9d99388b588d4cd8866a49c8763228e2c443a3b529ae59a52d7316ed2cc16368b529a190fcad5ce7808500bad8815386e65b453709e0d7512d993a41195d5c2f4b2c9fd13190f119f1dc85d60eb0a900585781b02e6493d594cab30fa775c58fc525f58420793a49e7134323b50f968bb5196783a34a12dadccd2024cc536e5e38674663917b3728bfcec9743f28e8bade5c17181cd6a44eb538d28673bf3894796ade71a1eec5bc6c6fd32d31695c82acb2759d13fdb2d4b7bbebde9fa99b227bb35a27252dda9e6f54c622b5cd735e2d7c0c5ac2de2b35bb643a0cdb319a5bb8f48eb1d1fe901d2d29a723fdf274ec6a599594164fc05390a1a19158dd726a4942cd03bb2a89c1ee6d13a26addf4f922e4e866ed9f2925cdd3249de91d6e9f69583f1f6cb27f175ca7675c8f1d24dddc4fce66292b462f1304f0746b57f35b1471474f3ae6799e9442a2abdc4bd49ce41c9fed20a34164c4c9bde71ee926d27d58156a8631e1760366617f587dfaa1ed64f7b1a704e2bc69643de53fc54920c920f5d6ced06a492b225bdcb4b66e6159a4dcd32b599e57803f38ba78b8391d950601aba65aff9479d6cbe5fcf7439ee97b116a533a1c6e95db1d7c22c69eb7abe90b6752c67fcb1666371e39223d24cff441eb5ebf684a4b191cd096c539b2c63164f67eb5a9947bbf3de84345694bea7edfc7e6f61f2519d6a594bb24826db4dec8ccecc6ce5df93d3fbd863698baed424477f4f8d5b18070bdb1d1c724bf257206fa36c2f49b20bc5ae945356663913a334c9de71b35dca12607f97ccd99f4d0e66e3c098b7c82d77d7be63ecd28946bcad2b0a7a5ad2d945e3663ba39be59cdf73b5b2e7d3656d1b11a5d93407687c0ae7f9ecc211d3c8788a17b19495c540bd6cefde1610d9bbd4729ef5bab5b5c96f17298ba4bda191c9660b90ccc3f63efa76ab0fc8fd9edc44e6092b529a58449bd97b4a8a5e179be1e727ed85366609bf36fe3dc6c8fc2de580df33dddeeace3d2a4f2debf7efdf4e1679eeaefd4b7a7748ef26e9bd2cca6f3c3f37a9bf497ed75b7aed58b371d4da633f0e94c32c5b2270d4256732adaf45ce6297044dcc3a7e6dfdd972e13df5423ba914df8eae79e7e7a4ff3d6e9433cd2cbf79fbb2b3b3976e3d33c1d3cfb394e45787ccb74e8e3363c0b9c32fb149b60fb585ad4b7373c059affb4d437de53feb755bddccb2be4e7e8b489635b38813cfb3ad7f068ddc56f994463d3b49de759b992c56b6cfb5f6f02b8d3e23e3e6cfa15a26af8dd106668428c74dc379672bba82ff34d3bd6b2fec8a19bf152f6439b7ecc16ef97a9f1cead9d9a891f5b958d4083df2ce1f2b34fe8cf2a9225df6383d9bd4079c0fa553607d0fddba2d67944f68178a81b92cc39ad8fee88231404f5a95acf69ff217c81af9e32e1739d191dedc32cee376e1778b94d9d680ddcc28ef61f56cd423c7853960b714d9eee862fbada36bce8547ebe0523e97f8a3da9f27f3e5b38a1870bef640e0a706bd2c8123400313db7fecb227fd517a2129e6a1e79c6cfff5ef17ad2c3b3cd81e83bcf59833f4ce64a7f09eb333e5f7a89eadd324473ddd65f501b9ac97cf0d8176d7433593503a69d04c91ce5a92ded61ebb813f5fa4ddbb9159c36f8f9e9f07cae97f4b849f4dba4f41fe11e98c6d666f314f978d5be4ddd1d2c7bad60b9c3ecc5d3ba274ca73b2d80accf5eeb39c209f523c72c6521f08bd34a714d2d97e04ce1bc9a2b191bde9cd7dca65efc5bbff56eae6de7d1e91b2d99ff7e7bf4d7a6adf1d9f3de51a1b6003aa89a48bf469c01fe5aeae4f72d229d2cede94c63e35ed7ef7f43c210b178879073bcd49673ae9735233d346ece263616f2de72ff86826747fdb20063c19d99926f0fb07e9c4eba7f818c7ed6c8691edb366a0df5b487fb301e02ba0ffb7e4052f05fb0b86414034484dff7a81fd148bb09f2b61d19641d7ff6ea02d32acd216a88246ad99b2e65c185173db57694762570a474856882148a54c0be7b9814a301855c1692aa220abf239a2d85e699863480fe81974ef901583a088ddb3301adc6c0f179915c6d3db9014c04c113b7f77ebe39fddb9853c34e271c3eebadfdf927cfd09cdf65571a70cabf867b1646ce739c27191938f0eb8fdd4ad7327959e3bd938252c6b8721ac4b54a244a156ae6742f2f315aa186e5149569c21863e686242178af4eb3dbb506a748a59b18668daad8e09296b72d51aedcd569b4dcc8a406ed81b1ca39a6731b678c4acc1062ded088989953a8452d1e561df96d32facb2861a06d3613e265e1e9e676dc4558c8dec0bf1d212c3908430434e56b661b4815d8b12c2b2e8634e764e6e616ee122436580b0f32bb3120c71d2fae10b4497b5d25a6f4f17a6da4d9959698691d242c9fe01b614fda6515aab5274d1afb7dc74d1552439d02a4409fc2a1201d81fccad220476bdb47fc79f5f11f606df78cbc36b9bce1c9cf9eda967228ed61b9fbccf3ce8bd3ffef052ce43ab0db7542ddf70b2e183bcbb238ebef1f5b2ff697960b9a3e8e86d7bc38e58ceda36bff4e4dc8c87a68cfbeeb1b7972cd572db7ed4370cd971eebead0f0c3cce7dfcabe9733f0daff9ba78d0f2c3611f4e78e1e0a9b54f2ebdee9aac4c7ecbca989d938557b3dc610b335e59363ae7f6e82dd1873fb4e8777ffee9b1b60da3feb43e696ddd9337552d74341d2dda9dba76c94b917145db567f35ef9960fbb39dcf4dfbe0b03aeacee41b4e8e1ffec690655f6fcb7af1dbcf93079c7cf6c0e4d2ad03976e1fb2e9f4d5df7d73c3b7373e544b367e3723e4c3d79317ecbcfd9547d6353ff2cd91b07f9e9e7162fb4f96ed8fc48e3db0f6993f723c06fe7d2b4f1a56be6b18add260c42a956a4214230ca98661fe67035993287f29eb30b99d99cdf42b6eb43bfd5296c5cee018427c0a8d41851547c05042fb862ac6180a0c79db476fcf5e6390a79b5cb61eb3f552ac04864a69492652b1481d9ca2083504fba5e0358670da1941d7a27f17a44209f1394a8191b9638021c11fdf7c4ce8bcca120cb4828cac8cdc9cf3b2825fb912a635fcf055d5b1b24159b7b46e49bbe3e8aa87c93b83a6bfe26dabb29fd28cbcefeae32fdd16f385626ed83f260fd74381f7f48bb7cddcfa56726ddcb909f949b39c592bbe5d5fb0f6c0975fde099dafcdbf63e6b0bfec1a3ef3ba471e3796fc73d4ab5fbc78e2ea0ffe9876f3f847ef7af4c4c70b7d4f1d7c6ef977af85de7de6ceceb437c7ced56a0b869f9b300d73d86758c57d21e771d8dfd2cebcf5eec87589d9caa0abb736af3b3f8fff2399d13b1d0d0581e9b8b09f8bea0d19d2a2a9bfb46825fbe1eb2fa6e4fed923a67cf0a6e5bad58965754d4b963f7b689b29d537aef40f37441544a6cc779f681a6eed98795858fc66f00fdbb5a3dae72f4832be3be4e4e927721a5ef8c707f7e58bbfd6de16fa58e590c537fc6ff5e61dd554b2c7f100a1c3221da4185a448ade500c2abd2922bd17e9418ad23b8a242a4d04014355488201421591a21489020282a2200ab2a04b478a5445145e02acb2abbe7de79df3de9efd2b67eee4deccdcf9fd3ef3fdce4c5ce5eda9e3b4d683f4874c227148c88dd2185b1cdd8751607556187e429de1c950cb9ea65eb349a44aa571ae542145d802aef08afc7aced8490fea1c25cfe1fba98deb1d0eabaae3b418cd7748232fbcc44255dc2ef199c4011a4c946166f8713a6640a07d57b6e78749cb52304135e3b6f8442257b1e2b089b76eb7fc8d4a6f17818a54a95aa5f1d07767c256b9c6a02565731926d5aa52e89ad0c2f51ee3a27d0111ead38704711e5c6356b5a26eaf40911abba2233db753b21d403efa2f5392e96b4a529294baec56324a01128038068a118d12fe593206f8fb4b3b3b6ea61fd766fa911ff16f3290a6f13fca40b93f67207994a3437cfaf58d2920366f42db5040d397bbbca9f549a087f59d9d2d4bbfbcda58d56b947502589b9703f87a9207edaf43d8cbcf6a3518765e188fe4be90bf37e514bbf65a7b4dba1a554796910df5e5f305de8b7c867ca2fb17dcaf9c16fe50dbce859e610a68740bee7b97e1144df4bffa3136204ca428373d3cadfc43e23e5fbdfd817cc7d4fadf5732434c7b8331692867f72ff44fe3de07d6d267f5adb29a41331d651ac2286f854735e01e5e16960a79261f5497ec6fbb7a77ec04278348c7c8f31eb9fd3aaa9c8a2c0e61a22d78d7b9d4a73eef94c7979823069e9dcd0df275275e37380ac80b95e3ca763b294af625144ad086bfe2a9b00dffed06de7b5d31b6044081d94808f8b485001610117459513186f599f28af3f490eace37062611c0e7f7dc666417d6f0f609f5dbdcb41477de473ea200ffd346dc7e9820c0bff565ce1f6ed1c184803d5bc3c4f3added8db3b00a21618e0e6ede71e104ac6c32138008301007c1b0f32e41390b0ede2dfd0a2bf9cca29eb893e634716f4f9c473d242ec80291ce18a98fdc775f489dceaf51b3888f259235c162ed141c6f399ba4be86c71509b69ffc2bbeb51fc8939175d2b9a3dc39c447a05140759289227529bee4bbb6666ba4133ba0e4bdd67aab48412b5c719941552a508e2870aa6752ea80f5f64a9cd3c6de6588c3a8b75900e3e319971c7e548a6213f8c4e942387309e24c933a694eecce160498dc811801b477fc89fbb46d9c2d77ddf4cab2236f2fee169d36bfaa55ff2c3ce04e897f174a4d28b0b812cae3ab8c36b75d96815cd376cd66eba32d0e53d479a5bcc551db1e3420683fb571a4a23d1ebb73acff7e6eff6b3556caf7b4f972b0c54d05c6aab8004b35f1adae6460180c403481c392f29c0c84c009916b9cba6cb67cedd2f5bc42882e3b65ec2c663acdfff7ffc507f11e39b54404f30365e594ce3919fa9a1107d15ccba68eb209393cdf858993a2926b1edf098d0c27b8b14a94accd156a7b9cf2f3b8e1cb1261c34755f173da3d2d65138487df657d815a59c5d3e1eb5eb6c063cee8d9fbb348659ad2106534ee16585bcad927031e90604962d4e8cc539f78329ffaa505b2fe7a271b197860ced1714f7c7d153a7998d56eae78d1fd58f37019f2130fa1801f4bedd7a2f0428f1f3916fa8eed82c95ffda6a318bd079646c5a75874a9c6de36aef7bbac4889ab4e622b8d448d84841f0701006d4e5a1427c7e30ee8d1a5b81bc079fc76bf9b73dfce091022d70abb5ac82971e3fb35335032ebefb85a98a7627bf599ecf6bb6c3d1298139f9cf31242a3c248983b26d61e0c19861d008122862ed6fa2c4baeebdf7bb4910f8bb90001c24e90539185c4e0e264716f024c4cb1cfc1d09c8bc3f4a06768075cb6e305838fabb91a44000e977766d4e2124b3416b8c7039e3ede5f27bcb187ed6b29f755386f4a3df75530410daeac6ee9d352e884df1415623869ba600f23d4998c924a1db24c9c30ec895baa10d65c3d9b0073da2622b414f84363a25ccf5dbaf57a36ecb874a839a0ae85e38b755e3572689c4def2f8541ced27962a9471e63b544bfdaee682c659cf8b09267cb5869f5c2862895c3d2837906a88e6329b82fe9ab3d19b4f4a7747e1e543ceb422477c55e58e2e79966a2feff517147eacce2b6854659cd99ddbc5dec2abe24b7366012da469af3ed3d896e102a921ca7dc6698e85df1638509337b8841dca126259b784a999294494598e8f4c5b858a157d9038c0aaa210a2ac7e3edf6d2442d88d7bec78725388a6f151acc1c5d894acc653e153f46b5154e756327c1525f35dd33b86a47f93a4dccd22770cb1acc856361fcd2f0035f6ee20c51e552e8a4282f43ea03fd2e154ff0cbcb0d1d06f1b704e125f28a9a840e04d8b2af00b980bcc21f65152f764ab9f69c9e80a46829b6b8db86a820478bfdec241096612640099800249765d03a406306e0a9f4ddfa10db07c1558d40015e963475e6e62cc79f8cd2275cdad294646b967289872ac93d60bbafc554744eb7eaa4f0ac7d49e562eecbdd03ddc6c6e5250c9fba4636c1eb36a5e75ecda51d151c29e81b09e15ae30b6d78b57f9a6e94e565cba7a37deb296bf03dd8dbe26bb9434b8119365a7ab6378087a18c2670aff7cce9633e5e1007fc27b4763c551da19d7b9d0e9c42716ce08348f0e266c08513d042d5d6f65ab6ac175b4d85ff6596c7f5d84f2a21d40f0de2d58897a40af9e3e0f2d760f2b274ae6df72dd832f8ba6f34c63afb9753043903a975d21b7b11850be27f412c86b7762e32fb3b8323a1fc67acf4e91093e9f424c8ed1075b53db3e7ada4be87b7b2e2964efda1d2f7c228dac65b99d042b0b80a29625a18c6f0b630c8edad98fc9ff390521be5ba1f8a720e31bfb0ec9c9ca1d24bb2538491b918af2e42210f03fe9c7763dd54feaff5212752253154a6d710bc4a1c1ae22f4955ec51b7b2e3f3c19b5ffe4fb72bfe5a2e2188fcafe72e170c6d656bc6e929d30fbe4eab2c88dca25afa0d2b9d99b8a8f9a1aad6c558a2afc65a1794e48c750acd392570cbacbebd74739cf6f1ab10639def389436053b962f34f22bb345d475f9b67abb67f1e0812ddaf0980467bcf85a3595f580ae44e1830b6c50ce07a4d324eb73bb767786426db9dd0639d38d06d6363676f9ceb2f8dafbda8c51ccfcb19f498ae3f33cf8773426fdafdcbc9db9e8933fb8ce00a975bb47538af19a6df5a72bbf97290def754407670bcc025cfb4a9717bad8e3763becccf9c4129e1b0f404c63becf5155db3f34342b30407c759b886d2c32d4984a24826bd9184efbccb3718ccf67912024d3a0d66f9f479690473af173dbdf6e527e42390af8a80915800991df9438a60036efe1dfcfb5e2ce86e193f4d401d50c5286314a30eef307e7f3c59e7e3e94ebe7a60fb449cff01720290e39f14fb329b86d0608713d500d40095af4e94324af6a727f6369f8bf0fbfe81013ff2840a7d7368852cdb748e93a65eee4394ade3156bdd0ff44a0e149d3765ee97a9fae831c6bc26b43b5819ef1676071d1167bba0d174210b712ec6d0e82c8a63f982ff4b5c836d3ba5cf13e869ee3a630e7c6c63f508b6031b7823c95789afd11c645ef9f122b4df4e76ad572ccc2eb33f6f6d69416d77b19976c9b1812405764b7a9df94558f49e3a70820d1b826a92d1a80bcb149751df472ce8a2e31413aaacb288e57f6613258f6fff52183d4d80ab546b780e43e6b5ea224a27e7cd6e638fd5211a4ce4fada26689cc134215e861bc76ab3a634aca35f9730442e5b354b8d8c9eb7393e2a133a2b7c299949bac2d0a6e581aaa565d1f3cee103c4cee93339f050180afc9884cd4794141400b2f21f03c73f00fedb3236063901707c9d50c52960b454d49bcbf3e469767be8e9a9604c3b57ce494dff566284fd02ecace50444bedd088691f2560e7ddb3df2fca20136fd699baa2452adae2aaf11f0db710b13cc0570c228441efce1669cf6d78d8f9f6c7262a191a23f3f8dfaf5c0ea9fd52418450102140e3f7f6d7555c9d03d2ec90252e6d8d73b09ea76e4b82142ec54351fb40b71327df04c6332c0229f61fd97fb9356a7aeb344377cf4b57cd57253b06040d8f102e451423981f5e29e63d62b173a746f564941ad339344a56abd3f35ff8ac5145271e4fab22e6b433af6a88d3ae1b55f4c6fd0873ce78e3edbbc303113b316d1ec5aaeb9927d422a3d372e7d729827f8c3ddda998ccc8ab229bd427e03af3288caad9746892cf7c578a44bbceb26620a0d93c78be3e750f778ec4327d3a2eec01a23aab410abea8d041a3a9b626db3035ea683bca311652fb2e1ada500c12125ddf7cb64fc3a820217ffc44274a3c76324aa5af2dc938346551e6d2ffb79de3e6c4ec2a248b20845b1f66dc46860288a69d2a50972789ffa9f2c6afe60299589866eab019424ca60ac009e9db1c7f86d6b8782147a5f6ba8612ce4f99e34c1cbc8c8cac0640e5993f8bb23f4d8c0bb464bf098e3ec74875d6e8654d9fabc95fb4108f8ba7ce2e2feb4383a4ac55ea6bca0f934447ab8012f643df5dbda8491962cdeb3eaec8381f48b773e8a73ea106626650c976a54b3757451916cb9e597bbf1ba4ca7e21327799c5446d08b23f516532fd1dcf2d843f5ab70416cffc482bd15e6d51431fb3a1bb38b5c6079708254457f62cf9247ec0462628ee05d6c8d674e7183bec81b2e2fda400d2909347718d40f08c5f305418db9ef5ab333a95b258bd504aeef5e29b660095a73984c7ad7769ed58e17d7c2dd17f75ef12d5e47cb7f8492f058daada84c4788c9b9ea696b42e7a5eb1912d3149a4ec7d37b026fffd6a390909069069d6ee1a5b27dd5d67a95e6fc64e5525d5753dae5923531764242a64ad6bf00accee0940d0a656e6473747265616d0d656e646f626a0d3831392030206f626a0d3c3c2f46696c7465722f466c6174654465636f64652f4c656e6774682036363439332f4c656e67746831203231343733323e3e73747265616d0d0a789cec9d0b7c54c5bdc7ffe79c7dbf1fd96c36bbc9ee66938d6c48020990105e79021a113091268a92f050501134f8568cb588c667ada5be2a6aadb55aaf4bb036a016aa562dd56aabd56aa920daaaad16edbdd66a95737f33bb848d71f3b8b7f9e40399effaffcd9c99ffcc997376989cbf67f72c49449405d150677dd3d1732e3ffff895a4147d4494bd7b4e7dc3ecabff7dddd124b7b710c94fce5930bfe9e2450f6e26797980e827d9739a4ea87db3b66d21298e4a22ff2dc73435cf5e1d5ba543fb97d06beeb1cd4d7363b3a7e8892aae25b22e99df545ae69878e98de8cb80fab60575c7367f79f1cc3af41fc2f69445f5f35a16dc74fa2744f51f10396f5eb6ba7dedb96f34ab247def2a22e59e65e7ad0bdd1d78ed6f243db49848d77ceadad3563f7f61eb6d24dd3e1edb679dd6deb196b2c888fe1ce8cf71da99179eba6bdb79f5246d8d136d787ce5f2d517ec7cefe818d1a24e926a0c2b57b42f7fa74afb3191742ddbff4a14b8ca3d2ab69fc676fecad5eb2e909e3fea358c7725d1e4bc33569c7396522ce791dc9c8fb26f9eb96659fbf6efecbe8fe4a967e27cf5ac6ebf60adeb7ccb2d68ff1eda87ce6a5fbd62d1bcfd55242fba9fc83477ed9a8e756a8c3691dcf611ab5f7bce8ab505afcedb41d2dd7710997f4eecbdd096973f51386fd912fbf44f0c7e769a88ee79bb30c6d217cf6d8f7cfef097a739c860c1a691fb3390ea671e388eea1cf4f9c39f5fe4a0de9a24d629acc47a12b590420bf05ecbe4a0525a84b7fd27d8af8c5a45b94aba91b464d0dea62d4707fe44aafc964e955d06ad6cd6696486662fc5d49d74411d1f01689e5717a26a0a857cda970f2c94caf533a5ee6a925415e75113d53ec68e9434bae490e4a9bd16975fa353341de439384aed226a9136d289f20374093356a6f9099d03df07b05d83743b6b8b3627c0f6c0a6c316c1b29365f360edb026b60ddf6dac2d7d054390d66817a95f627f9bb4cfd2a9b03b91bf47f336ddaf9b4aabb17d2fdaedd060e2321ff4b549f700dd82f23b50bf0c6577226dc1f6ddc82f46bb09c9bc517f1df9580ad3a17c1cfab92679dc85fc783ad4b7702cade8f318d895d8c702a4b3618df07123ad856d949ea5aba467d57b508f94aec0fe37b272587d329d8b7e36a07e16dae563fb0ae4b3310e1d523b2c0c3beaabc73e10c931f5315e9e186323b383bed8e7135f69cbc796ccd7a7d815293e57d030c0f1bd099b319c36ff1ff8fbd141d70ea70dde9b33476a3c8381f7e0199c1f1f4cd7afee013a239936c2f83cc05895549fe1ce8fff0b6cee0ccb3f658efd7fc0314f4fee7fd67fa23f8140201008c622d2fdeaf6d11ec350d1fa0f9fb10a0402c1682291badd007390583705028140201008040281402010080402814020100804230ffb1cec688f41201008040281807d3fe73fdfabf524bd24490fea74445a1d54afd7e1bf5ef47abeeb02ad05b80233035addb90157c0e5d2de16086ed8bbc9a5273de974d1c9ba48e18aa68aa97f3e79ead915f9939b7445ae8a67eefdfdd3cb5276c53b644aa4e79bbc84fa7c9344d7ef6b2569eab4031f96aafb82372149221f32cbd2399a53f285fd6a252a1a783f82c30e697097ff83ab6010b0ca8cf6100402814020488bf82b251894a94377554891185a4591645c0365693f30efa47f19543290413d404632aa5f92894c503399a116b240ad6485dab8dac90675901dea847e412e7242dde48266901bea81fe9b322903ea250f340bfa39a21f2ff2d9e443de4fd9d000d71cf2437329a07e4641ae21ca81862908cda3103402fd17e553185a4079d028f453044a11e851940f1d4751688c6b1115aaffa4f17414b4986b09c5a0a554049d40c5d089d04fa88c4aa0e5540a9d4413d4ffa1c95ca7d044680595432b6992fadf38d54cab6832741ad7e934053a832aa033a9123a8ba6aaffa06aaa82d6d034682d4d87d6413fa67a9a016da099d0d9344bfd88e65035742ed5408fa65ae8315c1ba90e7a2cd543e7d16c753f1dc7753ecd812ea0b9d08574b4fa773a9e6b131d036da646f5433a81e6411771fd061d076da1f9ea07d44a0ba027423fa4936821f28ba9097a3235434fe1ba844e50ff466db408da4edf802e85fe15516b2b74399d085d4127414fa5c5eafb741ad795743274159da2be47a7531bf267703d93daa1ab6929cacfa265d0355cd7d272f55d3a9b5640cfa1d3a01d5cd7d14af52f742ead829e47a743cf87fe992ea033a017d26ae8457416f462ae97d01ae8a5b416ba9ece56dfa1cbb8765207f4725a07fd269dabbe4d57d079d06f71dd40e7abfbe84aba00ba912e845e451741afa68bd5b7a88b2e815e4397a2e45ae85b741dad875e4f97416fa0cba13742f7d2b7e99bd09be80ae877e85bea1eba99eb77690374136d847e8fae42ed2dd03d742b5d0dbd8dbad437e976ba067a075d0bfd3ed73be97ae866ba017a17dd08bd1bfa27ba87be0dfd01dd04bd97be03fd21ddaceea6fbe8bbea1fe947b4097a3f7d0ffa63ae0fd02dd007e956e84fe876e8435cff8bee803e4cdf87c6e94ee816e81bd44d9ba15be92ee823748ffa3afd947ea0fe811ee5fa33ba17da433f846ea3fba0dbb93e46f7431fa71fabafd113f400f4e75c77d083d09df413e82fe821e893f45fd0a7e861f5557a9ae2d05fd216f5f7f40cd767a91bfa1c6d555fa15fd123d05df453e8afe951e8f3f433e80bd403fd0d6d83bec8f525da0efd2d3d0efd1d3da1be4c2f437f47afd0cfa1bfa71dd05769a7fa5b7a8deb1fe849e8ebf414f40d7a1afa47aebbe997d03fd133d037e959f525dac3752ffd4a7d91dea25dd07df46be8db5cdfa1e7a17fa617a07fa1df40dfa597d4dfd07b5cdfa7df42ff4abf535fa0bfd1cbd00fb87e48af40ff4eafaacfd37e7a0dfa11d78fe90fd07fd0ebd0ffa637a0ffc3f513daadfe9afe497f827e4a6f42ff05dd459fd11ee8e7b417fa6f7a0bfa05d72fe96df5577480de81aaf467a858d3477e4dfff8305fd3ff36e435fdfd346bfafbfdd6f4f7d2ace9eff65bd3ff328435fd9dde35fd9c3e6bfadb69d6f4b7f99afe76bf357d1f5fd3f7a5ace9fbf89abe8fafe9fb52d6f4b7faade97bf99abe97afe97b0fc335fdf5515ad35f116bba58d30fbb35fd70bf4e3f7cd7f474d7e9624d176bfad7afe9cf1d016b3a61c5256b9b39d3408a226bd8ed6859a3219da251944377be15fee042b341cf6e871bf4b2560f35c0f43abdc1a437e8155248a7e1be5059d6ca86441e9d9874babe77b57bef7ccb94e6ce374690963e9dc903ffff2639d1918675c87796b6d334f9e470d237141ca60c327352d18fdc28c61c923973b4872010080402415a8671792018ab0c7d9258b28c88af140d2e250d2c28d1b3f84adf4b22beb2e80d46a3416f342a3aa6c6c496decc1c105fe935fcf3c80a73d729ac14258a5e6bd46a533f00cc3b24fe6165856ff292be57b103c557fa544725ad5ba23a25be62ae693f889c1a3ff5bf9cd6884bec238e612ca086911bc59843b6648df610040281402048cb20179602c170268935db841844d1228e30b2f8caa00187e2ab44986235320c26c45788aa8c26bc8c88b3ac88b1342c064934e0f195fe607ca5417ca5ef131225e22bfda8c45769c3247d9a7c723822be3ae218c6022ae2abff1cb2357bb4872010080402415a447c251894a14f127bae193188568b4b4993a2d59251a3d5680cbd24c214bbd164369b8c6693a23719cc268bc9626631961d31178baf0cda84afc1c0e22b2bcb6bb1c5ee6fa55ea17227a689f125f286be57b1da019e786348751c2cbed2f2816b59877c67693b4d934f0e475c621f710c6301358ddc28c61cb23d77b4872010080402415a447c251894a14f1247c8c2e22b9d91c8dc1b5f197b49c4570eb3d98290ca62560c66a3d56cc1cb6c349bed663820be326af947063588b61403e22bb43b185fa5defee11d126a93f19591950c23be620d7b19e03e173f015f89afd2de864addb9b15fad88af8e3c447c352ac88ed0680f412010080482b40c726129100c679238f3ac884192f1954e4726ad4eab3d145f25e21de7c1f84a6b4c8daf506c440443465dc21721168baf585e67d0b0ef6719fb842f3cbe62c6bf0e95c81bfb863503fdb2c370e22bad8e3bb047680c7cffca98269f1c8e88af8e3886b1809a0777110c11d99937da431008040281202d22be120ccad027893b6a437ca5d3e352d2aa41306266f195b997447ce5b65a6d36abc56ed599ac66bb152f6c59ad6eabc5c2e22bb3ce643699cd3ab349a3316a1cc8a2446b325a8d7d42221383509b78aa84c94c7034f5bd4b30507c654ebddc1de408753a3e701e5f31d7fea1d3c141a5eea07f37e216c611c7301650cbc88d62cc21bba3a33d048140201008d222e22bc1a00c7d9278620ef698743d2e256d1abd9e2c3abd4e67e92511ef78ac363b422a874d67b6599c3687cd61b7596c560f822e443064d15b1029597408c734268d83ddddd223da32db4de6d4b886774866188fafcc165662ee1bd6e807789e8425f57277905f264ffea43a7b84c6c0f155eacefb5f4eebc52d8c238e612ca0d6911bc59843f1c4467b080281402010a465900b4b81603893246b820b3188c1884b4987d660209bdea0d75b7b498429597687d3e9b0bb9d3a8bc3ea76ba1d6ea7c3e6b47bed0e3b2218b21aac2cdcd2db6c5a9d459761b3da6c068bde66769afb8444bc43b2c0787c65b3b2121b32293e86013e8f674dbddc1d2cbe4a74c41ea1c17796f64e449f01f6ab35885b18471cc35840ed23378a3187923561b4872010080402415a447c251894a14f12ff940cf6183f132e255d5aa3911c06a3c160ef2511a6f85dae8c0c97d3e336585d76afdbe3f464b81063059c2e272218b21bed769bddaeb7db753a9b2e93b533da0c76ab1b4157caae788704c7447c859417f4b98a35a6bdd1c41b1c6290dffdd525bef9c5bee2c55dd3de89480deefa5f4e1bfbd40b8e0486f18bd1ce911bc59843f14f19ed2108040281409096615c1e08c62a439f2439559988af8c2607915b673291d36032181cbd24e2ab1cb7dbe371bbbc1ebdddedf07abc6eaf0725ee5cb7dbc5e22b87c9e1b0c3d7e1d0eb6d7a1f6b67b21b1c560fbf3dd50bef90e098f8b81e525e408e141fd300df7772a43a0e728446130fd44cac437eb32c9d636a4ce5e8576b12b7308e3886b180ba476e14630e4d4ed5680f412010080482b488f84a302843ff55dc507516198d66b38bc8a3339bc96d341b8dae5e12f793421e8fd7ebc9f0798d0e8fcbeff5797c08b0bc1e146718112bb9cc4ea7c3e934395d7abd43ef77399d4eb3c3e8b27b6d7d6e39391904c7447ce572b212ecd795e2631ee0fb4eae54c7418ed098f8e6177b8406774d1b26395207d8afd6fc353197e0f06618bf189d3172a318736842d5a33d048140201008d2328ccb03c15865e893245ceb63f19505b14b66daf82a2f33332b2b33233bcbe8cc74f9b3b233b3b3323d59997987e22b175e26d7c1f8ca8512165fd9ed8e945d25e22be7a8c4578e748ece34f9e470c447c48e3886b1807a466e14630e4db876b4872010080402415a447c251894a14f92826302643299adb894f4e92d16ca34594c264f2f89cfeb457d3ebfdfe7cdf11bdd3e4fd09fe3cbc196df17f579bd263291c792e1717b32d04c6f74eb83ac9dc565f238fd3c7cea2583416e188faf3c1e629e7daf622d033c4fc293ea38c8ef52192d3c50638f28e4aeae748ea91f01eb7fbbc292bea1e0306518bf68963572a31873680b8e19ed2108040281409016f183a78241197a7c156b0e2106b1d9bd440183cd463e8bcd62f1f69288778a0281dcdc407638d7e2097823b9e140185bb981983f908d0886bc36afd7e3f55a116d993ca67cd6ce96814e7232fb8444bc438263e2a97d48790179537c6c033c4fc29bea38c0733018c9276bd858873c984be7d86780fd6a6de22362471c83cc9c54fc23378a318736d63cda431008040281202dc3b83c108c5586feabb8258b2364b5da1cd94441a3dd4e7eabdd6acdee25f14cf4d260301c0e06f2c3166f30bb209c1fccc756385812cc0d58c94ad9f6ec6c6f76b62d3bdb64f29aa2ac9ddd6bcdf686bd7d4222de21c131115f21e505949de2631fe07912d9a98e831ca1c5ce07ce1e51c85dfb874e49fa0cb05fad3d7d43c161ca307e313a67e44631e6d0952c1eed2108040281409096615c1e08c62a439f2465cba364b3395c01a2b0c9e9a41c9bd3660bf492b89f541e0ee723a42accb7f9c28171f985e1426ce587cb1074d9c846016720e0836f206031f92c47b1764e9f2de08b64f97c29bbe21d121c138ff343ca0b2890e2e31ce0fb4e8154c7417ef7d7e6e4811afb8a1777f5a573ec33c07eb5cef40d058729c3584043233688b187ae6cf9680f412010080482b40c726129100cf073bafd9872e638b2db9dee5ca27c93cb4521bbcb6ecfed25713fa9223fbf102155acd0eecfcf2d2e8ce5c7b055983f251209dbc94eb9aedc5c3f7c7373ac56bfb53807ed5c7e7b8ebf30db9f7a4b887748704c3cce2f279795e4f4bd4be01ae0fb4eace1508fd0ee72f0ee5887fc66593ac7d48f80e5f6ab75898f881d710c6301cd1bb9518c39f453ce1ced2108040281409096a15f3a0bc62c697f4eb71f55ebc693c3e1f684880acd6e37e539dc0e47a897c46f4e4d2b2c8cc50a23c5317b4e61a834565c588c002b565855108d38c8412177289403df50c86acdb54e64eddc398e50ceb8803ff59610ef90e09888af90f2823e7709dc03fce45028d5719023b4bbf98d3037eb90b9f6bf35952435b80bf5ab758b8f881d710c63012d18b9518c39f455eb467b080281402010a465e897ce8231cbd02749dd9565884132b37029596ccdcca44277a6db5dd04b22dea92f2e9e30a178dca409eebce2828a09938a27616b42716d51f1384430549059509007df8202bb3dcf3e95b5cbcc7317844b43e170caae788704c7c4e3fc90f2823e57b118415a0a521d07f9dd5f57267f304526eb90b986d339a6dea2e87f399d296e611c710cf00495af523472a3187318eaae1ced2108040281409096412e2c0582e14c92c64d95e4f178fd31a2329bcf47e33d3e8f27d64be20180c796954d9952565235c5132d8bcd9852555635a5ac784a59e3c489251ef250cc178b45e11b8b399d51e72cd6ce17f5c40a26e7f70989788704c7c453fb90f2028aa5f8f806f8be532cd57190dfa5f2f8f8b3b57dac43e69af64e44347507fd6a7d7dea0547028ea1bb4e18a9318c418c8d9b467b080281402010a445fce0a96050863e499aee9b495eaf2fa784a8c21108d0046fc0eb2de925f100c0e68a8ae9d32bca6ba67b6315250dd36b2a6aa6574c9a5ed15439a5dc4b5e2a099494c44a4ab24a4a5cee22d71cd62e10f3968c9b162b3c2a6557bc438263e2a97d48790195a4f804d27e908f3738c420bf4be50df0f88a3d4283bb1e95ce3135a62ae9571bf89a984b7078338c0574f2c88d62cc616aba6fb4872010080402415ac40f9e0a0665e89364714f037b4c7ab89c68862b18a429d9c1ececf25e12cf443f79c68cdada1995736bb34b669437d6ce9d31b776c6d4da1927cd9c51994dd9541e2c2f2f292ff74f2acff09466cc43b349c192ecf2e29ae2e2e2945df10e098e891f6e45ca0ba83cc50723484b79aae320bf4b9515e4815a9075c85c8bd339a6c654e5fd6a835f1373090e6f06f886df57993672a318735816f78cf6100402814020488bf8c153c1a00c7d922c7fae913d263dbf92a8ce1d0e5355201c0854f692b89f746a5ddddcb975338e9b1b28abab6c9a7b5cdd7173eb66cead5b86a02b4001aa0c5756965556e654546666966536a35945b82c503971cec489135376c53b2438269eda87941750658a4f38ed17a57883430cf03d2d863fcc03b530eb90b94e4ce75896ba837eb5e13ef5822381b43f35dd9fea111bc4d8c3bafcb9d11e8240201008046919e4c2522018e62451921620896d4a8bb1859cbc943452350aea719da9250d45681c4da393e864ba88eea2fbe9417a881ea11e7a8cdea1f7e943fa98fe499fd3179255f24913a55aa9553a495a2f57c8cfcabb95f5baea904f55893da42f4a45e8f1645af2955ef6d2bbbc97fffeda5e9e91ff78b017f5ed94d732f52fea01e8eb94afee67e35737aa1ba1df5237a81fe375afba597d0aafd30c7f60b55fdcf5457ceff713479a865832a8fafad02a3fe52b59a7d32a3a8356d399b486cea6b574215d4c97d225f42aeda137e9359c4b1df5ee4a92659cd4aff4864a45a38597d164b690cdee70badc199e4c6f962fdb1fc8e10f8c8fe417440b8f1a172b1a5f5c523a616259f9a4c9532a2aa7564d9b3e6326ce636d5d7dc3ec39738f3ea6f1d879c7cd5fb0f0f8a6e613167da3a5f5c493169f9cbaa755a79f71e66a5ab3f66c22f620b70b30d64b2e5d4f74798acf75d7a73f2b3f7e804f92248f0e70fe18bf7ff53596eca637f78859f4350c6b1655d79dd05c533d6be68ce9d3aaa656564c9e545e3671426949f1f8a2d8b8a30aa305f991bc7028989b13f067fbb2bc999e0cb7cbe9b0dbac16b3c968d0ebb41a4596687c4364765b281e6d8b6ba291b9738bd976a41d05ed29056df1108a66f7f58987dab85ba8af67353c4ffd8a6775c2b3bad7537284a6d3f4e2f1a1864828fe427d24d4239db8b005f9ebea23ada1f8873c3f8fe76fe4792bf2e1301a841ab256d687e2525ba8213efbbc955d0d6df5e86e8bd95417a95b612a1e4f5b4c6664cdc8c5bd91b55b24ef4c8967646f43d516990c560c2a9e1da96f88fb22f56c0471a5a0a17d797cc1c296867a7f38dc5a3c3e2ed52d8b2c8d53a4366e2fe22e54c77713d7d5c5f57c37a155ec68e89ad096f13bbbaeed71d0d2b622cbf2c8f2f6c52d71a5bd95edc35984fdd6c7bd17bd937568139dbbea5a36a6d6fa95ae86ac5521b6d9d5b53114bf6b614b6a6d98696b2bfa405bb960765bd76cecfa5a9cc4c6a610f6266f686d894b1bb0cb103b12765489e35b116960256da787e2c6486d6465d7e96d786bb2bbe274fc85e1eeececea6dea5eca6e087535b744c2f159fe486b7b7d604b06751d7fe1561ffe29f4ad291ebfc5e14c9cd82d367b3263b1a66656f4d6f11c7767b9c6e37bcfacc44614391a13221e5a16c2485a2238a64a262b2aa96b5925dc40ab8456f1e5784756c58d756d5d8e2a56cedac7b5058e48a8eb13c20c887cf841df92f66489aec0f109b12c9b27bd530df507f3f1a2a2782cc6a688be0eef29c638936f4f2e1e7f5e8f1c89ac758490e0f4d1029cdbf6d6aa529cfe7098bdc1d7f454d3526cc43b17b624b643b4d4df4dd5a545ad71b98dd5ec3c58e33981d5741eace96dde16c14c7e842f139eb821dafb9fdd91e96e585915973207a85e91a86f6c8a342e3cb125d4d0d5963cb78dcd7db612f595bd75c95cdc5dd7a2f8e5644ef62bbc16937271af33db68b1c43505f84fc727f5f21ebd01b3929748a1d97147dbdc84b69ac2e12136ea513f62ad7872a8597298f1aaa2bedbd3fa6cf7199ea54bc1803551b9b1f9c4ae2e539f3a4cb5c40e8f4e2698f1d4dc120ed5c5e904fccb2cc07f3deace4a66adfe78354e591d73c0fc4b142537fb38fa93f956c06667f1f8d958e8baba664742b3bbdabada7bd4cea5919023d2b54d7e527eb26b6d43dbc189d3a36ebfc61f9f7d6d2bced54aa90aff2864aadd1291ae5ab8a55abaaae9c4966d0efccdbaaab9a55b96e4bab6dad62df9a86bd916c2e2ce4b6556ca0ad946886d50a38483ec960ddcdfbf0d7f433b79ad8617f0ed653d12f132c3c1328996f5c88932c7c13219659a4459352f63b035a6aeb92575f6f07f92adc544dba859396a6b342bf8d2e3ca38da0b939571dd4539c16d4aa192d33d2d58dda344b6ba3c65f69a6225847d96720d41d7c01e86ed80696889928b7207f4325827ec61d80ed84b305cf540596d08b606b619b697d528394aa03b1474d4142a3eb4f5e118ec8a97f6c35498424168296c3e6c09ec06d866988efbb19235b0cb603b601ff19a6ac5db7d5339c6eeedbe86275b4f3fb38c6fb62736179fcc37b77ea33591ce5b9848eb8f4eb85525dc264e4a1497d426d2c2f189d45550d6c95293b56c674da6928983ccc4c0d74225f969b24b1205e92ec5437198ace89225d58a6b6b7eb46cf30e454392222b122da7a0ba5391baadceb21a93accafbc94541f9eff287891af9c3ad3667d9e69a63e47df4306c074c91f7e1f596fc165d26ef65e71c3a0bb619b603f6226c3f4c27efc56b0f5e6fca6f925dfe1395c266c196c036c376c0f6c3f4f29fa00e79378f0576f33e77c37337c9f26ea843fe230eeb8f50bbfc06726fc86f60682f77574c2ddbc63345a5c94cb02099f1fa93195766598ffcbbeecfc6614645f14e63463da6e4d14c2a57f2ba0b26067b94aceee9ab823df2db5b4345c1bb6a26c8af501cc62ea05fc19e5fa1106c01ac0db616a643ee55e45ea54ed88db0bb6071186619d4010bc9bb60cfc35ea509b06ad80298417ea91bbbe9915fec8ed6066b32e5dfc8cf921767fc05f9399e3e2f3fc3d35fcbbfe4e9af90e622dd253fd39d1ba41a33ea096d1c481d484b51af957fb135df15546b9cf20e9cbb20b414360b361fb60476034c27ef90f3ba97075de8e431da65207876d3fb3cbd8fee3150f5e9c1ea681d26608849b46a067290cda1cd51b93abae9566c32895e7f13724ca2dfba163926d18b2e478e49f4ccf39063125d7e3a724ca2272e418e49747e3372901ef9ce9fe517062be69f21856aecf2f9384be7e32c9d8fb3743e69e4f3d98b3ed3b0b1ddde1d8be18cdd565d342e16ecdc2e753e2e751e2f75de2375ae903ad74b9d974b9dd3a5ce53a4ce22a9332075e64a9dd552e76352254e45a754fd489fcda9d55952e72ea9f321a9b343ea8c4a9d055267bed419922aaa7be470f7d1e53c69e0c9d61af68f0ee98c99587dec721867348c391fc69ab003fa224ce55bd5700ae5259c7db92ccddb1a9b95d82ea92a5b5333577e0a0d9fc2dbf014ed8169f0063d8569f4143a790a1dd8a1b3604b603b61fb612a4c07ef3c0cfc06ae7668296c166c09ec32d87e988e0f673f4ca635c9213ecc07569a1cf47cb6253f85571e5e61395c9de308388a1c73951b02923d579a9fabe6ca1589273eba9c06678f647df453ebbf3eb592b1c6285f2fdf403978236e4ca637747f9613ec916ee98e3e16acf148dfa35c0d669d3495a25201d24aeae0db93296060e9240ac80f222deb0e2c42337b77747c70bb6463ad1e0d7e167827f87ea04746f6bdc063c1d7423d1aa93bf87b943cf868f095c0d5c15f95f61850f278b44742b23dc45db7052a830fede2ae97a3e2b6eee07a963c1abc34302778468057ac48549cd281ad6a7bf0f8e889c1b9e8af3eb03458dd813e1f0dce0a9c129c9ef09accda3c1a9c80211425b2310c765c80ef3492cb3b3ca1a2475a593d5ebf49dfa29faf9fa22fd38fd787f5417d8edeafcf30b80c0e83cd6031980c0683cea031c8063264f4a87bab8b58e49da173b044a761aae17987cc9405e96cd1930c321d4371b7d2283736d54a8df19dcba8716928fecfa6488f64c2d58a36522bc55d8dd4d85c1baf2c6aecd1abc7c72b8a1ae3fa0527b56c91a4eb5b511a97afc25fe9e6961e4965451bfc2c2ed84692e4dc709d9fa5476db8aeb595b232cf9b9535cb35d3397576fdd7485b528b0e91d5279f13dfd4d8d4127f20a7355ec6326a4e6b63fc3b2c70d826fd43faa8a17e9bf4314b5a5bb62933a57f341ccfca9599f5adad8d3dd222ee4721e963f861c67cccfd0cf8c3ccfc2864c84df8dd96f02b407bf8e5b3047e46231570bf02a391fb6924e6b7a523bfa17e4b7e3ef7f186a883fb747843a93ebb0ae05350c07d323b6917f7d995d9c97ce233b94b200097dc007791b229c05d025236775974c8a534e97275afcbd57c4f8a74c82790f0b1ee3de863dd0b9fa2a1b2a2b6a848da3aad75d9621674b5451a56c0dae2d79cb7322bdeb93414dab2ac35198d45db962e5bc9d2f615f1d6c88afaf8b2487d68cbb4c55f53bd98554f8bd46fa1c50dcd2d5b1657afa8ef9e563dad21d25edfba75ce8249157df67575efbe262df89ace16b0ce26b17dcda9f89aea0a563d87edab82edab82ed6b4ef51cbe2fe2737c41cb1603d5b6e21a9fa75b65b309f3b5cd1f6eadcd74ac9dc927efb470d67aff765caddc4f66843c1684cf5618ab2aae29ae6155f837c5aa6c2cb24e5665ad9f16f66f97ee4f563950ec8cd452d1ba733bcea5ac8655f589ff3a008ad69dcb4e78428b3ad281ba0604c9f51deb881ae3b1a6c6f82c5ccd6ed1eb51dac60e295e75b0cc6c6ec0b57da2b0048555ac50517a1d59d974566634261dfbbfffe726d33af6afa0537e6cab549d2bada38e56259edbd82c6329684e8630db712dc5fe3c74b4e2003ba422a9e3601fc961171551629bd8311fb475e72673c973b12e99265aa249c7c153d20b3b5945bd676c1d3a24ed76f2c1b2b53f229f26cabe2ca0be0b7b8fa50756a9efb17a96ca7fc542d79334a2fbe92169153d443be849e923b47a1881c023c42e81eae90eba846ea68df8b376224aaea6e3f1d2a2fc66c9a73e42a57437feb0dd4d2fc0f71bb49eb653a694a5be4f97d106e565b4da4056caa31a5a406be83ae958f55c5a4c7b345750051d4b67d15aa9536d51af576f52efa51fd236e539f54b3253362dc3eb05f5efda3fa8bba9182dbe4bb7d21ee926e34fa91a7be984e7f7e91cba4d395923a9a7a99f6304613a1f63d0d03c7a41da2917a1f715f4ae94255da2d4a1971fa871f5697805e8645a49b7d17669b234470e6b17abf3d4172813fbb800bdde4addf4285e3df404bd2159b41fa9f7aa1f918fc6d3d1389e47e837d24ee5c097971f988533a6c5591a475351b3867e4ecfd24b5244fa85bc466bd19669abb517a9af50064da41330da1fa1e55fa44fe5f5785da63ca399add6920de7e5dbec6cd32fe92d295b2a95e64b8be471f21af94ee51c32608f13f15a4eab70be6f41ef6f621a3d2a5be417951f681ed4fc5b977360af6ac33b12a5dbe9fbf40bc98a230d491dd237a557a5b7e53a79897cbbbc4fb959f363cdeff4ed38ea5368355d470fd2a7924baa94164a27492ba54ba48dd2b7a55ba517a497a4f7e41ab9593e43deafac54ce569ed0d4e2d5a4e9d05ca1bd527b8deebd032d079e3ef0db039faa65ea95b410f3e1728cfebb74278e6c1bbd48afe3b587f6495ac92cd9f00a4961e904e962bcd64bd749f748f74b3f961ec15e5e92f649efe34fd227d2bf65fca59575b21f173fec1228229f832bcc9be53be417f17a49fe40fe4cf12a794a91325999aeb42a6b30aa8dca8d78fd54794b93ad7951a3e23c97693769376befd73ea87d52fb91cea2ff26fec63fffc50fbe8c7df9e6013a70d5814d07ba0f3ca2be459eff25ed4be09baad2becf72b7dc7b93dcec69daa6375d524a8016ba1108f42a8222542a4ba148584416c185b2388a20fb22a2d40504c7417063d1b21628055f11191dc58e8e286ea332331595778a8c320cafd0f47bce4d0ae8bcdfef37dfef23bde79cdc7b73cf739ee5ff2c27519021780f48b86240fd04784d0379af038ddb894e60157817c09d715f3c1838330e4fc3b5f87ee0e452fc0c7ec9a47d073e0c5cfa04ff00345b4986497337524aae2743e035964c22b5108c3d411ac849f23315a942edd4433bd31b699c4ea2b3e903741ddd45dfa35fd2bfd20bf432bcda3999cbe2b2b93017e16ee4c67173b88ddcb7dcb7fc18fe38ff8d200b770bcb8546e11f10d5f415abc45bc5b8b846dc2f7e248d07ed7c13ed4307ae2d28e3537411ed4ff7a1c74831970629cc1f419fc7a13b6825014d255bf14a321f37905cfe7ea137e98d6f41e7b830f0fa2df21cb9407ad34a3c080f43d348ea7b68829bdb0e5d8c7b13b57287616d7f8427df2fa8f821f283a0a23d10234561cedfd3222e428fa3cfe9d758e436a32f3819fb702bd942ab400b5ee3faf2a350883e8b76d05a3c1fed23fd11922f49ab418f6fc1db011786e31ef8226d8730f816d0a272fa37b4044d279fa256b0e395e8697c0737053d868af13cf42d7a19aca280bf47e82c78f03be44e6e1571e10644b86db0ba28cec59477a3a5384e9f117e209fa139e87d4e465fd15781faf7c90e5ac99de387e2a96001f3d17254dbbe083dc08fe23ec45310c5d5288f3b05e8368ff6e042d02f0054190398b61facbb0970e03a5a0967fca03983412f4600423c03aff580131c68d09d60e32301c5fe881a84e1a4114de16d18500721ee7862281addfe32dad03e05ddd3fe04ea0a78b0a27d1e3c712bfa06ad415bf1b2c4836806a4929f816d0fe60790f7f901ed5dc92af2191946d6fd52bec0ed3cec4767e0b503def4e50fa155dc276818aa685fddfe3168772740d80de87608585b60956761869be811549cb885ec6e1f4067c07abf46b7b66f69cfc2329ada7e171a820ea397441e4d102320e35df84358ef83681219da3e9b4e4adc097c58035c30805b73007f1e8668d8043c9eed158a08851c21471e341039a3cb3a3d72d9e0d125a47347d81ed72ea0760d78191e59d0fcdd022b34ed21886f243b0d458a09b2a51717137a615cd8d2d6822ada4e57a4efce30af86e12a4182ac1ca7965e7c4f2e867ac27d3446888e313e2ecbcaa2d0e6f510f9dea29d8fc72ab556ad051ed1a29d451515955adb69887cf7f21098602da6c56a6aba17b9a8a3d8416969b1e7dbf2af4b5e781fdf452db87fe2d0e57f259e6a6e66b48ea57bc96f4c5a1534e720b8c88b7bb3f34af8c6f68b4676b8a04411646012e44e3c2f28672d92442941a21493ed968516628148c1f058ed2596af30e562041b5647094e536bb7f819899158655b4c6b8bc4636d3154116344b5c5a0c10e6734ca8eee4538127131f268b1d9d6f568eefa65f7e622ba17fbce9d4b7c9f6c199d9ef66fb91afe044a87acadbbb1a25366cf4c62e12c9964a4fd80eb40c6dbaeb7332e660a98789085a36e64e10507b248a2862c8aa8a5cbaaa8f9ad7651f3d99c82c3677351b7cfe6251e9f2d8d78fcd600f1a4cb19d49d2e6752b7df1a141c7e6b96e04897e5f4f43c64712364b1fafd793e9bdbe7b379489e9b52a489790ea111ef377ada6c56ab2c5b50badfeff321d9e3763bb4be36511028e98bfc4f597d4f59f36c86233ac4f69c8dd8e684e4a7d22d4fc1738179fb1c51563a6c249bf7eadba6fa23da8578a4b5456bb9d29f67fc4ab6290e265bad0d58e9881642bb82ef1699af1d5bd1cdcf3afbaffe018be3f15a9f2ba7b4d8152a0db98a293b8a3d3934e409d11c5788ba42aed09491dbdebe39f1032e1cb96e24ee3df2e991f5c707616fe2bd91ebaa136f8d9c837b0d4afc3e0d6f5f8ba7afc5f58961ec589b58bb36518db727aa49059e0e5631aafd2b3e1f2494059ebb0cf731fe30d733d33bd337b7dbdcc2e5de970bbf44d2bacc17bce4e1c225656449c6d21069f0e2f1be0921e2f518de69886e0f7eee25b332666592398199e9640e7ad04b56f996a4936d9e1d5eb224b84a27abe42519e4b8fe563e69f61e4d274d81b7dce4ceb2262fb9d337a9984c2ac4d5c563cac880e2d159a4d27b7d3a290a44b348383d5727a86bd760d76eb28cd2bdde4c8feef5ea7a93dcd52dcb5dc3051a2e2908f6a24afaf2cc9cb1e35d335c9b5cb4d065b888ebcf996bfcd8df48461b19697d8333f54c9cd9b367c1d84d566cddd47dac2e62715a79ed7a536cade7e3ad60942de75be3d0c1182cbba5b5a27585ad5bc40672116db11536d669317360cae5dffea1549f270839d9f9e1d292b2f2306b8b7b783d6e1e9795fb04d1eb13c3b8acacb4249c932d78dc5e1fc602eb8b7b94d1e69a0fe7fe65e9f49d3b265efffeefd6bd9ef86f2c764d3b543474d2c207ee4e04e7f41f77e3c0093939b832b1ff89c98f2dbeb5be7ee2c4f5f336acfc62d8ccc7ae5ffa66e3a23f3d95d83d6a76a723f396dfb666005dd67f6ac5a071636fc81ed4b9ad146f18b97660cd9149a0aea3c13cf34dcc081b1ec453cc9f25882ed2711d26789ac0ac9f710455b4e2a495274d7c6537d3b09dfffc67e22c3c655ee256321ef445437d0c39df8e91e614254d6bc4c57bd17336097ac3213e671b8ba846754ae9ab8edfad361fdc76a155bb004f0753605cc461e228292f2b2f16447879348cbf5efbc7cad187173d90df27278223895b0fe38bd876f6f3b64b1fd4ac5a77e8b5445642ffc5fc930cb513e9a4118bac61e4b4300ae4e72886be013d47c7da1adbcf35681a1901838b0d76bb396869b05acdc1df0dbb2c9311765b1618f7abce148d2c35f9159dae1ce428c90fc3abd8ebf37a34d2b608d02fbb4ffedc45874757be9fb8159fc27f397c70ddaad11f5e6afbfc6ce2c7840454ce04efd48bdb0fe8dcd3c842f758c8ff48f41e5e142cf7c89cfc3f3cbea702c22f42d2d491a34dcc8d579e8fb5c6b496580c159e077438dfbd28cf01860f7e000cde4170a216afd98ed7246a5bf1135b59bf35710fccb33df1155e02d9838c6ed927838b7b05b0adca089bce07cb38866442e10d127a8abd864064752fc4099b40033629cc21c1bce75bb45613a5580b9ea9cd147ef7a26210bd5b10f3cbcacaf737578dec11052d6dae7d245c9936e13698f73adc48a691bb013fba186933c80c4a2a71254c998348809f0137a471331e652b6b896ba75161656bf722540bcc2c0d79ae2305b871df3e56ac6a826605504f519ee1278cd85892c49d88db04d737719b93666a6a6592a8a666e60131cb0a4914f480a26107116dff6a8f3b4a1adbbf327477f4698a097d8eeea484de87b09b7d8905c37d32fd0e91ef403fb6c1e4dcdeb9f064c0e8562d296b86c7f1f9490b8f443cb818e36d75895169fcdf7f76334f36023c99833f027a978947ec262c3a30e44090e3dd41abd5072ef53b53c7d8c048634a667120959d415e55855665e7502128583334cdb01eb6a2f4649cf1cb279d872709ec49a7415bcdc159234d5104f6488d9d419aaab2969dbbf2c8abcf6c10f4342d03d47f0fd195ff6a3f85bc7038e1b0b79f326ee7841564a5b2d2fe8e8db7888a9ff4770df6dc9cd62f7db86b8c674cdad0f4e9e27465a2eb2ecff4b4f1e90f90df08f72973ed2b84f5e23aed1dffe7e4a47052f9c21eb842ee2c8b11ca2929b26064d120b2a8cb72cc621ed2b0c1591db16dbcbae0db8fa45c2434b591d61499385e0b29adf9f3150c474d8d4b7332c4f43ac1c84c1c75690c1d1d1a20a6288c987e62d37d7b665f3fedc4e68f1e78fce0b679f3b66d7b68decd71720273b8cfabe3f626da3f4f24126fd6af3f807f9778fa877390274e3b7be772a62b5f83002f81ec64b4d3d0298b76a6730bc81ab241e25ee5b005093ca1161eab04bf2b9bd4cb6c4d089b4ebefd948922303863384c81669802b59902052e1b694c5c1d3231e513507903e22bbe8313453cd621b7267c9ad2846378194a9a466d04f892aa88c01b16774148e88b62078bb1c0ad4442390e41104bc10a8bc9a586eb4e0c7ffaaf85b3b907fbcecbda71e3bbe3d8da62a0cb22ac2d88df4ee992c5a159fd2e9730c2ca54c9e13007670d8ba6c128e8e6834c457dec8660905d0d66d8e04a506594071bc9214325b2cfa767690e0860b3000d0a3f6a666d332a6c659456b0f6580fa6bce4ca84aad349cc090d8bdd413ae63965284e17191174b373ecd97be0d1cc5414858cf0311436b9f8bfcdc6f499cdc766332733ca7af3bd8543fcebc221f16de99d0c71a05aa30eb74d57efb0cd75ce753dec3cecfc26f04dfab980faba72c045d2b50c2d530b6ac27fb59f432228bf04bd05a41508ca9a2408ef6604dc19190129230068210532a835a8359217f70e71604723f6ef632b40263bec98a8f22cdf09e036d3757c882c423ad2704f4375ecab20e3c8bd6401e14813c9852077cdeea4b203ae5c8830780170698b55b4b6c55b1c4e2659683a828b24d2a20e0be889e2383eb3a626cf130a9783c43b820506c26624019a007f9c78b99cf8f25e78e687ad1b1e5cfc2c3ee8baf8a713176eda72f4f931c1fafaeb62138f3c74ec9bc9d39f7c7695ebfdcfced48fda7ef8c59513ba83a654b79fe6bca029115c93129c92e63718fffd190833558da8f00617e4c856bb6a0fca72812798c1050b32f8026b8e55f5a7819bd535a6fcba18665264b7870b19fa3417b21772462b2ac089b482fc5adfd2de7246b563911eec60f2ebc45bbdd6fed6e556aebf63a4e3be743ad47b9736cd7d87778ef501f772eb2af7c3e92f59655ea7a6de28aad5c68918e6c54c2cec4b0287302b5c59716983aa7a387f137911a591a9463e50c9039956e7ac71fabd3ad1fd4c93f585e2acb0894d618cc25a9800c5e70fb02be1baaefe46dc734fda09dc847b822339622857d1aa4b237e6277076099526498753e124fe2565b0b534ef0934c9e497182a98200c15a716d8dabdccb30cb149c587e65d82143264491b528273b5cdd90b576fa829dcfcf2f1eec762ab31a974fbb73b5bb217466c7fdef4e9f7cc7e2bac47727df68c74bfc1b56ec5a3c6fb37b23b97ffec4c54b97eafbde9eb2e78e71cf760bbef6d891c43f4f03d101c0000d223b19981336ca9ca3d4a9ea33ea36f51d951f4c075b9fe2a813741ca902157959a12252c1d8dfa51c24441cb522a25a39911e2287900409f32643461c07b7a07765ae914c3ec0f3b2919955227720a19c744ce6e0ace9a1e4465c6e5845233ba7445c182a15ebec84a99362759720a2119d50c23ecc3e038396fdec33649fad11af3639fd77403f1308cf33788969a7351307217fba00c952d48c4657748b70c93c09d86d56b2ade0f39d51809c8f0ca5384ab3bb4629979919638fa80161c03d865b3594a8bab02aaa1ae1a89a9d017dd7a889b6352188ae70b103322a077560b2ae6d29f9dd936fbdd59028c5e35ea2fb2fdffc52623318f5dab6e9a078ccf787f8970163ab9396731061589f952d0867d8e4a0c793e16450a1d8392e9861b56124fac15f9811813930ad8c611ab312a647a0446dc7c032986114384decb59beda0c00399ab32d7b9b6b8de544faa5fa44b1697dfd639402d457c91d2043846c13a3497ec71ba5cefdaec6e9bcb6db35bc1440c1723c4b06d8280d666373c3845d4013b874f30f301543374469e639c76afb6405ba3711a1889df34123f467ecd4ffc1d46e2afd39d877129b2e3b5a0543df7d8f6fd6fc692f54b63b96a2e711651828d980b8d43c61b67558f1552b7080f524426f09998876b21dafa85d980adb858920bf6823c6e112281f088d73c1bee5adc50bf7ae4ea4edb1e239fb51d18b2f4f123589afde8f93fb4e185daaa478e3dffcc9e21155ef28f5713f78d495cf8d3db8fef39c5a2b64a909c07302f1375c64352a89765c759781ca638bd53d0809cd00aae2a9dcf0ebaad7210a33c8d39313382d3823e8d49d067629ecf8ce07ca970abf9a366edf71d9284bcf1589c49b2ebf4347c8368786e48bb411fed1cae4fa777887748d39c77e8b3a53919cba4e51927a58fbc0e51672cce4fda843022c7043c360a99174476215fcfd143ec82835159652540673a3e31ceac3b4c352c1d34433cdbd370a27d79b3345390900b6960a5b08a73075844a2d5759199e482386a782b7ce37cf7fa16f8389f975df379d974be4692bb37920cd2c0125baf0831857826d2c11a531263e6c3d0ae068b9015b1d04c1019b8399983cac9460ead9c411d765f23527a69afbfcbc0e9d5d78db89d5c77784a43db6f3e58fa9744cbef1efeaefecbb6f2218fdd32f3c5e71f9cbb9d1b669b565459d4f7ec9f278e4ffcebc355ad0fe141781edef6c6d6a397bf8c6faf69dcb87ee74e60c004c03b2fbf0559d10cc376cc8a39f8231267012c63565844306751adb328258c25434c174d49c02ecdb2fc371a02b21f47680574f7e205103ca6d9525accf2b0da58e5f9d65bb40b2c1a639901f3de514734e9aa4159590623202a8839654e67f904ba6f75a2755099fd205dfcd3c3dccff5abd7269c894b8d5fd4e333f8ed6759d5711868601a68a00fe5a02282923ad8a0a2f46037869110879111ddba39434181ef14745a831695291bcb02f69b5944c4cef258a686f68ec0890dcc8b763fed487269c75df48afad25c8fca6ef7984ff498eaebb99a2dfc32156111572b4bfa5319c9019310a183102149488b9999d83b303c353f3b0783cb46363bc9a6659ff49870e631577a757d1d93c15cb8304540c7c12ca8bcd48b0bbc03bd03c3a7d5ef8b784b119e8fe6e379dc6ca95699a9ceb1cef53d8256e1d5dc726991b2545d6e7dd4f79ee32d97331b2c654f861e609dae17b2aeab1e66e6132cd05514f42315c8d8d40d5fc3e959af5bb0a5914c31b4c82cbba183edd831b26b76626fc48fefefe19fb50b5267b8be277796e74a4ae3313cc453d7fd4a4a93ac1f9990d79a5a5bdc5c5caa50daf1937f88ec6a516d4d0dbe5a18ba12092038e3725f632dd79a0e9e36e3aed3af1f3933fdee158f262e7cf659e2c2e3b72f9f3e75d9c393a7acec35b06ed8a2adf58b176ca1e905eba76dfafceb4d939f2ee8726ce5e17684f191356fe0e153972e193771c5d2cbed9575435e5eb878fbd68e5c96e964105071474ade4a16b8803c0738800ba640992730d1c9cf529c4e4ca27e8729528799e938fc8e2e11a55390555086d8a8cde64655189b61a45583ac02334f93cd8268c6956391780f13447a988c016933f5d3188a7ef9fb2b99c435445cf59d4667d3793a4c2dfebfccfacbb97e3555e1b5131925bd0283bd46ce6dde913993e95ddebb035372e606e60757071e093ee3dd16381c38e33dad5fd05d7dbc1bbdf55edaabe00e81e433bf9b03cae40fe982de2938c4368e39d90c36253e519584e406464456138e220510d9f14bb75ad785e174038369c7155d72180ee2a88bbc7d6db4c954a9f55adfd901bb285e8be335294fd9979496e433b4851e8132391d66ca1cc61dd545509f19f5de791386cdaf2ac36587eede7f198b6fad697d70ee3f9e7ff57372fca5d9f7efd9366ffe663c4c9b7bcfe0059fce50fdd5d3b1f4e9d7587b26f1b7c48f896f137b77bc4e4b7ebbffd8b3ab017241670e42fab39c0b9bfb283d218ee091205a8810e3680c0b9c4c6210d720c232e6cd52aab654cbf013b201530ec98a222b28c271b0b9b999d634375fded2dc0ccf36ab58e6b36d689951384b59a23ca9bca09c5378e065582e9707c8d5f224799ffc575954649bc8e6146382c0db38e5159955bc72f8186792b108215e10639cdc53e9c51772151cd139cc6db67790143bdf02d1252b75b108b3adad554bd6bd4c2291f60e037934b3b683d02b25b0e65411ac83ea8e5218fba25ce256f163fe6374231a89fe658ce4429aee0d85f24aadc5b6feb681fe1b420372070cbcb17ab86d6e81cd9b5780c396ce99e182d24059b45f5eb5bf26f3b6507541f5c09aea49fe4979930bee0bcccd9c99bbccbf34b03af391d08a709a4dabb2213a8c3936d99e5fa454294411bd87c84da81f1a440e35f4eb45e52c16e7f5c27a644684449a7025ca2787f617de946b17b1d848961876adaa2fca756eb2e7166933203868c2db503ad9d850d1b3732edc6f413964a361d14b7169daa891ab5315c9d63616d2c55bcfb701cb00dd0a5b5be3605f2dc0ac8a780b2867ca2bb2b4d5ac7c3368334b38bef2629ad4c2f232676909c9cdc9e688c7ede48af5dcf26241e072b27373599dbcdc89423d38565635e3bcfc3076a7b41bf4d846b887afdb7c6bcdd63b5ff871e6c88dd1ecbd75c182ccd2ea99cb5e49d4379f49ccfff863fce43fb1806f1fb5aff86262fb3fbe4a3c9cb8d86ff81d73f11bd8b8881f9939e1bdfd9ff61fe1b626bc8b87f79c577bd38a0946ed34e38541b74dfd74d173b862d36df1dfb64d586d4fcfef5385ad6bb6e0ec1d5f24a69cf96762e3b65d0fddf9f98299dfac7ded8bf35f623bd68fbf537f3cf1d55fdeed9c9f86073fbcbedfd2e39357aebbaeee8f20fff63650b91ac8be4464c353f6639b5d33d39c1f1b52838b268c12e6976b4c976aba47de6c0bb5226d8a34d5325e5b49ebb477f8b78423da394d91f81a5c4daab4a9ca2eed27f527eb4f360ba77256ce4615d9c2731ce4c692208a2a8c25411531426ce7cf6ed6a5745175c32542293be761e7a8cea96ef89425c8f35250a0422399615890a47e6f104c481356c05d288653d5d124910eade2dee7bee6681d184e23c68652a51e11bf56699d8a55f65eb38bef8b6481b85024e293f6939f240d2b0d0ef8f3837604d234c0307f452c00da1263f5e556565dedd8ee8aa44a1f1056455768c78ed98e1d5bc1277bb0be41bb94618376056f1d3daa81b353496c6a3fc7b6371904d6e099b5f164b52c0717e31cca76c168385f102929fe1319f5e52b6dbfddfc19fec78601d919c57cd3cf03f0e1c40d64345e77f0378f3ec262b17510377e0f927298f980eb20e2402637b22a2ac70dc8a9ce999c33cbb2d422dc1998c3cfb0000af14b1421df6ba1fefcce416fa6c5e272063b772e2840199941e05b5630e840923f2ca82c0013202b368a99d3129ccc610902e3bc20b1a70ba6ac0537d30361785e58cd609f5065769fcaf4c2c3ee52035d3283ba5974d45315c70ba6173407a96ae3cf0da690930321597f94cd9a633cd27b8cff4a3d916ddede62bea96c3d9f2a31a66a51708063617b91d14207dbd0c5c92206ab37163b42d754296c2407877a240b51e11c48997b949bb609e37524bcf5f8acc95396ad19b9f08dd58927719f453d6f1e3460f1c6c417f8eeb1e17ea37b0d5fbb3a51cf37d51c9c34f6e5e2fcc30ba7ec1edf9d0e757827570ebcb7e0d22651ed397dc0d007bab31ae6e4f66ff9fbf813209513fb269269990427435d737ddf19e3d848473dac13d10c343b73215a9a59879ee15fa12f590fd206ebdbd60f504be64f990e9b33d39199493b0b9d1c9d33f4ac1badd5ee919eeab4a9fcf4cc079d8f389fa11b6ccf646cc52f92ad8e8f6d2ee44601cdad0538b66db0a753d40c5dba768a6a7684b9745750a5e941cea285ed37a330dbc70f64f9c2ba8425955123a505278e49ee96035002a3a14de54b0e5f72833cceeadb902acdc43e13f08071cedc62403b31cc9c34c343e6a6b986a37d126f7ed39af8e4b73b71bfa37fc65d7abf5e7cf4c96d7f1b73f7e9e52ffc9590ee3f5c7a03dff3e13778c4ee53c7bb6e7ae2f9c40f8f1f4a7cbfea30f33d1b017b468346db8177df18857a16ee2725b5d3a105ed4802922d38cb2cf2594ca5b2c8e62e85df3c63aa9e094981ac4ced3f56bd7f75a8dec50ed50bfe5af552e3f85595eb5ed4ef01a38ca68b9220f1122771429a3fe0278222831dc8e02ebc6eafcb4b8574ea0b61a70d1abf9411c25ed91142c0c54884fd6f2f17e138d3509fd7e7857493807ee6857aa42aa5908b8636e2ff7965f44335b367dd32f7f1e66589dd38faf84bddfb573e7dd72df589f7f8264fe6e0db13ef1fdb92486c9bd0a3beac7bffef5f3efdafceecd73ecf0332b06f182a68ade111f8a0248922a21c63a46c092a48129976646ace127138bd5997752b910356cef2ff61ae6aefdb920a94625aa569b0f1caf32d915fdb69f7a2e43660f2789ecbbdbc91462e7f4c97f24df5898a5713d67a664510da73cb600d16f4a81131d7b006dc7fc7326009cfea4457080928ff01dd8692dcb54a1961e2dfc8977b8fb986fc6be86f4926cd2c76fd35ed5be99797bf21bbdaaa18ddbdeadb26030d7783ed1f04dbcfc32e2390ee4ef790f1f978ace4c24e9a9b8b424e1fc94341621aa7ce68c058f0056d14b2380bc6e1fcbc5c9d525857fe78b3c8d862aec4f4bea96ae3e7a6044cef9bce3e4f662eccc7f999615dc6b299c8c869e189b75d31e54a2d7e21b51e209e153eaea4c731f37db2ea1b65810f28f40d5c4e7a4620232d830a6a58cbf384b3c2521e17cec9f35b3343c86b7785e066b74b17e15d369f17c2190a68b6db014dd0120aa15ccafedb6c664925c2b6236357be21cb741d22abd23cc72fd0c3eb13bb11800fb667ce022ad07e071d4cee5e93f860d3a789e71af6e2aa2f9ec3f889f0ced0edfbef5d76f437a19e2b3079fca1737d49c5abb8edd4cc5907f1d84f4fe2590d531a9f2a9ab1b0f2d6a543563e772c7171e18472ec0079bc0888926d5ac2a7acc67ac408b83c251c0d5ae44df2073291794214092c58174581d57f4d8f07fc66052c1899a5328125de7ed3f361d3f3c5175ab195287a6a47ed8821c343ff03f59352ea770de27853d6a35bb16eadb28eb7ceb072bd6bfc9178ed95adb4240225e5188999c564b026c8cb4d18c2e0e44025e1c881f6c5a3e4e7a347db04bea9ed6532fae701646f5b25d0f83a18d422e00245efed63b643d856dede9e7dcc2dbdbdc525c9be6b51b2ef5490ec73f2927d6630d9fb03c92dc0ce56ad44e7ebf89d3ce82a046b6bd026b40b7185c84055e86b740ef14e1d4ed621ca27ebe68c0bfe1477fedec19db31ddcb96068c948cfe4cef3dcc99a6bc0b7df98517b16423817afa99d196b8b77b08415d49929163b5e3fca4223586379fbb77482190d6d33b449648a309bcc11565a573a048b696f0d0a33b7461c30142e68b758c2b22c8515969a33ca948eb2b6924407739074daec8c61161895b8eec2bacb7055b9c6bb38170e2373db280989673a84fae714a60c72eeef5849ab16af4daea8d54cd55a5b23152cd348158acb4a612166b931dc7ba73863e2c0699d8ed6bcb1f88d66bcc9bf755ebf590fd11f2fa735be3bed2b868b10f5f1439946e38411a4d9e551c9d22b5f2e15cae41be5917439fd848af7c99fd1cfc0093194305d63277e35b78adfce9d917899c3a5dc498e7d6bee946171864aa8ce1a081af6aa51273bbb17de4ba99e637da6d91fd9ebf4b2f35f197dd260cebcbc3e92252dad0f98ae45b648324f394ee76537cfc33b302701a2764196114f384c444542924c898211d7487a19f6221e6fe277f147f8533cc7df2cb1734a91887588c277891492bce586aae8ffafcee8c7abce682b0be3533ad4da06b93bcbdf1922c598f9c462ec001464813cdbbb84de6feec8889216936210b6fb216c4f87b09d45d59ff6ac499695d89b737b5507e3d739c3070341b3394a24cda69558d848d6c036523f2aa831e326f31fdbbd7158b2816f5dd2a21c3bb2d3a3601c5fedf7c2d01b15185b156754ca764739c31d656cde9707434ff49a5f19d4b007e3da99f108628903d37e1cc2f0273ad61d259f62b16d0359dc8eda2e9c03f32f209fb4edb8bc9e9c3e93e0925ac37536bf2d75b7a1620208c82389d5121ac916c32e12fa1fbbfe0bff162e09ff162e9d8e277d7ed244431e20ef4330d39fea618af5080976a044232d1dbb4f126080899092cdea30bd1b80030c78b6d1df898d5427bbccdb556a41984816c586240b9115c1b45d2d65b83fef370d57436c4b2fb5928b1d2bb9dcf08bafacb04271c59123da071f1c61bb9e9148525aa8e32b2c59a2894782d952b3e5cc96375b89695b0e1b1133a80087c9bcb1ed6a462c9badd891304b8c6159e6862d8f555d7696d8cd865729c23608c92488cdd8c2d9d3cc81f99043a41a398157d5863515bd081dec371f8b58d93972be1074dd740bb1e462e257752ff51b977463012276c94dd225ee3e75b9fa0760a53a501d68a7055c9eb58b6d14bd8dbbcf7abf6d855552082f45ad65b6216410bd4134a44aebf536793dd940d789eba4ad748b283889dd662be209583b9154abb588976028a943ed43b10129b82459640570df66d3989cc63b173a89b3896c4556dc7d0faf4b8db8bb21ab165937d4050a569a609136acc015d20889bbc50e8a689fa161ad91541fd0f9f1fc421e5c09d9bad7c15c631afb9e573ce6073d3373731807aebc698943a65e114b7e3d35f50a40fece0c7dc57c3361870eb0f76a62fe1a52db2f810e9e44a4fda499970fdaa5c2b54ea6f55bdb2feeb6c9ec6c6a9bf6a3fda1a8ad4bc8dcaadd5f1eb5f5283787fbbac2d9d4766ca406327bb05156e104f5c75e5f59390e8183c639d8b11ee7e2db8abc69a5781ce60f25aa772646f14d977e7cfca6aadfd2cb3f0fe08e5f2ae54e5d62c6f82c207d168b80f1fcdd4ea523ce90fcaad7dc17f9ce08b19144c00b8b12c0ad44444a250b4788459438aa0b02dfe16ff92b210d9fb42408428c80a9ce715dc1ba52a58c5766280b155e91209a36831a2b4cf69f85d5dcbfc73557c2ea6b9c79241e312399daf3bf8864ccca5b34ba823325d401b4b4fdd401c0574987069960ca824a904183640c88c2f28fec1f10958c1ec9618fa808e8ca52dfff43d995c047559dfb7beebe2fb3dd3b4b66496626cb842d190813a2b92afb1a44f68c44056511256ca2d41aab022a626a1f2e550b144a5dcb1630455b534bb56e05eb5650c42a202e545e4ba9223379e79c3b1382edfbfdde4b987bcfbdb93377eef996f37dfff3ff0e7bfcb059e334d1d932874727956538d5035f6e747c7a8f1b364b9c66096c7a51f39b1d3dee16f4321d28c25a80e22b603cf60a45ee7de55c1e0aec76fa3628acb6efda50de7a0d8cfa0f33ef102a11245eb39b021af0e81e4fd00c06695aa73d922905e927cd3deacb2a659a56908c96d8c604f704d30e4c63a60953f5c9c62cf70c73963525303578aff908a9fbc314e50a4b823789f8bd28ca4042e08a511387e6a950d77328ee40bdcf15e73738249618763d81b61250a225910cd95eaec31f2ae6fa4eb29f2d7aee711770d960c2efd6119e8952531cb3d7e9446d0d61a44998f013d7803560d0eb60f8d31df93d2feecfef7de28fa0e4fd0f40f0e6cf7ffca7fcfbe46b602178fca5fc2f3e3c92dfb8fb8f60c66ff3ffcaef076910dc05a49fe48f39b93e9d83daad1016b1d3ae9e632cf09063f4319e99fa4c0f2dc961e86108d372723d5792c7e812af177c6f21fbe103d10080ff0296f2ff4d01ff3d83f5f71ec60a88536bd6c19c7a924027e686a90c4edcc324ec9b58cc80ed9e9c9dac7c60dcf50f4cff5bfed5fc1ab0f2859f65c70eb8337f37b35775cdd9b3f0f97c2ef70c05d6ded67c8757419a33ad7b1df337a8395ea202ccb5d7cf4a6e48927eabce4b4a213a82b2314fc453c656317dcc547208d360d627c73263cd51c92c33b96c5af2466625750bb3965acbac277e4a6d219ea6de25def51d238e99c7ac4088491155cc1086ce320f580f26df4dd2095f5532edcb244759a342c322c3cac624a7f0d38cc9de19a11925532253a3534be731d77a17245726d785d6253fb03e4cfa250b78a177db19cc10889a323898a12d8f55c5d4333449f92a28ae2269f918828d51ee0043a203828987c31a45f2f1302704926e0b49c25dd45c77316276231546b27017351735ec04928a7b34198856b5559155b124f44e12cebd24acbd92bff2fbda3bee740f1e78b2110356859cd6cc1046adfeaafe6ab68060118b914f6e5d9c40ecf572b6571e8a741c9e1d54506e03697a5db29cfee7eac5999f3dbef90fafe45fd8b61d0c7b1529fc0db9e34f2c7c1aeaf9c1fc2720f8e1dce699731ecfa6566756ceec02cd870e82d97b7f97ffc5a1ddf923f7f5cb3e06323b81f893fcfb797871fe4fe543d02a2a9ba05f7f166abe4594827376cc25a9c035283423722dbf30420b9872c9e32d87b77194bca02ec30448d4908b0da9d87075767fb2cb1548c3fda95da5e569031d9794a7f5c25e2bece1dfffb2ab24e9fc1d5eaf17f6e8eff628d848a8a343a3a393a4e6d0c2d06261857ab37697b8467b487952ebd44ea89f693a8c70a286e6310ccdd064c1152463019fc8ba106792b104c16706fc61130d1f98e26b9a44ac14dbb005f540e5c349f531b6482e668be68913ec529c6ab31854ce46e38be26d712a5e6afd5fed9afd5fc7a032940c7c0fda29383dff51eb644f450bb6ef149a4dcbf4c3dc4687dac8f4b0a87bfd1085dcd416795bcb687abde1aa47430568c551820a479c803f63c031c9055faa1dcae830b4d74b23f0d533c84cef054f9b3ed35d46f525a10b29c3ee04cf97c73691f7ec7be396d7de1e5731796cf7e99726df30b54f6ccc5fc1a6bb1e1cffd0e67c7f66ef843fdefcd87b2589f8f865f95630e0ceb583252eb78caaadbb79c45ccc156eeefe8cfe92799be84f7aedf26ba86be825d4529a4e940fa432a1cba851dcd8926191a1f1e1e593a8e95c73c9d48abbdd6a19829b507fc78b8d44b1912c36ca8b8d322c0ae762a791283692c54639caf187a35685928c9371aa3c31484b970d4d0ceb37233aa56c72e27a69beb240bdd633c7ba59ba45b945bb555f165f925845dd23ddaddca3dda7df15bf23f180f2a0f6a0375c88cefbc492ae603220242b61124e54065c74cd802431071a97d2e7e6e0dd413298f0297dc2e50990607c0c722cce2c55b88f100efb283ccea5a08fc83a1018da6531fbb1df49e73768f749c455456262a1927090e7589a2259908897c2732c130ef609d848edee8763cf491fd107037a38b2d24114348116b008b403167482edb6bb0fba25ba35fcc6a3852451092ad1b0adaae4e44af4d514f4beca400d7c269074a1900dfdc955547257cf6498eb0a640bfe0105802f3bee28c6164ee29991f390bd9ecba6d01c67ea347a22a8c668760acd8a4c479843eb792d86bed05d17266b6b0a8873bc1cd33930b5b380eb7b3da68f36b192227f996c7e4e99f5c75b6f7c6a5253f390fcf513e75df7c3bfffd7e66f57317bb5679fdcbe2933181c9cd676cbaaef1e7f25ff8f47c0fbfa0df74dbd74c9d061d7959957a5ea36cfb9f177b3e7bd71bb7aefbadb674ea8ad5d503164f7f265fb972cfd1c696a7f180fecc5f38e77db0a438661871378e144a1935cb22beaccde3dc74601d90f115900d80d0af8db095bc2ee812ff886bf1753d54f8a4ee25cd129e49da4097d22bfe791de592baa65d47347b3c7755c3fe260fc8856890b56dcf912fa9e7c90519e7df6ec3fd0b7dd04233e842b7a8883b698d4a6d1d3f85779da87d4c007e3e6343d841f4e8fe6976b5b99131a2713a4d1493edfc10a9e24598cc9c99e989cd40ba0eec77608a794d9a80f447d4d3eb2c5b7c8d7e6a37c0a06788b2980182d10571d7728163545ec7187225d48231d7728f6b84331eb4521f9797798ca2290b8004f3911208e70524416d41a85c80fe35318aa32e8969766e7bf7be74ff9b38b5e1af1ecadefed61f69edb71387f6ef33aa07c4e4d38b7f3c5dd57bf84ab5408018e73c3118f175c5ce02aba1840f038a2130946e0194032fd0ebfa91f7ed3a8ad857dde8827e08376bc1f03aa880a2a21f693fbcb2df2ddfcdd42bbdc259f92a5a8dc24933429f16481e823001926cff0231b1bf12c2c7cb72808519ef1f03c43401521190f493202bcd5e7511166a373783087e43130599169e2411bdfcec363006c85b42b32b348703fb981244974c688324d0cd91f66a0ed4c17738a616016ba6697d4f2849385b6a29a07f4b274a7ee26e03f69357eaf16b23005ec81d9e44e428392f8ef9d820ba01d4cc66158e410aa50d259012f1b84934e022f80870371444d8c815a2787ac05e425b93ffe19dcda3752da07ac7d39f712cc44de6f5bb462055d797638ea733f4170cb516c013eb0939544d2a87425ad0c31c8c8b80659a38811c628d7086b1a31d598e69a6ae90ff30f6b858eb46b7510f0a7bc69262d0f6586ca63bc573057c833bdb399d9f202ef5266a9bcd2ab315e8456b878686a2496636323969a89bd27eafc3045330cc972b0f345a88982a26a9aec71bb5c683d5d0b86920dbb18c28aa2bdec32d0de9ee1852927c1a0f262c2030061313c1ff65a1eafd772c98210f6ba60d365c89a16d50d8fae1b2e41e62d2fa3193ab42bf89518cad2354d10789e84dfc972b90c83e003a619d02f11c044224ac870eb852f9b60c0c43d5134fde9f777827b7738814136e01f970b58b95cc09fb3c60f9b33f4f88555aef017c5038572e1e254ffb8de80c2853b6849a8ba721fdc34ec2bb67a6fa0b035286c03e9844b442435470312f064d5790d2880142a3cb34bb6197bb0a3148bb35021dc8e42b85d70e7ae056500110700f8597ee52b47e281c12230bff8f384b2509fe3bfcfdff07cfef572cef4e45f85b6daf8d0fa2fe3d447b940feab7fdcdb41fd0a26b1d9b5d13923bedb5cb0d851507bdce46ebb128e467ee093c84a57a57b30a8a306f38385c14abd3ad055e7165d6e041bbbd0462d60c54a61df1b43b6af472072b40833df046e92c8245dc95548556ad23588aee7eb25f48923f92be82cdf2ccd50af705d07e6d0f3f905d23c758e6b197d0b8f62829b5c37b957d1f770f788ebe94efe39d7cbf4abfcfbf45ff883ea7baecfe813fc09f5b8ab9ac5354db20107611fda4a3cda4253fb66176a14f45c9209af47b744834571e7095b452d9d2548057a2592c4900492311c1e1d95ce426d16048096f0a5e040e3d6544501baae182eb75b827d462a1225bb4509b03ae91644b73bea146b53a4a24465ca23cb14f4481445926e050ef504dfcf0bbc503ba3b22d93722798f55c546c17bb444aec049dbb67159c4fa72db21db6dea4efd7291d5e648b51c2eff1be1443ce2735fe34d2d9ac75cc7f327b320b1b586db317e8ed6ae60215452c75f8a369482b1bf87dbd778e56ee9b8e035b27bfed810f71402b2108c59f012898b5821917e21804336e674723026f30c3970633a8167f670801625d76249471c3c097822f45f5990d6e97cfbc888719420345c396846099be30552b756524b9247611204a620d92885a246ac96e139e739bf01c6a91b075410c9e02bdda30f286ceb2169cf794459310c8babcfc191027950db80c94bf9dcb91a953f9fb23b101de7c3b798efc6d7ecdb2c6a6a9e0aedcb873df92529f814de13cc04b9215462f19ccdfc30bf5143d043edc67bb5c2652eccf6c1536683fdc506823a0bccac23aff177b086cd01570e382aace5789fd547a2e98cbce953e6269a4442ccf092c2bb09420ca88c31015258f284a2cc50a140a957de82c1525011cb8002b4b2c80a110903a49bf2d8822d42b387eaa9da4650bb270b92db68924d49cddb622497294a02e9f40de8f3568b72d406fea29664eb684c323b910127d520892486b8fa216b4ea8c83cb211270ced91d47915003aafd371c17b8ba6f2ac5c3518dc1d427d45a8d084f3adc8cd96e4267154254275e16647a6ff76982ea3e8de99ed31d5e1dca98043c0f025f506d3edae147c9d0f9559e62c679011ae490dceb5f8158d3b04baf04a14f72cf910ba971f9e13ff8c19276b0eddcaedc4f90942a61d4b81d4b49dee15291da698a911e0946f023054ae425a138bca932a12a400acb70640ab3d0cc730d8db97d05134f3d4dc33e068016449a17c564492c5d21826f61c81505341c9368b1420aa501da2009ef827b1a49da8dcec2b730618e2525310c8d5b7c1eec464bd9c1ee0f125c7fde86c1c568b9510252400504c34e24fc0a8a3ce1b833ee34b4524432681877bab5413faa9feb614a341819acddb88cb71599afaa17868ec5d331731fcf290964692c03ac18b2bb8f76fb336429ee4f98590e0483ea50ec0ab898b792fcba69e4b93fd18173af4ea79ee8a09e9e3dfad967cf71d7a1d9987bf3f3480b47ddc3ed144da500a9336c8ae05c50cb38f65734930004eb4c5e0b02391905dccff08f17168940706e715588222dc66dc4bc6546adf75e70dfc183f979dcc4f5df1e5c8f24559e9f073af09d1a6d9366521cab53640a46132c03e3c05fd1548243d3c3b688eff68cf0e80c3c85f71f6e0162036b8db28131d0915f72f020b82f3f6f3d5b8eeed1fdd7fc3c18a67f4950044ccf4023aade26fcf46597e0fad462e53605bb25423f999ff7a31fa1ef359d7e0abcc5bc04dfd3624bd460d39f266dcd4823087c173c40f0b21df0f9d34da089226daa892029b440a10e48b01a363ac9493bc12aaa936cd945fae9d65f837e84235c9c8de5605281c3690c1f8032aa16bcf5e3cffe1bded242e8dfe8ee137488be98a820eac83e76b5a008557e255055a95455659441deba607dd5a8aaac92ad9aafccab6ae97f8fb2aaf2a7be47034f2ade8ae2ec7439aed046adadfea72af6f89fafd8e7df5ff167efe10a7ea80f84517e69a014c0e53a4fd31c8846e6c9a815312356aaba2a9da133d5a3e891d553f8e9a96bf979a9e5f26af955f95be5db9451975601adf78ba7cd9a98c79a557963255919eaa736aaf7ab1bd46e95d9a06e53bf5629552eac49f045719582d3b617d5e8aa9865afb28885afaa21caec249fda63adf7844248dea7ed004ecd86958b35214aaabc4abf8a60b18b4ac4e228532a00115f3999529c46da1147cc18540b1247f8177af6389a7697d0ede2f846f162ce17ef2467da6ab98d6a26a3c9fec96d492683f0349461273bbbdfdb831b033278c2235c96ee9fe9ca901b332063a2ef7609fa44336195f68bbfc8ee67c908dbc892ac8ac12bec48590ba356b83085c5d032ab62040b7371d801837b1544438548e9d0987155524ffad5904b1d3b86b2aea3a9623966f1fa56079c289665128e0ea1a95fa2d56128a364bd0eff0e4c973bc5661793387bf779d1a21c65498ae554d261d0c38ba886d9bf9ebfed85114b460e5c70e83a503b6ccd6d37976cb76e3870f79aa79a74c12c7d21645ebdefc6e69a85f3e6fe3c5972c7e4e14fdf35fef6f11e5509c413e20d7d2e9ade6ab5de3bc6be6a74df15a7bebbeba2c1e0704548af18d76f64cbcc0917dd04357a15d468346785d61568b31f058cacc59981cc3086698c6c8f90914869a83674696851a43dc2d6bb1b7c0d81b1beb1812c9f55a66959df9581f9fcf5ca5ced06df0d81aec841f99079c8ff89fb2bf32bffa7251f47ba23fe28d34febe7e9cf346a3633566b62ae650e95fc933eabcbba57a5a1570f86e0882f7a43aa64c50f4840976ca9456a9368873328611d95acc274f19922867aaac8f370962a9050c11a069b910ef443f2949602a396a09dd92e0c21d4520992ec02a01d6c04dbc12940474023980028804006a4b40095109520f5025855004ef2810ba90ac0aa8222d30ea461f8521fba35b030290c536b813f3ca2ee82541d69c562c4e482678eeab9f3270bd07723e6bf3a436deb62a235061db131a8b6264c7a75a2acb49cf298bd2a71fafcb263f18eabb7b5daf9bfffe68505647af28f973ff38b65cb9f61f6e6fe79ff84fb5f5b92ff3affdee3e0c11727dffbe6eb075e7e13facaa6ee13d449e8af02604621a34fabb769409300a2fe2c823e94768524ce0ad11250bd1c8f9e9ec34fcfe17a174e474fcf610d7ff39d971db46a5fb606bd50e23f429041247499fb3273927b92d9e26e311f251fa57eaa6cd1b704645ef18bf3c979d47c6699bc486953b6cabb853de26e59f6c9abe44f494a2d9da5dda8dda6511a802ec6beb93fe623b5c0afd54e6c243e264ec1f446d324e2fc770cc1af1e5779ec9f4a83f0f9e2522a0263268068e248403696ce482c930096c9a89037be9f0311ae91233915cfbc89e8220ebb576e4030bdaf802a21be89c3bd5b5c58e01d97d90e9e7e72f1e9d4c9c5451e9e91e9a7678fc27f189b83729b0e4ca7f0b0507c50c4e1f0d23a0d3b4abefed5a1fcbf167f7ef7b31f46b6f96f9bb1e6a92d77ce5f07ee329fdb0f4a80f80c206fdfb629b8e0fadfbffdde4b3f4263cc7028b3230e4b1c4cb6b78824ad2494b4325461067a0686a6925788977b2685ae23673373846b3c2da1aec83bccbbeec3fe63ee639eafcd2ffdc7b0e5f92291540099eb9800b25dae2f1957fafaeac981ca18729832dc332a34559ca25ca71c633ff39d05a7551d782955d2356891126710d02429c9aa45d5505a42d70f1840376ca3c56833a069229d700cd47021cb31f0a0854cd560910619d8600d0c97a11e3754d4e3469123612070eb525ccab5d4157f91dbcf1de1ba391a896802477161ac72d84f73614715b1d8f0b0c4e1d187f387d34dbdd9abade34ee67a1b1d5e4aa6e12806c7d0ebbc9da179fed8c00baa45102da777f9dbe039fb6e7b77d9fc77ee6879b0dfae5cf49965cb7ff1c4ca159b56fd6ced779b3700ea9e899790ead9e1a4eb8dd77ef7f2a137f621998d815e340cedcc0b6536c9362344c80b33822c9315264b73a805cc8dc21c89f73aebffe00e386a5f8e5a25215c89eb3ac89cf59c09d0035cf5fe01a14b5ce302978426ba9afd9787ae722d0c5c155ac1aef09e21cf583ae1039a629a4d3e843352be90d6ae6fd4495da783219123f6924f218d2d7ab32e680db0df75681debddd07a4c1ba6791f62e0512996ce2b451e1cce0085f2aaf476052881080aa612c934dadb97a061360222be5a3dced9f1aa745152d15e920a6149390616c232c24c4924a9de3e319b1a973b3a5e6f85b94b6b0f808968828572b3865c6b43a15eab501280195445137326b43d5c0c639b20862b8059eacabdd57ffbf5e7f9af81e7c377810ace9d1077de75cddadc2172a23c78cadd3f78124c313777800874f632a8c87f94ff568f6edb3b17ac5f75d9dcadd08bb8a108db98b709132876d82300cddfcfdfdf6ffb17f91f951f539e54f88052a16cf777f9693fea8f8a40245dc22b94ac8544e025531e374db184b8c1033cdd6e9b36133441910f004ccad83560308e4ced5428926e2780df4666e2b71568268554af02a779a5c87088ea42b2f7f7c22499a73049f6051e76304d0a2ff6d2d97d165757139b2dff0b602f1123ce00912866844533c0b9218c674fea274f669dc410ad0592311cf2b04737588163791821e9822b4818ac16043049afbafd76908276b21805edb503d375688201ba35e4d5bc68c5829d1b36b803772c1fdb1c1c5c73f9d0fdfba99fae6d5d901e3ed5f5b838bce5eab5e7ae851671697e22f505b40854e379a3dd22498ca75a4a78c64ac33cac50e22fa996929eeab28c34c8335a1aee99c24d93e64a67c57f7ad5be65d5e517975d5c3eb6bcbd7a6335372836a8b2b17ab8343c36acf28ad81595f3b86b62d754b654b7551f2a3f11fb5bd9d7e586e963bd9de48e8e8a909bc323891e25fae371a48de8220ec004a693bcd5ae6142214d1c561a92459fb736512b262ceb800974d3365bcc3693ae865d4e4eaec66ecdc46ecdec716b26766ba85c1d9ffdc2716be82a54be5e706b260a0a46e38af6a51a4810a591f88bda7eed88d6add111ad519b00073a6c315a00c9562bc525d478fec0597a41c3be4df3a7aa97c6907b4b8defe5de4e9fd4bfe7e17247cfa0550e8e168a358f3ad300ad7050325181020e20cb9d1a4de4e7cc8145ca6aef5adf6bb74935972dbd758da582e5db3f3875c35bf7bd70cbd6391f6cfced178f6cbdf5074f3c7bcb8a27a60526266a66cfa8db7e2f6838fc30006b1f6e3b37ff9bfd2b9ea6aadeea7af18ddfbffc7b9495ad26080a553078c055bf267c50f1bd661aafa482c3eb043d901a46ed55687caa1ea669266fc886876200a18518ce23897242b06b07a5bb05d025001f1e637c362e19a9c05b0f128180120b03178fe0d84e08a0eb048c96e015aa3c4824021a60f08206a8dc041f9fd983897ee3f1848f991e94deee3be52317f936fab6fbba7db48ff4241c12950ebfc329b4be57146acec7048d99270548e6ac6d622ba58be4f05e54aab34e3c4890d82c491c728ef78e68eac550c16b2c613e55aa5784884fe335c0703888301b6c9d2aab720995958340e1a15d12083dbb9d8046ed10c89de55c8c32038b91f51aab3b7ed8b5fc57633a962d68baaf0186847f7f20bbe5b1dc2c72d3ea9593d6dd9a7b1edae41a28a806cc2ae78837ed2b8541e8092608edc24661bbd0251c114e091c21448445429bb0a170ea63a15b1023028cb1389aa40496fa21205886a545964b3004bd81de486fa7bbe88f69b68b3e4593041da50fc0239a7662657232ddd36f34ee375a4477a5b167a38b9e8d2ecef4d1c88844d487f478fefbbdb718af088a7aaaf75aa0d9c5ad295c2f0b7b654d474707fde5fefddf79e9e477875075e4cff313413d7e6617f1ae3d8c6612cc10ba9659c53026cf301c4d9334e3268022919447a60d46e2d0134a2c1732b476e8d14d135aa59210c5760944a44669824421e2aa5d879ea84064c5898284734a298c3313193d94c4e39c04dbb6e4777b9e8d8de86dd5d88a5195c7781d61c1ad44e3384c877115e830cec4456ded6a9d77aa97545ed792bc2e0681a07241c2d108b4a85dad17386bfda0593f54c9baaa233fb77450a46e5047ed250f8da23f7febad6f573ea28e7a806efe6ee3be71b391bd425da0be41ac74f22a3bc83ab1153b859d21509af20fe60c4b09c5b24287b022161b42b181198d98f03299ba49245d6cd48df1d453bb5ce5085f3dd501f72e069fc0930ca7ec3be11996a6199aad13464051b07dc469e24dd432f110f529cb6d6541199be4127c861d2c342a1394e9f474761a375db895be9979447899fd33fd1e7b94fd9cfb17fb2def75892243513489f8ec020f0f049e4f382c768aa6130eb35d840a4ba3c9469a41535c9244887427d06c81a131ba52caa3a358146707ba43c26b8701909420c804cc1509d0484c8096832a0a0660dbc712279c0208acc9840b7b009c4e10383521fcb2f2d7d8886b7bcb1a8b1acffcb79ec133ffa9f33c16189e9a19041cd245623b5efa138a9d6fa0f0b600892a63041011eea448c15210c912e61ece6a44b62854976404bea4a40131d377962082fa3b3ba378b72356587308335c5b89c20c01dbddb53386c9983b7d68f7d14e1dd3dae10e1fc978b7432a326411bc896ee53a4c03dee38377f3781af006d182765ae8cd5fed083a9783ec7407fd40940587f88e017e0e5a2878eaf3fc7cf0e247f94db7317bcfbd00b6e797e76693915bf233915ede013775d85e3fddc36007854b59ea063b252de981cebeff0067efac3adc6527e070a3311166037384a127c0cd29868a308b9836a69ba1a1371749ca71f0e893b0a3f7c2c8660301ba609a49f6f6f6df9cf7f625bdbcbd236b271ee30bc158919cd0dd5da42b147c17319ebed07721e785d1575c0603f011fa413d7347072e8871c650360963a632f00a222e9f2ef2d04f17d761fc8b3d4e52d209fa287d54f8ab792ccabccb9c8992261f2d13ac6054a0a8b27088f5a29082036c59c0af8b0712a03db1314126a01f5313ed0630689cb161929f81613a9cb179f0ea1678653ef4a00689f336ecc60c0cd0194506a65164b21b9d206bcb56a23d0882f8e3823d1f17c41f1744d50006fab8201e258338f10e225bc2837350461f1c2c227f41f4793e82ac2d4b800304401800192190fd51d8fe4afecdfeb0c7257c8511f85c31463e6d7bf050ec8842754c329ee8042b767ddf033bf84cee682fc8a617d4070f72789eae75b15383d2e818b161f6aec153658f3be9918d207029dee2405d485dd00a5f989e63e23557f0708de3e8de03f7a69aadf3973f14f9e16b3f7b6a5759f3c58bfeab63daecb1b7d7d3c9f5e3675d3d6defb63db972f2f1eb67d5afdf927b88dcb96245d34f7f9c3b588cb98e437df1815b6d3743b16ef209bd53ff94facc7d8a3ae36669e4721ba0c2dcac8387f503d6c756b74547798feaf1b960cc05589f222aaaacc62d1c675938e69270b425e1684bea89b6246c045229be02f5308eb6241c6dc1e36f1d814a62018d3b63637728e1804e02f09f34dec2b83c8abcac5316b9c8da686db7ba2cdaa2c85aaf0fdbe6990ec32894aefcc7804bfc5ec065f40ab8e8822576d9aeef0770e34dbcac49cf0f9ea0c0b86eefb3295cea8509ee700cee89c27cac2188bcc88914ab270d560d024d7415848c4a245b9117c6522ea0b8bd44bcfae7cb0eb76c6ad2c58eaa052397fc924e3eb46dd8a27135b7e69690ab6e5878c9036fe4700df5d0ee13743994a242f8c1823d5eab40ad3d818d0cadb5642f412d3ffe838b13fdf20876243f859dce5fc7cee3f9b45eefaaf70db486e9635c637cc3ac66a659b85ccfbab2becbad85cc4261b6bed0b5d037dbba097805965166525730578833e5eba939cc1cf17a59344334674097e1890771ee13c46ac0f52c37ca6130a7000416a157dc28b0d79d05980a0c77dce8b2ddf144ba3f07084ee7a21cc50d38027d043a3f0a4109b0adc6095945692f5eab80c0582311c2f2c51042c16ab1ff2170291f61c38f44ee8024060410a450582ed9919cde9aca9ec9f6a27cf630e311de8367de26319384ab99ab051a8d4de812375e288c282c1bd63b291abae5ee3f7c007c2bbfbcf748fee4af77ae5eb573d75dab77926e50be6e79feafb937bffc110803e58dd7df78eb0fafbf06bfd0eafc3c3a0625e822c2e06a7b9dacf7d12fd2c7e87463747b948c442be5b2921a6f4dc9a5258ba2ed51bedeac0f8e364707a7f333e566b339389f5f20cfd3179a0b825dd1b73d87adc381b7c3473d47c31f47bba3be323aa5a7bc03e97a7d383d5a9fa11f93be2cc9eb92a152be1082ce595f489508d51f3f20025db4c516b14da4a3588451bb40313beecc248b569172560ce87a6a971c185d44ba5686e9674b81bb96ac752508e23f23e645a05cef0594eb1700e567be0f94e3892ce82231501e195167810b90f22250fe7d98dca188677aa3e4eea253f5793d78d9a17283ea25bdd55bea1f98bbe6c0fc654756ceb8bfafb175f98aa77fb974c98efc3ce637f74c9cb8b6fbe1cdf9efee1d5b9ffb8edaf2e6bed7df7dfdb5f791158ecccfa33e8632d489101864af93c81459650d21c79037cb6ca3b7d13fc6df1ede1866d2ee74b0313cd43d3438c93d29788dfb9a604bb82dfc0efbaeeb38fbb9fc85a55792a572ca9b2107caa3c8e1f20c721e7950fec0fad4f7b9ff78f01ca9015af1044212a7b29e100d0567aab504c25735a06bb6d6a2b56974180311612c3d0d03115a0f10a1612042c340848607520c25f8505f6b0e539f752e6fc4de63a9f1eff86a1c5b32c620388c41703e27f075f0ba92f085e8c37fc05673a71bfe5d30442b300a38f8a002dc7001aa5a5df5d0e4dfe4bfbef1ed1ffea1f5e7b9d8332b966cddb67cd9e6fc3c921f321ef405dcc6fc1d5bd79dbd8c7af6cd377fffca3befbd8246b8bba0685e8652318857ed21fddc40a741199da62fa327d1d7d24b69563078811714b7212804c503099b04210a15ed3ce04ba36ee0264b8dff3db3ef89f5beb18d5e030d8b1dd105118593dcb3bd82fcf1ae11fbfe2db93faa674f2f462b10a0aec914170f25f45757abb8882dbb18ad20e1a8af83a87170a0b8ebe717cf6b9c79e5c5975e3ae44a4f984e6e6a1d59ffcbf2118d2d8b73efa05e68ec3e41ed80bdd09f32ed9574a9a7b45e182d0c8d4f299d53fa03619d70677cabfbe9ea972845300396d97f4cf57b2613242793a45e0344ab996f169ac566a9596e56e6f3f385f9e27c69be3c5fe94876946b88421caf1c149f214e97662767572c2d5b1a6f8bff447c4c7ea0e2a1eaf5fdb7884fca9bcbb754ec4afe21e9ab2846a2a5c54659b1112f362a9cecb0700d6a94151bf162a30411895ce1cc0cbe3c218b74209af4d252df920082ee4afdd57876c1dfe89fe09fe5dfe6dfef67357fc47fa3ff889f8ef8eff793fedf40d978a15e60acdbf6a0cb7554c4a8830330d1c3f3fc28cef7f8d20e06ae1a6900fa36975c5f429684bc1ced4c416360e278117c386ebb9180e9505f29120081b8df765be91af4f67e18afb59c2db2163f5e4fdd1f45eff447d1bbfc3871f463bcdbdf49cedcc9c5abd0ffd211ca1ca80255e82ee81d55c52a8aaaa29dc2c617781dc3aa00be55acbc2add52d3554336d6b4d5903508b7ff1ff6be3dbeaae25a7866f63efb79de39799f909d4042e02009c90921219003460c42086f09021a484242424ec88318a5025e7c56c45aafe213db2255ae5f85109ea5f581a562d5aaa855b10a152b78c5524ba96893f3ad597be72420f6ebbdbddfef77ff209399597bcecc9a356bd6cc9e597b1e43488239de4591334c2e43d7ce014e8081a72d72228c212eec805d489ecbb07a88af4306f61bb8cfd55233a67fd437ad4d1c6529e7a191f76dca01eb06af659af5e93b105831e00c9f80f9252cc00fc65e819fbef95c862f5ee75ef47c8a7873f4141a7ad9a0c136df884c8fdbeb8e710b52bac348266a969c4c6d978133c8078f69cec1c9247db0c3ae0cd39269d65055930262324975a7f07196792a053ab8c0667860eddab5644077c4f53f0ba307b80ecd1c3a92f10b30beb5281e0cdffd851ad0922ed71d37aeba3e3fe387071fac983066f80f667def17f33ddbecadf5ab96c5c56527af7bf681b9f507bff7dbf7e8387f434b4de9b8c10919b993d74ebbb2332b355076e3d284990b66160cf6a7c46843f226ac5a307fd3d54ff3763a24f2251b6e7b90c4f3b32b347e204366102fbb9900c09a444aa8dda15181c4b9d5804b8357b7a0bbdce9249d3abc19761a91952bd42bae939be535f23db24860e4f4b8bc4d7e4e7e5d967023a1b5a3f00c4a91cc97cde3e75a733e6601d61ec3af513af8988cbffbb96ac71a9a99a34a791f5b4612e8e8edb5174c52f13a869e62f771dec39f2ac1db62bc5c098527d3c1f82a23defc74c6bf0c780af0fc625c67cedc49538b17378e58b76ec7ce9d3181ac413fdae41e5ff363b6e42e2a37f6aebfabe787e52392707e0f7dd9517ebf1eadd84b92f8372798b93323268e6f693a1dcaf3fa8281183a448989b3d398381d3a730fb089e4c56524c4f3e94412ce55e2719612ef45b57c74b1493c76dff1d1f949bccf52d05bdae0789c70c6f3f98983f323124f9f8ba7f1d392501fc0a72649a7935873d2e349db92224962923d438dbe38f80d0386faba7a5415d5be17871a7d7158da680d75d0b82410f5ce3837515119ac4e4b3c4f25c095bedf9e8414f7e037cb92e2bec3eda01125896ea7c3e5e06bb4f9d145301111edc9c4a1784c15e0f0e16bcdc59fd657cda199a8068cef3fa8422859f5f6a29f54b8f56eddd33463c6dd63bb1fe92e5b5e91dfcaeeedd9b17ed49533666db89d157ef33ed44e12d7e243ed68f4336bbd40bc4d219a225129ba016008ee4fce0e0cdc0780db0076e7db2849f7146abc7f77780a5598660615ee30e8e976804f2d5fe3aa0c75505a90648183e34e353d2348e2c081a7f74337658d0c12031c977d18c95233b54292af95912bb5b9742eab54e6a9b5b496d52bf5eaf5a48376b04ee57ab543bb8ddec66e15ee906f57ee541f251bd51f684f931f6bbf20bbe5edda21f22bed7df2b6f639f958fb869cd1464071b40412a765117ec063050969aa2de48d0bda4054827d3719f0dd0f121f50709172e1760c827d28e7050fc3e12ce70a86329bcdaef30541bf0f006fc0be1a783540b2a3db240a3459513254cda7aa1a1118cb30d7cfdb348d68e6627849d65481505bb69ddad395502864de97459377866c6b6ccc065048355888a6eb9fbdc9a5e9545262cfc29e854909a78e2fb48eb98cea153d85e76fa2e76b3aadf548fd7fe66e055c9c1e9347e9cf7a1b7f793c233521f0f9dede2631b367ddd2f0ec95ec76ae4b3757d8ee06e9f08a297d274178f9c8147b1f73119864cd31dec2c3f945dcebc3218f61377f78aedb697e1480572b873c217cd63c022576180d51c905dc70d8710da3dd4399a8891ecdd24e991d9d871fd6fbaafb9d57dd6fe1a110d68e062c1dffe38d21195aa08f0e178769ec2acf359ebb3d82c7308f8ab70ebd16fb000fef76d4d4b4a0db9f62eaad43bb53870445c9aec648c96aa2d7261251d255dda978dd2446f0c97e25594f81196c863c5c093883245f2e52c63a4b852ba5905cae4cd12f775de9b9ca7b8d6ba6b741ae56967a3ba51be43665afb4cfb5cbfb57e91b354bf764912cc75067966ba837db378614783b945b958dc203f69fd227d993fa16fb4eb24bdae77c497c477a4f3d219e707dea3d237dadfa75dc6d6947d72d99cbf4f0958eaed712db64cde912bdc4a3c84a86ecca70f2699c53161cd49ee1d813792754c07b290748df709cab39a82f46d2744fa616f0cc16676a0b3c8d9e559e3b3d9a471341167975981573e1e691ecc0996c73cb9a9b5f3a66bdfde13f39e4137053896c53354d81398ae6f678a07f9fb2c346bc3066991caad55c4ee38047560cd9e3f5066cb2cf66939d50cf190ea7cfe1702a30dd09688a0f92f39d26564b218cca5e517179ec4e0792e7857e9c9f95c69b8ed7c577a06bbeb36e07e5c732ad71088e3df4a721cda8d068585bcd575db33921b5c243c39ed51ebec16b4e4877dbe875a82716a071fd74273d1b73b616874489e567162e4c80710dfcf346b630e1e2bb4cac56e741f79fd864c2eff2e2f6366b81f0946da9b3e6753b0cbbc1f6478ec298f62871465eef26392ec30b321a3dc1b972cab6e02c3c7be5f5ed323f931702d2664dd996870b9594c8d1edb261867aad7332f8b6d6d777c1501070436ff57a979cc3317691316c9f99531479345d3ca6f3448eeed00cd12063ac1d2cd626d9b776790bc9082f6e2ddf1ed3bf12dcd467f3e6876768f00e05fb939878dcea220c15e894de9fef7baa44cc7b6aefa6fc71bb9ee9edfef953c37e071dccc3c73d2fb3a69e8dbf7995d57ef33e5bb5f3efbfe517c4c37be8cfd0d3b8e907d67b28d645754964aac4240748a40b47e4aeec000a259e7998bcdbe5a5aef444f3709ee98985f35df78bf72b0f3a1f723d677b4e7a4efe8d4b7585e20a93841835d691e4cea745fa5a7ab7ae647baf162be54a7d9ef301ba51dba8ef667bec2fe92f3b5f71bf2fbcadbee138e2fe44f37afb77a3783dae0487bb6f370a875cb81b45d398f4eddd28b5922498fb51241577a4b85c6ebe21c5e572b8a3bb51dc9ae4622ecd7d901c54993b23ba1fe5a0833a32066e4991dcb82545abf052ef64c74df674cd5525a93785347833ec0e49d3a53578bceae521a721dcc4d22b8097933dab5eb4ee84c19705bc2bdc9fb8cf9cfad6ee9391818596b42eb42e49e09b4f70c7c98ba60b1e5e45a7145b42d1ed4c4829c48d217a4aa13d3dbe5000cb9fbbd20addb8fb31b690a6a715aa217ff460a44a549ae23722befd239ebf7a0af8d721612875d175bd0f1efbc948ff888c1dbfebfd01fdfeefdf2fea3dc9b268efb92b7326e67dd36bef798d5e55d9bb10ca95d63b43f802642489fecd929114cde71274c19fe8f24aba1413f2ba0c3d64372c5949cc0e24fd3e29e1d5a44437f770928eaf8de41d2e3f75f1422cf71766f9e6ba9ed184902304156264e504dddc91edaa37ce91e01daa0fb50f758cb68f76e43b1ff4e859deac98b2b84a6f654c656cbdb73ea63eb6535ae9e8f4dce0bb21f616c79d9ebbbc77c5dce1dba83da9ef77ffdcb3cff799f6a9efaf8e1ef7395fc43fa84fa2e262747fb2e82a75ad7309aec428f9a612c11bdda857e072d9ddd057c2c821d1171393e1d57cf0e0b2436798a16b300dd662f892715de20888dfed67d9fe67fdccbf8795ec74012f42be3d6c76482ff186bcec5aefb35ee6dd4327ee72d1747245b2c67f426e850c7b8ebdc22e4cb74770afd3c41dd92ee00d2be94e365641c708ccebe1e7ec8210f1d37b12dc678e27f29ba44e2525b84f214412f8c4a14fa294819f34b94859bb98a66c73426f9300bdcdcf893d7282e8911374605fe38b7cb8aba0504b2f2874422bdb195be8b1b6e157f2f1323f4e0bc42766a8b9caa50037d65943187e49d1e0f4d5beb1238acbe23d9936bd77f90bbf0fa4a7063eeeee6d9c302467d5dc60efd2a7dc5943921b5c296256cf83ed6b57ad640ddfbcf4ccc4ca597c9493057dcf5b20574efa4cc8e1ddc30e29cc4b73cd6d44af855400e8f841f8a5fb85d055000c63596ab6bb90166a93e924364999ac56b817d0d96cb6325f9dee6ea44bd81265997a236d536e54bf4f6f51ee50cfd1332c3951c9a4c394805aa83ca1fc8ecabcb5ec76c7061974af2a3fb963304ca45991aa3145d3322883d71fa3fcd86556c5b762485a958398f75de1db3ce0d4d81eeaea8697a14dfa39bb86102273b5152aebd31d8f3b2971869cd739d7384f3b6db8d67f08ffc9d946b49b287d86d00a12261122103cba8324badc6d69bcdbe05a40ebdb750f078e07704599bb872b018add9fc014f1135c5c690d35ddce17ad83b9562cc4e118d4e6ce613453e14a19937b0ae7253cbdb09b7391b3d23c80724525ee37e2efb20fbb5cb843c6f44eec4e2e5495b8e4717c70d6155f88d32e2dae90f9c026c5f5772c79f9541a6c6ea2199d97169bc536b7ceebad10aa7b9e0f772ea3ff79afa048f776f42cba517d984422e65e0edb0b2c939442b5cb643df933702d39e464d9634bc6b2b17e52166074ec5e964e86f189d68afc8ba5ba9c7c6da5da54f8a74256e8d778aac268aa85174df50ef910528d0e65b24d45d428ca296a2e5a5324de53f478d1b6a2a345a78b6c45a191b9415234ceef9fc0e8f82836fea6cd8fe23b10c57737e21b1a4a10587148d3a439cdc56b8a4f170bc5fec5408ec04afae909e40fa0686b14c3ef10c398d0203639c407939311cde450625270329f12ad9ebc61329bec876144372fe0950310c21fa7697a6f98af35078c9310e307e400f19182edd48f5ffe7c3e694eaa3fdbcfdc7efa277f84fb39fed57ec10faf8b8dbbca0294fa1513211f4d208db8aa16b95666d5d05f2c5e1f4d3b9dc6d234aca1b40b787d61aacbc9ef2155e676868b593d5016572a6d4ea5a966f2d4fee42bb01cbf8061e6484cff36a497c8fa8f08c9dd4de590f5e10b7719e1572e274c57b3652ad3f99c7cf93c96704cf87d16793cc3e2710428c9df4129cdec8b6cbe047692f8c1549f1048de4bb2a01f481f12acc8a259fc9098ed657c216725960cbf142265332d7e9ce9e347cae91496226281522ee0c785a9de2147219501af013f17b24d7e4afca944063933a2295b907e33e58168cabb31e5f0108c4c0685e2e2f8757d7c178e067c192436a1a0f55706b0a01fc7d6288edf218e9c503ccb0e9404d8ea4024c02a021b02e66340e45b88782986f5970204826342cd1196639e55fa4f01535a2886fa610e194cf557c0dbce538c92d4df684d4932d31e88a6bd1ba493901478c7d3e6444a12533d9e0994316300ebf2f9bbe043712babc0bd66357c33c04bbcead9c08d669900aca66bd84754080babc96a410893306515743a6384df41cb84dba848f7b0ebba18df74366b274914df332fba2eef39d3833bceac5b7df937c9983ce1c35b3eff80ef37eb3dc1bf4b8d13cfb226db015cb357161a4c042617c3dc8a48323fd08912b958dc24e0b5a51b70db848df0eb9414f3f6d3330bcb7bcef6f4cd56f8708f7f9630efc1e097998edbbf77bf78f6d557f1168c5b4999f091f02edee9bd2ea4ab82434d14525491af98fa4d485798724e96f5735abbc41990e80f723f94ecf204a59fa9217856434e4f50ddc42f392db29d13db8915cffc2ccfb7e8fd2c7a2baffd994ef356de40e06c0fdedb154090bf59faceece20b86e0bd8e2e9d4d857b7b9fa725f7dd44958dbdbfa6851b99bb770c7d89bed43bc6f439b7ee82327c6295614d08c6424c8d13bcaa48655e86049bae450bc129964226f516a1a8ed1b6c15e21c14e2041482c723b8c1f0672e2115eaf369c7a37be9ade43bc83fe506facf5af4e3a8d674e37bbfb98f96f43effc3d5bd5f3d408b7a0f3ec0dcfdb4739fcb5ba370928eb31d02eadb429987e58f65b65d3e20b32f15fa43e5470a6b556e56d81ca546614ca18a2e10e53f647efdc8202a9c8329b04e8a2961423191c72843a189f36313ec8f7626f45dfc8e778ff08db403aeda258746e5909615f04757e0b5233ed9bc7364d5f3a9816b468cce17c4afde78e2d6b133865d19772d8e8f0e827303de96b26c27e3ca311bdfce803795d97e82cbac88814be68ef77d5dfbbcdb611ef472baff04d8be4f6c21f3ded2141c76fc4434b55a968a14e4e08f7c82576c1e4b7ab01b1775f2cb7db7b27ba1554a6472c8679328bfe48fb1db48b528105bb1340eb54b1ed51e14ab49b5b09a16b34499df939e087c4828ef493c9bd0d31300972fc13b05edaf9857973c18e6ab83e9bc15afbdfbdcb1576cb3ad164889241e609b6d5b493c7920e4b9cd49438ad70d8d4f8f2745ae12650fdbd3155322ee61dda1443b49e4cb4557ea6bdde59e47e35792d5098947d3f84dbf201a678f9fe9b1ceaa28ffe3e77fef39deff9964842f4e755221368365fa84b85c121bc7a84f88cf25aa53cfa5b12c2697c651703487928ba775f71fd6bd762d5f019ac95732984bbef3cc3bc0f9bd68f1322d2aac1cdf3076b0912edf2c2c9f5db2f4f2d4f4d8382a1ea81b3f7ef4a0c1c1969631431212b279291b7aaf617e28632c99d0adabf622750fdbb9d3f948055e2e349f77949abd487f425ae92da7ec11ba878edf117735b6e11e984b9e39ceb7fbae387bea0cdf3d1b5f9087f737704a0af016167e69c3bbc15bd3e6ccbde70733c7eba1418b3253e2c73fb4bd419b139cd26a6f17937c295ebf0f329bd23b933e067db38f0c0a397d9ea761bae35354e969cdee222579a7724b6876de2ba77247e5a4f55d5f5e100bf9981f7d686561c9c8607c8e6f7249ded4bcc4b2898397e60f2f72e86b06a7e44dcc0cadc53e3d0ba4e747283d65a118901e174bed931e564cc7097dc22380f088aba5625ba2fcf00d17139eec7ee129c813f856e1a54daf1c7beeddd76c095b7b4fd004c26f7d26f4593ccdfc40a82c159552cf395e77441c12a18aa80ba2ce6489c9364da58a4d9361aa71886aba46a9a8289a4864e50a9b069c0f891f415b9ee6186dadbffaaaef086c6b8da2b53c0b1748e9b8465157aca559e61a4500be31b71513ddd05fd7057d9a1d3f47f49fd01df8e3c2623c70997ffa493437ba2594e0dd442ef3dacb8531727e01b4c38258d933f8969b6fde71db6d3bd8f8a6c79ad8873dfb5a1f6ded19066f5a9c3de15b7a21be693f227ba03687f1314fcc3efe76a5d5b70c18f6f83c920cc31e049c13ac710eee5a441c932c1c2f038eb890468991223b27d00183363e320099e1bbafd8681cf1c5930fa17b2644dfc548769a284ea0e618a098af2540ac73705cf7910f4600bb6989b702e6c2f02ebbbf9b0f1d622f183de1b7774c35d71a753c0db8334271f4b7c18f822c3b786d905504693096f0d4c181a3162e6d917d34833e49f93de109bf208cfd8950f69f40c8e9ed369aed3e8ed78a5398b2d0277bbdf40b9af1332b8d2df9ff9dc696fcf5265b557f1a4abe2bcd27fdf990de7d74527f1ae59f48a390bfed5306a471ff1369dce44ffbdc7d69700d3ebc315c64fa5ec222274223157bd029a97ed14524ea10244706099150700cbc686313822e924a58058c95592a5faee171e3fd8f5cc5489312dce53d2f5ebb6821ff4ac6e799365cefded7cb78f26851dec4fb2797a68f4e2d8fd3ba8b0e4cab8e79d0396df0327101d425dfff109147809c4c4539591fd9469771b962fc34670a2360652f4bb3e40a6a39d6320de4597a0f37ec16f6243b218c051316fe43784df85c1c6263b666e916b945495722ea675a48bfd3bed9fea663549f718e7249ae37dd614f8ca7ddf3ba77634c72cc7a1f8df5c756c59d8dff4d424dc289c43f2427f897fb5f4c993bc89d9a6dec4cbb3d3d2b7d21980d609e4aff74c8f48c92ccc4ccbf0c7d336bd5b0b6e193863f17983a62e365712347667bb2bfcc796bd4a6dcf4bcb3c1dbf3af1e5d3be6e1c2ff53f4ded857bfc39c802961a0786a713b98c78af716bf87a6d734e332c74d00b368dc9a714f8c3b80e6a38b9bf1c6f839ff2db3bb24fe3b4cfdbf64b6961c0bcd8e9a8d600e8522a1c884eb2df3d07fd9747d87f9d53f618e4e383a915c3297cc25f3bfda24fd7f31c14be692f95f68a64dac9b78f32573c95c3297cc2573c95c3297cc2573c95c3297cc25f35f36072f994be692b964fe65f3e1ffa421fc1b376137815b47d710899c26021912d9006e41e408b8c5e0fa882f5247861001c2874038870bd12d8a74835b8c7025c41c42e6a3bb00dd5d103e8cb82229e07ad0e598b3014f37b81c4f36e2c9063cdc2d467701feba0b62e641cc23e0ba7abf02d783ee1088938fb4e5435aee16a1cbe92cc0f80598630171038602ccb780a4a03b085d8ea180e462cc520c99846e19ba5321f7023213e13908cf45781ec2f311e702700b21975270dd087b104e813885900b77792e85809fbb6518672ae4580898393c07e3cc439797b708b06d00d70d718a001b8753101e84ee108c538a6e19864c859a2b026c1c9e83ee3c741744be20c5c88762e45b31e02c05d783700a602e069c3782cb292c460a8b01278fc3cb5e0c38393c0bc367233c0f5355823b994c06cc93c92e9241e620cd7390da391032955442481db81e70e7e3aff3f1d70518be00c37761edef02ae1e017717b8fcaf88fd125c01e165e80a28991a3e71981127f9cc8205b288bc62c1e28038369240875bb0449c74a205cb6471348e4272009309abe44e3add821d6c2be5ab85ccbf7c719d05536213f75a3023b278ce8205922d7e66c1e280383662b7255ab044645b8605cb6454348e4212c4ef5bb04aaeb08db060079d635b0198a928405e76e920c23680ddd23b084b18fe4784650cff126185c3324358b57868c2260f4dd8e4a1099b3c346171401c9387266cf2d0844d1e9ab0c94313367968c2260f39ac0da05f47dabc08db07843b392ca723ece6b4c9b908c700ec954308fb06c48fc5f29a70dc80f0444c3b13e164cccbc49932204eea007808c6bf0ee1e10837217c19c2ab38ac0ca05f1990977d40b8bdaf2c4f1183e4024746912040b3491da901bf9c844913d836d2499a31e472786a0198bb55105e8f3146c22f1348231883cc84b0a590be8db4e2530df835107b25b8d5107302c0f59096c7adc7385560db105f35c4590e7e0b6980b030a9fd6fd17261cca2f3f2e4142d25ed00f37c8ac85ca4aed54a6d402f3c12b8301aa02cc0544f96c0af61f89d53d306bdffc5e273cef5e7510e347f9bdad951a814e9ed80d84d4089412a00732de6c47fbd0c690c83a4d623fe69f84b1d84708a5bc908089b8ee56dc15fea917fb3c06d87f8d516750694a1908c01ca2a21653b3c73be7682df8ef5c1395e67f1bf16696dc3b030b8d518de8cf97562fd70bc0684b4204d3ce6122b4d8df55c85989a31f7e510ab0d7fe3a916238e36ab161bad723645a93053f4d1d132206e3372be1a285e827998fce840ba39472e5e06f399c75d02b9b52347aa51422fe4044fd1885016c41f063e97bec516dd17c7ddf42f94bd1f7b75b4ee5bb07df4d5659f0c5fac047db97f9baeb103ea8897c42c4b1be6d7d73a387eb3acd510d281250f638bfb479250755eadd760ed842dd72c9509b7c35333ba0652bb322acd261e1eb31162fc23191af994919b332a68ccaeab31cac34de1b6cee61ae3f2704b73b8a5aaad3edc34d298d0d868ccac5f5ad7d66accac69ad695959533d72424b7d55a351df6a54196d2d55d535cbab5a1a8c70ed7763e90b2c3253ceac59dade58d55234b7a6a5157e36f2478e1a6d6495d72f6909b7866bdb86f587e7e6608af2d951b4b3b953da52d551dfb4d4a8a8adad5f52635c66cc0c2fae6f32a6d52fa90b3756b58e30a657b5b5d42fa9af326655b53755033a6354e198dcca70bbb1bcaad3686fad31daea80feda70539bd11636aaeb5b9b1be187aaa66aa3b9a51e0297c02f35e057b51acd352dcbebdbda6aaa8dc59d90acc668843c9b380af881e368c1d0e6967075fb923603e8e8a8034206e4007e7dd392c6f66ae09dd14744b8a9b1d3c8aa1f66d42c5f0cb807c46efa87b963f46a5efa969a565e4acee1fe0c78f228aeb158a2ac7ac8a5ad6639af8e967ac8b53adcd1d418aeaa3e9f095566d16b5a0c285118b202b7bdadb9bdcda8ae59c9d90c71ea6a1a9bcfe7d048e82bc3d806792fdc04d2ce7bd14eea00095b06cf27b147eefb7d16c89cd96a78eba8161e12b60bbf109e05bb57d8273c3d005715f65a7dcfc71077cd7979d59c870df18983c451e214f14a711cb88510bb0a5a056f6fe65ba18e6ea33f82211bef05f89ba3057b6f8ec31c3f92c850723fb9f89f40f848c9436884ef5e835157397b369d158a998484deb7ed8367c314eebebf48045775f64e983975664e0ec432c78484d8c13b4dbf026c3082647711cad6b30789c01e620f01fc307b18e047d823003fca1e0378133b0df09fd957009f138002c12bc09848881126017ca53005e0a902ccc384d5c26ac28435c21980ff2afc1de01ea117e08800348b446c85b14a9bd80670bbd809f00de20d00df28fe00e07bc51f027c9f781fc0ff2efe3bc0f7db7209b5e5d98244b0e5db0a001e631b0b70b1544aa8748504f94a53a57280a749b3009e2dcd0178ae7435c0f3a47900574ad700bc406a03b85d6a0778a5d401f0f5d22d8449b74ab7017cbb7407c077ca9b09959f909f2082bc45de09f02e650261ca44054655caf714289db25a7904e047952f00fe937206e0bfaa908b5aa9761041bd5e8711abaee90e22e84e3d0be0613acc02f5a0fe53809fd49f01789bfe3cc02fe82f02fc2bfd3700bfa2bf4a98fe9a7e12e0cff45310fe85fe1780cfe86701fe9bfe3780bfd281f3fa39fd6b80bf81ca13ecd47e0046712fda7f0df04bf62f01fe8bfd0c61f6bf3adc843a3c8e442238921cf3f96d5f569d3392869c37796e72dbe2339471269468b6027c53e629502265beb208e02a6509b8b54a33b82b954e706f006e703eac05f766e56608f937e5df005ea7dc0af06dca1d00dfa97c1fe07b80579c4b5f5a3c61c08d00c023749843eb397a0e96f73f01fe5cff1ccbf22b700fda617c6aff35948b97220edc78473c9425c1910070222f97551e8ddc4ff7135b554bd562622ce96c6924e397b6d434906975358b5bc8a2c6aab62668fd1aa17366961ac447f80a6706dcd02d08e63ac81b82ad89cf771c039e29cc199cd1670a2d0f304d9d5d6690382b06e357b658b000bfba89a7a1a6a589d4a1db846e1bba37f097135983eeede8de83eefde86e45f73574ffb0bc617903398b6e2f77a984ae13dd38740759e5bf98cbc067037c3cc70468b7f1d91cd0ab41e9ed3883046a8997c4005f62a144f12481249224924cfc24850c22a9f096be78ba8b85f1999b789eef02fcdfe50f8311f102e80f1ba1d75b45d691bbc87de411b2993c4dbac97ef222ccebde221f90e3e4737286fc9d8ad44e9368161d4d4be9543a9b2ea02df45efa10fd31dd4abbe83efa027d99be09981542e9ad903b25d49b0334829f520794826f10d34f3b6eb685f475a63fbad7f40b5e37fdc291a65f64ca05bdf2ace9977d68fa935f30fd190611f92d6b33b61289dfc678ed2a22f1cd0f55c7cdfc973cc6a921b4ba059e65f01f33c3abf7987ecd48d35f1a87f1c4fa91f513ebe7d62fb39edeadff7c1959e6339f96bdb3ecb365bd0d5ef3a9614dc37d0d4f36ec37d337de64facb97997e5329c652c283c2b9e1b2f0a2705bf8cef0e3e15d18ea687ea4795bf38bcdef367fbe82acf0adc85a51bc62fa8aea15d7afb8cba4b6650c77c15f64626ba935fdd690e9b7759b7efb6766bc8e45965f8bd2463bee26d4d58c1caa271f5009ea2d9786e822da4c6fa6af30c682ac85ad6277b2fbc03ec636b32ef612fb0c9a8e5330c05e25340b2b85978437e11d9124ce135bc4dbc51f8b4fdb726d8f0b2fd95e960c6999d42c6d913e109cb224fb20051879a23c4f5e2457cb5be5e34a91f2b47250795df95af5abb96a48ad55ef53cf6a41ad4b9faa37e977e9f7eb8feb5bf5e376afbdd43ed77e9ffd1d0771688e1cc74447b3e321c7664797e32dc759a7e2cc75b639ef75ee71beec7cd7f90797e84a778d705d05d2ceb57f5c73571c3942ff1cd940cf81fd26b28151b06ae408d3c0bae0778afa4615f58d5c4bc875845cd3c8f5835ccbc8758c5cc3c8f58b026afbb8968f639751bbd49fa60ed3700d1bd7278aa817e35a31ae0de3fa2f11e9e17ac422932e68d11807f071cd1ec7cb758783107f1d6a0db9ce906b0cb9be906bccb8ae90ebf3b89e906bf4b88e906b081da82134b194a26e906b063916ae73e33a41ae11e4fa409e9aa7e474da516fc6f5805c73c675805c03c8f57f5cfb5786298ea0c66f1e72e10be811fa4ac5357dbc645ccbc7757cfd79955a9496a25e8f6bf5b84e8f6bf4186af4b83e4fc09c79ae5c97c75067c735762c1a4ec94ed4090b58da23a8bdb3b1cb22d7b1d160a7829d11d9cf6647f6437b704552214d2a8c9036433d97423d97423d97b2a4c8936c2899476c107a04428f4028aff95f42cdff920810faabe8934873231f337fe43d36247288dd15f998687464e4639a0d7614d83cf8d50d361eac01361d6c26d800c454e988c8dbf432c0668bbc0dd2550758eb006b1d8b83fc80a78013248de7457c10773dc45d0fd82701e64980791250be15a8a9031aeb80c63ac0b39e39228f312fc031916e96007e12f8c9e0a780352293a0648bd9b0c824c200ef1b90db1bd0c373290649fda7e891786c1ed38a75475f2ce282d0e721fd06a0f153e0c0a740e7a740e7a710f379e0c2a7c0854f5922d854b006d84cb0c3c006229f7e0b6f34f7683dbc7d5e3d48964c7d0df2f4f5402e100675f218d4c56324cd6a2958cf2073a92073a990c711a0f20850994a73c08e029b8772b0ff026e1e016e1e01ca5319a467bec834e0c434e0ea32e46a0af883a05f30e0b7c191e9c09d0d2c03c28692fd2c0be20d83f0e19169f0beeda3d40d7c076a2de9dff01d757a2115e7d7691cc017afd74eac572e7f5dc0fd2ec0d80518bb80fe2ee0fa7b10ab0b38de05b1ba80e35d302600bafec7e5ca0b983a20ff6ec0d60135b1153076000d1d90fa0850bf15521f017a1e030c47000397acad80a10368eb000c1d405b07d4de56907c6857c4f12d69ba9824a55f204d3cd53148750c521d8354bc168f41ec6310fb18c47e036aecb790e218a43806b5f45b48750c797708521d82548720d521487508f23a04290f41ca4390f210a43804bd405fbbe76d5effce747d6932cd7490cb2118b7b8221248a4449e8a7490ad60bb2287a1e7da15b90edd0e18b5ed028e8f27a56c42e424bb825cc6ca2287d96480a780cf7bb1f2c816360d7ab219005f0d61f3493c6b047f39c46902b8835c469cac08423886324c7912526e86946f40ca93ac027e9b01cfd017028693ac126c0dd8e5404b2ca4dccfc6438c1062d8cfae402cfb01cb7ec0d20158f663fe15408789653d60d8cf1641bc5ab08d00735ac2605700dc193909a3ce8b941b72ea809c3a2097c390cb7a3609e82b037f0a60e518e703bc00ec2288732dd8c500d780ad05bb146c1d842d037f39f8ede0af047b3dd84ec02fb172e0c5342ce93e5605fcac83e7e5c01b86f93500559ac5a1c32687e0f772e0f76cb09ca7d7823cd521574e12c5e2421f2f0f03174e222f67000cfc8337cd406e9b79ef83d9348f730de61c4f542bc549133f584e5383f92bf0ea24d45d3cd1b1eefa6a80e75b0e7e05f0c4cceb30f0e330d6177018c6f5aedeef41cff23de8590e43cf7218b8bb3ecad910c4eae7ee80b2a2341cb6a46133629d8f75781d947b0b947b0beb80b04e785bbaa2f4a04442ac3e4c53012e4749586fbd5bf7a13cf1d25d075c8412c14ca36f04f454640bd0b6c5aa792e63fb5908629a580f03c6cd2857262d9ba1e6b7002deba1d6b7b06ab03510568bb45dc7eac1e735df80b5bf1e38b185b5826d07bb12ecf5603b23eb492670e73470e774943b26159b818a931697365b1cda8f523e0ddb84c9e76bc072f95b08714cce74b0ebe0f72aa46a335b027035f835105e0bfe52b05c26ebc15f06b601e030f8cd605bc0b682bd1e2c974fc5e2ea7ecc792a602c8fd6f03ec0b89fc848575fcb33e9da6749e46190e2326cfbff97b7ef018bea3af37eefbddc0bc8951042d5104208259418420821534b59eae7dc65713e4b28853b33372c414290126b61b8f37f98b9330cae75a9b5aca5d65297b294b2aea5d6524b2da5c458d7b2ae35682c35c61a638cb5d65a63a835d67eef393317479a6cbf6f9fef59cff33be7bde79e3fefbff39e7beecc20f16745f76c1241c8cac1531b4694183f9a886a793fdaee78d40b88fd9e8afa5543340e0ca1f751bba0efebd67e067b45bc6e02adba94f046d73959d762d492c3515f1d8a59235f888e4dbc6a286abd5fe3c96a2d8d119178d58e92dc83d67e85b6790e6b1a106ba97f93f6749d1279d90dd4df27684451114ecac17148c1deb8c21024fedc198144b457289f44632fcecf1919a91d4757a3b169911e9b70a4e3513e8e4747388ebd090fc7694b16fb1ca76b34313ae3f1187e276222df71c227cafa6cccda56d14249f3fd9e9be7f20e87348247a326ce84f109ed8b633c4e63c55aa2fb9898b13e3a36e187a5b5449b1c9d818c4c224e420c8f117974cd7f2eaa7dd2e295e8ddfd0bef52a9e3a8d55b6222d4227d4d53dd13bfa07ac7181bd158541a6c99822d9fc2964fc12eecaf4463e19d1e4b698f8895dec63513e94974e08c7a58fcbcc662b9d7794b9cb7beaecf3bd6d675791c25587017b5f45cf4eab3547beb7105b4d355496d43b4addb3fbabb7e6e9e1f5da33ae7fa5d32133b2f6ffcfc8e7727f23460e469a03b7e223d29fcb553020b4fd3774fe42f4890bf279103e4d3e1473171f004a638780a138fad9ec667e28f628a878f41099e6f4a312d22df87c027fc5a4c225841c1335f1df9b6037c1fcf50297010532af318f338dcc73cc13c014bf03cff142c657ecffc1eee67de65fe00e9cc1f993fc283cc7bcc7b90c9e2c3353cc4f22c0f0fb3f1ec22c866457631e4b2f7b0f7401ebb945d0a8fb2f7b3f7c372f60136031e631f621f46cfcd6173a090cd6573e149f651f65128621f631f83a7d802b6008ad9621679674bd8ff051f6525b61c3ec156b015b08a35b15560643f8d7bb18995590bac6115f4ff67d826b619cc6c0b5a45615bd9367896ed603bf0e9d3c1bae0797623bb119ad94dec2658c7f6b03dd0028cd024ec229f84c319280668eb470c02633b8de5086214e973588e21f623a6a238843812c50c407b0b96b3883388f3d8e722969710571173885bd886452420921169887444162217918f7dae6059845841ef31b6ebf43e63bb89651942429810550819980e347b7b1da211c03e8cd88dd80b8c7d1ccb49c441666ddba0adc416d7e16f9bb25537d7db9ada2ed9da286ed91ced09b601a477b7d77588b46cec10db2fdb7c884d6d23b6956da38831dbca7585b695ed473b6ada045b79db7e5bf97c9b599b05eb5662ddcac8f8ebb6b60fd9eadb77d9eadb0ed9aae9fd23589ec1f2cebcbe18babeed2a96887616fb2563db39c42ddb005e0fb467d986295fa49cb5edc63926f1fad87c39673b4971cb769ae292ed1ce2627baeed747b3e6285ed1ce222f63fd75ed5215048b69b3aadcbde5cdf9149d0eee9584eb1b1c3807aab6eefb1ed2032b4ef413e0791bf7d1dd03ed1514a74a1eba0fd7287826820b247758ced717c822cdb4d5d7f3a505f6b880e75bdd1b14edc19af6d06e53f1fa3b7299b85daed10f230bbae6fbe7ee1fd183da24eda08d0bef531ba0ec5dafe03da38dad350ee64db16c436a4b7117b20bd83d6eb488fd887d82916d4660911bb214f7ba3e578d47ee3c8ebc185f66b2f423b117b95a18dcaa2b622d8d311a6c8429d57614980f51d9b3b0482689bad14b1f5c4be26443efacb60d4afd1c63876c4bfe54889f5a7b13e55f77b5ab6d0f2265e2fc3720b96a97a7dfb06f40f0d7d83209656efd0e84339e83f85143da8cf595b6b7b2fea6e3b825eafeb6bdf893e75c7569be87aa92336e858a583fa840ee21ba7a2f459c48558dfd3d721ae3b72ef7247335e3bb05c8fb0b55fb35d69bfd1e16abf1d2d2376d88bfa9fa672dd59275710d789dfa33e2b506f95e43e45bfad98ae49e2076cd4c687d12607701d44cbb6a90e3ff57fea93741de83e6bc1f948994d788cd463a9c786589f8dfa20f147b4511bf139ea53d1b5afde206320aee21abf6abba8dec6f53e8b988b5cdbe3508eaa3bd711ffb06753c4f88a2e17f5858488dde97502b9c6f1f56bb62395006d6ab0e7a1ec342674f8db7bec0544167b31f287ebd45e82e5192217891fb66c0a36267e21efb8bb24d14f4e817e669a403f2d4da49f6926d34f3353e8e79869f413cc07e867970fd34f2d3f4c3f31cca59ff715e0282fb3bf63713fe11ee21e02967b987b1838ee23dca310c73dc63d06f1dce3dce338fa13dc1390c83dc93d098bb8a7b8a720897b9a3380c805b96e48e6fe81fb47b88ffb02f74558c67d89fb123cc0fd13f765c8e0bec27d051ee2beca7d15b2b8af715f8387b9af73ff0cd9dc37b87f8147b86f72df823cee5fb97f85c7b87fe3fe0df2b96f73df86c7b9ef70df8102eebbdc77e109ee7bdcf7a090fb3ef77d7892fb01f70328e27ec8fd109ee27ec4fd088ab91f733f86a7b99f703f0103f712f7127c94fb29f75358c1fd8c7b053ec61de75e8555dc2fb85fc2df72af71af4105f73af706ace6dee4de844aee2dee2d78867b9b7b1baab85f73bf854f71bfe3de0199cfe3f3e159be9497a0812fe7cbe1337c056f82567e0dbf063ecb57f295b081afe2abe0737c355f0d6d7c0d5f03edbccccb60e32dbc053a78855740e5ebf83ab0f3f57c3d38f806be019c7c23df082ebe896f0237dfccb780876fe5d74327bf816f038db7f12a74f10ede051b790fef83cff37ede0f3dbcc66bf0053ec487600b1fe6c3f0457e23bf11b6f29bf84df0257e33bf197af91ebe07fe89dfc26f816dfc567e2b7c99efe57ba18fdfc66f83aff07d7c1f6ce731c157f91dfc0ed8c1f7f3fdf0357e27bf13faf9017e00bece0ff283b0931fe287e09ff9617e1806f8117e04bec1efe277c120bf9bdf0dffc28ff2a330c4efe1f7c037f9bdfc5e18e6c7f831f816bf8fff118cf03fe67f02a3fc4bfccbf05dfea7fcbfc318ff33fe3fe007fc7ff23f87fdfc2bfc2bf063fe387f1c26f957f957e127fc2ff85fc014ff4bfe97f012ff1aff1a1ce05fe75f8797f95ff1bf8283fc1bfc1bf053fe4dfe4d38c4bfc5bf05ffcebfcdbf0d87f95ff3bf869ff1bfe17f03d3fc6ff9dfc27ff0bfe37f0747f8dff3bf87ffe4dfe1df81a3fcbbfcbbf073fe0ffc1fe018ff47fe8ff00aff1eff1eccf07fe2ff0cc70546e0e0a4c00bf1f04b21514882d3c2626131fc4ab847b807ce0af70af7c21bc27dc27d704ef890f0217853582a2c85f3c2fdc203f096f0a0900d17851c2107ae08b9422efc4ec813f2e0aab05c580ebf17f2857cb826140805f08e502814c275a14830c0bbc20a6105dc144a848fc37b429960843f0975421dc309f5423d132734080d0c2f340a8d8c804f8deb9878e133c2679824e145613d230a36a183494e4a4c4a645292be9b34cedc2be2e32f73bf1827c631e9a2200acc03628298c064888bc445cc8322fe6332c564319979484c1153982c31554c651e16d3c434265b5c222e613e2c2e1397313962ba98ce3c226688194cae982966311f11b3c51c66b9982be6328f8b79621e53202e1797334f88f9623e5328168805cc9362a158ca148965e24ae613e22ab18a5925568bd5cca7c41ab186a9166551663e2d5a440b53232aa2c2d48a75621d238bf5623d63161bc406c622368a8d8c556c129b18456c165b9867c556b195a917d78beb99e7c40de206a601187605ebbff3fcfc023e8fbed008cc3a7c8e7e019f895fd880f420962ac283d0a2d888e889a217a0390fcbed889d8821ec83cfde2fec42ec41ec434c200e200e238e224e204e21ce222e202e639f512caf216ed07bccba317a9f5987cfed2fdcc639e2108b10298825588fcff1cd19886c80d666c47a840d985617967e44181e8015500e55783222dfde7141087aa00f06f0ac3a0693701866e0345c80ab709389639299654c3653cc9493ef132bfb9ecd56269ecd530e3c8b915bd9ac9c51fa95f34869ca59a557b9809443995642ca31a4d62b471497328354a3b24f69518e226551c6957a651aa94a6550a9514690929421c5a4e069452951b628e5ca36a40a95ad4aa9d28754aeb253c9577a91ca507c4ab6b205a954a55959a6ac472a01c74d563620b544a956e2140b52a25263bda92848b14a99f5aa22016bbda1acb45e50ca91baa22cb79e560a913aafe45b679422a40ee0ddc34a0652e34aa97552c98438eb19c5842daab0856c9dc531e23037616d15d6cad64b4a1db6de6c3d63dd6a45f95bf658cf5a37b6ecfbffb627f2f4fb4640bf6914f94e4f22fd3ecd52fa6d98fb8141ab84f0642ca2bdf2011ad18f1ad18f1ad18f1ad18f1ad18f1ad18f1acf4681bed478390af4a5e73761895c36a2ff3c8ffef33cfacff3e83fcf2f41a0ef3c8fbef33cfaeef30508f4ffe74b102b11e58835886a8425a6be1ed1846845b4211c081f2204b00ecf94ebf03cb90ecf93ebf01cb9ee3ce45bf3ac05886244c9ba646bb9758d758935c39a6d9db63659575a5badd5568bb5cdeab0d65b7d9887ac9b306db16eb3eeb00e60cdb07537a6bdd671a427ad07d799d655ad930945be4586fa4709d9ebecbbc0b27f405bc4515b08d416f1d41622dae26368918fcf5be45eb4c8a76099f069b44b06b5cb83822228f010da653764258da2751e497a2fe94ff091a43fa38d96ff0fcec4c04a50a9ad0b20e1bfb613c68b048b6af15834cb464b8fa5d7b2bd997c3b25817d877d078939760e18be842f0156a816aa8143dfb3429cf02c7a209ff4eda46f8390743be936c4ffb7fa30a957ee23dff7179949c098d382bcb62423d210e9c06ae86b2d59885c04fa6c4b51f47a05a20c2145af4d515445dbc888ba79302d2ab0c13860312eb2c145b4849646a453903e1483fd58b704911101a943176583d991fe1479511444db172350d2e04a44f97cfb3b3c61ec6fd980c0b8dfe2a163109e699fe8bcd082fb40cb46da8e0dae89d6f5fc3780fb47cbf618e01ed23244f5c1366ac03eb7711ed0b22b52d748e6de4379a3fcd1eb7d1f88c8fd0952b2afcb9b9d538101b5c2ee090ccb7deef1c06eb5d29e1cd8abd6b82703e36aa5fb20de55b066526dc0fca0daec9e0e4cabeb5557e018ad19576dee638193aacb7d32705a6d709fc636a4fd39ec3b19b8a8fa91be4247bbaed6e02c17d50aa46f62cb73d8b2c67d510379c4b55313d4b03d5913694daabad97d2530ac6e755fd796a97dee6398f7db5b301fb47bb44cf990fba696a38e38ae68cbd57e0f6885ea28b6c954c79ccd9a41dd8f79a93a456b0eb92e6babd4231e41ab50673c22d6cc62be4c3ee449c55efd9e655aa57ac693a919e4f39e1cad463def59ae29589f8a2d2f790ab506f52af66d463a15e94b1e83b65e9ef5946a3675ceb34a03cc2b907fd49be6526f792a03e376d6531338684ff02881734837a08c7d9e5122454c3eea19a334e6f62a5a43a4ebc7fafd28d75fe476d933a529f63acf2194b7d973441bc47c26302dcf7966b54c7ba3e70c8ef301b93ae539af8dd09cb4c45c1da4f928f6cdb1277b9a35bfaa78d623b72d9e4bdaa87d03d68fa92edfa2b593f6348f4d037bbac7857982c78f6d3c9e39ed885df3dcd266ec2ab6dc2f87bd6ce0e28b0d9e30b6c9a21a88f4caf5546ae1684dbe67b3b6d95e84f956fb0acf56cccb3c7d5a9f5da263c6e6264f3f6acfe419a439a137baaea1bf8d3aa7b45975bf3aa29db1f7781334d1deeb4dd61aecdb7196319468bf769efadb5e2ad714da62444b8d70a8567aaea2d791fa43f69ddeb4c06979ce9bae5db21779b350879bdd93da557916f53f671ff2e66ab7e4196f3e6a6f17a1ed7b082dcfb82783ac7acb5b84fe496c376bdfe75d114cb04f780cc164fb01e47caffd30faf9305d3be3f6a3deb2609a7dc22be1dd135e53601c2d753ec8da4f79abb0ef59afacadb25ff0d6a14463f26642a3afceaa87ecbd489b509f07b1fd7e6dd98b7d84b65ff636223fd7bc2db8a646bd1bd0a6b7bc2cf2267bd560ba3d8dd2373c478259a8f9ca60ae7ccbebd1cedb6fbbc783f98e38af162c722c422b0c23bd31b8c29142c6742cf1f66839115a9df2f6a22790be658e0cef76ec1ba1b3092df7797706f63af2bc436b8f390abcbb0217893f04731dc5442247098eb01bb96a447aa577cf3c5deedd879181e82a0725421a7d0f69c71a423baa296d41894e3bea711cc9d184e350bb042555f14e044d8e566f0fd6b7516e1dde035aa6c3e79d406e47bd87910eb933b4cd8e4ddea38169fb0aef89c0b46393e708a54f511a5787638bbd77ed24c68470b0cab1cd7b36283b76782f04eb1c03387ea33a2a8f055b1cc318493249040b26d3961bc82c41559df15e0e4ab8ae2f62d49af11406257b027272ce514c6d2145e96bda32c76e7b72b0d1b1d7e95a9b8dab00bd5dbee5190d7a541bf107d4f90d4d718c47f57c0d399f8cd0640d46f44fd769a6e32099579ef2a4a2d4d3dedbda8ce3982f0e653f896d06d0a6d7d66eb2cbae346d9563ba73bd26384e77dab466a45d94f653fa4efd499f0f2da57a0ad76e52155f0a7aceac6f097a4e836f374a34ebdda5e538679c53a161e7acfb7a68f78b0d6417709ee90c87f63aaef88643e324c68626ed59bee1c0b8f37ce766b423a5e539127b9d973ab7860e3aaf76f669ab9c73ce70681ab5e70f1d23913f7412a3ab183a6d97903e877dfbb529e72df7b9d045ac3784ae38c631f25fc7fa41f481ddde89d07517db39a2f53b4ea2b6075c09581fa5917f83d6ff62839f45af9ef18c052f382ff91370de7e7f327abee44fc388d148e29823c59f8e724d115aeef365e02ac6b948fcf465a3379e46cf99749cc3bd69afbdd7971738e938e72b40afbee82b46cd5ff1956861c775dfcac06ec74d5f396aa9d25712cc45bdad419f1cf5556354a9c0963964d7086af2669f85d6d407cbb0655370a3137cade8c9e77c6dc11ea7e073047b49a40a6e778aaec6c0b433d5e7d34447bd2f447628471e72deeb14823b9dcb7c9bb065837742bbe5ccf440700867dc829672f9b605ce39737c3b70a7ebf30de09aaaf085d02b76fb8683bbd430d955710fcad11a9ccb317689ce42fb05f4e438b53fb8073df93446a111b521b88fd0c1099c7d0d6a63abfb62f080d3e0db1b3c6c6ff4ed0e1e456d8c074fe03886e0298c9ce3c1b318313012aa53844fa7df9f154e4779219ce5eaf1e786735dbdfefc70be6bbbbf285ce4dae95f115ee11af29785cb5cbb5457a8c4b5c72f8525d73ebf296c724df8abc255f221df152dc775c02f8765d761cfa5701daeeb9df88480fb35ca62f1d7213d48d6bb2b196d37ee3aea6fec5254c5391a3411ff09de40fbb6044dc4be481ff06f0837aa537e15e3c321bf27dce23ae1d790ab53c8d506d759e44a755df0a7e931441ef56fd46e911d21ecc1bee95a18232aeeb638570ffa552fd253e8574813bfd2a6b04daf168ef88fe324a5e9fee8bc84bbd5a063933f59dbacd39ea9d041c738f13d47bd7f3b890684564791cec1717606aebb2efb87c29a3d8bd0ea887f483338d6f877e9fe897de769d5e6ef0d6f74c4396e867bd441e754b0c575ad3333dcebcaf5ee096f77ddf0ef411f18c50893e6ba8d4f3e63ce11dc077388edc23b89edc243647544a4085e705c718f776d252b976a2fb23ace6839ee38ff3ef4995b2869bf33d3bb2b7841edf78d072f3b4bd11697d50a7c82ca71ae424fb886f1c710649df83418bc816bc7477cde3749f383d8a6d2371dbced5ce59b0ec591f698d760bec8bed1776c6d0ab62f41ebccfa4e921c57df32a7e281508a7cd5773a7093f812d6d3b9481e5aa28ea997307a3438fdf379b35a11ca88e4ea7e7b6f281b3dff5c70c8b9de77319447f3029a17d3f5d242f96f89781ace0838a3cd773d70dae9f2dd24f19978a6d3df09a195ceb05a89b9df99b336433dd32984ca699e4d72cde0dc6c4e08cae899062229eac7a35eea14436b90939a50b573abdad058eaecc3158d6baa3375ed4d67bf736bc8a29e776e5d7b13357952cb3427742e437da236821e674d67268e70b533476b7656e04af73886914f0fb1973647f250bddaefdd156a227138d4e4dc8a6d64473db12cf2a9202733387b6be4a90c475b1ee5a7cd39d8598892e2d369c8e11c91fb7076ac5fbbc959d96908f9e4399f2f2839c3f24850b637e22e99e31ced2c0d85ecc99dab429b9c639d15a12d4ea1b330d8ebdcdf5989da9beaac096dc35c09ed5095ce068c127d9dcd81eb182143da79e7215f283440f7889bf211f7f52e7025e3d3fb4d8c12c7705da7d93da16157bafb5897803b9da74b244fe05da92f9213c180a31eef0e90e7f9ae6584eecaa4748ebd91d064c7ec5a2ecf619b56521f4c53a7906e2291adab509d75dfec0242633da5ed07c819c495459ef6ed92cfd765c0b503a126470ace75dd7e8af043d64857a973047958e5ca25f5aefcf9fa0a5a5f49e91a42875a1d5bdcd36bb3c97921546ecfc2f6175d45d846715cc13deb3a9105f729a4bb1a288d11988ca08eb92e878eb95620ddec2a933777ada7f5cda4becb4669176d53ee927c9bbafc2e53e7a836ea923ac728bd1f6953e75457d855d57908f35cdca3afd3fd740a77195fd7667506f7dcd3942ea5f424a5b752bad59ed67904f7f40b181b876269c749d461ae4b269eec18409efb5c759d42573fa52b283d88ed6730c636da5bba46e4cd9d335d39ae16a447497dd7986b8353e81af90b7a3f6d3fe54aee9c45bb17c9335d87d0ff67bb8ea8cdf291ae99187a96d267081dca469e4bbacea39716869650ba86d02426eb74d725f27c82cf90d99d62f014ee6b3e7c06503bc5aeab8e697212c46798335ab33ce6dad93587ebe84cd72d7c1e384ddadb35b4d1dd347d4eb06b5a3ffac92479e6b16b74479b0cb32ed6ae851308dd7584d2c9f29c53c0a79aa2cef3e13497a7f392d6ecd23aaf62543cd33917bce0dad8794b33743bba7ddd21b72f90a2ad723b0229dd2b716585d01b3122a1cf9053e45512b135c5790457932992bb17f927c2bbdc29fe03e13dee251e5b789f3bc37f383ce1cef61f0d1f889c91dd799ecaf06172d20c1f25a7c8f0097781ff043e15444eb8f46c1b3dd5c69c58a367557a4a7517fb4fdd7d568d9c46dd25feb3e153ee95fe0be1b3ee72ffe5f005f71affb5f06577b5ff46f89adbe2bf81bde838ee7aff6d6d99bb291017be41e60ddfa6f3169279bbe3a2a76972762e2467e7ee458493ee14ca49e11d4eba9744a48844487252eece2067e4ee8c885ce4e48e23d3f335894ba42ffaf921b2837467931da43b8fd474179035d8bdc4dd6a6fe92e8e8ed64ff96c0b2cea2e7187024b42bec8db89c81b03f726e75477b95a83cf39e3ee2d818cee35d17711f4d4efde16c8eeae76ef08e4755ba2ef1ca8dea26f15e8f9ddbd3750dedd1a7d6b11793f10a123ef2bb05757857b2050109a740f078abb06ddad8192ee7af7eec0caee26f2172de8af0e21e657872cfdd5615cc2aa040bf0f4978619f497860fd35f1ae62438127cf0444220e11fc1407f4568a4bf22ac4a7a34a9106a922e255d863afacbc7e7e8ef1c9fc7398a2007fe060024f87b4887460842317c1e530d6c852f412d0cc037c00cc398acb01bf680023f84fdf01c1c8257612d9c85b7a01dde86cbe08439f83374322cb31cfe81d9ccf4c01ea68f7915bec7bcce9c8777e25ae33e0befc50dc57d0bfe1c3711f712c3c51d893bce24c65d8cfb0d736fdc1ccf311fe273f847980f0b9b8509e611614a7889b1082f0b2f338a705878857956f845bcc0bc109f18bf94f972fc83f199cc50fcc3f10166383190b891e5133f9fd8cb2e4efc4ae20e7669e2d71377b30f247e27719a7d2cf178e229f6ef125f4f9c639f497c6f511afb19f24913db95949c740f1b4e4a4d5aca6e4cfa55d245b6476c1377b27de2bb8b59f6a78b1f58fc007b7cf1838b3fcc9e58bc7cf172f6b5c58f2f7e9c3d0d0ceaa595be29cd24bfd732f621fa118388114837f61b078d23c651e39871bf710aa943c623c619e3acf18cf1bcf192f12a9673c65b122b2548c9529a942e6549b9e4b77fd4b690604c30029b604a30d1df48a6b2f96c3e00bb825d010c5bc29600cb7e82fd0470ec2ad60871f4fb5c02fb49f69310cfd6b2b590c09a590512d9e7d8e76031dbc83e0fc9f4fb5c29ec67d9cfc2bdac9db5e3984ed603f7d1ef732d457de7c032e115e115f2be1f66e10c952c95fc22d2d8048dc62663abb1cde830fa8c21e326e316e336e30ee38071d8b8dbb8d7386e9c341e344e1b8f194f1a4f1bcf192f6279c578dd78530249904429555a26654a39d272a9503248a5d22aa902eb52a54aa94652a406a9595a2fd92497840ff3c69b77126d43d255698ea6d4f9742b9a364b5ba5bebf65a57e044883d208de1b456a4cda2f4d4997a443d211bc9a9166a533d279f2fbbaf86fa23697dce5e7e4ef2914431b7a6d09b8d1e757513fffdfe8df7be093e8e13f844af4ef57e119b884a98aeae853f11f8e7f04aae33f12ff11a88d7f2cfe3190e31f8f2f00737c617c2158e30df10650e24be24be0d9f8d2f852a88bffbbf80af8fbf867e3ebe0b9f8faf87a5c2f0cf4e34a225ace069efa0c1847116388fd882928359e355e305e365e33de30de96e28c37a445528ab444ca90b28dd7a43ca9402a964aa49552b9b406f36a8445aa979aa456a90d9343f249216993b445da86f90e69401ac6badd58b7571a977cc653c6a3d2a4f128a6c3489fc0fca8718f719f71c27880fc1631a13dc14e7f6dbae82e6db93115c3cf313d0d6f6232e0aa7f0b3e0a1731ad88af8aaf828fc5d7c6d742497c537c137c1c18f1fa62fa17736039c403d42423d28091af62998ec8427a0e718b2baa4990cf5324cb9728089d265fad4997e7e875967cab26d7ccd2fa7c73424d913999d693fba44e6fa7f7d3e915e6b4f9b1493de94b40c6d26932b64e9799d329c87d529279f47b3a247316bdaff72334998f943a4c389f292a0f99bb0a4b197924e5c2f1de8fa758de62f1417d1782c85a67cea57a6931e7cfcbaef3457821f7897e74bd9ade078d38672c483f1d44161d3a6f4467a41f197303cea9eb469f3bd686648ca88c2b17998beed26355b424f7f5f67a49eea9e615f3bad5c726a527ca03a13573192d379aa579bdeba53e37b926f6d44b9d47a22f221391a1c76cfa8bfeba6c7ad96baeaad96e966b769aebeee233569685bc9a16e8412fd3637823f2e8fa5be80b8d3174accf264465d0f547eaf43186cc8d77cda197c91f20bf2e6ff202f9f56be23f84d6fbe15cb210a95b58ceb7d9656ea9d963de5073c3bca7e6b679df07eae5fd4acfffe5fdbfd6eeff659ec6a87e753da72fb0d77f557aee5ccb6244ee0f2ae7f5b240d7726a444f7fad9cb7bbe97dca5839627d9f94fbccea7cdc98307b6a0e98354aeba51e93f5f579d8bc71fede51730f9d97f8bd1eaf4f987b6b4e99b7cfeb2ce18e6fd0f2ac79e7bc8ca4fd05f350cd656c73cdbc6b7e9d47fbd4c699276a17990fd071749fc4b236c57c988c51bbc47c74de5ff5321aeb6af3cc676b33cc27a80e975bc6e542cba46cb01c944b2dd324aecbab2cc7685d85e5a45c69394ddbd5604c24f172a18d5187f2321c7f613daeffda014b35f57be5ce1cf3366fb09c2332ccebfaaff95ee382b5bdd0a716c6ab857129aa23c293dc6cb9a8c71079bde58a6cb35c975d969bf3bad2e75c188f75bf79bffd69417d6db6f914d5334181f9426db1f972ec3e555b62be56bbd27ca3b6dc7cfbaeb1f47d1651bbc612575b6d5944698b2585eeb93af471ea2d4b68d964c9a86db564d7b659f2a8fc1f805a87a58040f7bb5a9fa59896214b49ec5e5abbc9b2b2768ba53c76efa9dd665943cb1d3806ea91da37766fcf8df841edb0c542e4a532eeb6d4d7eeb534d17ee396d6587dd54e5ada6a0f5a1cb5d3165fed314ba8f6a46553ed69cb96da73966db5172d3b6aaf58066aaf5b866b6f5a76ff452c7cbfbd4fdf5362e3f007950bfd6be1787a3dd9c71a63fcedfde2bee77dc6d763a2fe7ca0af137dcd27c4f81269477c3133ba3f97dd29e59c88bdf5721e7f4dce0f88b577f9726ca9af9be405eb68e1fe17134ba93c31e5fcbebf2026dd557e10bf550bf4b960bef9bd72e1bebab0dc1013ef624bdd267abcce8fe8fb73eae73cfa7a93fd5620eb400e5b0579b35594c1b29762ab359560fe395c1f4f1f9bf0d7675d36bf86c93cb1cfc7fafad39f8da3fd69fcc67d42eeb766ceaf7b528feb8eacbfd8f1e4416bcefb3e7b47c79547accbef5a870b62941e8be4516be15dcf44e41e89896356434d82b5b426d9ba4ade6fada074beb5b226d75a53536655e4296b03bdc6fb3592b599dec77bf211ab8bd6631b5a46c7a07496753d6d73c86a23a7f8842f247c1120e949fa97ab7e9bf45b207fb535f77ff6fd0acfc19fe97b94e7e87b94b5c294f032b38dbe41d94edfa00cd2372833f40dca1bf40dca9b89814569ec2afa5e6496be17f9257d2ff21a7d2ff2067d2ff21bf25e844b27ef45b83cf25e847b94bc17e10ac97b11ee493cd10ec1ae3b6f0f0c2c5418ca0c92c164a832c8863a43bea1d1d062d8605031f720cd1a34c346438fa1d7b0dd90602832ecc43b43865d86649af620f619b2309fc074c070d870d470c2905c1c329c329c355c305c36a461ba66b861b8fdd138433a4d59865c9c85a4223a22b94aa758816d8b0c59e44d4082957c7f72c1d9d68316e984009e6a47317d8c9e734be01598c193ec094c7fc3fc8c9986b2b86371c76125795f853d19b0407d8cbc59901de5a008e78b485e14955d97dc1323730f4a4ce4dd8372eec2b40f5b351a26288fe4cddf52fa8b4440efc925ff17352616cfd2e4eff3e6638a830278027878128af07cfd34ac8044e44982c5508e29192a30dd03264c29b006d3bd5009cf20a79f826a48439fb3c012fa1737d3c181e901f063ca000dd38370045326ca7e1c1e6292996478987e3bd47f47d6d547b9a2d5474bafae3eb1fad4eab3655b565f587df9e9e94f4cadbebcfadaea1bab6faf3e618a5b7dcdb4c894f2b4c594527adeb4c49451d66acac6babcb235869cd24ba5b74c05a6e2a7074c2524370806285b635a692a7f7aa0acb5f490014c6b565f28f33dd164aa5e7d74f5519365f5ff21ef7ca0abbaaafc7fee7df7bde4e50f849708297f6208346088c820601262c8c288f0fe447e48315626b694524a639a524a197e2c8a95d62e0699b44544069181ca6045ec301419062ba5fc2822bf1619603a146ba0c8428a29a591a99126bfbd3fe7bef012a9adce9ff55b6bd659fb7bf7db679f7df639679f73cffd93dc16ace688fdae146d123ba409d32baf8d3d1c5da85692699cb169ec8568bd945c52158fe5ab2de11f8baefad8ecaa79c2b7402dd1d9d17952de93f61cd75a48aba75c11ff72d46ff1e2d4843555f3a4d4aae8c353ce47478af6bae8c629c7abe24a632f889d2bd12dd16d534e8d1b3ae554744774f79496ca8b6aa18b3ac61948f4a319623923fa1cd60f440f8fadab3c18cd91562b496d3e1d8d9e54bbc95ab09824f141297a5a8e97c4aa50747574a126ed89e8d9e88509fba215e3c5c7e818d16b8db68987ed3193b416cd8885b4fe6e750bc5b26291685fe97d69ad78295c92544249d1c2af3f855a62ebbbf9df8d62ebc71e1ebb31b629b635b63db6b3abbd297423b9ca627bae7bdead15228fedd351b6a43e681d5dfe1fafbc181d1e2ba85a223854a27209564f4d391e2b197b21362a36aeaa295639e57c6c626c72ac76ece129978853139b3ea52376ab68dd169b53b53afa70ac81316c8fcd8f2dd29e8c2d8d2d97d81923912b63185b116b96e8a88bad8956279a120b134b120f271e4bac4aac4eac4b6c1c5b9da88e2e99723eb185d1941a12db123b94622b125ba215b684e625767fac9ed8e9ea4ddb73d1d595c774c4af8f69d493d85a2df3ee82509bc656e2b9c4016c1f4e1cad6aaabc3cb689585d176dd212da379517c70d1d5b2da92efe74fc99244faa8eef92d81929c7bd42fba5fd66ec6a4d13b64fd81e3f147f297e3c7e2ade326e68fcbcf44f75fc52fc4afc9d0907271c8c77441f8e9e1dbbf1938d71b72a9ef0c60f4f642472e273137d1303a9a169dcd04491cccee712c325d6a58ec4c84fba55d5b1f9cc27a939312651116b96bebbf5938d954712d589498978b43d316d4a47a24e4729511f1da32da9bc2c2378307624762cf64ab44e5a253330f69ad0b9d82b31695974ddf887bbfa6b5dec72ec6aec9ab6be6a55e5b564bf4fb91477ed313a269e1eef15cf8bf7d75994948ddf28b6dbe3854af1e2514be3a5f1d153de1917ea22e6766c79bc4cea9c787d5de81a174fd63625e67dbc4aa8261e1db55463273e353e8318f279a2e81559c066c667c5e6c7e7c626c61be30be28be3cbe28f26a35b56d4b8e8aeb43333fe84acae4b947434edda1177e36be31be24f551e9c725ea2ffcad8d55f3aaaab6de2a48cc3c9c4e9c4ecc4bcc4d9e8245d0fc5c72b32f6a5b18955eba2c36575be266d32d1eab11bed6aace393b8105d9728d2918f564bedc313ad89b6447b7464ada90dd566d546a2d51fab8fada8cdaf2da81d1aadab2da91d553baeb6b27662ede4b1d5b5b5b5d36b6fad2d9972a56ab58c568eaeb9b266cbea547b5bed1ced13f5bb76915d29358265540fd636d4cee75c78e7ffa01dd45cd3c43d73fdbff366e442e308e58d9c2f6991a4a5926e93b45cd28a914746364b5a23a944d27a492b246d92b45592cab64bda29698fa4e992f6493a38f2a0fe77cbf42fa5dfc67ff1fcb4f98cf4eb1499d8019390dd41c87c4e7a2f53faf92f4dae71b22e645dc1239e7595ef344e65a51cf7c871626074f9f6f26bd04e9f94df23b4cfff7d50e8882f3f26f48a2fdfe7cbf6f52897e45ff38f49f9319f8ea4f00753f8733e1df18fafa4e425e9a29f7f30c5d64eff98a4d4f6248f491f7bdabb914fa9bea5d27b95ed49dad6cb7e9d5753da9ef46b9f9fff5a0f7f7b52cffaf7a5d0ce144afa76ce2f77c4af33d937c752e4c931dc97d2c66b3dfa31793c96a29f3c4a5e859bd2b7a979491fe45891ee1f7ba5f8b0b347dd3bfdf14c1e537d3f688f15793728bfa7bc5b1b2bfa0b150a1577f7b35b5b7afadab31f7a1e7bd6d9732c52293566936d48f6dfb9eb362a4aff485d376a7f4f1f7a1e5f4b198764fd4959cfa3af53315aa84c6899d0a37fa45ffe7f3926fb37797caff17a9f6357bbdfe7d8b38f93fdf47ec76ef3abe7f1d80dfc4fdaaf2aef9a3b153542519f8fa6e8a5c472c5d4149d19d63e71efafd715338566a5f4596a6ce8f8cf2def360f2b1a8516082d4ee9f764acac147aa2bc6b2e76cdc9b5be2f1bcabbaf357bcabbd6ba8a67849eb2fcf85542ab85d6096d2c675d1fbfc5976d13dae1d7ad6be2d51b8c61b20d3de552d7f8e1b66da97524f3c7efb66de8b606be5facf55c6fffd87a75a375e9a0f569fc73d7e5e30f081d163a9ad257efb50e25db7aa3f3530f79c5d37e3f2bed12da5bdeed3c55b15fe890d04b3d6c9dbb4e15c7854ef97c8b1d9b2e4ada39ef1f2f095d117ac76fff7b504587a564dc8df7fc634679b773e9f81ca1bee5ddd6e9f103fd6391df8fc353da9e24e9abf1236d7bb58de3c70855f8e5aabbf7d7f8494271a169427542f542b385e60935092d145a22f4f007888fd473ca1f5b973f68bc258fc9b9f55ee79ef73aa6ae8da973bde73139e6ef757ce53de8fdea7fbfb5f746fdd773fedce8fcff7ec794b5e886c73f657c52edbec739f386f5dfe8782ca5fe947eff7c729c740e9cb4f360fc69a1b3428ff974c152d77e35593e695b63b9b5fcfa1c3e58de7d7f9c9c7fc9bdb15f5ed76f3d4f8c6fbbee0373afaf9d7fa9f6c6b797df78efeddbad34e5dde7618f352ab9165586cabbef898ed9795c9975bd7d959194b8f0f52af37bc489dfdf9543aff765d7b8a5ce01d52928bfa6ef3df19505f33fe75ad369d6ffc26fb29c5efa6193927d4207858e081d137a45e835a1734217fddf9785ae0a5db3bf47b83ea55b9d11bd84f252a87f8a4ea150b150a9d068bf7c9950952faff933282a3435856608cdf4fd982534d7d60535fe115a60aa4b16952c2d595eb2a2a4f9a6c5256b6e5aa0a9a43925ad4f72373d51b2a964eb4d2bfdfc4d42db6f9a5ab2b364e7b0a18a7af4b93df697686e424fcbee2bd95a72b0e4a0681c4949fa0d86c81fbee9cb97453cbe29f221be1dd2976f87dcc4574306f2bd9041bce35bc83bbe1fe51b217fc1d741c6f05d90b17c17641c5f0429e38b20e57c0b64c27f7b7d8e1371ec5bb37bcc086386492c0dbbda83aef934d11e874bdc0c97d81ade2b8524ae864b5c0d2ff4c9f5a9d83f965eb785ae8cfdf0324bc8275e27cd2b3af4be346258f3b0353dd2fa3f90fc71f90d927e719037b90d5f8eb1df8c09f22677066f7267f3cd987cbe1333902fc40ce2db30857c03a688afbf14f3c597e17ce5e5237cdfa5e4bfccae63b69b9dd79f010d5a6d12379f1ab45bd3cd2d83ea6e3e7ff3a59bafdc7c89dfefe811ea18b4bbd82bcef0b57617e7a85c53715f95151749cab1e9e6539a92168b078ac52e7b6087b594b433a80e0b19a2b345cba9dcd63c68b7de3974b58f43ee46f7c7b2ac3feffe1f53e0bee89e3743420f861e349fd2d5d3d464fe53e63ef369be58932f14f1bf0533b8abbc27e59f92f25bdc3d26e8ee155bfd29335034fa827e7f0c18691c25fdea93a27ecdc89499aa148d7c13c93f967f6c40415163d182010503860e2819502b297fc0a8fcd7068c13aa1c3071c0646cacd53770ddbf77ff5eeafe81fb0391fcd0fda171dd1dee0e13709f759f15cffe59bc094a9b0e99745a93219efdd86466fe44fccb9119f79873887b77d34c1f89e465c67c7886a5a247aff3a954b4f2c67221a7e88a4914c58b76179e2b7aae7054d1013dde34bb68c7e0f4a2c31f1e5e7454f9e4effe25452755a7685ad1699515d5159d5579e16b4517d0e95574baa8bea8558faaab5434bba88d32a25b34afa8bda86988491265470d99a8a436a1ba2121a1e95d24be25497c93fa870cf57d6c2b5a35a4c4f243c615550ca994fa0e50d76aec64f97eedf67d6a4df1e724b6e70db9b568dd9051fd4b8614146d1c32b968cb90da64fb6f8a8b1f0b8764152d1912a15d0f4b7b93fc6343f21947fd2698e10b5a4ef8d6f05f1a37fca5f06d26149e1d9e6dd2c373c2779970f8eef0dd26337c6ff85e93159e1fbedf648717861f34bd3f700c3bce36be49966516cabec50c96d570f02e9ff60aedf74956b5c12f091d173a6569d01c399eb7c7541a7ce93a5f70ea3ac96fa7a82f7ca2b0acb0ace0687edf82818377f413aedfd47e530bda243d37284fb8f67e530bf93d389edff7c3730a06f6db2569eae0dd853585b3063f2639870b0eab8e68b5e7f7edb74b4aecca1f98df37bfefe0e706af12e985fcbe853505670b67f49b5b70b470661761b370a552c18e8276a5c29a7e658535838f7651d9f5647d2c68b53e164e95728b076f547ef0eec15b0a8b07c72577a0f54f7df3fd2a93daa36239aa1e8975df1fb1adfeb4153e2a7e1e102f0eabdf05476dfb456feee0d585b30ae74a6d52b6e08258127ef03af9b5a050bfab92e57edd9535dafda6fb4d1376bfe57ecb6484bf10fe8244407db85e22e08ef01d1201f3c28da657f8bef07d2697af9ee565b665b6997e995733af9a7cbe6b76d39fb4c6d5094d156a64952be26f4c6ee55d864a7fe5e3fbb966316f1c3866528ade683347bfced3a5e7c86af4b712d1aeac47d44f6d05d4a6dfdc4d27d20d91ee11e921223d8d480f13e919447aa644fa42938d256d83a10d41da7033feacf1fdde46dd43903d8cd78ed997227bc9f73b556f0f5e3ba6c997e97fcffa8ff4bdf67afe7bb63a84258325074b2e9602584ac7867e8d39f8873e504b26f67bbd675fb87cf34b7bc38ec350dab8c8ef8ba62e996b66faa398aa37c7ef8bc9beeccf19a5f71bf7f7f27b8dd99de2b795ed314fa5c49e9535faa3982a7bc21fc5a4ec3f6b0c3fc828fc4746f9467de1985de608bb82fefadfc7f3a67551222f2aa97fded4bc1979330567c9af99c8e682968f4a6e34af51d2acbc05fc563eeaa76592a2798ffa144db1982e290a25ed252da5da69e4a8398ba97faefdad6d09df1ebe5ddadc1496280b3f10d608f8c0e726b38311f49f6ce6d60b6d3189dc4d9226825bbb8e9bbad2d6dced5dfc4e4982911d915591264d299afb223ba0e46f6b693bc7eb16b67759b27616e6665949a44ee8406476e440ee9edc3d8a91031ae5e13bc373ffdc16465a85da4c2272397235722dd7cd4dcfed959b27a8c7feb985b9c5f0a5b9a305dddcb2dc2a9115e6d6e446859f9a3b83344b34fbe7ce9554e6272d93de65b1317701d83f77b1e8a8b574dfd232dfceacc855c953493aa5956ac899490b678517fc09e70f57f6ff27595ded3c2cd6ff9fef8c76cacc7ef9bdb69b74b8339255f8e16ed20267286b794337699ed3df2c93df33ba49339c1cfeceb2ba9bd43821335d7e97a4485d73957d765e97ec7adbde7f8647dc4dee66d1f8aebb4556b6efb9df939df536779b947cc67d46fa66b7bbdba449df3c6fd2dd03d24361f765f7a8ac3fc7dc7f31d9ee09f784e9edbee2be6272dc53ee29d3c76d715bc4e6ebeeebb2e6ecc9dc236bce8f6557fe21d995ff446243f7f68f835f07bff507fce329fc1329fcea14fe1b3e2f6d770a1d69af93fc4ee93064f94e81fcbadc4d96e368eda7bbc9d29d5ef2eb503799f6b023239d2233ef980ef9b5b19becb2f4ba23e7a254d905d3cad92855d662cecbafd9dd64f6ef4ca776931d25b62abbc90e753b1758d93e733065ac87718da6e36a58931dd6645d8d1b38e375ebd5f0bc3fe8d52752e44fc2cf4ae1eb537afeeb293dfff875ded7f9464ad96fa4d8b4fc3ddd46cdf2da9622deead4eb48db9ae1d7b5c57f7b0daab84330c30465b797d125edb6de64751893ed9944b6c90e65670945b2f3b30b04f538547e97648f92949f3d4eb0327ba2c8274b8a88bc367bba68686af08f4329979a0a442f226543d9f3c5c62239aa4e969f5b29b434fb56f26c69a55b49a3b26f13bc2d7b4ecabee1835ecff472a6d3c2f9d26e13c910ca4921b9fe8848bf458a84244222237db9ea6dec415bfce3369fdf213446a842a8dafece59631219cbfbb4f4992a78becfa53e57fabc23e9529f8e8897b15c5324a34f871e7326f76989e4f4391fc989f48de488f6154d918c4851a408bd1c9b6ca9a4c5c870b52888bdc848b5a596aedb898c11bb5e9f96cca8f003334b331a32d647060a2ecf68f84fdbf17cd0b3d959568b2cde253699a384c60955fa47a5894293fd63ad9fa77ad37dba55fa736966b1b46345e6e8ccb2ccaacc1a49d1cca9192b32966a123ecab146b4464b2ace9c913993df92e4385574357fa64d7ea9eb161b53eda92ddf52d24e5966b16816abad8c4519cd19cd99b332e7ca716946f39f797df267456e6f999b39b23ee74864e64884e648e4e648e4e648e4e648e4e648e4e68cf1f5e242b21bcca913925d528eac9b39f3849afcbc854212b539d53ec9efd14b4d22ed70efe25e6b044b7b9749aa9254d6bba57734edb0a6de537bd770acea5ddc7b86e8cce83db3f70c7e6b6aec3db7f75cf267d8e497ea6eb14cb4b0a7b6b074dd4e99fc8a0a55093f2b7d7eda8eb4b3bd67091e4edbf1df1eb9fa3ddef6941d805eef843a9ade3d974cef73c6507d87d1d335f8506759724d0e2c0f350b7f3ea4637b3e6d0558a7f2b4bdc6f196064fcbcadc1ad2b3587be0b87182a7437295ecf557797864e08271d2067a71919c0d3d2a31521f345ab653cf70e7154543d67f27ca59e07c4793f28a81e52a092c7ff794ea287a4b55e2ee45b35d51ea10f4ee44deaa98d6d0b149e48b3ae56c1e98a6e89476ced39d42e8a262da56703092e96033a8fe9f0ee9bb9797435f504c3b8ae6237a860ab508ae09e995dce8b474e40de8286e044d50af4f8de68afe1790701f21b813899635de59f85ec84fa3bf01c4825fd749507bbb9d52edda22d3aead10feb8e67654816340ae7e3b64dc3a73d572c72fb01ff67e428dbba4677e905623b8195c1d9291769f075bc1532a0f0c503eb00fc951f897c1122423bc17046bc0291655ee74c01f55742ec23f0f2e042bac0e76b2b03341e59d6fb96f89a43028adf35679b25f0e967a7256f77ea3bcf713e40f2a06bfe83d2d7c87f2ce62c5402db97f8b2411fc67d9b645d074c02f63613f36ebc06c248bb1f377e86480b98a6951acbd0e5afb9b029bb4ede0770212ed8113c11dda332a71a7050f0b7fce1b22f8239538a59eee433fa61818075facfaa1886fe1fb822fa8dc7dc81b24fc5f06c41fe7b7de58e17f4ca9271583f7c3cf01d783ffa018aac7ce35c5500b3536aadc0b21bf88e634f87cea2a845f8ee6786f381eea4c794b31704cd143e2de07bf2cf08a7e051dcd7a740e83db14cd00678646111806d31d99899dadeeb3fc6796513a671dbd0e3a1d18a09eeb758ed3e26a3f74280606c8bc74dc51cabb1be01f094cd678806f057fa9127733785425ce20e4ef28caaaa27fc1d4ae7c600e5842ee51afbfb6d7da51dedd0a7f17780acdc3f09bc13a708423aba55b8b3f23c00abcf5e0f59b62d222ef1945f83356a23e48edaa3301ac437e99b26d487ea9d879d91b2dbd1a0f360a3ea3733f700f23f200dece817f127e93a2e83412f3a2e9bda4e86ea6540992fe9a1bb880ce025fb29348dea9bd84661692af2a06ef872f43ff09700616f6c1cfd3dcb47ee83c017e040b4f62ad8395aa13dfb214cd196cbe80cf8b6d5cd1cf77791f173e8d18cb0d7e49743e41a972db4670b262e759dde1bb1b58e7fb76bec5eaadeb7fa1f2ce2072376bae5b077f027e07b802fd065faefa6d4846813560a46366f2ea4e72f59c720cfd622c1453ea22f8203a1de0a7417bedf802a85f6b9079a4771465a4ef165c859dd68e5dda76744e734e69523e482da2af9acb757d966b69197799099cdd14bd0fc33f002e4673aef7b7a2f9453d0b3833dc72e5dd69d24bcfbacbc067c173f4c619c173c455b62bab90eb309ba6816b89ba98f7869eefbdd745f26db51c28c47e1dfc0545a70dc95e24cbc1698a5e7fe4c54876812f83f7280687a3f34df83cf867e01761733f9238fa6bc12645d3eee95dcd43e0d7149d7cf88d8ae295f267c0e7900cc45a339ea4fb1654826577147c297804dc8d7c35d8002e435e4f59e3d7ae3c7e9ad3e0d3e0655f47710db8126c54ecbc0d7e3658a9760263b0cc78394f51d7515a7a9c7e9864ad7572069718d7fdcc3f696f743ea3ed025b1545ae2bc94e45d987a86417b97bc11ae4cd608ba21747671a5808668117d0df8cce596c1ea2541b980f2e416705fa4de85cf364ad76467b3f17feede03cf80ec1c2608e46bec68f1354dec90b16086606b394f7741f7926a4f7525e09ea9ee462288bde8b0a7e54cf386680f73141ce7766027c58cf6e9dbf4227e22d43bf1854f9bf2b0a1f07f3c032f639a3c00fb123ba1d2c020f48a9dd1adbc2eb3739fa710ead0b06b4c7740f69ceb0d7da089eb13b31f5d92d0eb202040f29eaeece2dd6fdaa531f2a05db1491ec574d673ff2fdc8db90b4216943b23f385b51f7ba4e9ba2f860759ad13f84dc5a3b849d6674b4f63a744aad7d749ae19bb1dcac12d34e5b0e81edecb4dbadb7da3fee04da32c1fb77452d25a8164aa9abd9dac79fa7c0e93eafb9d35553ce26acb1f8b319df366b8b842f65cda72d5a97ec199ae0d7ab3fb28649fc98ffa5a3cf93978b46ff12d69871a07a1b36df071fd075acf38752f67bacabb9b29a8a850ece0e6033927645a7d4f2ba9f97ddec2ecd55de29b56877ec942ae55aa099dd7bb3ee7b0575a52d56b95b874e1b36ebd1a9d76b962077c882796a47701e6be9ad5a0acd366ad90fbf0edc4f8debc0366cd6e3e165721fb448a907c97d95ba5ec5ff33689eb1367507eed45b3fe99f762bf173750f7f885287542eb955f055b4344be7fbbb5b55626bc74ea98eb8b94c29c33db049a0e9fca9605ee731c1022479480a3a7f2ffbff7d2a91f28abb145deeb3b9e978c55d4f69a34a46c197dab327b9dcaf74578347ed999adc25b645f6dc0aff4345e97199cb9d9f5294ba94efaf28d6b4de85e07d60a3a2ac573fd51151cf655c32e039fbabe7ee6c747683cd3e6f7dd6156325781e3c066e04cf50e35cf8d386ab0c3d639aaf395cb7a6cd62b5a10f59098d5d5578abe7a32ae96c5589ac0c3a9bf2d3f4ad9563f4bcd15923ab132b52289f9eefcfe810d5ac0ccd3a76ee049db332379b75adb6d7cbfe55ad9d29da57ebe9bd1abf0fd7e87e153e1b9c009ea3b72fc2afb03b10b04ef565bfa1b99ff547738df1ef753b4f21e12d1ee716ab2f36a42e45a70d6c5634edf0df03f7a3530c6e45520a9f0d4e00cf21bf08bf175c01b62a06a691fb22b804fc2cb55c46a70249147c0afc0ed841ee09b001c9743c9fce884fd70871e2f09f85ffacc686b4da46be9ed73e4aaf0ef02350dbbb8358bdc6be6b22d6fe11acf6ef30af61beab6605f223e08be077ec0e13cd0f71669f0866829f01cbd8277c153e04b283321f0673fcdd8b9e85a3683eabf86eac9335b3f331703d380f1c093e0beaae35e8cb1780baea9a8edfc01f0097aa35f6bae6dd77c815bee35f8372367ff7553d3b77bc19ca14fc8da244f8d3e0cf88db02787b37e02af8101e5a1d7d27e26e9fc79fc0dbf07b88ff4bf02f20ff35fc4be0df81ba5219aefe8c87ffda039d97d4bec9a396b7e08d771b485b3c6963c7d934199177cfa555a8e77aee1609f74042d5e09be08fc1f9a0eeee8cea8b57ec1f82edc8bf0c2e013f057e85f3ef46f079390bcc481f23f8a2a2f7ba62a85cd1053d03de8ffc69c5b4af2b3ae8bb48d2d1491b94cefd16f4df20f716709b620079f00c3c16bc13487e8ae5d3f013e083601f24d5f08bd15f00765057165848ee15343f0f1f06ade52fa24f6e2013c9efc91d89e457487e0dff7df86cf47b838b40177c93566c001b913c093660ed73209e7b7340dbea3cf067485682b781c3c1e9e04c90367af7e089f56d3cadfb11486ebaf5ff1fc9bd177e1ff50e848f82781e388bb532240f2966304661c62b7d36883cb01efbabb03302f924e44b29bb053b27c14791d0ff41c6c2bd4cd97c72bf8b8529e4eec402f2e018f88df075e07970147222a4f38b1a87821287ee43e01222f376bd47e4fc7da8b7c6a7467ef04545ef75c550b9a20b7adc1bf4ee47feb462dad7151df45d2412e16b89f0b5c4f65a8d586b41f9b441d6b2f2de1bd69af2ee2de86c530ca01f64171dc0be7702c94fa9f734fc04f820d8074935fc62f417801d78980516927b05cdcfc387416bf98be8931bc844f27b724722f915925fc37f1f3e1bfddee022d005593ddc0d60239227c106ac7d0ec4736f0e685b9d07fe0cc94af0367038381d9c09d246ef1e3cb1be8da7753f02c94db7feff23b9f7c2efa3de81f05110cf03ac725e199287ec68326aa7c1138c915174ec683ead98018619f1f4d9206503ebb1b08aba462037561f7e123a4ba96b0bf59e041f45c27805193b97fbd869f9e47e176b53c8dd8905e4c131f0dceb0ed681e7c151c889abce2feab570e72d9d12e79d71ceaadfef4808be0edea71818a8e880ae01cb91df021e5434e83b483c7402ab905bfd07c82d016780cb905f86c7823b0f3c47d946f8efc0bb603a928df09f84af001f42f228d80cfe15e881d6e60f40e4ce23f0ef92db0fc915246df027e0b1e6a68195a0033e88ce67c14f2099028ec3da47c00f23f93868db9b01de896412380acc03478285e05834bf097e1b6baf82b4da0ba2f36fe4fe08be85dc5ef0df05bf46ee5bf076bc7ea218b4e3c21879a3c10968be848517c10f211f829c52eebf80f7809f02f7803f466711a5562299063f14fe14b956be0efea8ee7c24ae6612578adbc072907d91b1f2b715258a66126f2a590bff5b7486775ed5fbaeec1b7711abefb07be46d1c2f04b2630ff0de4ff069248fb14b3c8f84abe0c04cf84672b780fdb17610dccb93ac3994fa6ec762bdb240d2c4b56d0b16aac0312a49e31acd2902ed75411d9abda8c5be61724cfd4fe39a2e68f7fff9f67a8debe21ac560a5a217029f41fe0ecf8976dafbb11d9375c7aee83ea25e055eb6f72da96b2e586debc5c22be45eb0d783f4e174c5c036da721ccded7a4d14b0d78c63e807560099719afb3a9eef64145af1f05624c843f82f7d22b9c1438a5e1c5caf57c1ee0a6a7c0afb63a87713fa59d49e85cd85d682dec59593d03eaeacf7d16ac508b8175c062e0447f9f2e3f4b3e26a245be197d16f0d602b771e78b618e08d2fcfbfb3ddb19cabfe4dd4bb89d1d1b2077dcf9bb85ab4168eebd501385d517ad2d6a29223befe7156b3e3d8b451dd84e626f84db448e5e9f4498b6a7a9fb4d72f58980d7e1b3c64a3d18fff4dc4c64c46d98e60136da7cf89a59d8ccb22463c07feafb170c05e5da25f61efc960219f56cf2702e7d2f3f32935c9468b8d0a7f8e84857f544b85b8cf105ca9b9a193589ea576bc4bd83f458d5fc7ab958a61622ffd8a621af72542bb7d0b8b1911c134ae9a43f5ca070df2adf4db616b93ba36d8ab66eef35c54f496dbf8c1c37db4a55adffc0eda7b20f73aa7453e089db5b4251f7e2663da4e4b4f23d984640d759d43328d3e5c0ace03fb83717277a1b995e70527b1ec61813e09fe5f227f995dcdf08d991e188257f7f1147505b899e7aa85f02778d25a04ff7b7021b9d3c034245bc1fb42830407f37c76309262f808169a91d4289a37c0335607fe34d6e6d867bbe0289efc3e05e662a10df92fc1d5fe7367dd639ce02973a162300f9babfd9d9beaecf5f763357a1782fd6d918f35dadbec310a7d3b8a5378763f971a3dac8dc2b7e5d4db00a6abc48b23df8587a5c8b762b9cdf60696abc012907d9adb8fdc75e02728b5027975f04d3de3207f4eef2cb9ec850cfb1fb70ef9586afc08b5cc47d240ef75c22f43f31498adad70ed93f1006df9b91d5fdea918811d76b9818fa1bf97be3a085f4bee64f881f0ec5765a4d4e6dbf0ffdbf62a9687e14fbee5ed13793c3f468de7c0082ddd81ce12f8562cb452ef29fb5600925fa3bf03fe97b65df6f97eb053fdf4a3eeafd51fbd5a0f942b1f588ee55234df41e749f83aeada6cfb39a46f125593bb98dc5ac6ee08b9d95868b13cf2df7177e20df87a1bf3ca07ee01d390efb7c8285c867f157e0d78dec67cf061f55ff9e0d3e0e3369ef5be5fe0023a03e9dbbdd4be01499eff2ec412668da0c3d596d884f7dfb2b843a3d18f49d55c48bf3d42eee7a8653b92a320572b6e0d781ff1ff0673876ba8c04c3bd6b4e22b94fd0afc9bf06f5a9eb2016afc359eb481cd5c1710ed69f81f8a2aa6119fc143f8f303c5f47f20f71bc82b41ae98024db64fb0832769f446682ebdcd3582b3c4ae24d45e8c27b3ac652cacc4ff95767d082da27f1611277fcdeaa4fcb4509958f8163ae5415db11fd12753b2e6b4ea759cea98d7959771e7ed027012c8dd2a7724b9a7898d33f4c96eb5e37ec75fdff439d1dba107d5bebf1216b082a97c6d50dff0f92d759d650d79065c4abb1ec4ffc3f44f2fe4acb741037e14c937d1d9449fbcace8f5570cb623790d492658866400f8808dd2e0dbc2ff06c905f02d34e37a674ce2b01a7f16516f356b6935b50ba67176082ea2f60be8c4154547f9fef4ed0a70afeacb5ab188b28ab3c18f2a063631672f802f0739d704edec269ec1bd8ade50745e83cf540c3d15245a14d37e4484f4a3edb7e0c34bd87f2068fdc4aba09d655afb24727761f377f0bfa33f59153d977ef801f2c3b462a0d5a7bdd78276ce2ee2ad06f5f028769e84afa35707287a65783b83dce394da68cf6bf67ce17b5bcde82f8257f967a8eb9a5d2dad7dbf27b5c6afc25760f31aa3f61b7446688d697f839dd3d4bb80c83989cdaf52d773d4fe1ac8bcf3d6831f61343f81fe11f8e1368a2c8fce2fac1df00934e9b1e0c3f044bbf46a1ea3af9271489883a1edf0f76373367c06f802b95fa0d40cfafce3e059daf56de6cb40241f017f017e8675a01ade81ef8565e6a07b17f82e16f6593b7666c11752ea2afc5a4a4db2e702c5b447b0c63a9fd660fdb1ab349a8f23b904cf6a2cbdadb99c11d2382b059fc3f2a6e030e2791867abcf315ec388de6144fb30e6dd137a9f8a1a394b86a6c37f1a3e9fba5ec2f39f8097b0bf116f0f5adeda01f751d75d689631e356800d7efc57333a3aaf1f520b19b72a1f7e42f9f431a04bbdec22c223994dbc5317642796b6190b5389d5fef04ffbeb83a2e347be60c6fde8f35e9f77a71fdb8aa1a08db16a6687f231e49fa196d1ca8758bd43b3e8e13b88f643fac421f08be071c1f9f4c9fd5e95f099de568d706f8568b2db745e545e66c40abdcf06ce5474ea19914a2de5ddafbd24115ba6f7f73cbd1698af12e784d6e2b19e7bf6fcc26aff6eadff3ce52b82bde17bfb4f527836ddc9938eceaf820de054ee1dbd01bf529f4aa87ee7d5cee3489ed0b3b9da71ef530cf4855f01ee45520e7f42d129028f20a923771a588864357c167c2bb810dc8afc65f8cde0b7c05160315883e5b095bcfb6f7a76a3758be0cf60610eb91354225731aa5f0f7620ff257c8be6bad68713ca7b1f873f4a6e29988fe576e4e93ca11e063f9c5a66c237a0d986b50aeb21d6e2e8ec4242dbcd69ab89241bfd15d86ce1dddd34ebb36dbb4adc69e05e9e6b9fc7c20be4eeb0a3a0cfc19d7ab019c95d7e9fa8b5422c7fda3e55a76c0c6bade0046cfe10fe04986dfb19fd2224cbb0b39cb2ff6a7bc08e26b93bb822cb457f09f277903f4fab9b6c6f5b3be406c05a24532c6f47c1ef31b5f3aa46a3f373451971e57f87fe4072bf80fe74bc9a4c2d93e16d2f8d40278ab76fd816d1c635c8ff825a229d4315c9adf06b54f9082cef560c3eaee8fd5e73851faaeb0392fed6131bf3fa36825b0c8eb5f10f3f8ab71406616d10ef2d9c510cf42577047c61e7e3dae75cdb06906f00b7da9eb1886419586173c181e06a70079a3fa307aa6cdc5a7fc0567016f84b342336729034e0dbbf826fd8bb37d8f9bc8d6a740e8247297b8a7645c17af04ddaf82b747e84e5bf41de02ceb5331afe0ee2641c9a0bad353040ffff8e3e79d9fa09de45a90ef874f8f9d47592913dafa5d2c7289fc63c0d4d07ab19bb5b34378d352a348c37e12f318e05b46b315e7d8ea8988d26ab56c8daf7905fb69ebfbb9099a5b8dffa6c673af78b02dc955a89cd95cce20d1a27b21e0e256e87b29a0dd595c7ae3060396bd123d8a9607d608d32af2399e4cf3ed509db754c3130c7ae6fc83bc057c19f63b3a6a344d0c08f447311de7ec7ce29faf06dee5e96833c6177d7d2dedfda56f36ec96dde39f167a157ab3cd1fe3cd723b77177fa799eee8d30c67f4720c36c709e36c1dbe7df3ecb14def157f31bccf4bbe6df798fa99f7be7acf9665ec3ed0b1acd22b57bcbb49a425320678e4efdc69f099b4cd3c7e49a6cfd25b274a37fb596657a9b88c933bde4b7be69aa39a68b73f4af317cde35211350bbf1e9930bf57fb190eff9794193633e74c71d5f6e32cbc047c195e01a7003b87576c3dd77991d73ee6ebcddec069fbbbbf1ee05e60078f8eefbef6d3047c193a278bb390d9e6db8f78e0673016cfdf29db3ef366d60fb7cc9760cc8bd70e37561004e6f4ea977a16e92eb9c63b8676ddf7df1313305d353303b05d3406b272305b37cec63869a5233c6549a1a1337d3cd4c33db3498056609ff2160b5596f9e32217d2dc13c667d7622f618b2efaf39e9fa3f9df53f6c0ff58fab8dfee5a793516bf80b988c9df8eb64bce41f4fdb634e813de6ee907272ec37c91ef3e75a3bf9fba42eb19f7fd4ff7dce6f85be4fc41b44fc571357bc4ee89b0c6915fcfa6ffe7f54c1791a514e913b2630c9abfb7fed9d775414c9dac66bbaa89e816991ac223949a6872088204982088880888a285994e488284640c488ba620e08985049e6acd7555731075057454531111441548c5f4dd1ceb27bbd7bf7fe71bf3ddf39dff138f576777575cd53eff39baa1ea7051ac011b8035f1004468228301e88c134908d955b06d6804250022ac1017002fc02ae805be001a8074de02df88c3f3a18fe0100f9a5fc32fe415296f30f91b2827f989495fc23b82cc3d1515296f18f91b29c7f9c9415fc13a4ace49f04142eff81b7ca71ed53a42ce3ff4cca72fe695256f0cf90b2927f16d72ee7ff82b72a70ed73a42ce39f276539bf8a9415fc0ba4ace45fc4b52bf897f05625ae7d999465fc2ba42ce75f256505ff1a292bf9d771edca3f28227932f95490f99714b941de7929ff26a74c35a74c0da7cc2d4e99dbf83aa5fc3b9c3ebf72badce574b9c7e9729f53a49653e401a7c8434e91479c22754491c79c224f3845ea39459e728a3ce314794e1479c129f29253a48153a49153a48953a4f9df28b20a14806da0fc5f2af28a53e435a7480ba7c81b4e91564e9136a2c85b4e91762e63de71cabce794f9c029d34132e623a7cf274e9fcf9c2e5f385dbe728a7ceb540483862822e0752a22a03a151140892202994e4504a8531101dda98880dfa98840d0a98840f63f50e40cb804aac17dac480368051f79144f4e20d7a98840d8a98880e95444d0ad5311817ca72282ee1245040a9d8a08143b151128752a2250ee5444a0d2a9884055a28840ad5311418f4e45043d3b3346d0ab5319817aa73282de928c116874ea23d0e4f4d1e2f4d1e6743194bc53810ea78b2ea78b1ea78b3ea78b41a72effb1224d52458c3845fa708a18738a98708a98728a981145cc39452c38452c3945ac3845584e111151c49a53c48653c49653c48e53a42fa7883d51c48153a41fa78823a7487f2e639c38659c49c60ce09471e19471e59471eb5446f26c4d49bfc927d072fc49c08064c93f1ec39f061ac008b058af81200084313731e93d0443659633d55c94cfd4902808efbbc545f9cc6d1c79927a77b8289ff99544927a77b9289f3c5fc5005802073c1e7e20148cc5544f03b3c07ce69ef44af7a557aa955ee981f44a0fa5577a24bd529df44a8fbf5f8969c491b7c003ef6be2a27ca699449e78df2b2efab31e3d91f6a85edaa3a7d21e3d93f6e8b9b4472fa43d7a29ed5183b447afa53d6a91f6e88db447add21e61eff32c79967802a34ea9e3f9a03ea54f3e8bf1ccad9b2d9905a401c9d3a2e8df8d169efd406f4051ef49e4238d0649235f69349844883c03af279e2b1a90335bc9596de48cb7a4763ba9f94e922d542b3e43922d2b40af7fd60aacc3f39a727008dcc0fef9809dc3f0d4783a3c539e2d6f00cf8727f9f7ce32c29f715b6b49745a1a9df91e519771b4864457a4d15569744d1a5d27916456ca50372431f504bfae22c76e4a6b554ba31a1241ac9e3c50a16e9133243dc9a324bd5849eadcee52478d92f469157516405c73157547dad2afd2e8ae34ba278dee4ba35a69f4401a3d94468f48c4c7f3e69e40078f9e25e80b9c283c37a036e2eb5591ab6ea4cee15a1b293c53a00af0f605b2b7803a8ff7165075d2b61e735af0a925d4329c2f85d4365cb3842a05725439550eba5395d46ea040eda5f60125ea007504cff8219919abe0ac913cc54532ef53e09ea858840feca276e136f7e1fa903a4e1dc773459c79d40af24b71c9f3f22479883f7524ff473a9ef962ce52eba8754093da406d005ab88d93409bfcf2db85fcf2db953cf90ed2f3e85c4ab25a80905c1eca4139c97d28c890f6700df892d68492cce7d1dab4aea487bc70b00b36406d680ccda025b4867d6136cc8173e17cb8102e814be10ab812ae8505b0186e833be02e58062be06eb81f1e86c7e12978165e8057e07558037f85b5b00e3ec56d35c166d8025b91313247cec805b9210f341079a141c81705a020148a46a2081485e2d104948226a129683a9a85325136ca41b9683e5a8816a32568195a8e56a055680d5a8736a0025488b6a012548a2ad13e74101d4147d149741a9d4317d155741d55a33be81e7a889ea017a809b5a0b7e803fa84bed190e6d342ba3bad482bd33d68755a0bbf6f1d5a97d6a30d6823da9836a5cd694b9aa56d683bda81ee4fbbd06eb4071d4e8fa563e949c23dc27dc2030cc5d08c1c23cf28316a8c3aa3cde833468c3163ca983322c68ee9c73831ae8c273388f167029910268c0967c632318ce4a915dba1004aa61cda501b8f431fd807505865333c0e16d002f341044500413b6807689805b3001fce81738000ab3f17c8c279701e90830be002208479300f30783496826e301f8fa03c1e9595a03b1e99b540016e841b81222c824540096e855b81321ea91d40058fd62ea08a47ac0ca8e151ab003df0c8ed063df1e8ed07bdf0081e06ea78148f83de78244f010d3c9a678126ac8255400b5e869781361ed9eb40078f6e0dd0c523fc2bd0c3a35c0bf4f148d7619a3d854f81217c095f0223d8081b411f3cf2cdc018be86af81097c03df00539c05c6c00c67823930474ec80958a0016800b044aec815582177e40e589c1d038108678817b0463ec807d8e04cf105b6385b02801dce9820d017674d28b0c799331238e0ec8900fd70064501471487e2407f341eaf689c50324a06ce488cc460004a47e9c0054d43d3802bceae59c00d67582670c759960d3c70a6e5808138db728127ceb8f9c00b67dd42e08d336f31f0c1d9b7040cc219b80cf8e22c5c0e06e34c5c01fc7036ae02fe3823d780009c95ebc0109c991b4020cece02301467682108c259ba0504e34c2d0121385b4bc1309cb195201467ed3e301c1d40074098247bc1089cbf27c1289cc3a74138cee3736034cee58b2002e7f3553006e7f4753016dd44374124ba8d6e83289cdff74034cef1872006e7f913108b9ea3e7200e35a246108f5ea3d7601c6a436d2001bd47efc1789cff9fc004f40d7d0389d8071024612ff04132f68310a4604f7407a9d8178a6022f6863210637ff40093e85e742f90466bd29a6032f68a1e48c74e3100d3b05b8cc074ec18633003bbc614cca425bf689b85dd6309666307b12093b6a6ad41166d4bdb826cec2607308776a41d410e3d801e00e6d2aeb42bc8a5dd6977300f3b2c1cccc72e1b0b16d031740c58488b69315824dc2ddc0d160bf70af7823ce17ee17eb004bb8f024bb10369b00cbb500efc849d280f9663372a817cec4835b002bb521dac64b4182db08ad163f4c06aec5023b006bbd418acc54e3505ebb05bcdc17a866558b081b1656cc146c681710005d8bd4e601376b02b28640632034111e3c3f88062c68ff1039bb1a303c116ecea10b0153b3b0c6cc3ee0e07dbb1c3c78212ecf218b08349c45edf89ddde0426415d680259680bdbe022f8135c0dd7c34d7033dc0ef7c283f0283c498879095e83d5f00ebc071fc127f039e6651332816dc80499c145c80f05a2101486c2d1581483c6a144948ad2d054340315a36d68272a477b702e1d4666e804fa19fd822ea02bb01a97b7d05d548bead053d4805ea156f40e7d445f698aa66939ba1b7c8efc6855a847f7a613e9be2804471174141d8fea8487181946c0308c02a3c2f46434181dc680b1646c187ba63fe3c27830decc60660813c48432239908268a896392f17b1513a601c2341ea11945680609cd6408b510e1154d48c527a4121052c91252c911520909911842a46e8448f28448dd0991140891140991940891940991540891540991d408917a1022f52444ea4588a44e88d49bb04883b04893b0488bb0489b70468770469770468f70469f70c68070c69070c68870a60fe18c31e18c09e18c29e18c19e18c39e18c0521802521801521004b08202204b02604b02104b02504b02304b02704702004e84708e04808d09f10c08910c09910600021800b21802b21801b21803b21800721c04042004f42002f42006f42001f4280418400be8400830901fc0801fc09010208018610020462ef6b83a1c4cb41c4c5c1c4c521c4b9c388734389738713e78611b78e206e1d49dc3a8ab8359cb87534716b0471eb18e2d6b1c4ad91c4ad51c49bd1c49b31c49bb1c49b71c49bf1c49be38837138837c7136f4e20de4c24de4c22de4c26de4c21de4c25de9c48bc29eee24d2b68f3a7debc08afc29bf036f6e643e24d9c439c374dffb2370f2153741c9d42675115ba0c6fe2b206fdca79f3256a466f503bea405f681e8d6859a93775b13727106fea126fc6616f1efca137ad99be8c2333807167bc185f26e0ffbdf9ffdefc3fec4d1e4ff23f526b800850883f45f78113e03c59dd3e032de43e0959370353bc8ec2eb37d88e73391bbec7af39b003bfce879ff0eb127a3ea090333d15bfbad0d3f0ab1b3d03bf7afca08577a4850fa4858fa485cfa48505a4850cd2c274d2c24cd2025effd1b3243548345b1a654aa32c69942d8de648a31c693497446445cdb44962e6edf73d98368f00405fd05740612ee0752266030d68cc073920c0be8e23bf7bf52577908c802d6945417809bb199f091bbe47382f24abfdcb78ab0dafde6a493d79381b7b1f1feb2c610359214a561480ac0d78f8cc87923521f98e424056bccff16ab454720f842aec5c39821a6177a1fc3f7d7321e993e4bb293d608ed575e5ee175c246bd94bd2757fbde4e987247a2a8d9e7d8fe82992da7fba3626dfd8906fe418f24d13968a6a81bd65e265c6c92470dfdcf13a6b01a02ef93daf0ad90bd44fb2d9ea476959d35c9fdcf7dd787caa305bbd14ef2aa1783c919095a591993ca4d41160236939339a27c3cbb6a7783285c1ec50d6bccb1e8d62ad4c0de044fe0c015160124801892016a4e1bf03247f58dd2e8dc9a864d42e6d295edee22677532331a280dd1fbed8bd4f61b66a369b2d739acd86bb0a21c5a328651bdc455b03916b55e1a98c3cd2615bb69bb4b73c84fb358574130e93a195a961c122655651b22150961b1e39695c42727c5a4ab248819597ece42bf383626392529263445aac86648f9cb2aa7f42b43865524a5c9a8e478a3835451c999680cfd065b525c7a172cfdf8e872424c55a04a74526a5ea047ab8b15a3dba896c581b6b7b6b9675b0b61b89376dd9bed24d366bef7fa567dd58a1e4b85059c67f486090a80f6bd8b9a995ec91903a2e56ac3330d853c73338c0d1ddc1d3c3c28675b3b5b017d9da8a0c59fdce77a4f1c377141c2b4e4f888e65b3797a5d15e62100b379dd01de2f4765f378e0a93abf4c6e9579f501db988bb63aadc764c2b217ed97bd1f549dbae971b8f9f3f6f15bda0f58eececa1dc16b1a946822a3d5eeb06878cff67f58776bb65dd6f48be7d3a30be50c77be2e9a3eefce9bd478dfcbe3ef3fab403f3937a3d446b7abbb761bc61ddd557cb067c754e5a9932f2fb2099fd91c7fa6197e312e0d1b7b6afaf1cc3c9bfcc828c1eea543956297bacd3a5363f8d222ceeda687edc7d5591f3ecf2b6aee17a4fde1e5806f119955745ffebd7b87c79fb3bf9abb5f7db06fb561ebb9f3791591f10bef065bb5f969cd318fbe50a810a478242b6c927bce13db3daf1af24ff8655f9bb94a3864b6d55585d1ea9e71bba837630c80d7a953c36ecc11bbebe53a6e39911fc8a3240f19de9ccd93c58a2056134baa292fa326a33266b0fb03e6b04361755cdfbcd04f692306c56599911cd2d497e9c9aa65aae8db7ef835c82b55aed9f553faa7bd6695a7edf67667432415b465fcd9c1eca042ef42cf5c8f716969a98e5656d1e244cba4efe364199d9264953a2141b2d72a559c1233393a6d9295741825a348061167a525aec286d1026c4c84f83c9e8c1febcbfa7cdf66a95c27ee0253a64cf9d10562c57fd2721aab2ce9afa10cc3ca7d6f120afe604828c992eeee8185355a653d5cb4e5b699d92f8c0fb3d8cd0ee9fffae7e1094db137fdce068a5b2719beabcfa1ce4ed69818e6b1eb4dd5ce250f2fa484392d786e75799a5d53dced9a88234b360dcf5da150d838d4be6cf8bb3ed3f587f4baf328295dc6908d542adbba64b3d1019fa7c1ad9e01670f2de8a3b071c793abfa2f3312cbf3c739aab7299f513930cdb1c0edeedad0826b371fa9ad5a26f6abe0bd37a03ff5325bb367d8a5699b5e2c779c209a9ed9265f307cd1c167e8403fc375abb34dfa2e72282f5fa45efaea7993e5c9c1965bf976596dca3a0dfb7cf30b4e6e98133abb4cd52adc64a27045bcc367f664ecf3f67e0f1af49ae72ddeb5a7ff7edecf658f3e2f315465f44e6c629a3531c69a30c6aabb60ac52b1426ed1b5fe9b6a09862bff88b18cff0a2cf459dd4ed3ab773d1e13ab139c109f8c5bed023291b5adb5b58d8d4dbf4e90d94a37d9ac39ff1b20e3aac37f51fddf82e9454578b14eb70fc6338ea1e9b3cb5e35a6971a07bb38de739db97789cdb3e12e5b87aada866cbdba6fd10e9712fb3a8bc0663bb580d7fed3ee29a7cfaf346f1911bea3b1eeb6c9e4fade73fbac6ffb6051e0d6d74ce8fae944ff2387c327e7ab050dbe6073d6beb2ad715649bb9b6ab8205653d7bec5fc889e5061b7c2c6297a7373660c39dc7b5965fbe6af8bde32eb020adbabe4741fef7cc2ebebfdc52a7b7c166cdf61777fc5f08d9f0657cb67df7358aaf4f5c9ad6969f363eaa2ce185a9a966feca92daf75e0e70a837df281c71e68e4870fda96b1ffc0bd2b1da9d38d7939874c4dae9edc8150dda3ee13fdbf9485ebcf31693c77d6f7fc8b3e393767fde2215c09d0ee21b113cf7e07d358ac48f88f8c0abbd06ac4c46d236dfcefaee1677ecbd13a31af436cedd6ca0e951c5694c1bcd8e2c50efce3f8e00c916c2265531b915d3f3b33dbb8c83836ca5e64111963636f611b19696311d9176fdaf78d8a66edac6d6c6d23637e07c08b8a2f2edcd8a716c6abb2b7b451533becb74e4e9b0ded04e0101623b0102330d7f33f0220ce659cc93889c7b00e1636220b6b56c412048eec82c0001643b00b0207fc3504fe8bb6d37ec43bd1ed6453a5e13659351b7f69ec70ac1ee82f287815f170fca8831957a90dc7d2c7152c2bda203c3dbb78f11bff232bfb7deaf6a86efddbd106dd7be7cd57759c71afeccadeaac423fdcc3d671a288618b1ddba7df36e80fca7f571a3cda76fd4dca1f051a332ad7548c284821d0639779b57153e9cb4e5f578f5d2c151056f66fc4365b6cf65ff3d033b5a9cf293dcefbc98f1ac47e1fa71e3648d3ba8d5af15e191f8a0b2532ff74eda7623fab2efe301f56d015fbe153d3a4a29f71fadf36098cbe6f265ae2287c9c611323bbc929eb54fcb703dae7df985674df9e3d103da279f7b16173df652cdba9c797906ecfbd7b6d7a23577bbc7fbca0f3ee928fffac04ac7ed0ef586cb05dbe6c7e1691b3a8679b7a5937772913646ea64b626fa23e6c6107ac8c92e375a90df6a1ec3eba506b1f0a25e6c8fdfed94958e8bc88235ebe482c16f5c084a49c170c003951097101d9916abe336396d5c8a38212d83c00c4fc06c44d6d6a27e36d61866d6dca6b564f3efe4ecbf23d81ef188f05e6ccc49cd75637574dcd7a607270ee87d2be5d2c5370d13beae565378f4d0316d8efa41ab42eba66f0f7e760fd0af11837b76c3e5165c28d719f4b6655ca9ffe0bcadc733064f5cefcdbffbc5f0e1c6c9f3afee9c3470f6edac7b6dc75bfb6ea90af7bc5f51e6fcc878dc6af5ed5bc59342dff45851ffc56e85b8f056fa18ad299e73e63aa85d9b340ae194c9dbba27c1ea6e2fe1d7e569268fd3ad426a55d8111f6ee4457db95835c64b1478b88f72bd2b7b556ca260ac77ce3ec0b9d0da79d9e522077a6e784068b6b129b23e38f8f690e8e7372ca2de783a3f2f1580775e4505d7472d360a7e316da76fabd7557b2787827d53c2b7f628c8bba8b834d4e954a9ec1878f33bc122b02223d9ee123228f378df64100b71d1855e3f248904569add65647006e6b24ab42cb73451e5c920d2309efe4af7519256be5c1705dc345ab8b26ecdd8fe25a2946d4ec7ee58b0bda495542819464b0e0483c97839e301dc7ec732f9d2ecb1aea17d563f3554fe6c5a2717bc7244fd1636b0936583586fd6b3d0a3d02dd7e5afb34c7a588c535b822042b1902e14f3613194bb50cce13f99c8490ce3d1d9ea3ff38be28111fd06cc36f2aa684c71dd6dbd7f7ca3bc5572c9a0f78d632637fbf5b7b8ed5126fc7af1a58568b3fea519816b327547973a5bf91d292e09ddf024f5e8a17d1f32f60f12bf1fd0e036fb421dd323e1e2d60d3a161f858167422f5b3cf1bd712cf57949b762b835f4d1a1858387b7ae74dff0a6edf5ab27b9dab64e8742d7b504ebcf35dd92ad91ff78055fb3f571c087c545175e286ffd29e07cef1b4bc52b4d2726ad57ffa0d1127c2bfe92deb770cdcbc58b8ff7d993111d3ab078e8e58e979bc3426bd7539e03adc6bcbd5b5e9d6d9dfc79cb4ae5fac684e73b8acd4f9c3753908f5db2f65e7bf1472523d95887156fa669fb1ebd5e17fae2dad4553dc3abecd4c6d4e66b0e5a6271a2cc76a0c62b05557530bad66e94ee9535e7645fcd955f3c24495e39c0798689cf06f1f5b6c40ba79a52370f5f3e7ce68abcc2de3e70e4fbab9be3e5d2b6f66db6b0ea71fe99d85ee96dca6ea7f8ec8ea03d79366ab15af20b6b151ec4bc4db9e2557db3c7cb8c3332fb6e7e327fa8bdb0a054ee93721fd7b2fa8eba1db3bd8ef2c77ac78e750da8746f0a68de9b9e7147ce5636492353a4fd583ea4f669d1a7a7de0a65316bbe05aa59ce388974a73d5ee9d627e174fed295557977d6eb96770bdfd0525c9e3b6e0e33dee268fa04a0b9aaac556dfa3bb5390687e75f1d5fe22db25a77ffc944e7db605694f7f52bf3ab0ef5fc282fce3bb5d9b982721dff2d61fdaac70a250afbec0305b74e3bb3d9341ff3fbf5777eab8db325fcd6f83bf8cddab3b62c26b69d0d2b998c5a8bc8265e6ae3cdbf6fb9ffefe8bda92871f7c37b3ecb4d674cb0ec5577fcf193b36b87ea07965da9ed1960d0fdd5f5edd7fdcad2581dc5467e4dc84ad5412b7abb2f2f5f13ce1add05135e4c3fdeb480dffdbdbccc9a960597b42fda18ccdbd8fa365ec3fcf3f4e7f3351b9e076c2e3aa51f7c21efa3e755d96b1115d72add658a3bb625e6c7df36beef155c997beda9b197659fd2dc21c382987a68fe69fcb2656cf2bcb611ecc68fb36eaddefb4277f5ac0f3794db0407839382f6792edbe4037cbde314fb98c495acaebf4967f91677e46c57f45691cdde94d33c6cea57de3acd40c15ca0c07a351f7ca0ef75f48c45c8a60aada96ea22997d63fec3f27bf2892daafd96df7e7f7ebf7f0aee80d0ef9d6814effac23fc4eef5d5891ed7f46ef1f2e847f476f85aef4c67b009bb5a613be59cbd8acbc1fe3b7287a4be47f3d3db31532cad48a7c0bb796f94d0a7bcb57b68cfd3f43fdbfb474c75a2bac5e783a1c0eec5bfb725fd9947b573286faf3765ba64d1c95c428efba7262fad24396d54ac58b93a20e0da72e06e82807aead9de6fa78f8d18ab0751a759abcdcd2a3535b175d6beacf7bf5f8c45239743ecfe7714bb06aed905dcbeb9fe78dafc93cf56c452b6d3517befcc9d4402ff5d3bbcff553d75a767bcf7f9c7aac67c0c62513e4c42b0f15f5db106f7176a87c4354b88bda9a453a2e8ff9ead61d9744bee9226733b1f07c43aaf3b7b972ca0f7f968b5cd272fb508fc68045b3cfda99456c3ed9786ca6d07d7a75b058f7157be1e8d4d8f051bc1e722af237eeaaac69773a1c17b6d7c2ea79c7dcdc4b43435f6c4c5d9158dacfaffa5dc6c99d3da74599bc2e5e6f624b4f518faa72d64ad2ce6e119e333f7ad563efd38ea699fb9f6c2949b33b147076a2be9251bad02968f1c4915e1e2ac7f6eeadf48f3fbfc9fd5b66866e66812a1bf7c25d2942fd7c819eee358f97662f8fbef5b9645e7dc73ad3cfc8d4c760ccc886d0d7db1eacdd78c131e578569f345af155baeec9f5d9a7fa841cd83dde7941517ae4bee422e56d27777ab728a57c59689db8e7ebc3a1e717eb57c51ddfa8394f298672b6a818b1f450bdeed3fd9517a2f74d0d41d56e9681a52b2ab74eddb5b770d564f55f97cf539eac67655d22482e1cb5d8f064e1eb9c0bbab71ab58654ad7b35e8d17b5e6cca02e1ccf309e79f25376c5f7d4564f24dfeeca8f03bfebd8bee7cb42a70b11ca636a14a79f31751b60cb6b0cc768ac763b1ddfebef9f28f6f9bfc7613b930eb8c64bac6e5af2c14315def50e30efcb62514c9b35d8faa4a2683df4f941161289dddb6297e83609bacdb9e9589f917d236181e9e5dc3c67439851185b22185a699c6c01f248068200629e426771c48033a2004648054bc158ff747e2681cc82832ca34f897664dcb484d891747a68ecbb0fac3878a4c360f0c4c899f71d37faec2dcc8c85ccf890f5cc7bd3ef13cea52a662969bc9b0f62b936a92a21357acadb310c7bc5fb021af5dac507672c0e4537cb5c3b2ad695b7fa506b1ba0b22541aeb7de7cc2e0c9f3cc0fb7046fa4cf6d0c3b9abfc7322ac786fcfd769ee3f9458b7a962698fe889f5f21f74b53264462e34b91dbcf47a86aac3b749f35c5e75146b15458ed6091a3544bf8cdfba21cabba14de5deaa5aa7eb535629ede9886f38605efc246f7e4f30d9ed27ffa4dd370d2fbf3b5792e5e1dd57ccebe73a715f51568bf084f75197961e82ee81c7742d999a29ffb8a3d3f70eff2affe3f6814f043da383e267e72f78bc7de0d19e81d7828ddfe798ebaa8656d4f63f7c7ed9d427661f1fb9176553c66c3665f0db18d1a26c4a15ef522459b9e46f9b05fcf81b892e39399aedd9352585bf7db3c2c317971e41a2ee9d77d9440e22071b966547fe5346b63b05661e0025a72e8c395fdaf2f26972def59ce23ff05a922b37361cf825b7617db7ba8b9bc7c568e64c0b8f3835ea94bad2a0e498f92ff27c1da6a5bb1e378fbe28ef17f471ad568971b965fa04d7cd4ab3bfd4ec9a76e5fee08e805dccdddeebadbfc87b2cead77f5bb64dd894a1b7ee76fb07fd6687e37b77ab972babc22edef6b8783a4b257ed3b310bff529058becb3b3f8ce8a4f2727c60823141dd1acd6b0339f6b762578289f08573db646ce4873f4bdbb7b76e64c36127b0d361ff35273e4a0be373735d72444ec959f689a177e88326f4a72d99bbfa9257e5568b2be765dc3fcf8cc8ffd907dd2b53b6283b12ec2f63711d7549abf8efdba2e79c725915e7575b5c9a992b5fb6eadcf301db3640c70bba5d0249f957558ef59dcb92f71eaf73bc0ff0034d7868a0d0a656e6473747265616d0d656e646f626a0d3832302030206f626a0d3c3c2f46696c7465722f466c6174654465636f64652f4c656e677468203132383e3e73747265616d0d0a789c7bc6c0fa4240f4a582ca6b0393370e2eef0282df27247f2c28fa5850fcb9a1e94bffc46ff317fedc7fe0d7f90b9fea81dc49dfd76ffcb9ffe09ffb0f2c2c6c9293d30a0b4b66cf9edbdbdb7fe5cad563c78e4bcb28686ae9b9b97b858446d437346ddfb173e5aad58f1e3ffefbfefdffffff3f7efcc8406d0000fac642d60d0a656e6473747265616d0d656e646f626a0d3832312030206f626a0d3c3c2f42697473506572436f6d706f6e656e7420382f436f6c6f7253706163655b2f496e64657865642f44657669636552474220363320383230203020525d2f46696c7465722f466c6174654465636f64652f486569676874203235322f496e746572706f6c6174652066616c73652f4c656e67746820383132372f537562747970652f496d6167652f547970652f584f626a6563742f5769647468203635333e3e73747265616d0d0a789ced9d8996e3a892866f6d3d3d55d5397d4b0b02092d65bdff330e4810048b365bceb45df19d3e5d4e1921965f2c01262e97257efffcf9f6f6f7d7af5f3fff27e48bbafaf6f6fde7cfc59b09e2147efffcfef6f54ba4c0345fbfbdfd204d1277e0d7bf6f5f3fed9421e6f3b7b79fbf3f3af1c4ebf0cff76fd7e81029f2af1fbf3e3a13c4f3f3ebc78d427482fc975a48e27afe79db3b40dcc7d7efd44012d7f0eb7b3c593e418f3f4e6a1f39e3e7447437187b9e58df81bd091f4b298bf0e21d9438cbf1a4bc891b6b45caebeeab64bb2fa010d73dc0d1caea0eb17e103b133e3642c4413f588c432b33d1c836ae8e999bc5786dad72b153c5471fd04ac05c91226efd5f5d8ca56886cb105efd5831b6eaf568941c45b710e0f55a46290073e54f6c19bd1770eccd870f156321ea7e4e4df492186e16e3dd392ec63d397a7531d63818dcf39162e4a25e12a185c4f864ec4cb8783831b6229a4f8590189f8c8714e3971d295aaa978af3d17c9cc538f003069eea4060cec3e1da185dd1d778d08273f78cb924a31089a86736c438ce79f72a6b8863d7d7c6f05a2a37e1a5202f6161a50a2f8c232a0efc9485e2081372b518ffefbf217b8ce4519e62922de350d47a703f0f2627317699febb3565df083bdce54294e663251af3a9f402bb8c32114d1cc6563f29b371a8f8d8a55797f8fc879df974931542e490429e4f17b2ca3e602cf4df0d1e920751236231a2c13c9f9e550cb8b2a61c89acc3f3fb395c3eb8284c22323c139c535e176370c5e6659c8bdadd13165e2adaa838faf982a98054710ced9485da649cdb7a60f30dee8f1db2fa6f54a05fcf11a34a551f5eeb55ce0bc60a937225c65634fa6f9bfd1214dcba2229ad2ca52a7ba6f2ded802b5b5da5b7b4a26eaf9ca588bacd511dbf894187b514be98b512548a587c9daa6501575d332961b090931d4ea994c5509bcfb51d4883531eaccebbcd69513a37a9c9cf25f3831aa372bd74fac2b88423d522542e212d5099dee84607e5ec6463f8d15f0ce44859788362c0e6d3054e95389b1e51d17079b0a0caab052b5a06e92728a13fff19162d4c5d5fa9d4d0faddd60f221e772186a63fe19ac982e99ca05349773f0569baf5409e520d3700c3366b65c1b31351943669fc845eb5a1110636d0ad57e51887ad6ce389a07c8b9f25a689de3a8112b6254129cec4943d340b27ba3834157bab9d6992430918d368a626ea85570db5cb626946aa8ec3cd1cf4b092da4bd212cbc44b44171282d36f337e6fb547174f377552d82de3cfce35e62fc1cdd9442356e196e1c95e4fcb692095b77bd6d6632537795e873137a3019af6cb18f90ef508cb930f6c3d21616b7eae6027784e63377653ad1b976c63ea01e6dc286a5a8112b62ccedf32b3796a86df0caa5cebe97ea4ee8106c7ee15225a0c195a6e882bc48dfba9b28bc38dab0385ad78cce248a0305662e98778ff9702f31ee5c81e16a3491b9d1451bae7b3068fcace05498d6fc3b5881da5eba80dcda40a1181914660675d5984ae1d8f6be24c626d492b04f524fef96a24638a337832ba6a975cf2f6cb239e4df49b5474d6463a3700396c246016384c1b46beb624c145e1c6d10c528c2d5a344710068d4fb906254f25083e8dc1678166680c5e9af4436876d5459cc2d8feda533e8073a7b9f2f4667d974bd3dbcb01c878582cb049a00e87a0d26b1ae3aac192a1135428acc8c5e7bb8c2c3e7776ede85068ae663019dff6883417b88d3ed8ad24efafcbcf476c0616f880a2f19ad1f85ffaaa68ac3f1f86254334f016d7d54d52cd1b2cfa556e9829a5b9e114de520df7522d7237470b8609879ffbdb71ebe57239d8c8dee725cfa615a13512396bbe9d2dd37d8585d73e5a245b36fdb8dba4b36d4888bd236757e5e74fb9b3b39260a2f8e3688828970d1342e8e29353d2ba46c1e5f8c2aa735c8213499a6c4d84eef2bd3f5504e85d1c3800693c835120236f5408f8cc608ee8fa1d05689d1de16ae75c7a59f883a9d06b8c2a3b85d93178bd1cb25f7a2c0c30b947188d9cb8b2a38354892dcde18175e428c7e1471665262ac64541a8f2b463dd836839a3d629c8d8a4d76d12d88fe7f6e7a693ed908fc3d31c93a993ed72e686b6e4f8a712e7f6355dc27c6286ac419626c5cfc4b2d635a8c5e5e345a8e36f771e1a5c4e845b14b8c9d36586913fd1374d39a666edb4611cec0526254b3c951c9b09d6fac5c2f5d455af672cd61a277f1fa44f7fd821827c3ca7c6f6706aca907d8b426a2462c8bb14f76d3a066f8ba8eb79cedeca6fdbc5c4c6ae704a50a2f2d461445bc6c911023985b9f448cb686b2d00a9e1463a1429582dbef7b186623436b7cd7e05562c2eab222466d9e9c123244af4b6acc181b741ccb624c4d6090b0c1d22063eb654235756202e3e7e5621f214c46a2c25b122344d1ef78373b288eee39c4684bae081b95a4183b35c46ce61cea2e3b077d24d67ddd5d815126324aac8a117aba2c7c44a22988a346acd819ebd8b483c49fd914c54385946a12a69d302f90039e4ed8b2186d1443c2b4e382301cf4e219ee1e588ca5ed380611bcf54931aa5a1b9c097c7013dc3ede9386a63dfec4b688e6c5ab62b475db870d48428c71d4881531c2ab888cded660ada745761612ef454e4d7bb1d13bcc3aee5cad541385b72c461b45018b4086d4a8c594c6986d897187aeae12e35b74534c6f3a8fd249d0adb88c5e8efcf4ab5ab3f5a13486f4db88c6ac56f1e0ae2e2c35d56b1bf3e660d49514e36096b26075568abac3294c88318e1ab122c6b1b6cb81999badd5f38a29436bd32d24a10ba3409988970383bcc0ba4f367f880b2f8e362c0e95e4c65b1f8c8bc3be3b632117c408a3888f14a39e76ea857a81ea472f10b66ef53e2d4635a4b2c3736d91702fb45eb6cff53a3e64dbde5583add94e155535eb15fd16baefa4183bb32b021a93514efb0f585e57de033c5b461835c219bd252cb5b92a8f374af05a4fced5240025afb04970ed67a209832d16760133c84b53aba26a33f83a2ebc38daa838aaccdc14d975a138da29c494abb418950e5aa61bef8f146397cfbbc50adc7e706394725bc812e9af5dc7537b7de2c8b2d9a0d50777c54634d8ac660dbf4931ce9bb5bc15f47e7ec48a18a3a811e83730dc5e8150b3454ea9146576509a164def25cf6edb6a2f61143854b8852cc8cb9c46bd616da9f01216a3a838463647935d168b63de04a792e1aaca5f8bd0b9d662fe48316aaac4589f2f6d4cddc570e0ee2ab16d35959c78abe8e67dbba28e19139b66674a6fa437f23d7b88a3cdb57ec28728921d8517e75d47b39068c3d68667b37bfaef3b89f1c7469688a31489fd682fc6db9dc448c7e49d8c9a2a5cd3d23e1524c627a1d8fef5dad3f3dd93d0a7af09fe896efa9f54305f8cf14dc4357039fda69ce7e12ed657e4a727a15b4ec8f1c5785a02ff703a3bf5ce5f5f8b24c64767e8f5e93cec06f3c2f3f0fb3e62dcf7131882f0b88f184f3a118ff8b3f87c17317e3b2d7dc41fc4d7bb8871ef020c4120bedd458cdf4f4b1ff107f176173192cd9bb8821f771123f93b20aee0e75dc4785af2883f8a7b88912c3bc4557cbe8318ff3a2d75c41fc5d73b88912c3bc455bcdd418c349926aee2df3b88f1bd9c59f6b9ccb7b79cf6ece5b7a5be0abfce17e37b6d9328d0cf9a5648b9a0ba825e46873e9fc9b5ee935e8bcfa78bf1d0fc652873fdeb4f591cfe8947a57f193ca27d7ed1b1b233811817426d726737204feb6de354fe424ddaff26880dd83f52c190180ffc1a4b1f69a57f189c89e39511aa63acd32af3c5b8142acde85a436a19df016f0d26c1f1dfc0ec5f7fe96b9195e640bb9dcefa1c79d0fd867f5b7c312e854a43edd5fbf26b435a87c5b87fc8d88b5b7e661475bf0b2d97176e31541a12e33bb3e163e8b018ffdefbe0a18e8ee13d4220c672c935ab176e31541a12e33bb3f173d5c362fc77ef83a313f01ca90313423f61e12c393e0d61bec10fb7eea22d748db628c6d813da25ed446dcf7721fe090c917fb49b4edc7870fe39578c9ff63e373eddcf50cd0ed17257e44ab5700e8db9121c131d7b481ba65824c7625c75d176e181ff32fb0cf0d60571479ed0b8f52be779037030cf6359ea6c1ce746ce4f45e81f6dc515dc4bb0de4f1f15e3ee5eba5c38c7b09f4e22d30ee76078a734a58faa62eecc2ca98fe66ae0d0ecd8439a3e0a6c8aa57755bfeea24d69447b1ecbe1843ecfaf181663ec094d45c4f411624a29a91f381753eadbc6486a4d8c8117b5c83fda8a2bb897e0fbaab88e8a71f7eff7171c8c76560ca53b1553c84c4e755ca0837b71f71b7948d34753ea2baa9dc14e82d65cb45dfaf9538fce4146ddb41363c2131a17e6f86da5a55826953d1d12bc042c8b31f0a216ba8b5b7305f712fc5e15d741317ed9fdd826dd4b838732ed1ccf7c12509bc8011d1263ec210d4ec355aab4e1365cb4a512961263c2139a8e280fe24684fe52d6c4e83bae0a1dcfacba827b0dfe5a53d74131eeb778a7878cf8d0723870de9d6d9bbbbe1b8931f690d640fdf7f09c0d176d40fa5448744c727c5c3677c72b274e683a4f8cabaee05e839f6bea3a26c64ffb3749a4c588bc4d38d70eaeaa91505c95263ca4b9c8c1c1dd968b3660438c294f68a8a14a2c85876795af8931f2a2e6bb8b5b7305f722acc9eb98180f6c654c3834b9f86f7c173b624b8a31f69086dd9ad8d664cb45db452f94b35caf4dae8931e96205c59dda97d14f87cf5ee22089d9b4ef452d7417b7e60aee45586b1a0f89f140c398726872f1db4bee4e41b69792628c3da4e126cfb9a00a4305a7f8cfb61967ccb924c598743eb521c6e974e82c31c04888d1f3a216b98b8bb2f082ace8eb90188f6cd809bd61cc5c27c6d0435a5a8ceb2eda5a55bf25bf6c75d357897196a3dc319bd6382f6a1acf5ddc9a2bb85761a5693c22c6230d2376a68cb8a69b8e3da40d896e7ac3459b73afb12ec66bbae9394c1d3b464d8bd1795133b9b1fed1d65dc1bd0ccb023b22c6633f7e89dc4d69f2f404c65e5a183346768ec40466c3459b6ba8d32ee39133bcd404665b8cce26947a8d82a954e9fd6dfda3bdae41c763b9693c20c6430de364de4e8df533f88c4c3bf652528c8989799e30edacbb687336f8e61ad3ce0e31c2230a64a95a106390583b1cd8b3b3fd0558b4351e10e3d123760adf8c31838ddeb61dd81263ec21ad4f18bdd75db4817cabf5094cd213da3e31da970bdac34a2c893170f8e7fca3adb8827b1d7e7dba598c5f0e3fb4404e716c1526970337c498f09026ed72a00043f1ba8b36eb3c6f68d03a257248bab11cb826c66ab419328ed3ccf0b4ca8a488cbe17b5d03fdaaa2bb8176269857abf18af3855beac8568b4372f593bd3c6e4b5ccdf28b121c68487b431b15162dd455b337d998ba673cf005762e14609196e945813633bedc0685c86fa3902d57a4762f4bda8c5fed1565cc1bd120b9b77768b71f7761dccd8cf4edb9cefb1e416b22d31263ca48d85d989855bd035176df3e6ac9ae9ed1370cdba12dbdc42b626c6d2f841735fc076b3488cbe17b5d83fda8a2bb857e29f7447fd25f2b2b110eeea5f4b277c94edf24616107b484bb94c5bf5a396d8b63aa45392dc5cbbcc18b9345b76611678518bfda35de90aeeb958df4ab605b97e21cee4dbb6e416a1c36a8953f9fd795b740bd091f2c4c92c0c1bb7b97ec048100b6cfda27f814f346024ce67879bd50474061e710f567f82b000b93a27eec371359216897b71548da445e27e1c53236991b82747d4485a24eecb7e359216897bb37399fa13d97488fbf3ef9eb5982f64eb26de837f36ce10557ca33540e27df8bdb58787fc6011efc78fb5aefa3375d1c47bf26bf917d27f53174dbc33dfd38de3e7c7984593bbb63f8bdf0993e3a707192dbeafbbb629aa773e5de4ce8e909e8f9f615ffdd77ea7433b38d15ddb02278af16c4f1c63291b91c962e9dccf3bbb887b463c399e2cc513ddb52df1b82da376b49029392ebac3a1963101c8f15c299eebae6d8913c5782ebd10f3c18bdd8326f051f9e7af4ffff9fc76ae14cf75d77673b8f766ac5ff558ee77e0f419f4b9eeda6e0ef7de74e8bc35e2a37902776dab54290f6c71fc4b6747b0d34ffe3c316f7f1a0fefae8da303b4b9792a446fbcaa35aea795c29defe398ced9a9dbc4a43f6a19d1a1bdf57c3a2eccd1504ad8fcace868ef6379237c1ede5d5b654fcf6eaceb0f2746731a588346bd52a8f8d5358912ae2eaa602a1509276e63e873ad84bf3b119c7c0607799bc4b5f6ef1a1c6a1dcb1be1f30ceeda66f2e8386735dc9defe36edc2b45319f03dfbb833e5bd1e88f639e3a4c5f1f8c873b4ee7e5a51091bfc299325075056fe7b57923269ec15d9b7f9f13a33bfe9883f224b84e02a722953d4d14a7dba17ad19a2171413f6d7ae9488c109f61040749d7e68d987906776d7320508015233ee4188ef88633955d7f5ba0d36e5386834109b8761d676902d95e3a4c49640c9210eb9579230ccfe0aeede22bc0f95473c35d988738274b70746806e9ee16a6cefad4d0c6061a4c54857d62201d19289a4132aecc1b617906776d175f013656dcce815f98447a5c2a969d6694e834e666166f6dc3fad261416a51937d65de08cb33b86b0bac81cef529c31743ef2e1ca2c7a44b6172396446c4a69fee6046ec8991db61b061446ff3757923806770d71628e0b818dd13972ddc238c8de77e1a7a692f2563d893e0445c9537c2f10ceeda02051ceca6ab9d5b91dc6bd9e88911f4d29e74424b98d7645f933702f304eeda020f17361d657a02931833ee3a85dee9aa544317d74be3dcb681dc3aafc9be266f04e6f1ddb5850ad830ed44625cb0eb87b8c40e4ae5051e0adafbbb60c038049df615aee8088f4777d7d6c1cc224c8767f406537724c63e3052a741fedf743f5d67f00de476088de64d30fbbbc2151de1f3d8eeda22056c2d07c6a6a6c61a11c7f8adabcce20bafd14c4e0dfed03805721b6a2f9afc5de18a8e087868776d399aa2a6364ab4e14689588ca30aa0b2c764c2e6ade7daad4e8c9591460d00d01b60735ba269b92e944aff6ac8f7817edc151d11f2c8eedad03ead7d5bc81246f89119576df18f59aa62fe2af756ed1abcb1cce6169b11d9c53760da471d764547a47868776deb0fdcfe6de2b4a97531d661570c07127456de08822008822008822008822008822008822008822008822008822008822008822008e2d9194a566e6fdbaf4eddda4f10297af74ba9354ef476c0eef7d3ba3b464deca62a99942deb0fff5c681082f16efb47f20fecaeed7da22676d2c3516d872ba3dcf9ab4b1223b1874aff825db789036769d7072b143b1d4c3daa5322e2a1a8ead919c0753cbb872ce291b0ee31ae84c4489c070b0ff93a068991388db116696fca63a94fb991c88428dbcba80f59cac06b4ae021eb72e97221ea024fc9752cfa062cc62054257bed07ce1cf03ef6b99a4e65702e5ae54e2636073fc159c8c811345c6ba5beaee34f0e3da65cd57272dcc651ba65e945d387072fafa79138877ec1ab68a5bd51681769198846c821d3d213e0202a3cf6487f25f1c165fafc2f1d4b5d213186a1b860552ddca1dc62d2780d47272d1efc84ce9f826b52a8ffb2298284994aa5a79e62d7318dee04e9dc4cc36c34f88ca71d6924ce214f9b6654c9e7fabd1f7257a9aa02325dfa43e31dc7ea2aa498cf41ecdc79ae4a17fa63d564ce2954144a5574d6a8cfb332dace84ca8224b1e86cf1b418d9e460682c8253664dacf3818ed538e7ddbc0fa33d103532edd8731a77a691b8099936cd34700ea63b1e56d44697f8fc6224463864b8b495d4db630e07702c9a08c5459d18b666c119a1cee3c18618ebde46108f3f6a817bd6de66b28f8f2db74f9047d248dc467a290ff9ba70ae06043a1e1614ec75bfb6f66d25e5c8978a0d1787e222356c6dfd6362d1f1d91b626ce0dbb8cdf7c536da3f6d2f1d8ad19de1bd2b8dc48da4c5d822bfb7e0bacd054d1e163aba9ab4defadc11cce0d63a112aedfd23704fd12484b7d04d9b4f3c714eadf4fdf91a118ec85727fe1abd00bbd248dc485a8c12b5037decf66cdb5ddb54e703aa415baf71287529f39f5ef1529f798c2b1a7b3cd81063223d2e6635f9472d9ce99e7b68437d31a217604f1a895b9149cbce351eb24a77f876b6ecae2d0e15a86628ec4239aa68cfe3c10d62d4e61991b9c9fe3c71c961e8e789119f1fbf238dc4cd148123fa998ff31da8bd3fe78c735ea08af63d1edc22466d5d441e54a77edaf5d29e18bd17603b8dc4eda4bdc2679e18b3f9c3a618c3cac78ed21a10e3aa4b33f0a6e18dc77c9f17b789517dd1806398a98376bd3416a3ff026ca7913881e40a8cef9ed1f4569b63c62c8c0639b070eedaa250b8a24b3419866714bebf958418872362d4a66f13e1d428e63895280c7e0136d3489c014bf98fc26ef9a05636c4380a1146e42ab443b3e93054daa599fbd407abe7908e128618fd21316a938df9a484887ae90b9eea7b2fc0561a8973686075cf313aa34c0753e22d3f3032f2160c766dbd80c69742252b7a84c94155070b7b900e8ea38fd2b34b8caa8bee511308d1f441a16ca4913809bd5eebe697e65f6657012be745704b8c5c40b59a68c6cc0cc7d41cda2dfe85a1fc2e309b3fe4d6dbab4a5e308e70e9a84d546dddec13e36803d91742358b396aaa6dd4d10bb09e46e234c65c88ac2d39ef590eb319ed5090f3ae409ed0363d64f5da0795baa9cdecd76a0a233bdee5a270e1a250b8a2476d08e4bccceade3ca31535b30c413afa39915294729f18eb4245de4bb48942e51ded6eb751abde021eba238dc489f0d9c998c01553ce97ea441fb6e8aead33e637d7d2f2f94aebad6107a13cd5e8df4068a3cfc0cd3356ddb5f5b549e33e3156269bd2357bbdc0131567c58a76edaca5913897aa63acf37fdbcc55b38097679cf3b6c139240b7e0f5d952cf889a18aa51f82707ea8d1776156315656ee6ac51d63900ebdb350257bd4a1a2f48c29cf687adda4c4d77d2f75366af44cbe238d044110044110044110044110044110044110044110044110044110044110044110044110044110044110044110044110044110044110044110044110044110044110044110044110044110044110044110044110044110044110044110044110044110044110044110044110044110044110044110e731f68c0ddba178f50e69211e8881f5effdc8aa1642b0cd605cc8339ef60119243c54db934bc6f876c86bab7cec582173f588f1f0ad99c839df4eda49623c291ae25a986e7b34db9de175753514c2b2ddc40554a2d915ee26158df08e90183f9642d4ba51acfafc4e0f604264ad6e13795f94476fee45bb2bdc2d2a6ac58e4e8178077a516fb788b7a09ac5c31274b09d8de92d629424c60741de22951d94427437dc4e62fc9310f7ad89b1be4dec24c63f892c68b8b82cecc756c23092c9a9be2a69477043dba8a1a0b442eb73350b92456ceb63225b78302f321543e174d0cbeac2753cb9bdd64a99a98748d05955e8af71822b1d8bba018b310ca5123daac18231da54ad543329694d38ea19b568a4c998cba07a8fca2960397a11319d6f76dc2a40eca0108d57b2a310f6efda4db0b3f9225479554f2211c24622a4164edc8a6562c170d70a516b1db8090a139ce96b19e846da493884504f556280d7458d78e7580a24c628949063033379aebfd55fe7fe33e4c5cba0caa24a47a30366958b68c8b470455066c4490caa5df01ab4dc4aa11399ed622b53755057f69bb90deb4533a97688a6429593b68f9ac34f8fe96b108dea9145ab439768e880bb6935d7d2cd5dd5c035a5ace90e267250511c4a35d9fa617342f8bc9ca3de26784b5037edc4a802e43ae4908bba828864a6830e0d5980ee835ee2c0dd4e69db8ca2eeac91af353567ebaaf23bdf7ca9f95337a4cd849d10a6862b509e6a168d2e0bd7aa2131aad786db5b8cea339bd6d6366da950a216f1f8a1173006498ab181ef9dce456d7439ec31ca125730e6aaaf73edcf20eaf9439dab8e7a56a9e9a5a1ae82e9c2f20c802d3421d2690c823068459184190e68255a9876d9e94dcd93e452a80beed781d166332d462e6afb828e56de1737a6903799088815b89e4a408534734177aab92be626cff6d2505763edb5856c710cb520c611b52c83d5200a0ba3442cc60634d39b90cc89b6b037c7a12e69e3927b464a8c2d12706135e8860f7b27f9c415a8a11bc8ab9ceba1501a317d19b3df415df568ceabb4d588ba4cca71418c1c77f399a96254c14931ba8bf6f6c2cd7e4aa7bce821619f3af28e31b62e4689deb63e8e9bc4784f745f6daa64982bb196530ba63f36aeffb4daea54632aa10eb5e5a44ed93b78dab2e369d476d91b62aca619fb4463be479dbd1bcd46a1506c9a3e9ca327c588cdaf3c8e88c4785f0ae8f31a3ddeafa61157ae7bb801c6f278acd86b031fe84f6f86a8e3de7061a47f8d18b9c078775ef068360ae58971d47699b6e79c93181f18a79ba9a4dbe9af5e77d9257459fec445f5ed68ae3ce4a9b159965c80e97d31f6eeb1330b620ca3c9dd1d9d1363f4347ca915350fafa6c4987962cc969345dc05680ca66d5bd9a4b369ce09bd74388baefcb5bec24d508132d94f7b92b1569eed3163d8c832679e61ae498b9a62fcb01a5e98ad31a3531b3c86c4f85e0c78bd65a8ccdc4075d9ae978e56805bf7d5651a6146f63c35ef4eed01739a506d9a91f096189bc89ad939f5376e361dd93c9118dd5bb0d14d97a8d16f9c8d28912ce20ea055e45694add155295ad74b5f21466dde4e58c45b57d78d55eb96185502c32952eda6f9cece18854a8ab15d17e3e8c61c1dd83f498c77a63305dda3115f25f22c9b3f0ea2c9dd8a1ed819e73fed961cf3274b74d3b315087a4e644886d5961a6e5f17a3bec73ed85c2acd66cc3103a3772294df4df7268b195c2de279d09499f9cd52631158572431de17591725e77a830aea4e33b768e1b6145cd09c356b3b7553668cdd3257517445b20d5472d77b68980acfda06aa50efb4e8a72860e5774b8cd33dea419c35d03ee77a9b3a2feb1aec8c8950588c4ce5734a6b2be16a2fea9ef703cee065dafc51ccb9723b2e488cf7c5fe3ea5c12b7aad6b265b2c315b57bdb9a9b0ab8513d9c212d95836267ceda21a8cb94f42abb929c64b654d84f0de8cedfce40a6fb7094379136c3627a4bc38315ea6e4719c414d59dba01bc922ce433522250fd72838fa38a2eb95fdc018ebe1a6aa67ebbf2e1c79a91ee28f28871e47a1fe7689708f1ffc94e97b4a1e5ee1c1efa68350fe8f0bf5efb0f5d8a442f9ead4253f83f38d41ae16934510044110044110044110c49fccff03bc739abb0d0a656e6473747265616d0d656e646f626a0d312030206f626a0d3c3c2f436f6e74656e74732032203020522f43726f70426f785b302030203539352e3332203834312e39325d2f47726f75703c3c2f43532f4465766963655247422f532f5472616e73706172656e63792f547970652f47726f75703e3e2f4d65646961426f785b302030203539352e3332203834312e39325d2f506172656e7420383032203020522f5265736f75726365733c3c2f4578744753746174653c3c2f47533430203231203020522f47533720383339203020523e3e2f466f6e743c3c2f463120383432203020522f463220383435203020522f463320383531203020522f463420383537203020522f4635203232203020523e3e2f50726f635365745b2f5044462f546578742f496d616765422f496d616765432f496d616765495d3e3e2f526f7461746520302f537472756374506172656e747320312f546162732f532f547970652f506167653e3e0d656e646f626a0d322030206f626a0d3c3c2f46696c7465722f466c6174654465636f64652f4c656e67746820353935353e3e73747265616d0d0a789cbd3d6d73db46cedf3393ffb01fa59b46e692cbb74ec6338993b47de6fa5c7a4ee73e34f781a2689b578a5448ca3ef7d71f805d5ae2eb921295699cb8249700162f0b6081e5d5bbbc8cef82b0646fdf5ebd2bcb207c8836ec8fab2fd9eedf575f9e77d1d5e7e03e4e8332ced2abdbfdbac44b3f47c126caafafd9fb0f37ecdbeb579ebde286c55ccf5df926138e58591ee3fecaf7581ebd7ef5afbfb1f4f5abf75f5ebfbafac419375686c9bedcbd7ec59901ff71e61b2b2198ebbb2beeb02f5b78eca75b97dd17af5f19ec9efe4f18ea7f7f7afdea8f055bfe9b7df9bfd7af3ec21b7f3bbcd85dd9b5d72256cc75fd95edd15be9651daf601f7fbd61573df3f03e2bcb6cdb3f159fb2acec980adb4692044c88632a8a0f33a11e1b7e08a9aa4f900df3631225ad29f8ede5a5005bc06bbdeab5c004a703f4d033c7906dc75d590e13007a046453e09bd45b4d63650f1364c15b45f76b2b9e3a6d8e726f65750c3a7e3d37f9c807714e473de85be31e344d7fe4838e8dec1cf1a465f0b14f5aeed8275d6be493c2f0914b474f9acb37d6c2c0bff8d259387de34c13f97f34ee4def930234b71780db370c88f5bcc338060a84fa11022dac971a61ae3ce778100df8b25fbe311729828c8b78291641df78c75c9962d4bc39560d5287cd61579fd1dafc7af3cb076628132287e7f74a4f5d6ea249e58658098781615526f5ee6f1defe0577f0fd27bb688d237bfdf2e0f36897b60039dea5dc017d3768fde756c9ead0ef3cc7d526b174c81210e96f48fb786f1c1b9aea9ed34605d6b8169582bbf0dab691f5ab49ba36977266053916e8b9539051beb6c6c861821f8ca704e60c414ca151f9aa0b4948b8b526e7aa789e0099437416929b72f2a81dc9e26814e0f3626a06155c858424c9c1beea21d42f5e435b1b8dd45611c24cc5ada0bc3604b7771fb14174b6b51b04f39fc13a4610166953d64fb024d6d0c861dd00b964dde9d879fe57a88581bbf24c900e25320cdbcbd0823b4f5eceb02aeee8278c3e0df2c0d2316947097e15f0f115b47e0efa547f8ce8c6e359d4df392dd3198ac1230c0190c976f001bc0284b82bc78887770efeb7235f7d419265e9a6ceadc8b0a1ad81fee1da3c3d933cc4414e4c4bf8720b99b9b27f0a86976407e333b2017239336a0bb60e92df208c58eedf6eb24066d0a5999074038ca6eb143da33f82d2f291841290961469cc5666ea91020159d48eac4c2bba858985e43bf6f329cae3dce5011253199166f916ed8233a7339a97086b70b984854e65d8193f803834b1bd471b188f20206b938a888ef614a1fca22c2eb314efa3dd804b1c8f6247705990b7aeb3ddc0bd218fefe8b4cca86dde17374ef52e6a2b916bc98da9fb2c70830cb0183741ba5250ac6c7ffbe98bb2401f222b472b778ed81c4288101d2acb007a42ad920d1394c8f58cc2e4d1076c2b8c98b99afe4c7e41c5d7e051e6248cf30b8d62b3eb8d69557edf83e850ed2abe616aef4b5f18790b6e351eb88d61a20ae00c9e8568d84c0d135bb60d4869af50c422f86c7336cf6a752406bf9d00cff76a053b9270a20066d1a2a35be6deb4593dc1c447cc8ce1c218ea268bcc04359d461dee79bf6be6992568e45bd8692dd1df65916284ac57d0b22c94101775ae9a7bef19216259f9e835aa4e4d3ac724008a213557704147782903a202f869c30d24c2e33731f13b04df13d5ad4759cc4253a3fcf4bce17ec060c3758ac9256c63c0e1af3abdeeaa2f77e503a7360debcb929729d4aed8e290a6045d11838eecf860a071b09977a70297668ddc3f82e0ebba7cf31ea466b60fe4c63eef9732c95663c4639ccd24d8c6eced25f14ba2c009f6f1e859cc74e9cb4d908b3be1408b74fd5da43ad89daac9d55dba8f46c6c2e45d4b1b7c4589532edb991b7dce195ac8d825347dee4e3057a8c899b84bd2994f08c45deab236f78e3e5668c0999843c1a924972631935ec6ddf1e2b37d618bd9d82bced7b13e5c6aaabaced99a3e5c69a5b656d7202a6205fd758dbf147cb8d35b7cadaae39556eea2a6bdbce68b9995b636ddb9f2a377595b585355e6ee656595b38d3e4463434d63246cb8d985d652d6ba2dc8886ca82233e526ec4ec1a6b1a13e546345416008f951b31bbca1aee44b9a96bacf0f978b9995b6505848e13e5a6aeb2c2f546cbcddc1a2b3c3e516e6c6338fe96f8a87db71e7f77608b85a2b2638406b758c600ebdf6369c1d213afd9e23ce0d3cb8b81ec03c54c9324c9d66c3b8ec06788178e3561bbeb44da152b9aa0f4a46bf24067b20282163e0d1fcdcee399ac803864fc9eeb79ac6882d293aed97a3c931518c44cc3a76ff3711e56c804c777614513949ef4beedb059584151cd3403d5b70f330f3eb8064e130dffa2f840e831cd6a38a357d393f0c1686212bf9c8b2e70141f4ce29773d1058e5cfeefa3ca2d507ad22fbac051c0304d34ce5fe086f0319a25135a7cce5f75064483bcfaef231a2d507ad2cf5fe006584131c134d1387fd519628533a5eaea3c563441e949bfe802276c7bea8272d1050ecb57a789867bfe0237241aa6ffdd44a3094a4ffa45d752c19d8991bbdbb796caa20a898eaaa998124bcbfd670ca6eba2fa6b40a5766584e5446c13dd635d4714b1437d4af46d1f3f62751e168144583c53e2dddf65c91bde89f2222e9fe12e8ec7ba12184fff84d93d96c4c57fe1a33874c3d6cf58e1a74ae76e61f0535c147d3530e752db0ad5bb90eeab5f3919b843a1d0f43c81dbe74bf4e133a92088f6286b6bf717e040b0db25b88b1e0629962eb12dcccc9eaa9e4aac7a4a332a0f5a4758acb9cd54bd19712fc0faa1f18c1b595fe859289f6d5c2d1bb14376a9aabe8265c96666e8d82ce076009f9b4a218c6e8e04a459e5d247e5d8665bacd392da7654ec392f2e9574b45229523204480649439ca5e315656c6d236dbf4dcfe2b843353ae74f05ee26d714f71d4e4548025f16ec09a53f63815286787e25e0f64a74a0710b26fa292eff92a52d09d62ca61b769791e56e2867ca540d2c561e4a3b1e944796178b9651bfd338bda7bb1956245e4ab85ac9a197aae5872c09a89210cb0ae31dcda658dc46bb124df4768d2428f473fc9d9145825f92188b2ae37512cd2d9602903e25a1e5f6853af3cc21e70d2da94be516a4e0c870ef68d2b2c77803d7c1cce36c2751591ee6f3ab2c0e66d1ec26dcc0c6ce36be7da5d1e7ac15aee800b485b52a8893af4b7697675ba45d2c3e63e1737617617f4191e134e57017af6d4f77462631b09d967bc8a87e96f815a7804b51c6e51eb514cbb50b2cdbc66e0234fb01aa8342f499bd542b47ec294e121aab4a8f59b1df55ce56fe1823b911dd01023f63b9f207bc3bb7cad886d14da25667863b50ce9df256e6f197f4a86742ae6cc5ecab9a812d7d6dd8915c3922725fea4c81eb1f90c171c1f27d8abe16d8f907b085a4b74599efc3724ff66fc33628b421297a869782841587426d6c00819fe45242dcca9dd6dd0470223d70cdb6fd960884d55d8409b5526e244540a794ec980c52dbf1604b6ec05ac782cd16abf28b02cb3d636ac6c1450bec1a0c2ca39c65f9a5e86ee568950c29ead03db3a49efa9d7abaae1a04c22c2de2cd8b199641d1513700d1e835695ce14cfe0b6422db93435eec4384c19ae5adb3d1dbca016fb2702fbb05487f808992512112494c7ac2153c49f0018817f2e83f11ea58196d96fd3d0227afd16070ac5352d5ee7027d2b9d366599d8bf4dc4c8211aed7018d9a7fdacec043f0482e0068575444e46f850f6c87d623db65284ea46a098be1776a7c53faa96496ac50196f7131b9cb836d842d71280660afe08fb2641792c4560a5cb6a9a4a5327ebb188551b5ea81f6d5dae202e523392a80016b81512fca2cdcc1953694dd7e24d7db3d2dc26c8371d76346ce120ba4484beffadb9e6c144e44b35c7b36825b39f6a0c41906dd432d43a43216e33ffded7d27a300be9b274e48f3bbc39d5c674e09e6de27f8be6b5c655848ce1dfcb5c52809a5c2aea402a53aa22514cd6f514823fd8cfd5a494022bf0fee494a8a3fc1a2c1a28c0380f7f9c5b8de4ee7dfc162d672dcc02b445a373116e817570061f6d8d3c54b6d74d06eb824f9d2d3985bf42ce16369d5f46d0db72f973e0f5f9c6613616732802c2c5a9504fb98c9c46e9ea52ca66499ee40631d341a77703fa73ec42d1928083b04787bc84e5af2d18461875e8ecbbe5c702f2370ad4d8b5a0f6074d4ff7c8b8d35ed46c0403511d662720cc8d17f2db3cac83e239928cc1487151138404bec803c725ae54b714ef0c5b30727986d334fd8a5f1fa7645e661c0e45d1aaf6fab623c3e5d3586153e7426cd113a9ffffe1158f4eef623f2f6fffff105db447f3c83379db07dbeb2441bb6762aa6ee924c634d6bd7069d864f37b724d318d360773d5a015a9251a52bef9d4295cf0f1f58f162292b9d81bf496d603552761d35485a932ae8d7b7059f4b9ad1ca3943c0511431468da9da9d214d7de917fe5d9e78f3088649c62cb46f32b3f587f8caeb406ef6d4aa63e2a65e1bd08b81fa0cebebcb5abb074b26ed7815c7c1ddf22963d4f3bd0b7262dca55c5fcb6f26c655b4f9629a318edc834fbf22b1a3fd9c2a448ef1288b542585c88127a92c81a2fd4686a6e4f33e67fb9c6110f7901551dab51a756ef45d8862b7d9c805e1c55931aedd050cc679660730d9440874c2e4cd4c9f6ba09d6b839c9d363cb2ab034e41a15dc4beed0396caacc2cc9a65c12a3b3381dd704875db805e34789795182b41684869230a9ef278bd3f6493aaedb4a0b2e9b40f815a8ec11d25651fe8f887b991b72d0f73836de4e7ce8ddbe05c985d227e29c5759abb256b99a84a3306c11472406e304798f8846826dbdf3fe0cc1f710df91097d2ce40081e5627ea148a67ebe7a310ee53244fa0a0e83d613728d270770b6b198674f12518d7a2120f93333ccfa3d3e1b2b3f601c5c0dcda8d0d8eb786217cc3b04df8b10dc3b0e08f732df0b2033fefafdf586fe56df1e9dac1cb423e69d36df8b9b9b6f1090b2fc9a7f125c29797e9bdd76f4c75d92458d7de5bf912e1c95be2067eded1fb6d5ec3c276e1c783bb2e3e2d6fd335a77ae1b50b8f990e8e300c4ea309b479834fd2af84d0cd6190ba4ce87beab65034e0ef9f14468ebaae60be77ae6932e82dad92a37964df6a7691ca5c51b1cb6853275e9324e329054226196470b40dd2e05e46586b702b32126e5205b9ca87d1662f5376b8e0e2c6a88d2e070e0820404b66cfa90a0ff7d3dae4689df1aa4f4e9dbc2211a80e5ed11d4ce1552d6e8793572cd36c9c6bd2e8b6fa7668acea79b47db08757f5c3a96345cdf1adbb5ee3ec0c0d545d3b97650e37eefe76a0b22a4293f05e8e4be9a55157e239f01e6d2d1ba13de49d1fe1ad0e4b51f00e87a5f4223e943fd4bd48afa16331afa1e4bfc865edd415d3760fad7c1da70a1d64b3e7c936f57ebdc1d6327cf4124689a6df68b01d06aa954c6e769db6721b2554cd575220880b9db3b8c13c565c46791c68cc83df3cb6e84414b96baedc3e144730d4d794ea4bb48ece227527957a2262d3f24bbea656ff80d009a7609abe3fb6e2560fa7bfe0b60e464fb2a61de03c923d67429df159543721e909d734039c47b83ba543e62cc29b90f4840f6fb84a648ece881ba97495656f291d2641288b9624d9d3e1504e4c6b6de26d94d2c1cdb4a75e602a4e267a30359fe05e50484708c1b3a1b46d94a10ff2082d1eeddce3767d84db4058281b50e14ef2dc97153d9538db74578ed05b94b9661194b823df190618bf6de20de58aa21fb140e5679901bc7aa01a051684c126a28453f3a0a8b351b31c074f066fa3b6cba954314e224aa5e6b48517517560f8c0a8941997a91d86f3b4c7375ce57d2a7e427e88a08d9f562186b74a5bf84c8a15d130f14607b2e5d6c32615c4091516e1651920ca004bc5882a22a3f84a058314517ea0c1d5931862f10f5df1db7be728763b8a2865d8a8623b2e4157c11b05893787f04fc571184702000a400d15522a9a0825f725d8adc25709e0408f8251d1e450402ba364494b05c6e6142e12082280ee72de13398e6056a77e730890449b597ad919deeb3c119d4a76dc66390925944334741bace5d9ca3366c32a079d96d17fb1d4e2473c0c5995557cdb07092a9ca82a8a8bfd4ed62b3fe2684c4b63b9853c43956a9fd45e4895b503bb9280017734db206792ea340f62b9a3bacbbdcaf22376d28c5096691b03d559b6a3635329e354c65869d25b117f22769670f0831b6decb427031a463d0497088c3efb94b742702c311a1982f73dda8e73b8513f8b478d1c770ea36135c38841b8ba50c714c3a7d9b48370054f1b8403421a5f6fe045da3083f09e16852b78fa289c1b4325ecba37e9b56e2cea759c9cee389c0be3104572a39d643a4868dfa35d33e0d625d4e2a343716e348e0ad5c0d54aa825ba22ddaafec4559b19b5195423f9d15945c3072d71c39f1769f3e55b10c7487fce299d99e3d1d23a5bc68d9930e2963a64b813a531b2c735cda112339532e8c16c286eb3a6b4af8f013610b93561e91715ae39d6e180502f5b860c9939f5502bae3b557a044243dc30a674b09f48bc624613d408da358bca79b473df3e49124fa0bd056a04edc39d55121de56d4dc1472d4b56b3bab4de182bf78dc9df633b0cf9c33fa93ad4c1a65955ed9eadcb00fddb14ddc5aac9b9af36f3547c05688cdd816edfe6f1e970042e7a6d40db204ea89aafde383537780fdb1fdbd07f8dd3b8c02aca9c4a0a710b7f5ec0953cb40cd3cff1fd4394b38fc8db3d75a620e5b8fa620602fbc6c238a2ededf80e534621fb27d5d95b58673ff7ece009f27ae339031c29042d40fdfdae2783e276e53a34b2507be0f8dcc02cfae2641b585f2c77322061ae9c2e407a7337dc1477ae781bcd8a6634771b59b39cc42995ef1e159f17fbf516addf7147922aa76f776a61888f2d21b333cdc3869736ea1cb0806bc6ca34f02b80f6eca608e0764d999e87c369ef3379886b6867434429cbfe8aaa1986ead265cbc81a598915e9db58b60153e39dc5287d5ad2476fb0e9b0623b35956e624af60425b6d86c58badfae31559e571de3f3ceb66dbdf822e3d2dee7cea2d7fc004a489dc13b14f2a8387cfb8bcebac8e55e014c6afb296cc14f93e7af4bead3437de267a14c69a0767d2c8795b12686b01cce3b3358e1e4898e99999b0596834df66d3845f4d2c613d2ac825f95164c557d51c73a5a1cfcc26ef2037542c6f7697f57ceb912e2f83d6d9072fb0393a01b59d0861f8523b52ad4e7473c95db940943a99254094e76d259142b2ceb5169d3ac4407c3c4f2623503f23353c7673a90610e33d9ef56b08bf93fdc761afaa7667f6699362deaf8e120da8e7951a956fd926dc2669f41e1ae6cd1014831758599f24f199eb304729d14077ea395e60632f91d76151f35055019f74ffb781325b49519c9adcb47181f60b38d3cd603b7b8d477c72e2516c2eab496a0a1289725ac18787e0166d1b1924d156d7e5d50396d44ad94eb28410d7efaba1cfa6ed8c926053f24dc4252bf527bf5d4b9045fa5cebb128bf5e17e2b77ce4d973eea3be2c3611d8ff67e98caac5709a9a123bf1cd62c13eac3715c968f5bc6f069eaedecb90238e2d361a62eedd47cd394ac13623e6803dae973056fccb7c3cca113bc3a5f354903c7e25ec74974e7cf5d9b567a2900b639b0c1d3f36417fdf51a4bcec99b18973d379b45968360b512caddaea46f33796e2dbec4d823dc4c62a89718c79f05d224d29bdf053a137f18a63284c7f87fc2eefb25f71758da82fe10b6603a8b3f7546ce6c6e4d9c881cda57d7ebc36e94386a8ebe9488a92c77376243794cee8e4d628e003490c4acc1d12f3296e680cd03327ddc18225aae5193e9ee0335407613d208ca75df9b3f87727fca21efe710de0434826eddb7e6cfa1dbfd2edc7627727af8f84a898972eb26a0a2d63edeec64fac72e3afee876ed800799904a12aa59eb71334fc4c7329c6e7ce6860300ccef0147387892cee5e1380ed63cb5e1701b5cc99569001b795ffeee449802acf44c84754bfcf03994674abcd1f82c603dc5c73ed017ce31638b0d733fce2e7ef885f7160e17128a2618ae72ba9792093d59ddfc1ede873c8fdf7ef318c3db2889a81e99fd42878d60da277f8ca3a71f58804d8e7fcece73d3439fb985c86598de0223f7f70e9b7b62f133a5fae8c43cb160781a0535bc1f8e4b687f34f7db2c28565f6b6e76c2ddd23e5f4cf5c721fb272a1e951ed3510f332f33d8c7dd4260aca03af59c8644a2ca6974047bff0387b22c4b0d0a656e6473747265616d0d656e646f626a0d332030206f626a0d3c3c2f46696c7465722f466c6174654465636f64652f46697273742031322f4c656e677468203231332f4e20322f547970652f4f626a53746d3e3e73747265616d0d0a68dec48f6d0ac2300c86af920338d266abdb40844d1105f58fa2c2f047d1d215e6366611bdbdeb2a82279084908f37e1094f8101f5ce092613ccee17555b4899c0eca18fe66a4b88228e33d92e95d1a58598129c2b2f0b8825b8a8a4be4348b8686a9be7cdb308048f8719f050a46ee33c0cb7f2a630eb8cac462b2b2b7319ba477f37620c7d37ab75a520e0846b25afa6d61086b8914f4fc393788c3bab6e871e0cf7af560d571c52675adb7478fa909260d3694171d27ff85f1362ec22f399af9c11d18fe6a3fbaa1d7b5f9ddf020c004466649e0d0a656e6473747265616d0d656e646f626a0d342030206f626a0d3c3c2f436f6e74656e74732035203020522f43726f70426f785b302030203539352e3332203834312e39325d2f47726f75703c3c2f43532f4465766963655247422f532f5472616e73706172656e63792f547970652f47726f75703e3e2f4d65646961426f785b302030203539352e3332203834312e39325d2f506172656e7420383032203020522f5265736f75726365733c3c2f4578744753746174653c3c2f47533430203231203020522f47533720383339203020523e3e2f466f6e743c3c2f463120383432203020522f463220383435203020522f463320383531203020523e3e2f50726f635365745b2f5044462f546578742f496d616765422f496d616765432f496d616765495d3e3e2f526f7461746520302f537472756374506172656e747320322f546162732f532f547970652f506167653e3e0d656e646f626a0d352030206f626a0d3c3c2f46696c7465722f466c6174654465636f64652f4c656e67746820353432323e3e73747265616d0d0a789cbd5d5b73dbc6927e7795ffc33c92a72c08180c6ea9546a7d4db2b53ec7592b270ff179804950c22e057001d08af7d79ffe06e00d03604062a84ac592a801fa3add3ddd3daddbd74595aee245c57efcf1f67555c58b8764c9febcbdcb37ffbabdfbbe496e3fc5f7691657699edd7ede7eadf0d12f49bc4c8a9f7e626fdebd65fff7f245e8598eedb2200cac8833e10bcb0d99135951c88ae4e58b3ffec6b2972fdedcbd7c71fbc1618e6dd99cddad5ebe70984dff392cb22d2158100596e3b3bb475af6f3e780dd972f5fd8ec5efe24ece6c79f5fbef873c6e6ff6277fff9f2c57b7ae36f8717079677f25a60c58220b2bc50be55beace315ecfdc7b7ecb6870f6ff2aaca1ffb59f121cfab0e56781e4812c4109f37141f38d12c1b5e04aa4e19e4117fb8a44461c16ffb97126c41af0d77af2521f81da087d61c43f6fcc0727d2608f408c85ce04dcd5bb96d79c304b9f456d1fdda9d4c7d55a24e68b91d0f1dbfdee1cec885e0e9a885913b6e21e7d1c885be07718e58e9daced8956e307665e08e5c29ec08523a5ac9e737eeccc63fcedc9ff97dcf710ef91f3d77d3bb52d0ceed0510f43d46c486e1e139461b08fb6341b4b05e6a04b742fff821f9c0dd767ec3671940a6653a17b3b8ef799f5b5c8ce29bef9e40eab039ecf613accdc7b7bfbe63766342eac78bfb669f06644b2382670b4bd0cbf86ea7aefed6bc83361fa78fdddd4a57088b1fafac37df3128e7f6bfe2ec9ecd92ece6f7cff383e91af39e7e23ce9d002806fede8a4b7bfbe7ec4d4246334bb3b937bb67f96aeece5845df3f24ac24462f1ec0f47c4d828e8bf221a5df6c7e681983c9b8b922b47cd1819b7140be8fe75440b485691f719bc8747cc34085138c22adb6d68ae6f14603b8e3603f355890810e6ddbe952b9e387ddbddaee35d6731004ec34d6dd79b5638dddc50b3d4b5595150d982652a89f23931cf02e08c74f7aa7ae5903b36632ef8f513cb17359dd6cfeed40a41352e4e1ef00c21a0e92e8f7ecca11afe9570d27921e1968f371584315ed3d38e8e230dac18031d1bd476f4c46e27d8c50d86d4885c78fe4cea3a85f6522259aeb7eb826a2510c37b4a24e8decc2d1b1cf02a1d54ae1ec2243b90f9d3ac67dbdd9acd3453c0f6688585bac6b9ee41e367b83f7f056771cb348f3b089298f715ee68bed6392cdc35955c225b7b05691e2869072846f797d5869b1704fed93c347db27475c444080b35507531d6105a182ff97d9a775129709db14f39b7096cf6f1c3efb3677bc59ba9cdf78b384cd6f8299cbcaa42a3bf5c48f22f8860345628022cf2845e439035fa188e20831638b1cd86fd284b0bef16779860f75b2f2cda0e7b892253df8bd9e73772688cf84d026de50d093143ac402438851680f9bdf85186264db217782a0d76ab1aa5eb623cb86f976856587f4507890f7c1ae36aa11fa47caae3121a149d5f0c31030dbac87aac37490ba2fa55630a885d4944aab1ce7d9fe7e1990bfa323700f86650564e2cd3ad1a0c32ff3132a3a141d06bde8e898c22f33fc1d584470363d58104f040e059de6072a3dce9ef2cb1c429f8a055ed7ee5ee638b96c21c5c704ff66157dd0369d2a6eae29d3e3e184d0835c0c5b9e2d09a15b7c97176cb3c519abadfc0d85be7d6ad987786bd457f974940e84aa070f847902cc1fb5fc34e4691c3af904bd08a5245c1c51d986105b03b1b8ac52487dc1ca8724918adbe3364530da3672437e690739eada64a40c5f5399e6582645f965ae63b02997e4721c9b7a90b2745818f21a0e7933c1fbb0d02a5b347c406b50a2031af7824e94dc81031a45f0f6f1f1fd47db7ee7ffd43ec18f06d579a6b2614415485ac25d7b34e1dda2183a9822dc3e0f9bbeecd5586c86a4e0780877ce97c278ba1b21b401e9c9e65714824dbbf33c6cdceb61e387d1708a45c5465c4f25fcc0bf6c639eab120a203dd9de1585e0bbe7ee4b4dfe6a12369e7dae4af4a5a54ca8841b3c934ab401e9c90eaf28042ece5589f11ef37c2150c866f3e710421b90966c31d55f0e90ed45e1f3e89e02484ff6151db347619f2d9e83ec36203dd95774cc5ec0cfb47b62aa631e1282173d93eeb501e9c9be6204e009ff9974af0d484ff6152300cf75cfd5bd2b46001eb7cf0c51c5d40860081b5b536c55b199ea98071454d0976771850a203dd97d11405df06e70690adea391696a83287a9da8c4dd43c23ebcfddc57d3bf109a6f5b2eef80c6e7decc76e662d657cebf105e28db6654783786c17832cdaf926513494e6014986b87b0252a30b3a272e9a3a8034abe42b1285da4f11acd27b12c8ba2c74796455724c7bc40c1e091d1afbfccaaeff465932c594cbfc9966c53a45995d0f7cb2f732c6b974d2662edd9fb0cd029da7f9f23e9780a4bfe6af7841bc9364b8e8a9f8d94d62eb768688329b99987385b3e156955a19c05ce453bcecd8359c99ed2f59a7d352b52ce153c640d2b24e5450dab5d2f980acfa5dd2e3a48872e2c16c9a64a9666010676771ecc320cc6b5fc11e9b6bde87d747d3a9e6ff153d552fb6bfa4e3b2634d0f14edb3fdee6d0b64d3af76749892c36abebc03129dedc7166db2cfd961428c5a4d57746ab160956e1932a5dd1cf6887a0375449c96234a42dd97d112f13a3bc16847514aac89b35e0c2892cde014556244a360fc992495ac11a77b6c837692277e923b1615b3605216ff6d5f00eda894ec929c6156a64b5d86817bd92a698cc2b5a3d8a382b5145915d80f44b96c22ab3bc48d16fbd96b535ecc022913d21680fc9097b32ea197b4f5fb2fb752a5ffcf00a9ffe4c3a403fc02ac5d92b90ffa148b2c503cbe9fdc555e855b396bfa2c9315ea771660183d7f891f4ae22af03c35e13ccc8844225dd5946963398c1cdb0659e25eceb772876d328f97b5baf6bb38ba763f673fead6e2f901daca848e25f29dc7facc0c77421d9569835299e20f77341b6d61b6e3f9d2685c06f87336c9d40efaaa438361805188dee1168895175a01839e41d884019936c499242d8413fc07f8a5991ef238f4f45be925bb4cc8b929166036d14c4e911941e65335753685ea5c97a89055f6666854a7cb4c30ef46b8bd1b615fbe5f5850fc55b1892aa928c4efe5aacb724c192b6c5fabbe178df43b78b36013e194c687551d608fc286465b5d123d508a523234396b483d64d413600cd5c643a9fd2eaa1b61b733476c968179e505a998e46c03d931d79d1238424af21442587bf8917ff1b13f2f709e26ad770c4c3891e7141e5c0ebcbe799e001ae679c6cabd7ec60873664a912ece962ef2761a5e2821cd786ec426d2a3690bcfc25a986e1ddef52bce77560f918ff65381af5201b058e056e786c13df27b072500b317b6576e309ee758b42da13192e326c355818d9819a4aef6ad8ca8888cb862c050bc3c446f29a970a86cc0c6954ed0c57b5993905bc6793077be007807a0daba014956a6b5726685b969a5fa0d76a939714069a75d401ee056aab5a93531ff240a98259e5c523da7169377f3bd86d046e0fa47ddd76dbb18f8ca6594509a3ee1a9f59a30cb5f72f29257abbbac6aab879fb8b61abec382d1f21adf2635ed1d6f79b2c113247497d82293afad20d68091de6544cbec0f61a4e38b95c96f65460dc702ac5c59d2b158ce98c8d6f7541811329cd42a2602d5020211bc55d5726a3becc0d676dfc080d9e5a16aadba5af1e6660bba032dc11c4acb6483478b22bd69d15055cb7b45ff2671cecb78f4c06a9552ca31c69efe8d82e0faaf90a1fc50b19d72c650328edc074c136dbaf6bdc09dc9b41328e59693e5cc46d4de2b14a9c96d57d353813ac46b7a3df132f6ebe1f18d79c1aea5f64abb420763fd6860b0e7e1e1d9f3363f6697ff094a70a1c38a54d8baba39c834c7a13b3c937c9a0e8337dfc84abb165bbd7d510b14ab1fbf7ec107f15c87c10553576710542886a9924898b44e69e53120328c859b9dd24c5b794e86e22ba9a26c381a48b9bc0da1afd64305dacf9f4f08e215550615f2d53192e1b76132244907e6df276c2f7a2d6befb35a3001ce9120a8520ecf2014993a2626fff79d0fbeff9b660f1225e268f29e9ea82c9881d91fca64e017e43ae8dd4dbb0b1409520ec40fa3abc117ecb0afc7a9c1baa2d6399802b4ff4f3434d7922b7022df984cfe877ef90704d4b566c33a80ecc6f9a35bcad8aeda2da2218a5407489fca2b4c4555ec81c26b1d5db5dd406efe9fff52ba421e3eb10acb41ef45a3cec837849c247da8ccc1dd2a748f821d55ab09c94a38edc626c900ad4d259421abbfce85571757429bdae10644b789d25fd262056a65732794a57c3d7848cd82eb5db987399e75a2605896605f757d414fb44312e21e0bbbcce31ff4132055ddb5dfeb794ceb7961c332c2c6c020c2551685882b3e4f60364a2ab932ce6662db35a750d464d4519e2aad29d511726137ac9ff40c56bdd86735b1ace39853e2e189cdf1ee2f5b5ce186007ba363a8e370f49bca6006c01d781c937249f7d71ccf4e186cbc613050fd3d92bdb93d3871438c7999dbf5026446ac77ce6b819a9a2c237ccce40766ea8602ae5f2dc5448518fe08eb3d38d1ec1fbd6b5d69d2ec94a47d264a7e9d7d21523d1718ae35e6a5ce64982eb941044d8eeae38a4c977b916ef24d72264a655665b449da236cadafab6b98a96e103a48810a3aa60b4066968acc35459f8ed2684f7f1e2811d6a5c900a645026d5212b46fef0491e59d8020e6f53c7bc8677969c5ba5e267785b85327a54c19c44361b19b2949bbce8babb39d577a3762b3a5020932ce8e44881e126be97f5a327c41790c1153cb5f0bc76d6860e7a14c5c9e206055f31da180c2755788899222a68ed9650078b3413731a3c76137306678b78d1fe2df7bbc9246e64456cccbc9c9e951db36476f7c6ebcba0f573a3aef8faadbbdec33075333e306dcb19397866d79f2ae1e9a7e5e8daeefb5fa36def95580f99cb23ac9b31373538fdb41cbfaf3f7fc47bf4db692cde27180945ada5dc5dd73b927b7bdec741275beb5ceb641b9e40f24e9592fba32f9efbadbbd1ddd88dd44939a0af7dfbf7ad9c1d52c90078311f3129c20f4ca0e4e010e5f7e09466b8671eceaaadbc80de37c3473847c311f86ee666371f43837c74f617168f915ed1a1bbbec2cf0ee73d84543a7e4646f819c891923db88dd80e81e6f2568d5573f35a51777daf3e097afc659231c006daf5dbb0b42e2ed05ce13ae0d3b1d5f566958432e80c547c34467e043e43b2b0dd8b647116ed8d28daa0f4a46b2e724d13851b9ddb16130c57946a7476930bcf604fe3b960ff4e02d1dfb632be978643767fe2cbb2af2ade4c0dab50cc78c51e625932686a015f13566ebf22ac4deb46c0a5cc451d1253ddc1e5548a14655fe5eb75fed48cc18c97cb7d3b6b59fe601a07f436f04b36dc70316b2a4fec76b7dbc7344bcbaaf85eb7bc4122bfa0c2742f73d862c6de23078b84e64296a6206eb40c7f46da3b959710909f4d57f87ec1fe3b41db888bb611c30c159e8dc49e4a8069ed119e8b104e0594f6e64a2f068572b6e80075b725a198061686161fc14055238733a3133552b5836f961629da3fb66b3213bfc04ec85457befd7fe35b14ad766df8ec060b9bf16cbd8d6f97c24422963e5289a677cc3170d930382ed0d4a2f535060005f0ae2aa03b647ecd2bb3eb3930afcf4018c69f8e00a4ee9ae1f4ddd45d1304e7fa95beebaf66f0f1dbed64ef4def5634acf10e407d777a2e0714a0615305f418a7eb1f50a5340d9074d9ed02681c10461076c0a98b9ca85a6ed2acfa0fc469096a9b16aeeac80690ad05df9f19df5b81b44e2308efd4e8e19bcd5335da6b777cdd25ebdea9e81703737d3ca7c0ba92e81538b6cd89f5c61d2b06eeabc00287ac106999831601d7efbbb47db13a8950aad3086676a953387c8b72aa3ab961cb60ff917cc5b633af52c2ad4fa76d8057d22905ced3d393f5286f5159957193c1657e750c719d32dea5d69bb2418dc67ecefed048e5902b55032083bf7e31a26cd0b7544dd186a773ac9b0747a56843d1cedf0d42d565175dee3519d1b18583069eb672106a86a60cbd479f58e1ed8e4d6de9a081a7af1d84434721dd8bf436622ce6272805ddc503c711b844b71bcf6987cac0f08376f6aeede04078aa9e7684bfb0324e3ddbe9650d58ad7e82e7eaa0f5cfdb47d9b88c73c73ddba28eab8b8d23db14668e274ff43da88d1067a4c9ff3698ede68e766336907195981d5bcec18ceb2868fd39570598f6941269d2cd4708f5ca65807ad485cf27bd17523fe5a780f4646b52cd53c90ecf999f3591f2362c3df19ac96153890fdccb34fe12e2dbb0f4c46b5ce1a5f8ec88f7ed33f304916684d85484c4b98d9991668ad854f570cf19dd35513ddab0f4c46b86964d950677ce550fcd40d1a9d2a89f781e69b461e9ff6e89ad294d4f1487139ddb11e5d8e3e3858b300a35dd431d181970e14318f9ed3aa51ea3eb7a578c687a2e0ba2c01a41bd01f73a240fe19ead21067cde903c5cfbf9e4d18635827a030e76887a277826d24f008da07bb820d220b3eb243d039be6f0ecb46fc9ddf5de36bc1c1639f0e678372e5f3b0112fe94b20a6860b8e6e5b0eaf99a2a30ed7ccdcb41d6233655907dd59c0990e45d8d0ee206a76c5e0caf19b4f90c2a52cfda54019d356b5336f763b4cd438e3e8edc349282742bea62ff85ece8362dc3b5cda9a6850ef32d17f7f69fcdad083193d7e7f315ee34d537e5f7ac4609cdb8cc5d172353548cc6e5bf1d7bb86636995361fb9eecc7e1111ef5700d5c2ae7fbfb3ef709eec3f6def6b99c779e6cc952711cc93b67b84034997741fbcaad99490387b955ab0497884b5cc96d4f19c868112e867d7e3adc6aed648b397295cc843239540e6a940305fae70dd032b9c23d1a39b0bb8add4c582a5a83bcbec8fbbad9626da10ed97125d728994abea3dc5fe29637e9cdeb39f7e41fd7d2665a7af57c783ae4648eb8edbb8c230644ea47376e0af954528f6efc3243cb62991ced17444e2de797676bfae0bb7911785c0e5952491d2b82e109789345a04bfbf4e2357477c6005e76fb325ce770be66287899de930c33b25af5b4be242ef67fcc9eac5e7832ad0fd3d5c47e96932f47dcd197fb841c0ddb96a99c608bbbc9d1d1d564ffca3650cdf774cc9efcf096befdcc0ebdcaa073370bc27c50c9232bec400c5c047bf34d0efb2a7bbfd76cb59f835bef412c924c3fdc34f687aff962bccd9599aca4b0b403dc26985e0f973ab559b3defd35dce23f9915badc592f5ec34de993f1f27c65b84e2e7dfae2d099066f50b23a04eabce75ec269acf62ad878057c9b7c4b730cc328d7df595c4f26c9a47206a741c72dae354863b35ec3e1d49128faddbbe7cd195553258fb64c37ebfc51de4196a70d442b7254baf95385e3a0a0ae4de5f5aac77087f864d6b8ede6db8fc9325dd4267d914835f08e4767c0d04be74f22cf77b3cfc8a03741a16a614f2203f3e18010753b8142c758fe5e377546ef6fc9fdaeb9e7bf9f80b3df7e183307366e62393c1d97e32bf33e48e6a354b4c6b26bd7a3d274793588ec2f8777f4c2fc1bdc8cc5430d0a656e6473747265616d0d656e646f626a0d362030206f626a0d3c3c2f46696c7465722f466c6174654465636f64652f46697273742031312f4c656e677468203136322f4e20322f547970652f4f626a53746d3e3e73747265616d0d0a68de3c8ed10a824010457f653f2018772d229005338da07c48c1e749971cd0557647a8bfaf95e8e5c2857b3857491109a544bc154902c71b94931b71802c1512eaf76c207ff1b96264a37558a037c564195247386c2e8c03b590db76eac83ea1219b5a4fff5e90f39cf5e844ac207027e35b47334f4ec8c3577d872bfe1652eea1c4d140b1836a797090d76e31eb8b355671431df75ea828d05a7f04180033d43ea20d0a656e6473747265616d0d656e646f626a0d372030206f626a0d3c3c2f46696c7465722f466c6174654465636f64652f4669727374203831372f4c656e67746820323333392f4e203130302f547970652f4f626a53746d3e3e73747265616d0d0a68dec459db8edc3612fd15fe41ab2ebc018181ec3ac1e6e6183306f661300f6d5bb1673dee363a6dc0f9fb14a5c3be68a62935f2b0c0608ea42e1e92c5aac312c5e23ac7ea5274ec9d28390e4e7210c7d129657b9c9c7234cc4ec547279d53154372eabd3a61a7410cc5692443759aec47f14e331906c36c189da72e394986c9303bcfc1c83be7454b6786d948d8794dd68938a3b77b753e2443ef7c2c76c1f9d495ce0c83dd1b5f66bb37be6cd3f09d0b5d694c86b974e202d97cbcb8c064f76a68fcdebb2036681f0cad5f9b5ad081dc05df1966c3d2d8f8ccd0480c732171219a138c32c46064f6177369e46c98f6a3f1a5f2cff8726776f65336a704e3cb76133bfbebd8453234e744bbecca43b1479dba687f64ce88de30db8fc5c49c664b10b9dcd8a5989f6336b4c9a7d234b14bd6c416ccd965549b84b92c7ae34b66eacda9c9f8cc712e1945a058563c0673922d450cf66332bec8ecb2f1d90fce962c265bbf328464ceb5a9c7648d72e99aedb9f165736236be6c46162ab62cf6bc0cc90667ae4f644144e68344e610eaac33b695239b7d62293f895d9823cabc9374de2e6c2062a3255b8124a93c315e95d2ca8835969f8cd9dbc8888cd9db9291dd249fca13630ee60422630ebe5c94d8360e22638e365e22638e360b2a4e28914a64cc65c9a8b82fdb30898d39dbe2904d34655b121a3c6386df7db7faa5244ce76e56afd7bb7eb37fb3ebfb923ce74f5ef5dff6bff47f39caab9bed63ffdbfa4bc9ac62f3e6af2ffdea76bffbfa6e30bcd96ef72f5e14da3bcb976261a1cc40012ad00303300213300fe8cde523820f347e6c262cf89981f55e811e1880119880e886d00d11107c043e021f818f06befbd56b378e60755b1c36cefed5d7cf7fde75ffc005ff14db2ea4a8407f0105c840b40b011827887601bc3ee3be7b1e3ddaf90404af078faf76748e0a5e453bc402a95ec0da0ef350f00a780476e227085e41bb04fbdc5d409a204f5026a813f433182618db1831de84f1258c2bd5f9601c09fd27f493c09fc093463f338f7c8c1c62c673e41233b0abf6b0436ef128288e91633c4a8edd13ee05f78c7b20728f1976c84166f050f50ffaa13aceda5f1d27da759517e3a53ace1aef882bcc87384d10fec17c08e3208cef09a27fc2b808fd12fa25aa763c41f0c27f84f113e6f514d1aecea3e639f21e6184e8a930722224b1d208f4098ca346702056105a882c00e20e6e848a406c5a005d819c84b17900d9d81124088a1400630f901da850182cefe94e2017023911c88878060a50811e88ad053225902981ac0964ec88e0c5a804c3128c6b39fa098609c609a609e67384eb8e4813e409ca0475827e82618271826982181762471035025912c892409604a126883c41200a8255109f021916c8af407605b12d0875411e083240209782ed5220238ab4d15a7120bd14e9a5484745fa29645121870a1954a4af229d15e9ae487385bc2964ed88e0854c28644321274f11fd408e14f2a3905185bc2a6457215f0a3953c89d42e68e085e01afd40a8c6710fd617b556cab2ae84fd09fa01f6cc78aed59b16d2bb6ed238217dbbb2a7835cc20fa43d9a0d005852e287441a10bea6b8939f473cf770c0f303cc0982963a68c991e111b1066cc983163c69731ff7f112bc0580186e7199e67789ee1798687191e667898e1618687191e667898e16186f2329497a1bc0ce565282f4379198acb505c86e2321497a1a40c056528274331194ac9504886323214f188e08512321490a17cf3887ea1840c056428204301190ac850408602321490a1800c05642820d7c22ce5738412329490a1840c257c8ae807cac850468632329491a18c02651428a3401905ca28504681320a9451a08c02651428a3401905ca28504681320a1451a08802451428a24001050a2850401915f07e38f81952d941d3bc83a805879c8ef52239647776b5eeef5c7d13a0c315bbc35b83abef0beaa4bec11cae82935a8d3ba4370d07456560c35be2f79bcd76bfde3f6c37abdbfedd7ef5fd6efff0c7da2e86bb7f7fb4b7c993cb3f3ff6fd7e78c55cbd7c587fd8ad3faf7e7cf8f075d797dbc7ed8793df7fd8bc37e67ef5aafcfbd15ec9fbdd4854ae8fbffca75fbfafbffcb4797cd8f4b71fd7e575be3cf86dfd6eb73de1bc7d7c78df8f976ffa6ffbb7db6fa3dd7fb7bb4f6fb7db4fab97db775f3ff79bf1c9b1214e03ecdfef6fff574e4ac6a3850f56409e9c20fcfeaf9f6f5ebcc07b4679a7a631f24e0d6f57bf3e6c3e4df9b4c997aee6f34dbe78355f68f01d8c62b3d37075a7a9c9e7afe6cb4d3ebd966f4cb819a78cc978b153b9ba536ef2f1d57ced48a6abf9748953dae1d95ddd692b3cf13a3d1c7175dd32be6624533af2d132be6624d3211db53dbc5ade1ccfecf499fe5fc31ace3b1e2b60d7c3a00fc708b558ea0eb1a8fc94f5cdcb4a8ba280622de74f0f1d86e6f24cf39b7a9e8aa217352f4a5b50d5f33ed4ed38edc341e5087888d34c1c66e22c1347a307773e55551bc8faed635fa7823a8a504711ea281c14cece85423d50c4461b64593bcc82300df27a7a7038df5eeb868da5d0b8ac5dddd4eb965e3774c9cbda733d70ac07900bfd843738e25a7ce8b27654cb16f8a71e949d2440b33dea3642dd46ddb21845d988fcc9f9f4146abe310eab5084f1a246289c5137a36c4ecba201c53ad2322e0b05bc91e08504ef2361d9729e1d88156b1f1b7a71eda1d83ce1e543b3b9b6e548f982c9ed97f5e660e4cd287417a5d52cc2ac459cb5487316a158f8dcb2c87316b19bb5a0590b9eb590590b9d9dcbd04b6a2dcd5d51d8f279a67caa19be5f86787fa155dd06cf4e7807e3d008908811ce58a52556b63d98498cad3997d589a161e14b1c45dff68acd9f7cbebf6079f0c4e9e1f8e009df187d8a758e4dabb0c48a7cb860729a76bea45dd296334a102569591487269e7117b9b205dbf67b7fc1babaecec93c3e0326d4c336b7546d34a96589196d4cedc98ab1679c8d4b2281ecd5ddb1be563bd0e6994bb463579fef166f085b4cac4f38f3973f6f563cfac99ea0593d348d22247b925365a5233a79605cf594849cd1cdbdeb512ab9457a4ddfd05eb8387cf3fa30d1ee3962ba8ab1e6b9a75799199941445857469c27e3069099af06012669c22e5a3f5fd25d38347ce3f4c0e1ea156cc9d7fa89cb3af1f3267cd842e989cc69c14e541857ac1399c069396c2719e37d1c144da2e663f7ce7251e32fb59f3a39bcfbe130f6eeb9ef7c7df020c009a501dde0d0a656e6473747265616d0d656e646f626a0d382030206f626a0d3c3c2f457874656e64732037203020522f46696c7465722f466c6174654465636f64652f4669727374203837302f4c656e67746820313131322f4e203130302f547970652f4f626a53746d3e3e73747265616d0d0a68de8c97c18e25270c457f853f683006dbd26856d965d3ca64d77a8bacb28bf2ffabdc0bbcd71dcd14544bfd0a8a53c6be185751a4a69c8a68aa814b4be6b8f4544ac5d55251f6f1efb827918463352731c5b5a44aae4aaa4d70ada992ab9a5460b5b6a40d366a4f1a0d574b4dc97b6a51708dd461ab684ebde3392dc932fb920c360a58eb985b3579c6f3da922bb99e3c386e2930277d0cc3fc8a107206d06024c36a6998251b5ca07ba5c046035f3a7e1a0c48c1786b0c9c3043a4ffc36706d09c41006c41afd1ebc33d3cd10bfd00dc85d380194669be8f0770bb93a36083e3a31d967bf007b6ac721c96cdf19461d8054f59a1daf861484ed8301c9577603968d55a929c097734a82982140a02635824fa6b5cadc0cc8ee5aad4d90b1af4ce058de0aad6245a398fa241371d961b17014248e32a382c37fa8bf8a5e7e1141a58d412b0dc8777b06c1401618b51ec8065c378c142893383900150974fc172140ec17230c1e08a04158b4046c120824b58018c67e418fc40034906080d6419fe18371a9d4c4b553325e96828870c0dc69d1da959c8c072c3520a26aecc3eae7ded704c0a2c33ff04b95c2d93816543160a32a61aed1458f64218961d2923e85467b80596636c0d580eda919234c34dc1722af3f0dbb7b7dfc7b6cae98fb7f784641b8dbf91d6f3de8fb73f7ffbfe7d61ed1e568170e3fec4bcbf101948dd202506223f233ffefdeb9f497d14ee05298f2bf4fdc9d5e1cdd8f8b892c796dcc450976b274cee60add33f6c93cb685b1b44de1053b1d8ca816c6cfab8025f62689d62a8bec4f06bf73f58fd262f77f85135972a3bac950be2332024dad0c5af75511f846d8838123a88bed516251ed55ded71c5bee49dbb6394f8a75cb6952b9e72ed31bf83e9d87cba8b7664925e47805a3188b6d723279d1bef57e0a71831c5e8f92546dfe55ab3259edfe1c7ab71a9b2c3aa5f105f72ad1a83699bb255c72e6d9baa55fb912883d897357eb6a0e2cfaddc7675adf725afbde46a3bb9fab3841f30bd83d5b13bfb265a1999d465430cc57ad9ea81cf3df1c715f812c35691b7cf22afbb28ed55e4f798dcc1a45d105f524c46a1b14d999fefce1e9b17e394d4f782f1c3006ff9c715fbd2ccd7fe8c55b462d5fa90755def8a58da465bd79578f19978b2dbd7b6e6f1358faf797ccde36b1e5ff3f89ac7d73cbeea82fb9df9f0f9e017c897e5b021a56d6aa5e723518e841c897a24f448b423d18f841d093f116ddad8bf4b1b8f59a9e7c715fb4c4f6cf72e67aaa6ae67aae12c77a62c753f5381f360c279c8cedea1cad8d93bd42c0c43593bcf2e732fc81c40695cdd753b5677de9e1f95e39831ba73dff1b031bab2baf3f6fcec1d078fd1d5d59db7e7c7f338848cee9abe7c96dbcd276ec9b1273eea33ac3bf63eea336abd357bd123614782fb94e7be5d51c1617e50794bc5282cb1fffa0db903e91da8df81fc065472be45c92d4a6f51fd1675cbfb425b9a0f106b698d03c408eb693a8af5aba3c7ff3c67e2ed4f1f80864fed003141ebe537c87f020c00d97520810d0a656e6473747265616d0d656e646f626a0d392030206f626a0d3c3c2f457874656e64732037203020522f46696c7465722f466c6174654465636f64652f4669727374203836372f4c656e677468203930352f4e203130302f547970652f4f626a53746d3e3e73747265616d0d0a68de8457bb8e1c390cfc15fec18a0f5112606ce4ccc9c276b698e0a2cb0cff7fe42acdecc2b89b16836975ab4a7c14a9568f994b13b3101f18ba0cc790a26d611ca2d1314ed1a91831a7a0395674f01c7313b89bb8264617efc01cd66660ec123a31a644602d5cc4243ea52bf125bd637d3449acb550c9e4b3492ef80997419f113212be10cb58e4a54c236fc8ece44d9993bc25cbc0430c8bf17595c5f8ba211f068e496d8ca4076e9812dcab2ab9c879270b83aa8364646d94a12fdc2036cb861b0a8460d41bc809cb4ee512963d414e588e46322c07b34a580ea695949379252c77268605da99d980e5be20e180e5a4ae0396132be84f73813c60796c089647929cac0b676079422d1bac14701bb0bc1a96436f5d10da90adaec18a99586b204ffc1a6a64ac55a32f8ad5e86bc2baeef2621601e10675d4850b8566a56db16f98f252b6042ecbd80384d81cc8d256b0bab0b1582e86c12483615088ce3068b4330c3aee08c31bfb0b4fdb28d5f066d411edc5050963de821a4dd965607778a32270e83b6da31d868ba239ab3811946b6394891b4680c2ba1a1db381691d5de54a1328be2bdd2039f6367898460f619617c210001771c8810b1ed8448e06748a8469714cc9972f2fdfd87f2f6f78c666fbfef2f6af4c44cbdb1f2f3f7efff3ebf57593d622c7ce9c418e9e399d9c76e63838e8c123873143e313673266887de2b49d567c70e2c1f8f9f5816f69b0f7fe83bf3d607bbefc2f07be0dd835e33da4df9e933ebce486fd0adeb2475cc17357771d22c086c456c426b4db73eec3d43b1a112d88e643db293736f62db6a5f0cdc60d86fd237cfbb1dd519db335947807deae706f05ae056e05ee051e05de0b3c0b7c14f82cf042bf28f48b42bf28f48b42bf28f48b42bf28f48b42bf28f48bbb7e7a85f756e05ae056e05ee051e0bdc0b3c047816ffd2c0f6fb7be25f403e51d875ceaed39edf305b795f271896fa57c5ee25b29f753181d1f7082231c677faedb73fee71b7557de2f5fa9430bdc0adc0bfc9ecfe5b1337a8167818f029f05becef86c05bef5b379e8ac7997b01d4a8a8fc419b7e7b44f4f77a52e7b7cde95ba3c7ae77d8f9c1a1c9f9ff8a65aedf69cf9f6f7178bc7658f2f2b702ff028f05ee059e0a3c06781af33aead5504ad085611bc224445e815212bc25dc7794d98156115046d15412b825504af0851117a45c88a5029a9f703ecf4f1fdd8b01f15fb30b7ff2b61dc7bdafe774efcfcfefafa47800100651287de0d0a656e6473747265616d0d656e646f626a0d31302030206f626a0d3c3c2f457874656e64732037203020522f46696c7465722f466c6174654465636f64652f4669727374203837392f4c656e67746820313132322f4e203130302f547970652f4f626a53746d3e3e73747265616d0d0a68de8c57bb6e243710fc15fe814876b39b040e17397322dc3913149c01c38961f8ff2357717a25f9ac999e60c1d9ad6275b1f818ae7429b548d732179a519a2a5a2b6df1bb976e1ded2cd21c2d7e9ba04b2d2a036d2b3a814b2fa3f3772963802b5aac121fc58cdfadf8e0772fb3923fcb54f257990e1ccf0b7d455b690d5e447b691dd545050fce5fb43469e8abf028039d152665b2b7c335ede82c6d2c925769de20085e73f490016577c303946785f280f2841119509e8691c1615b15ca83c3c7d864407931000c0a815070955e69cc2a1e0859c3c3820ebef48664c4040f1b523c2c9247e99d36ccf030a16c4876478a783abd081c74e12438941533210e6585bc3894953a0ee5c1a090481ff4ec50de51636cdd9464ce99930ce51d8243d9f598baeeac8e0f5c00c2e4f5496313ca93bd2694572519ca8b8213cacb49065c598ba1572119bc4a1b0bc36e15e4854fa3c385f1378c5b98da0e8113d3b982d6e00a23d9b8a44876ae2192b95806c98bab6415e57c68c73aa3ba2228e50252b8d3caf940865a95b34832677a926c9c189219b192cc19729277c420b7ca1c416e3b3590b9bc263474478345a94d396cfe42738d64e34848a6cb0d4d9a23990e68035b01f540ee5b1de4dea935ca972f4fbfbe70b7d5f26d6fb7a3b5683dda19ed8ab6b37d7d7a2e47cfa7e73fcbf1f0fde9b71fbffff5c7d7af5bb863f5ed0e7a087779eb287b9fffb7e7b7e8c6dd76749368f55637097bfaa8da8eaab6ee758f514b8c5ae6bd6e6152224489b14ebfd73dcc4a8bf656447dcea8f2616ceb7ff45f0e3a77d08125ac96b35e78faedd23ede4bcf0bba05dda30de7be6e759f35061a93397bb4126db8998fd8ed9eab90f5f64ef7f364bcbf2573c5929c854d11414804211f82b0f36eb1aafb6355c726e9b149ba46108fbda691bb46398d727aec923e426f84de08bd117a23f446e88dd01ba137426fdcb36f51ce1e9b32ca5994b3286751cea29c45399bb7cac46eecf2e1c818e73326e36dc6ae58768bf5be7bf4dce08a712f7937d82fe811cb8a5856c4b2229615b3b0e2ecab719cd4384e6a1ca5354ea91aa7548da3bec6a157e3d0ab71d4d775c71edeb107bd45b916e55a946b51ae45b916e55a946b51ae3dde2cf546d95281eb78db62ed67bc119ff633fefc98a96b58ae61bd86c7356c1bf633d8afe1790dafcf73f9fecf8fbf1fc9ece8a69c535e3095adbf7e4e7b146a47467a8a1f218d53fc48a95ed9c09d17b75dde73719fc5bdf5f5f32ecf8f9d829ba3641cde52330e6e979e7170935d098717efccb3f0af47c6e15d32e3e00e9879e63f8bccf3be61661cdc1c33cf781569e619af27cd3ce395a589e7328e15dd4ef196e03dc125c135c147825b827b82cf045fd7b825f959929f25f959929f25f959929f25f959929f25f959929f27f979929f1ff9f5535c125c137c24b825b827f84cf0758dcf9ae02dc193fce6ce6fac8b97e2dc11fac57bf305afb269af9fd3de2aeda47c9ee23b295fa7f84ecaf5c206fec6e13fda3a5ecf7efafa5d7bcc7efafa5d9ae023c1ed14ff578001006bdb25ca0d0a656e6473747265616d0d656e646f626a0d31312030206f626a0d3c3c2f457874656e64732037203020522f46696c7465722f466c6174654465636f64652f4669727374203836362f4c656e67746820313236312f4e203130302f547970652f4f626a53746d3e3e73747265616d0d0a68de8c57bb6e65370cfc15fd814591d403586c952e8db19bce70b10182344190ffaf32d499fbd8b58f742a5d1f0e87e4907ad88aa69cac58d282c553352c358d8aa525995f7b92dab18e5432be6b4e45075649a5c10e8c66d855933adc1564bd6175f8805ce1e38a15df7af8f7e412fe23b9c3df72f20eac49aa45b096541d58d354477cb7d4908399a756c35e531b616fa90363d6536fe0b5914606afe734c0612e6934f82386e44810494846144396921b52754f22821cbde2470319024b690146d53ac1033f428f9a93c45f8624c405ee15ccde904a05730dad209fcca42b981b32b10ae6996e05730f4da0a5f48855c13c42a106e6d1f1a541d20c7d0cba961ca20057a484c9f023ca4749a54439a8b994165f1a1a82a619f22e1acc0dad3281a9a357218c7530d7f0ea60ee0266c42b03bdb20ee6d103ec686474065dd21c2d401b5542fbdef12332ec03938209b091f163e0cb90a48a1ed8c01c680f1306c1046a0c4c42b4cfa08846be061dd5230d2882610930987d0406cc1533e719cc15627b0673059967303714e819cccd0303e686a43c83b92367c7646af7f002734739114607d2700c850e4c8aa3d33a20a4873419ae1e59660ca80b2ac968d1ec6b1e31a2d04830f32ec85b221f812282725d6237947c8c7109c239e7e88ccf01469a5e62b2b145be7c79f91d73f8f23a1b96d3b797d7bf93cc1fdf5f5ebf7e3dec7d631f6b3be63b00557e057cffefc7bf778c4c9205e64d72ec157dff1cf888661350ce013e017a0ea833dfbecc051b063d14b40f7bf4fd73873ba3cceab0a54e016507d01dc07680a3ec7c0ea83b40db01e6a4545d355ae6b4e0045a888b819522ef9f03efd1caa1d9f9dc9543b3760e989af565a371ed0876b7c48553fafbe70e0fc6595d3fef82e61d407680b203ccb2c7799bd47600df01e6a8f8aa8954e996e98d6ede6f58a790fea1777f7cbbb97b239c344e9a4a9ae33899d7dcb12a5723de6f618a7d88f2e3cf7ffe62203512f7caf508ac47e06d9e9d713be376bfe6c6323acbe82c43ca25f746751ad569e39a1b936cce9535977acd9dc936267b9ca15bb7ca242b956eacddf23577265b99ecb1a1b76ec664eda168fd3809bf71a4e341376d1b94ed516f71b3ced0fa145a17708e90b23bca82b55e73e72c2865d671c9add0ad3ce6bc96f3cacbb857be4069dea3de4c185a9e42cb02ceb9299c9b42794bb9e45e286fa1bcc5af45a59b3cceab9acf2b17bf57be42d53dea4d799629cf32e50e50ee00ad3ca2b8b1941b4bb9b194fb54b94fb5918fdb5fb9fd95db5f799a687b3af2c6797a8de1788629cf30e519a63c129547a27686e309abb713963784f28650de1078177325df20df20df20df20df20df20dfe0bce47ca51ccb1ca7cc532db3f199f392b91d33cf9fcce9cddc6f99e184e3297249455e685a9fb2eca793a3b751dda0ca1e85d014da29b45368a7d0cf57745bd0b00fce3e78bbe216ff2a1f07f3d3a5e30b38e536ca7dbbaf3d5f72678dc61acdf5825bca3fbd1bfad1fae717d0c65e3676ddd86d63f7b5fdada6967ac2ff2678490b9ea578b225b1f75d55be03d41da0ed007d0368fd761113f5d3732db5dbbd7b62365f9a4b5d9a735b99ebede17f62befdf37562f6bc34ab2ccd5256661f4bd5bc2d55735faae6ba54cda5adcd37d55ceaafaf34e7ddeebcdb9d77bb3feef61bfdd3a6f6a38d4035ae9d2bd9946c7c88f9f110c3aa5c8dab3fa2f45fb758f17bde1f6db6b0e967b6ff0518009f9961780d0a656e6473747265616d0d656e646f626a0d31322030206f626a0d3c3c2f457874656e64732037203020522f46696c7465722f466c6174654465636f64652f4669727374203835382f4c656e677468203839332f4e203130302f547970652f4f626a53746d3e3e73747265616d0d0a68dedc96416e24370c45afa21b8c4889a4040c66959db3684cb20b72802040eebfcc6335ab1b69979dbd17066952f545fdffab5aa6a3f5663a9b0ac1da5482371f84686b1256936ec4dd848e8dde6406519af8226a93b589030cb00658f46c5853036d78d3006e441b3dff5f6d58e2ec360d9cd9db5ce04f9e11d6e504994f72cf9c1956d6ad79279f4ca7b93e9a93db5ccd3d7176f3c53cd65b74e63169c1acc60c416e365a0478365b6cf0ccda12f09865e55eccb23638b6dade89c3797b1ed87b12c04ae7c47de9319648cff90689666b9230a1b991783ee5240b3c6613ed004296282c9a27938c6901b206b3f127ba41664019c9028cc9804a0b9007b35a803c52900079c2a205c849a305c8b98f05c8b659bc4076b4b5952a1d1482ec6e0797e8c6846049749e827d096436aa12f068cc2dc17406a1129b0951589630e10679a1b5519595b4ec3400d319ace2049037c83b356214d90c6554e1004018c625ec05c52a23176f12f8f3de4956aa2c4db523337651c5860ed7aa29340650853fc79170d9493ced2624200fcce8a0eb406dc7053ae0cfb1a50e6671d6e9149039894e1ce970add3b332d3ae000ac8cedbe0ac534f5709c81eb918e4e8890372e46bc2031ae9441ed04061579003b6be7fff76e3a5515eaf9fdf7efbf6eb5ffffcfde34715e5aad82f8aecf3958a6fc757208bd9b66afffef3defc233f0d948e4fc31167af7810f6673e8563eaa95fcea7a6d52aaf18150b6d169a159a4945ad382acee72e51bbdcceb9e73ce7bee88d4f7afa41ef761eeb85b579e58371c5ef9dad2f537c3b3ec5a739e63b7358c96a25ab95acde1fb299bd3387cf5a5526f13289179a179a175a9449a24c12659218cf5dfc55647f18e0a2a79ff4e483deed3cd60b6b76e503bbe2d7e24b15df8edfbfd31ce39d39a2648d92354ad6d80fd962be33c7aa377f954956996415da2ab45568ab4cb2cb24bb4cb2f5b98bbd8abc1e06b8e8c927bdfe41ef761eeb85b5b8f2415cf11bfea58a6fc78de33487be33c72e5977c9ba4bd6bd1eb2edf16a8ebc7ce4aabc7bdce3ac6815bd62545c15ef26c94bc73d3e7fbcf67c1139af3a35f745af7fd8cb4bd375ef761eeb85b57de5837dc5efb62f557c3bee78a739e4d51c2e25ab94ac52b24a9cb2f9d3520f73dcaf70c76def1ecb245a685a685a685a26d132899649467fee325e0da0a7012e7ab23fe9ad0f7ab7f358ff65adcefc5ab4abe2fcffe2bf020c006ac521050d0a656e6473747265616d0d656e646f626a0d31332030206f626a0d3c3c2f457874656e64732037203020522f46696c7465722f466c6174654465636f64652f4669727374203835392f4c656e677468203838322f4e203130302f547970652f4f626a53746d3e3e73747265616d0d0a68dedc564baedb300cbc8a6ef0448a1f1178e8aabb7411bc7657f4004581de7fd9a14d3ba8e364fd904540859446e4cc38b1f168bd194b6342d0268c60cd0682b72908b35157c468b4547a2371446a6413911b457e1f8d152043da50a00c6d63027b58939efbbcc9c8f3b389e6fe68e2c84b6f1281484d19fbd181626d329a1a70449a4eb423e8a1a31fb1a551cb1e722dc0b05c036362adbd79c71abdf8c8efdc3c80a3a3cd008e4a8b1c56b5459e516be1388f9e22727fce4b59c0c01ddd9961e26e38820ff5092cf445d401069e88c09e9960912d9a6261e80b1fa2e94b73c4c900d822068d664925fa3407323b320ee40106cd812ca0d01cc892f33b90257233909580e340d691a780ac962520eb4487c022eb3805e6c920aecd94091c1afaa6ecce40268443875097bca3c3096487ce99255f8804b2a3bb64943c803c813c531fb482b100882c840720d8e59e6c805eeef08505fcd4c19f8562912e0883c37a961c0b4687e09a312a168105f8f3deb1402f8e7dccddb00032c3870e746628ed700033f87358125ca6d6401e04b131090fb8d1c1350fa3c5062c0440eae94d00621f2bd87002b2826c27201b6e7602b2c1188e039c2e741ce054d809c8c996837dce9b1dfe60c7d3e060841d56749c6487c28ed9d8c1d6fbfbdbb519507bfb78fbfef6edf7df3f5fbe7ccee465798a33796d0aaed6f28f8fb5f8331f6da496477b8d5ad132fe4a50a85ea7be6ea7a4afbb842a72c5429342934213abe81567c5b8ddc275cb75ef3baaefb3da7c52f307b5eb36d681b575e663f28cdf95ad97495e969fd232478f3b7368c9aa25ab96acaabb6cdaefcca1b1eeb232899549acd0acd0acd0ac4c6265122b93d8bcdd4247917537c049cd9fd4ec41edba8d75604dcf7ca067fc2abf54f2b2fc876de69877e6f092d54b562f595d76d92ceecce1f5e47b9964964966a1cd429b8536cb24b34c32cb24d3f75bbc1f45f6dd0027357b52d307b5eb36d681353ff3819ff1ebf452c9cbf2d6b099c3efcc11256b94ac51b2c6d8659bf3ce1c514f7e9449623549be3dac912a72c551512a6ac5db9fd78ca3c8b11be0a4a64f6af2a076ddc63ab016673e88337ea3bf54f2b2bca76de6b0a339bc97ac54b252c94abcc9e6374b6de6c857b67597579c150b8d0b8d0b8dcb245c26e13209ebed967910395f10d7becf6af2a4361ed4aedb58ffb356331f9327fcfafebffc1992ff0418001e6120fc0d0a656e6473747265616d0d656e646f626a0d31342030206f626a0d3c3c2f457874656e64732037203020522f46696c7465722f466c6174654465636f64652f4669727374203637302f4c656e677468203731302f4e2037392f547970652f4f626a53746d3e3e73747265616d0d0a68dedc55bb8edb400cfc15fe8197bb7c0287abd2f90ae1922ec8070401f2ff65662d4a0664f980b42e0cd22477343b1c5bde0735f22ed41941493a82910d04a79cdf82580c31a98b938f46dd159169348c8d4e03b98f4143313f8486cfbad2484134129ef34e82dc4790e8c449120f72692499884cdac1050c14b9cb2035e0899006f044c91af064b29bdf9d2c8023c0888993140c7c6d1438e3ca148ef3e01489791d943ceb42096eae4aa973de281d38e094091cc57d1b83902612b0736b480c94f0e116c0042fe67979e8c40cf5dc040928ba29129f1523ee10cfcd8907d47303f2985737208fc0b0035918380e6481720ec680992d208b831fb05812a7203a2b03105556c8e7a0cd0a760e1d59030c1dc8d6c030806c58aea3ca36f5006f36b07388c916400e20fb5c0da8f024e5a872809443588e5c95e5ec7318c809ed3c819cd30009e44cb4e092de180c21736fd8af63efbd413f4f45022e8eb90e599138920e8640efb83312180b14291a9cc5e01298ebbd19bdbd5d16f296b0e8e7e5fbe5e3f7df3fefefff55bcde6c3c8b0b69d36afff85c9b3fa7b951ba99fb1661ee35f28cbf26282e5fa7be6da786d69455f48a85360a4d0a4db862af382acafd295e4f5936de438af7596f7cd1eb4f7acb76ad836aeb9d0fc57ea6efaad6cb14afb73f93cd1cf2600ea9b54aad556aaddaf6b5893e9843a5a6ca245a26d142d342d342b332899549ac4c62e3fe143b2e5977039cf4fa173d7ed25bb66b1d5493331fc899bee22f55bcdefeca37738c077358add56aad566bb5dcd766f2600eaf5fbe9749bc4ce285e685e685e665922893449924fafd297a5cb2ef0638e9f117bdf6a4b76cd73aa866673eb0337dcd5eaa78bdbd3c3773f4077344ad356aad516b8dd8d716e3c11c59bffc2c936499240b2d0b2d0b2dcb24b99a64be3fd7787f79851c979cbb014e7aed792ff2496fd9ae75502dce7c1067fa86be4ef19f000300b3e17ab10d0a656e6473747265616d0d656e646f626a0d31352030206f626a0d3c3c2f4c656e67746820333635382f537562747970652f584d4c2f547970652f4d657461646174613e3e73747265616d0d0a3c3f787061636b657420626567696e3d22efbbbf222069643d2257354d304d7043656869487a7265537a4e54637a6b633964223f3e0a3c783a786d706d65746120786d6c6e733a783d2261646f62653a6e733a6d6574612f2220783a786d70746b3d2241646f626520584d5020436f726520352e322d633030312036332e3133393433392c20323031302f30392f32372d31333a33373a32362020202020202020223e0a2020203c7264663a52444620786d6c6e733a7264663d22687474703a2f2f7777772e77332e6f72672f313939392f30322f32322d7264662d73796e7461782d6e7323223e0a2020202020203c7264663a4465736372697074696f6e207264663a61626f75743d22220a202020202020202020202020786d6c6e733a786d703d22687474703a2f2f6e732e61646f62652e636f6d2f7861702f312e302f223e0a2020202020202020203c786d703a4d6f64696679446174653e323031352d30372d30365430393a30383a33352b30323a30303c2f786d703a4d6f64696679446174653e0a2020202020202020203c786d703a437265617465446174653e323031352d30372d30365430393a30383a32362b30323a30303c2f786d703a437265617465446174653e0a2020202020202020203c786d703a4d65746164617461446174653e323031352d30372d30365430393a30383a33352b30323a30303c2f786d703a4d65746164617461446174653e0a2020202020202020203c786d703a43726561746f72546f6f6c3e4d6963726f736f6674c2ae20576f726420323031333c2f786d703a43726561746f72546f6f6c3e0a2020202020203c2f7264663a4465736372697074696f6e3e0a2020202020203c7264663a4465736372697074696f6e207264663a61626f75743d22220a202020202020202020202020786d6c6e733a64633d22687474703a2f2f7075726c2e6f72672f64632f656c656d656e74732f312e312f223e0a2020202020202020203c64633a666f726d61743e6170706c69636174696f6e2f7064663c2f64633a666f726d61743e0a2020202020202020203c64633a6465736372697074696f6e3e0a2020202020202020202020203c7264663a416c743e0a2020202020202020202020202020203c7264663a6c6920786d6c3a6c616e673d22782d64656661756c74223e4261736973666f726d756c61722043442042756e643c2f7264663a6c693e0a2020202020202020202020203c2f7264663a416c743e0a2020202020202020203c2f64633a6465736372697074696f6e3e0a2020202020202020203c64633a63726561746f723e0a2020202020202020202020203c7264663a5365713e0a2020202020202020202020202020203c7264663a6c693e5538303739363931343c2f7264663a6c693e0a2020202020202020202020203c2f7264663a5365713e0a2020202020202020203c2f64633a63726561746f723e0a2020202020203c2f7264663a4465736372697074696f6e3e0a2020202020203c7264663a4465736372697074696f6e207264663a61626f75743d22220a202020202020202020202020786d6c6e733a786d704d4d3d22687474703a2f2f6e732e61646f62652e636f6d2f7861702f312e302f6d6d2f223e0a2020202020202020203c786d704d4d3a446f63756d656e7449443e757569643a33616366623666662d613431302d343134632d393837352d3863646566626138323638653c2f786d704d4d3a446f63756d656e7449443e0a2020202020202020203c786d704d4d3a496e7374616e636549443e757569643a35363463626363642d666630342d343433322d626637382d6339353532616465363662323c2f786d704d4d3a496e7374616e636549443e0a2020202020203c2f7264663a4465736372697074696f6e3e0a2020202020203c7264663a4465736372697074696f6e207264663a61626f75743d22220a202020202020202020202020786d6c6e733a7064663d22687474703a2f2f6e732e61646f62652e636f6d2f7064662f312e332f223e0a2020202020202020203c7064663a50726f64756365723e4d6963726f736f6674c2ae20576f726420323031333c2f7064663a50726f64756365723e0a2020202020203c2f7264663a4465736372697074696f6e3e0a2020203c2f7264663a5244463e0a3c2f783a786d706d6574613e0a202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020200a202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020200a202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020200a202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020200a202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020200a202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020200a202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020200a202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020200a202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020200a202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020200a202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020200a202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020200a202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020200a202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020200a202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020200a202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020200a202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020200a202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020200a202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020200a202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020200a2020202020202020202020202020202020202020202020202020200a3c3f787061636b657420656e643d2277223f3e0d0a656e6473747265616d0d656e646f626a0d31362030206f626a0d3c3c2f46696c7465722f466c6174654465636f64652f466972737420362f4c656e6774682035382f4e20312f547970652f4f626a53746d3e3e73747265616d0d0a68deb23030523050b0b1d177ce2fcd2b5130d6f7ce4c298eb63030038a0629188249131019ab1f525990aa1f90989e5a6c670710600080b50e750d0a656e6473747265616d0d656e646f626a0d31372030206f626a0d3c3c2f46696c7465722f466c6174654465636f64652f466972737420362f4c656e677468203134342f4e20312f547970652f4f626a53746d3e3e73747265616d0d0a68de74cbc10a82301800e057d94d4787fdba9c1a22a45e8520a2f3da262eca1f7eb7d7ea19f3109deafe7d154806ac69c431861929bd5450d6aacef65cf4e474f0b80c3ab87438e490155082821aaa5ced204f00928fdae2e80de18a5378b12b92651b975c8c687f74597cfb89d046e3fefd73bcdd9d0969a757bf4e48cff8d0c4fa817571b1bc6ddf020c002b5d386d0d0a656e6473747265616d0d656e646f626a0d31382030206f626a0d3c3c2f4465636f64655061726d733c3c2f436f6c756d6e7320352f507265646963746f722031323e3e2f46696c7465722f466c6174654465636f64652f49445b3c32363043333946373432443545343430414231423233303237433535443439453e3c34343730423839393638353545413430393833324337393241343837453038393e5d2f496e666f20383033203020522f4c656e677468203134312f526f6f7420383035203020522f53697a65203830342f547970652f585265662f575b31203320315d3e3e73747265616d0d0a68de626200012646c6f68f0c4c40463c8814ef04b38d4124a31788142d01b3194024572b88643d0122597e80c9cb20922d0ecc7e0b261f8148665310c93703ac773a987c07b4eb3fff22101bc80391ccff116c4624f628394a528b649c3b1a0ea3e468ba1a2547d3d528399aae46c95172345d8d92a3e96a941c4d57a3e4f021993681e3970120c00039781d5c0d0a656e6473747265616d0d656e646f626a0d7374617274787265660d0a3131360d0a2525454f460d0a, 'application/pdf', 'qualifications', 1, 'Abdellatif', '2015-08-19 12:58:57');

-- --------------------------------------------------------

--
-- Structure de la table `hs_hr_emp_basicsalary`
--

CREATE TABLE IF NOT EXISTS `hs_hr_emp_basicsalary` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `emp_number` int(7) NOT NULL DEFAULT '0',
  `sal_grd_code` int(11) DEFAULT NULL,
  `currency_id` varchar(6) NOT NULL DEFAULT '',
  `ebsal_basic_salary` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `payperiod_code` varchar(13) DEFAULT NULL,
  `salary_component` varchar(100) DEFAULT NULL,
  `comments` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sal_grd_code` (`sal_grd_code`),
  KEY `currency_id` (`currency_id`),
  KEY `emp_number` (`emp_number`),
  KEY `payperiod_code` (`payperiod_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `hs_hr_emp_children`
--

CREATE TABLE IF NOT EXISTS `hs_hr_emp_children` (
  `emp_number` int(7) NOT NULL DEFAULT '0',
  `ec_seqno` decimal(2,0) NOT NULL DEFAULT '0',
  `ec_name` varchar(100) DEFAULT '',
  `ec_date_of_birth` date DEFAULT NULL,
  PRIMARY KEY (`emp_number`,`ec_seqno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `hs_hr_emp_contract_extend`
--

CREATE TABLE IF NOT EXISTS `hs_hr_emp_contract_extend` (
  `emp_number` int(7) NOT NULL DEFAULT '0',
  `econ_extend_id` decimal(10,0) NOT NULL DEFAULT '0',
  `econ_extend_start_date` datetime DEFAULT NULL,
  `econ_extend_end_date` datetime DEFAULT NULL,
  PRIMARY KEY (`emp_number`,`econ_extend_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `hs_hr_emp_contract_extend`
--

INSERT INTO `hs_hr_emp_contract_extend` (`emp_number`, `econ_extend_id`, `econ_extend_start_date`, `econ_extend_end_date`) VALUES
(1, '1', '2011-07-18 00:00:00', NULL);

-- --------------------------------------------------------

--
-- Structure de la table `hs_hr_emp_dependents`
--

CREATE TABLE IF NOT EXISTS `hs_hr_emp_dependents` (
  `emp_number` int(7) NOT NULL DEFAULT '0',
  `ed_seqno` decimal(2,0) NOT NULL DEFAULT '0',
  `ed_name` varchar(100) DEFAULT '',
  `ed_relationship_type` enum('child','other') DEFAULT NULL,
  `ed_relationship` varchar(100) DEFAULT '',
  `ed_date_of_birth` date DEFAULT NULL,
  PRIMARY KEY (`emp_number`,`ed_seqno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `hs_hr_emp_directdebit`
--

CREATE TABLE IF NOT EXISTS `hs_hr_emp_directdebit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `salary_id` int(11) NOT NULL,
  `dd_routing_num` int(9) NOT NULL,
  `dd_account` varchar(100) NOT NULL DEFAULT '',
  `dd_amount` decimal(11,2) NOT NULL,
  `dd_account_type` varchar(20) NOT NULL DEFAULT '' COMMENT 'CHECKING, SAVINGS',
  `dd_transaction_type` varchar(20) NOT NULL DEFAULT '' COMMENT 'BLANK, PERC, FLAT, FLATMINUS',
  PRIMARY KEY (`id`),
  KEY `salary_id` (`salary_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `hs_hr_emp_emergency_contacts`
--

CREATE TABLE IF NOT EXISTS `hs_hr_emp_emergency_contacts` (
  `emp_number` int(7) NOT NULL DEFAULT '0',
  `eec_seqno` decimal(2,0) NOT NULL DEFAULT '0',
  `eec_name` varchar(100) DEFAULT '',
  `eec_relationship` varchar(100) DEFAULT '',
  `eec_home_no` varchar(100) DEFAULT '',
  `eec_mobile_no` varchar(100) DEFAULT '',
  `eec_office_no` varchar(100) DEFAULT '',
  PRIMARY KEY (`emp_number`,`eec_seqno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `hs_hr_emp_history_of_ealier_pos`
--

CREATE TABLE IF NOT EXISTS `hs_hr_emp_history_of_ealier_pos` (
  `emp_number` int(7) NOT NULL DEFAULT '0',
  `emp_seqno` decimal(2,0) NOT NULL DEFAULT '0',
  `ehoep_job_title` varchar(100) DEFAULT '',
  `ehoep_years` varchar(100) DEFAULT '',
  PRIMARY KEY (`emp_number`,`emp_seqno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `hs_hr_emp_language`
--

CREATE TABLE IF NOT EXISTS `hs_hr_emp_language` (
  `emp_number` int(7) NOT NULL DEFAULT '0',
  `lang_id` int(11) NOT NULL,
  `fluency` smallint(6) NOT NULL DEFAULT '0',
  `competency` smallint(6) DEFAULT '0',
  `comments` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`emp_number`,`lang_id`,`fluency`),
  KEY `lang_id` (`lang_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `hs_hr_emp_locations`
--

CREATE TABLE IF NOT EXISTS `hs_hr_emp_locations` (
  `emp_number` int(11) NOT NULL,
  `location_id` int(11) NOT NULL,
  PRIMARY KEY (`emp_number`,`location_id`),
  KEY `location_id` (`location_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `hs_hr_emp_member_detail`
--

CREATE TABLE IF NOT EXISTS `hs_hr_emp_member_detail` (
  `emp_number` int(7) NOT NULL DEFAULT '0',
  `membship_code` int(6) NOT NULL DEFAULT '0',
  `ememb_subscript_ownership` varchar(20) DEFAULT NULL,
  `ememb_subscript_amount` decimal(15,2) DEFAULT NULL,
  `ememb_subs_currency` varchar(20) DEFAULT NULL,
  `ememb_commence_date` date DEFAULT NULL,
  `ememb_renewal_date` date DEFAULT NULL,
  PRIMARY KEY (`emp_number`,`membship_code`),
  KEY `membship_code` (`membship_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `hs_hr_emp_passport`
--

CREATE TABLE IF NOT EXISTS `hs_hr_emp_passport` (
  `emp_number` int(7) NOT NULL DEFAULT '0',
  `ep_seqno` decimal(2,0) NOT NULL DEFAULT '0',
  `ep_passport_num` varchar(100) NOT NULL DEFAULT '',
  `ep_passportissueddate` datetime DEFAULT NULL,
  `ep_passportexpiredate` datetime DEFAULT NULL,
  `ep_comments` varchar(255) DEFAULT NULL,
  `ep_passport_type_flg` smallint(6) DEFAULT NULL,
  `ep_i9_status` varchar(100) DEFAULT '',
  `ep_i9_review_date` date DEFAULT NULL,
  `cou_code` varchar(6) DEFAULT NULL,
  PRIMARY KEY (`emp_number`,`ep_seqno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `hs_hr_emp_picture`
--

CREATE TABLE IF NOT EXISTS `hs_hr_emp_picture` (
  `emp_number` int(7) NOT NULL DEFAULT '0',
  `epic_picture` mediumblob,
  `epic_filename` varchar(100) DEFAULT NULL,
  `epic_type` varchar(50) DEFAULT NULL,
  `epic_file_size` varchar(20) DEFAULT NULL,
  `epic_file_width` varchar(20) DEFAULT NULL,
  `epic_file_height` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`emp_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `hs_hr_emp_reportto`
--

CREATE TABLE IF NOT EXISTS `hs_hr_emp_reportto` (
  `erep_sup_emp_number` int(7) NOT NULL DEFAULT '0',
  `erep_sub_emp_number` int(7) NOT NULL DEFAULT '0',
  `erep_reporting_mode` int(7) NOT NULL DEFAULT '0',
  PRIMARY KEY (`erep_sup_emp_number`,`erep_sub_emp_number`,`erep_reporting_mode`),
  KEY `erep_sub_emp_number` (`erep_sub_emp_number`),
  KEY `erep_reporting_mode` (`erep_reporting_mode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `hs_hr_emp_skill`
--

CREATE TABLE IF NOT EXISTS `hs_hr_emp_skill` (
  `emp_number` int(7) NOT NULL DEFAULT '0',
  `skill_id` int(11) NOT NULL,
  `years_of_exp` decimal(2,0) DEFAULT NULL,
  `comments` varchar(100) NOT NULL DEFAULT '',
  KEY `emp_number` (`emp_number`),
  KEY `skill_id` (`skill_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `hs_hr_emp_skill`
--

INSERT INTO `hs_hr_emp_skill` (`emp_number`, `skill_id`, `years_of_exp`, `comments`) VALUES
(1, 1, '5', '5 ans');

-- --------------------------------------------------------

--
-- Structure de la table `hs_hr_emp_us_tax`
--

CREATE TABLE IF NOT EXISTS `hs_hr_emp_us_tax` (
  `emp_number` int(7) NOT NULL DEFAULT '0',
  `tax_federal_status` varchar(13) DEFAULT NULL,
  `tax_federal_exceptions` int(2) DEFAULT '0',
  `tax_state` varchar(13) DEFAULT NULL,
  `tax_state_status` varchar(13) DEFAULT NULL,
  `tax_state_exceptions` int(2) DEFAULT '0',
  `tax_unemp_state` varchar(13) DEFAULT NULL,
  `tax_work_state` varchar(13) DEFAULT NULL,
  PRIMARY KEY (`emp_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `hs_hr_emp_work_experience`
--

CREATE TABLE IF NOT EXISTS `hs_hr_emp_work_experience` (
  `emp_number` int(7) NOT NULL DEFAULT '0',
  `eexp_seqno` decimal(10,0) NOT NULL DEFAULT '0',
  `eexp_employer` varchar(100) DEFAULT NULL,
  `eexp_jobtit` varchar(120) DEFAULT NULL,
  `eexp_from_date` datetime DEFAULT NULL,
  `eexp_to_date` datetime DEFAULT NULL,
  `eexp_comments` varchar(200) DEFAULT NULL,
  `eexp_internal` int(1) DEFAULT NULL,
  PRIMARY KEY (`emp_number`,`eexp_seqno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `hs_hr_jobtit_empstat`
--

CREATE TABLE IF NOT EXISTS `hs_hr_jobtit_empstat` (
  `jobtit_code` int(7) NOT NULL,
  `estat_code` int(13) NOT NULL,
  PRIMARY KEY (`jobtit_code`,`estat_code`),
  KEY `estat_code` (`estat_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `hs_hr_mailnotifications`
--

CREATE TABLE IF NOT EXISTS `hs_hr_mailnotifications` (
  `user_id` int(20) NOT NULL,
  `notification_type_id` int(11) NOT NULL,
  `status` int(2) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  KEY `user_id` (`user_id`),
  KEY `notification_type_id` (`notification_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `hs_hr_module`
--

CREATE TABLE IF NOT EXISTS `hs_hr_module` (
  `mod_id` varchar(36) NOT NULL DEFAULT '',
  `name` varchar(45) DEFAULT NULL,
  `owner` varchar(45) DEFAULT NULL,
  `owner_email` varchar(100) DEFAULT NULL,
  `version` varchar(36) DEFAULT NULL,
  `description` text,
  PRIMARY KEY (`mod_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `hs_hr_module`
--

INSERT INTO `hs_hr_module` (`mod_id`, `name`, `owner`, `owner_email`, `version`, `description`) VALUES
('MOD001', 'Admin', 'OrangeHRM', 'info@orangehrm.com', 'VER001', 'HR Admin'),
('MOD002', 'PIM', 'OrangeHRM', 'info@orangehrm.com', 'VER001', 'HR Functions'),
('MOD004', 'Report', 'OrangeHRM', 'info@orangehrm.com', 'VER001', 'Reporting'),
('MOD005', 'Leave', 'OrangeHRM', 'info@orangehrm.com', 'VER001', 'Leave Tracking'),
('MOD006', 'Time', 'OrangeHRM', 'info@orangehrm.com', 'VER001', 'Time Tracking'),
('MOD007', 'Benefits', 'OrangeHRM', 'info@orangehrm.com', 'VER001', 'Benefits Tracking'),
('MOD008', 'Recruitment', 'OrangeHRM', 'info@orangehrm.com', 'VER001', 'Recruitment'),
('MOD009', 'Performance', 'OrangeHRM', 'info@orangehrm.com', 'VER001', 'Performance');

-- --------------------------------------------------------

--
-- Structure de la table `hs_hr_payperiod`
--

CREATE TABLE IF NOT EXISTS `hs_hr_payperiod` (
  `payperiod_code` varchar(13) NOT NULL DEFAULT '',
  `payperiod_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`payperiod_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `hs_hr_payperiod`
--

INSERT INTO `hs_hr_payperiod` (`payperiod_code`, `payperiod_name`) VALUES
('1', 'Weekly'),
('2', 'Bi Weekly'),
('3', 'Semi Monthly'),
('4', 'Monthly'),
('5', 'Monthly on first pay of month.'),
('6', 'Hourly');

-- --------------------------------------------------------

--
-- Structure de la table `hs_hr_pay_period`
--

CREATE TABLE IF NOT EXISTS `hs_hr_pay_period` (
  `id` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `close_date` date NOT NULL,
  `check_date` date NOT NULL,
  `timesheet_aproval_due_date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `hs_hr_province`
--

CREATE TABLE IF NOT EXISTS `hs_hr_province` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `province_name` varchar(40) NOT NULL DEFAULT '',
  `province_code` char(2) NOT NULL DEFAULT '',
  `cou_code` char(2) NOT NULL DEFAULT 'us',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=66 ;

--
-- Contenu de la table `hs_hr_province`
--

INSERT INTO `hs_hr_province` (`id`, `province_name`, `province_code`, `cou_code`) VALUES
(1, 'Alaska', 'AK', 'US'),
(2, 'Alabama', 'AL', 'US'),
(3, 'American Samoa', 'AS', 'US'),
(4, 'Arizona', 'AZ', 'US'),
(5, 'Arkansas', 'AR', 'US'),
(6, 'California', 'CA', 'US'),
(7, 'Colorado', 'CO', 'US'),
(8, 'Connecticut', 'CT', 'US'),
(9, 'Delaware', 'DE', 'US'),
(10, 'District of Columbia', 'DC', 'US'),
(11, 'Federated States of Micronesia', 'FM', 'US'),
(12, 'Florida', 'FL', 'US'),
(13, 'Georgia', 'GA', 'US'),
(14, 'Guam', 'GU', 'US'),
(15, 'Hawaii', 'HI', 'US'),
(16, 'Idaho', 'ID', 'US'),
(17, 'Illinois', 'IL', 'US'),
(18, 'Indiana', 'IN', 'US'),
(19, 'Iowa', 'IA', 'US'),
(20, 'Kansas', 'KS', 'US'),
(21, 'Kentucky', 'KY', 'US'),
(22, 'Louisiana', 'LA', 'US'),
(23, 'Maine', 'ME', 'US'),
(24, 'Marshall Islands', 'MH', 'US'),
(25, 'Maryland', 'MD', 'US'),
(26, 'Massachusetts', 'MA', 'US'),
(27, 'Michigan', 'MI', 'US'),
(28, 'Minnesota', 'MN', 'US'),
(29, 'Mississippi', 'MS', 'US'),
(30, 'Missouri', 'MO', 'US'),
(31, 'Montana', 'MT', 'US'),
(32, 'Nebraska', 'NE', 'US'),
(33, 'Nevada', 'NV', 'US'),
(34, 'New Hampshire', 'NH', 'US'),
(35, 'New Jersey', 'NJ', 'US'),
(36, 'New Mexico', 'NM', 'US'),
(37, 'New York', 'NY', 'US'),
(38, 'North Carolina', 'NC', 'US'),
(39, 'North Dakota', 'ND', 'US'),
(40, 'Northern Mariana Islands', 'MP', 'US'),
(41, 'Ohio', 'OH', 'US'),
(42, 'Oklahoma', 'OK', 'US'),
(43, 'Oregon', 'OR', 'US'),
(44, 'Palau', 'PW', 'US'),
(45, 'Pennsylvania', 'PA', 'US'),
(46, 'Puerto Rico', 'PR', 'US'),
(47, 'Rhode Island', 'RI', 'US'),
(48, 'South Carolina', 'SC', 'US'),
(49, 'South Dakota', 'SD', 'US'),
(50, 'Tennessee', 'TN', 'US'),
(51, 'Texas', 'TX', 'US'),
(52, 'Utah', 'UT', 'US'),
(53, 'Vermont', 'VT', 'US'),
(54, 'Virgin Islands', 'VI', 'US'),
(55, 'Virginia', 'VA', 'US'),
(56, 'Washington', 'WA', 'US'),
(57, 'West Virginia', 'WV', 'US'),
(58, 'Wisconsin', 'WI', 'US'),
(59, 'Wyoming', 'WY', 'US'),
(60, 'Armed Forces Africa', 'AE', 'US'),
(61, 'Armed Forces Americas (except Canada)', 'AA', 'US'),
(62, 'Armed Forces Canada', 'AE', 'US'),
(63, 'Armed Forces Europe', 'AE', 'US'),
(64, 'Armed Forces Middle East', 'AE', 'US'),
(65, 'Armed Forces Pacific', 'AP', 'US');

-- --------------------------------------------------------

--
-- Structure de la table `hs_hr_unique_id`
--

CREATE TABLE IF NOT EXISTS `hs_hr_unique_id` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `last_id` int(10) unsigned NOT NULL,
  `table_name` varchar(50) NOT NULL,
  `field_name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `table_field` (`table_name`,`field_name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=24 ;

--
-- Contenu de la table `hs_hr_unique_id`
--

INSERT INTO `hs_hr_unique_id` (`id`, `last_id`, `table_name`, `field_name`) VALUES
(1, 3, 'hs_hr_employee', 'emp_number'),
(2, 9, 'hs_hr_module', 'mod_id'),
(3, 0, 'hs_hr_leave', 'leave_id'),
(4, 0, 'hs_hr_leavetype', 'leave_type_id'),
(5, 0, 'hs_hr_leave_requests', 'leave_request_id'),
(6, 0, 'hs_hr_custom_export', 'export_id'),
(7, 0, 'hs_hr_custom_import', 'import_id'),
(8, 0, 'hs_hr_pay_period', 'id'),
(9, 0, 'hs_hr_kpi', 'id'),
(10, 0, 'hs_hr_performance_review', 'id'),
(11, 2, 'ohrm_emp_reporting_method', 'reporting_method_id'),
(12, 1, 'ohrm_timesheet', 'timesheet_id'),
(13, 0, 'ohrm_timesheet_action_log', 'timesheet_action_log_id'),
(14, 0, 'ohrm_timesheet_item', 'timesheet_item_id'),
(15, 0, 'ohrm_attendance_record', 'id'),
(16, 0, 'ohrm_job_vacancy', 'id'),
(17, 0, 'ohrm_job_candidate', 'id'),
(18, 106, 'ohrm_workflow_state_machine', 'id'),
(19, 0, 'ohrm_job_candidate_attachment', 'id'),
(20, 0, 'ohrm_job_vacancy_attachment', 'id'),
(21, 0, 'ohrm_job_candidate_vacancy', 'id'),
(22, 0, 'ohrm_job_candidate_history', 'id'),
(23, 0, 'ohrm_job_interview', 'id');

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_advanced_report`
--

CREATE TABLE IF NOT EXISTS `ohrm_advanced_report` (
  `id` int(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `definition` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `ohrm_advanced_report`
--

INSERT INTO `ohrm_advanced_report` (`id`, `name`, `definition`) VALUES
(1, 'Leave Entitlements and Usage Report', '\n<report>\n    <settings>\n        <csv>\n            <include_group_header>1</include_group_header>\n            <include_header>1</include_header>\n        </csv>\n    </settings>\n<filter_fields>\n	<input_field type="text" name="empNumber" label="Employee Number"></input_field>\n	<input_field type="text" name="fromDate" label="From"></input_field>\n        <input_field type="text" name="toDate" label="To"></input_field>\n        <input_field type="text" name="asOfDate" label="AsOf"></input_field>\n</filter_fields> \n\n<sub_report type="sql" name="mainTable">       \n    <query>FROM ohrm_leave_type WHERE (deleted = 0) OR (SELECT count(l.id) FROM ohrm_leave l WHERE l.status = 3 AND l.leave_type_id = ohrm_leave_type.id) > 0 ORDER BY ohrm_leave_type.id</query>\n    <id_field>leaveTypeId</id_field>\n    <display_groups>\n        <display_group name="leavetype" type="one" display="true">\n            <group_header></group_header>\n            <fields>\n                <field display="false">\n                    <field_name>ohrm_leave_type.id</field_name>\n                    <field_alias>leaveTypeId</field_alias>\n                    <display_name>Leave Type ID</display_name>\n                    <width>1</width>	\n                </field>   \n                <field display="false">\n                    <field_name>ohrm_leave_type.exclude_in_reports_if_no_entitlement</field_name>\n                    <field_alias>exclude_if_no_entitlement</field_alias>\n                    <display_name>Exclude</display_name>\n                    <width>1</width>	\n                </field>  \n                <field display="false">\n                    <field_name>ohrm_leave_type.deleted</field_name>\n                    <field_alias>leave_type_deleted</field_alias>\n                    <display_name>Leave Type Deleted</display_name>\n                    <width>1</width>	\n                </field>  \n                <field display="true">\n                    <field_name>ohrm_leave_type.name</field_name>\n                    <field_alias>leaveType</field_alias>\n                    <display_name>Leave Type</display_name>\n                    <width>160</width>	\n                </field>s                                                                                                     \n            </fields>\n        </display_group>\n    </display_groups> \n</sub_report>\n\n<sub_report type="sql" name="entitlementsTotal">\n                    <query>\n\nFROM (\nSELECT ohrm_leave_entitlement.id as id, \n       ohrm_leave_entitlement.leave_type_id as leave_type_id,\n       ohrm_leave_entitlement.no_of_days as no_of_days,\n       sum(IF(ohrm_leave.status = 2, ohrm_leave_leave_entitlement.length_days, 0)) AS scheduled,\n       sum(IF(ohrm_leave.status = 3, ohrm_leave_leave_entitlement.length_days, 0)) AS taken\n       \nFROM ohrm_leave_entitlement LEFT JOIN ohrm_leave_leave_entitlement ON\n    ohrm_leave_entitlement.id = ohrm_leave_leave_entitlement.entitlement_id\n    LEFT JOIN ohrm_leave ON ohrm_leave.id = ohrm_leave_leave_entitlement.leave_id AND \n    ( $X{&gt;,ohrm_leave.date,toDate} OR $X{&lt;,ohrm_leave.date,fromDate} )\n\nWHERE ohrm_leave_entitlement.deleted=0 AND $X{=,ohrm_leave_entitlement.emp_number,empNumber} AND \n    $X{IN,ohrm_leave_entitlement.leave_type_id,leaveTypeId} AND\n    (\n      ( $X{&lt;=,ohrm_leave_entitlement.from_date,fromDate} AND $X{&gt;=,ohrm_leave_entitlement.to_date,fromDate} ) OR\n      ( $X{&lt;=,ohrm_leave_entitlement.from_date,toDate} AND $X{&gt;=,ohrm_leave_entitlement.to_date,toDate} ) OR \n      ( $X{&gt;=,ohrm_leave_entitlement.from_date,fromDate} AND $X{&lt;=,ohrm_leave_entitlement.to_date,toDate} ) \n    )\n    \nGROUP BY ohrm_leave_entitlement.id\n) AS A\n\nGROUP BY A.leave_type_id\nORDER BY A.leave_type_id\n\n</query>\n    <id_field>leaveTypeId</id_field>\n    <display_groups>\n            <display_group name="g2" type="one" display="true">\n                <group_header></group_header>\n                <fields>\n                    <field display="false">\n                        <field_name>A.leave_type_id</field_name>\n                        <field_alias>leaveTypeId</field_alias>\n                        <display_name>Leave Type ID</display_name>\n                        <width>1</width>\n                    </field>                                \n                    <field display="true">\n                        <field_name>sum(A.no_of_days) - sum(A.scheduled) - sum(A.taken)</field_name>\n                        <field_alias>entitlement_total</field_alias>\n                        <display_name>Leave Entitlements (Days)</display_name>\n                        <width>120</width>\n                        <align>right</align>\n                        <link>leave/viewLeaveEntitlements?empNumber=$P{empNumber}&amp;fromDate=$P{fromDate}&amp;toDate=$P{toDate}&amp;leaveTypeId=$P{leaveTypeId}&amp;stddate=1</link>\n                    </field>                                \n                </fields>\n            </display_group>\n    </display_groups>\n</sub_report>\n\n<sub_report type="sql" name="pendingQuery">\n<query>\nFROM ohrm_leave_type LEFT JOIN \nohrm_leave ON ohrm_leave_type.id = ohrm_leave.leave_type_id AND\n$X{=,ohrm_leave.emp_number,empNumber} AND\nohrm_leave.status = 1 AND\n$X{&gt;=,ohrm_leave.date,fromDate} AND $X{&lt;=,ohrm_leave.date,toDate}\nWHERE\nohrm_leave_type.deleted = 0 AND\n$X{IN,ohrm_leave_type.id,leaveTypeId}\n\nGROUP BY ohrm_leave_type.id\nORDER BY ohrm_leave_type.id\n</query>\n    <id_field>leaveTypeId</id_field>\n    <display_groups>\n            <display_group name="g6" type="one" display="true">\n                <group_header></group_header>\n                <fields>\n                    <field display="false">\n                        <field_name>ohrm_leave_type.id</field_name>\n                        <field_alias>leaveTypeId</field_alias>\n                        <display_name>Leave Type ID</display_name>\n                        <width>1</width>\n                    </field>                                \n                    <field display="true">\n                        <field_name>sum(length_days)</field_name>\n                        <field_alias>pending</field_alias>\n                        <display_name>Leave Pending Approval (Days)</display_name>\n                        <width>120</width>\n                        <align>right</align>\n                        <link>leave/viewLeaveList?empNumber=$P{empNumber}&amp;fromDate=$P{fromDate}&amp;toDate=$P{toDate}&amp;leaveTypeId=$P{leaveTypeId}&amp;status=1&amp;stddate=1</link>\n                    </field>                                \n                </fields>\n            </display_group>\n    </display_groups>\n    </sub_report>\n\n<sub_report type="sql" name="scheduledQuery">\n<query>\nFROM ohrm_leave_type LEFT JOIN \nohrm_leave ON ohrm_leave_type.id = ohrm_leave.leave_type_id AND\n$X{=,ohrm_leave.emp_number,empNumber} AND\nohrm_leave.status = 2 AND\n$X{&gt;=,ohrm_leave.date,fromDate} AND $X{&lt;=,ohrm_leave.date,toDate}\nWHERE\nohrm_leave_type.deleted = 0 AND\n$X{IN,ohrm_leave_type.id,leaveTypeId}\n\nGROUP BY ohrm_leave_type.id\nORDER BY ohrm_leave_type.id\n</query>\n    <id_field>leaveTypeId</id_field>\n    <display_groups>\n            <display_group name="g5" type="one" display="true">\n                <group_header></group_header>\n                <fields>\n                    <field display="false">\n                        <field_name>ohrm_leave_type.id</field_name>\n                        <field_alias>leaveTypeId</field_alias>\n                        <display_name>Leave Type ID</display_name>\n                        <width>1</width>\n                    </field>                                \n                    <field display="true">\n                        <field_name>sum(length_days)</field_name>\n                        <field_alias>scheduled</field_alias>\n                        <display_name>Leave Scheduled (Days)</display_name>\n                        <width>120</width>\n                        <align>right</align>\n                        <link>leave/viewLeaveList?empNumber=$P{empNumber}&amp;fromDate=$P{fromDate}&amp;toDate=$P{toDate}&amp;leaveTypeId=$P{leaveTypeId}&amp;status=2&amp;stddate=1</link>\n                    </field>                                \n                </fields>\n            </display_group>\n    </display_groups>\n    </sub_report>\n\n<sub_report type="sql" name="takenQuery">\n<query>\nFROM ohrm_leave WHERE $X{=,emp_number,empNumber} AND\nstatus = 3 AND\n$X{IN,ohrm_leave.leave_type_id,leaveTypeId} AND\n$X{&gt;=,ohrm_leave.date,fromDate} AND $X{&lt;=,ohrm_leave.date,toDate}\nGROUP BY leave_type_id\nORDER BY ohrm_leave.leave_type_id\n</query>\n    <id_field>leaveTypeId</id_field>\n    <display_groups>\n            <display_group name="g4" type="one" display="true">\n                <group_header></group_header>\n                <fields>\n                    <field display="false">\n                        <field_name>ohrm_leave.leave_type_id</field_name>\n                        <field_alias>leaveTypeId</field_alias>\n                        <display_name>Leave Type ID</display_name>\n                        <width>1</width>\n                    </field>                                \n                    <field display="true">\n                        <field_name>sum(length_days)</field_name>\n                        <field_alias>taken</field_alias>\n                        <display_name>Leave Taken (Days)</display_name>\n                        <width>120</width>\n                        <align>right</align>\n                        <link>leave/viewLeaveList?empNumber=$P{empNumber}&amp;fromDate=$P{fromDate}&amp;toDate=$P{toDate}&amp;leaveTypeId=$P{leaveTypeId}&amp;status=3&amp;stddate=1</link>\n                    </field>                                \n                </fields>\n            </display_group>\n    </display_groups>\n    </sub_report>\n\n<sub_report type="sql" name="unused">       \n    <query>FROM ohrm_leave_type WHERE deleted = 0 AND $X{IN,ohrm_leave_type.id,leaveTypeId} ORDER BY ohrm_leave_type.id</query>\n    <id_field>leaveTypeId</id_field>\n    <display_groups>\n        <display_group name="unused" type="one" display="true">\n            <group_header></group_header>\n            <fields>\n                <field display="false">\n                    <field_name>ohrm_leave_type.id</field_name>\n                    <field_alias>leaveTypeId</field_alias>\n                    <display_name>Leave Type ID</display_name>\n                    <width>1</width>	\n                </field>   \n                <field display="true">\n                    <field_name>ohrm_leave_type.name</field_name>\n                    <field_alias>unused</field_alias>\n                    <display_name>Leave Balance (Days)</display_name>\n                    <width>160</width>	\n                    <align>right</align>\n                </field>                                                                                                     \n            </fields>\n        </display_group>\n    </display_groups> \n</sub_report>\n\n\n    <join>             \n        <join_by sub_report="mainTable" id="leaveTypeId"></join_by>              \n        <join_by sub_report="entitlementsTotal" id="leaveTypeId"></join_by> \n        <join_by sub_report="pendingQuery" id="leaveTypeId"></join_by>  \n        <join_by sub_report="scheduledQuery" id="leaveTypeId"></join_by>  \n        <join_by sub_report="takenQuery" id="leaveTypeId"></join_by>  \n        <join_by sub_report="unused" id="leaveTypeId"></join_by>  \n\n    </join>\n    <page_limit>100</page_limit>        \n</report>'),
(2, 'Leave Entitlements and Usage Report', '\n<report>\n    <settings>\n        <csv>\n            <include_group_header>1</include_group_header>\n            <include_header>1</include_header>\n        </csv>\n    </settings>\n<filter_fields>\n	<input_field type="text" name="leaveType" label="Leave Type"></input_field>\n	<input_field type="text" name="fromDate" label="From"></input_field>\n        <input_field type="text" name="toDate" label="To"></input_field>\n        <input_field type="text" name="asOfDate" label="AsOf"></input_field>\n        <input_field type="text" name="emp_numbers" label="employees"></input_field>\n        <input_field type="text" name="job_title" label="Job Title"></input_field>\n        <input_field type="text" name="location" label="Location"></input_field>\n        <input_field type="text" name="sub_unit" label="Sub Unit"></input_field>\n        <input_field type="text" name="terminated" label="Terminated"></input_field>\n</filter_fields> \n\n<sub_report type="sql" name="mainTable">       \n    <query>FROM hs_hr_employee \n    LEFT JOIN hs_hr_emp_locations ON hs_hr_employee.emp_number = hs_hr_emp_locations.emp_number\n    WHERE $X{IN,hs_hr_employee.emp_number,emp_numbers} \n    AND $X{=,hs_hr_employee.job_title_code,job_title}\n    AND $X{IN,hs_hr_employee.work_station,sub_unit}\n    AND $X{IN,hs_hr_emp_locations.location_id,location}\n    AND $X{IS NULL,hs_hr_employee.termination_id,terminated}\n    ORDER BY hs_hr_employee.emp_lastname</query>\n    <id_field>empNumber</id_field>\n    <display_groups>\n        <display_group name="personalDetails" type="one" display="true">\n            <group_header></group_header>\n            <fields>\n                <field display="false">\n                    <field_name>hs_hr_employee.emp_number</field_name>\n                    <field_alias>empNumber</field_alias>\n                    <display_name>Employee Number</display_name>\n                    <width>1</width>	\n                </field>                \n                <field display="false">\n                    <field_name>hs_hr_employee.termination_id</field_name>\n                    <field_alias>termination_id</field_alias>\n                    <display_name>Termination ID</display_name>\n                    <width>1</width>	\n                </field>   \n                <field display="true">\n                    <field_name>CONCAT(hs_hr_employee.emp_firstname, '' '', hs_hr_employee.emp_lastname)</field_name>\n                    <field_alias>employeeName</field_alias>\n                    <display_name>Employee</display_name>\n                    <width>150</width>\n                </field>                                                                                               \n            </fields>\n        </display_group>\n    </display_groups> \n</sub_report>\n\n<sub_report type="sql" name="entitlementsTotal">\n                    <query>\n\nFROM (\nSELECT ohrm_leave_entitlement.id as id, \n       ohrm_leave_entitlement.emp_number as emp_number,\n       ohrm_leave_entitlement.no_of_days as no_of_days,\n       sum(IF(ohrm_leave.status = 2, ohrm_leave_leave_entitlement.length_days, 0)) AS scheduled,\n       sum(IF(ohrm_leave.status = 3, ohrm_leave_leave_entitlement.length_days, 0)) AS taken\n       \nFROM ohrm_leave_entitlement LEFT JOIN ohrm_leave_leave_entitlement ON\n    ohrm_leave_entitlement.id = ohrm_leave_leave_entitlement.entitlement_id\n    LEFT JOIN ohrm_leave ON ohrm_leave.id = ohrm_leave_leave_entitlement.leave_id AND \n    ( $X{&gt;,ohrm_leave.date,toDate} OR $X{&lt;,ohrm_leave.date,fromDate} )\n\nWHERE ohrm_leave_entitlement.deleted=0 AND $X{=,ohrm_leave_entitlement.leave_type_id,leaveType}\n    AND $X{IN,ohrm_leave_entitlement.emp_number,empNumber} AND\n    (\n      ( $X{&lt;=,ohrm_leave_entitlement.from_date,fromDate} AND $X{&gt;=,ohrm_leave_entitlement.to_date,fromDate} ) OR\n      ( $X{&lt;=,ohrm_leave_entitlement.from_date,toDate} AND $X{&gt;=,ohrm_leave_entitlement.to_date,toDate} ) OR \n      ( $X{&gt;=,ohrm_leave_entitlement.from_date,fromDate} AND $X{&lt;=,ohrm_leave_entitlement.to_date,toDate} ) \n    )\n    \nGROUP BY ohrm_leave_entitlement.id\n) AS A\n\nGROUP BY A.emp_number\nORDER BY A.emp_number\n\n</query>\n    <id_field>empNumber</id_field>\n    <display_groups>\n            <display_group name="g2" type="one" display="true">\n                <group_header></group_header>\n                <fields>\n                    <field display="false">\n                        <field_name>A.emp_number</field_name>\n                        <field_alias>empNumber</field_alias>\n                        <display_name>Emp Number</display_name>\n                        <width>1</width>\n                    </field>                                \n                    <field display="true">\n                        <field_name>sum(A.no_of_days) - sum(A.scheduled) - sum(A.taken)</field_name>\n                        <field_alias>entitlement_total</field_alias>\n                        <display_name>Leave Entitlements (Days)</display_name>\n                        <width>120</width>\n                        <align>right</align>\n                        <link>leave/viewLeaveEntitlements?empNumber=$P{empNumber}&amp;fromDate=$P{fromDate}&amp;toDate=$P{toDate}&amp;leaveTypeId=$P{leaveTypeId}&amp;stddate=1</link>\n                    </field>                                \n                </fields>\n            </display_group>\n    </display_groups>\n</sub_report>\n\n<sub_report type="sql" name="pendingQuery">\n<query>\nFROM ohrm_leave WHERE $X{=,ohrm_leave.leave_type_id,leaveType} AND\nstatus = 1 AND\n$X{IN,ohrm_leave.emp_number,empNumber} AND\n$X{&gt;=,ohrm_leave.date,fromDate} AND $X{&lt;=,ohrm_leave.date,toDate}\nGROUP BY emp_number\nORDER BY ohrm_leave.emp_number\n</query>\n    <id_field>empNumber</id_field>\n    <display_groups>\n            <display_group name="g6" type="one" display="true">\n                <group_header></group_header>\n                <fields>\n                    <field display="false">\n                        <field_name>ohrm_leave.emp_number</field_name>\n                        <field_alias>empNumber</field_alias>\n                        <display_name>Emp Number</display_name>\n                        <width>1</width>\n                    </field>                                \n                    <field display="true">\n                        <field_name>sum(length_days)</field_name>\n                        <field_alias>pending</field_alias>\n                        <display_name>Leave Pending Approval (Days)</display_name>\n                        <width>121</width>\n                        <align>right</align>\n                        <link>leave/viewLeaveList?empNumber=$P{empNumber}&amp;fromDate=$P{fromDate}&amp;toDate=$P{toDate}&amp;leaveTypeId=$P{leaveTypeId}&amp;status=1&amp;stddate=1</link>\n                    </field>                                \n                </fields>\n            </display_group>\n    </display_groups>\n</sub_report>\n\n\n<sub_report type="sql" name="scheduledQuery">\n<query>\nFROM ohrm_leave WHERE $X{=,ohrm_leave.leave_type_id,leaveType} AND\nstatus = 2 AND\n$X{IN,ohrm_leave.emp_number,empNumber} AND\n$X{&gt;=,ohrm_leave.date,fromDate} AND $X{&lt;=,ohrm_leave.date,toDate}\nGROUP BY emp_number\nORDER BY ohrm_leave.emp_number\n</query>\n    <id_field>empNumber</id_field>\n    <display_groups>\n            <display_group name="g5" type="one" display="true">\n                <group_header></group_header>\n                <fields>\n                    <field display="false">\n                        <field_name>ohrm_leave.emp_number</field_name>\n                        <field_alias>empNumber</field_alias>\n                        <display_name>Emp Number</display_name>\n                        <width>1</width>\n                    </field>                                \n                    <field display="true">\n                        <field_name>sum(length_days)</field_name>\n                        <field_alias>scheduled</field_alias>\n                        <display_name>Leave Scheduled (Days)</display_name>\n                        <width>121</width>\n                        <align>right</align>\n                        <link>leave/viewLeaveList?empNumber=$P{empNumber}&amp;fromDate=$P{fromDate}&amp;toDate=$P{toDate}&amp;leaveTypeId=$P{leaveTypeId}&amp;status=2&amp;stddate=1</link>\n                    </field>                                \n                </fields>\n            </display_group>\n    </display_groups>\n</sub_report>\n\n<sub_report type="sql" name="takenQuery">\n<query>\nFROM ohrm_leave WHERE $X{=,ohrm_leave.leave_type_id,leaveType} AND\nstatus = 3 AND\n$X{IN,ohrm_leave.emp_number,empNumber} AND\n$X{&gt;=,ohrm_leave.date,fromDate} AND $X{&lt;=,ohrm_leave.date,toDate}\nGROUP BY emp_number\nORDER BY ohrm_leave.emp_number\n</query>\n    <id_field>empNumber</id_field>\n    <display_groups>\n            <display_group name="g4" type="one" display="true">\n                <group_header></group_header>\n                <fields>\n                    <field display="false">\n                        <field_name>ohrm_leave.emp_number</field_name>\n                        <field_alias>empNumber</field_alias>\n                        <display_name>Emp Number</display_name>\n                        <width>1</width>\n                    </field>                                \n                    <field display="true">\n                        <field_name>sum(length_days)</field_name>\n                        <field_alias>taken</field_alias>\n                        <display_name>Leave Taken (Days)</display_name>\n                        <width>120</width>\n                        <align>right</align>\n                        <link>leave/viewLeaveList?empNumber=$P{empNumber}&amp;fromDate=$P{fromDate}&amp;toDate=$P{toDate}&amp;leaveTypeId=$P{leaveTypeId}&amp;status=3&amp;stddate=1</link>\n                    </field>                                \n                </fields>\n            </display_group>\n    </display_groups>\n</sub_report>\n<sub_report type="sql" name="unused">       \n    <query>FROM hs_hr_employee WHERE $X{IN,hs_hr_employee.emp_number,empNumber} ORDER BY hs_hr_employee.emp_number</query>\n    <id_field>empNumber</id_field>\n    <display_groups>\n        <display_group name="unused" type="one" display="true">\n            <group_header></group_header>\n            <fields>    \n                <field display="false">\n                    <field_name>hs_hr_employee.emp_number</field_name>\n                    <field_alias>empNumber</field_alias>\n                    <display_name>Employee Number</display_name>\n                    <width>1</width>	\n                </field>                \n                <field display="true">\n                    <field_name>hs_hr_employee.emp_firstname</field_name>\n                    <field_alias>unused</field_alias>\n                    <display_name>Leave Balance (Days)</display_name>\n                    <width>150</width>\n                    <align>right</align>\n                </field> \n                                                                                               \n            </fields>\n        </display_group>\n    </display_groups> \n</sub_report>\n    <join>             \n        <join_by sub_report="mainTable" id="empNumber"></join_by>            \n        <join_by sub_report="entitlementsTotal" id="empNumber"></join_by> \n        <join_by sub_report="pendingQuery" id="empNumber"></join_by>\n        <join_by sub_report="scheduledQuery" id="empNumber"></join_by>\n        <join_by sub_report="takenQuery" id="empNumber"></join_by> \n        <join_by sub_report="unused" id="empNumber"></join_by>  \n    </join>\n    <page_limit>20</page_limit>       \n</report>');

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_attendance_record`
--

CREATE TABLE IF NOT EXISTS `ohrm_attendance_record` (
  `id` bigint(20) NOT NULL,
  `employee_id` bigint(20) NOT NULL,
  `punch_in_utc_time` datetime DEFAULT NULL,
  `punch_in_note` varchar(255) DEFAULT NULL,
  `punch_in_time_offset` varchar(255) DEFAULT NULL,
  `punch_in_user_time` datetime DEFAULT NULL,
  `punch_out_utc_time` datetime DEFAULT NULL,
  `punch_out_note` varchar(255) DEFAULT NULL,
  `punch_out_time_offset` varchar(255) DEFAULT NULL,
  `punch_out_user_time` datetime DEFAULT NULL,
  `state` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `emp_id_state` (`employee_id`,`state`),
  KEY `emp_id_time` (`employee_id`,`punch_in_utc_time`,`punch_out_utc_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_auth_provider_extra_details`
--

CREATE TABLE IF NOT EXISTS `ohrm_auth_provider_extra_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `provider_id` int(10) NOT NULL,
  `provider_type` int(11) DEFAULT NULL,
  `client_id` text,
  `client_secret` text,
  `developer_key` text,
  PRIMARY KEY (`id`),
  KEY `provider_id` (`provider_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_available_group_field`
--

CREATE TABLE IF NOT EXISTS `ohrm_available_group_field` (
  `report_group_id` bigint(20) NOT NULL,
  `group_field_id` bigint(20) NOT NULL,
  PRIMARY KEY (`report_group_id`,`group_field_id`),
  KEY `report_group_id` (`report_group_id`),
  KEY `group_field_id` (`group_field_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_beacon_notification`
--

CREATE TABLE IF NOT EXISTS `ohrm_beacon_notification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `expiry_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `definition` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_composite_display_field`
--

CREATE TABLE IF NOT EXISTS `ohrm_composite_display_field` (
  `composite_display_field_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `report_group_id` bigint(20) NOT NULL,
  `name` varchar(1000) NOT NULL,
  `label` varchar(255) NOT NULL,
  `field_alias` varchar(255) DEFAULT NULL,
  `is_sortable` varchar(10) NOT NULL,
  `sort_order` varchar(255) DEFAULT NULL,
  `sort_field` varchar(255) DEFAULT NULL,
  `element_type` varchar(255) NOT NULL,
  `element_property` varchar(1000) NOT NULL,
  `width` varchar(255) NOT NULL,
  `is_exportable` varchar(10) DEFAULT NULL,
  `text_alignment_style` varchar(20) DEFAULT NULL,
  `is_value_list` tinyint(1) NOT NULL DEFAULT '0',
  `display_field_group_id` int(10) unsigned DEFAULT NULL,
  `default_value` varchar(255) DEFAULT NULL,
  `is_encrypted` tinyint(1) NOT NULL DEFAULT '0',
  `is_meta` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`composite_display_field_id`),
  KEY `report_group_id` (`report_group_id`),
  KEY `display_field_group_id` (`display_field_group_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Contenu de la table `ohrm_composite_display_field`
--

INSERT INTO `ohrm_composite_display_field` (`composite_display_field_id`, `report_group_id`, `name`, `label`, `field_alias`, `is_sortable`, `sort_order`, `sort_field`, `element_type`, `element_property`, `width`, `is_exportable`, `text_alignment_style`, `is_value_list`, `display_field_group_id`, `default_value`, `is_encrypted`, `is_meta`) VALUES
(1, 1, 'IF(hs_hr_employee.termination_id IS NULL, CONCAT(hs_hr_employee.emp_firstname, " " ,hs_hr_employee.emp_lastname), CONCAT(hs_hr_employee.emp_firstname, " " ,hs_hr_employee.emp_lastname, " (Past Employee)"))', 'Employee Name', 'employeeName', 'false', NULL, NULL, 'label', '<xml><getter>employeeName</getter></xml>', '300', '0', NULL, 0, NULL, 'Deleted Employee', 0, 0),
(2, 1, 'CONCAT(ohrm_customer.name, " - " ,ohrm_project.name)', 'Project Name', 'projectname', 'false', NULL, NULL, 'label', '<xml><getter>projectname</getter></xml>', '300', '0', NULL, 0, NULL, NULL, 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_customer`
--

CREATE TABLE IF NOT EXISTS `ohrm_customer` (
  `customer_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`customer_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Contenu de la table `ohrm_customer`
--

INSERT INTO `ohrm_customer` (`customer_id`, `name`, `description`, `is_deleted`) VALUES
(1, 'etudiant', 'etudiant', 0);

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_datapoint`
--

CREATE TABLE IF NOT EXISTS `ohrm_datapoint` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `datapoint_type_id` int(11) NOT NULL,
  `definition` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `datapoint_type_id` (`datapoint_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_datapoint_type`
--

CREATE TABLE IF NOT EXISTS `ohrm_datapoint_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `action_class` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Contenu de la table `ohrm_datapoint_type`
--

INSERT INTO `ohrm_datapoint_type` (`id`, `name`, `action_class`) VALUES
(1, 'config', 'configDatapointProcessor'),
(2, 'count', 'countDatapointProcessor'),
(3, 'session', 'sessionDatapointProcessor'),
(4, 'organization', 'OrganizationDataProcessor');

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_data_group`
--

CREATE TABLE IF NOT EXISTS `ohrm_data_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `can_read` tinyint(4) DEFAULT NULL,
  `can_create` tinyint(4) DEFAULT NULL,
  `can_update` tinyint(4) DEFAULT NULL,
  `can_delete` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=61 ;

--
-- Contenu de la table `ohrm_data_group`
--

INSERT INTO `ohrm_data_group` (`id`, `name`, `description`, `can_read`, `can_create`, `can_update`, `can_delete`) VALUES
(1, 'personal_information', 'PIM - Personal Details', 1, NULL, 1, NULL),
(2, 'personal_attachment', 'PIM - Personal Details - Attachments', 1, 1, 1, 1),
(3, 'personal_custom_fields', 'PIM - Personal Details - Custom Fields', 1, NULL, 1, NULL),
(4, 'contact_details', 'PIM - Contact Details', 1, NULL, 1, NULL),
(5, 'contact_attachment', 'PIM - Contact Details - Attachments', 1, 1, 1, 1),
(6, 'contact_custom_fields', 'PIM - Contact Details - Custom Fields', 1, NULL, 1, NULL),
(7, 'emergency_contacts', 'PIM - Emergency Contacts', 1, 1, 1, 1),
(8, 'emergency_attachment', 'PIM - Emergency Contacts - Attachments', 1, 1, 1, 1),
(9, 'emergency_custom_fields', 'PIM - Emergency Contacts - Custom Fields', 1, NULL, 1, NULL),
(10, 'dependents', 'PIM - Dependents', 1, 1, 1, 1),
(11, 'dependents_attachment', 'PIM - Dependents - Attachments', 1, 1, 1, 1),
(12, 'dependents_custom_fields', 'PIM - Dependents - Custom Fields', 1, NULL, 1, NULL),
(13, 'immigration', 'PIM - Immigration', 1, 1, 1, 1),
(14, 'immigration_attachment', 'PIM - Immigration - Attachments', 1, 1, 1, 1),
(15, 'immigration_custom_fields', 'PIM - Immigration - Custom Fields', 1, NULL, 1, NULL),
(16, 'job_details', 'PIM - Job', 1, NULL, 1, NULL),
(17, 'job_attachment', 'PIM - Job - Attachments', 1, 1, 1, 1),
(18, 'job_custom_fields', 'PIM - Job - Custom Fields', 1, NULL, 1, NULL),
(19, 'salary_details', 'PIM - Salary', 1, 1, 1, 1),
(20, 'salary_attachment', 'PIM - Salary - Attachments', 1, 1, 1, 1),
(21, 'salary_custom_fields', 'PIM - Salary - Custom Fields', 1, NULL, 1, NULL),
(22, 'tax_exemptions', 'PIM - Tax Exemptions', 1, NULL, 1, NULL),
(23, 'tax_attachment', 'PIM - Tax Exemptions - Attachments', 1, 1, 1, 1),
(24, 'tax_custom_fields', 'PIM - Tax Exemptions - Custom Fields', 1, NULL, 1, NULL),
(25, 'supervisor', 'PIM - Employee Supervisors', 1, 1, 1, 1),
(26, 'subordinates', 'PIM - Employee Subordinates', 1, 1, 1, 1),
(27, 'report-to_attachment', 'PIM - Employee Supervisors/Subordinates - Attachment', 1, 1, 1, 1),
(28, 'report-to_custom_fields', 'PIM - Employee Supervisors/Subordinates - Custom Fields', 1, NULL, 1, NULL),
(29, 'qualification_work', 'PIM - Qualifications - Work Experience', 1, 1, 1, 1),
(30, 'qualification_education', 'PIM - Qualifications - Education', 1, 1, 1, 1),
(31, 'qualification_skills', 'PIM - Qualifications - Skills', 1, 1, 1, 1),
(32, 'qualification_languages', 'PIM - Qualifications - Languages', 1, 1, 1, 1),
(33, 'qualification_license', 'PIM - Qualifications - License', 1, 1, 1, 1),
(34, 'qualifications_attachment', 'PIM - Qualifications - Attachments', 1, 1, 1, 1),
(35, 'qualifications_custom_fields', 'PIM - Qualifications - Custom Fields', 1, NULL, 1, NULL),
(36, 'membership', 'PIM - Membership', 1, 1, 1, 1),
(37, 'membership_attachment', 'PIM - Membership - Attachments', 1, 1, 1, 1),
(38, 'membership_custom_fields', 'PIM - Membership - Custom Fields', 1, NULL, 1, NULL),
(39, 'photograph', 'PIM - Employee Photograph', 1, NULL, 1, 1),
(40, 'leave_entitlements', 'Leave - Leave Entitlements', 1, 1, 1, 1),
(41, 'leave_entitlements_usage_report', 'Leave - Leave Entitlements and Usage Report', 1, NULL, NULL, NULL),
(42, 'job_titles', 'Admin - Job Titles', 1, 1, 1, 1),
(43, 'pay_grades', 'Admin - Pay Grades', 1, 1, 1, 1),
(44, 'time_customers', 'Time - Project Info - Customers', 1, 1, 1, 1),
(45, 'time_projects', 'Time - Project Info - Projects', 1, 1, 1, 1),
(46, 'pim_reports', 'PIM - Reports', 1, 1, 1, 1),
(47, 'attendance_configuration', 'Time - Attendance Configuration', 1, 0, 1, 0),
(48, 'attendance_records', 'Time - Attendance Records', 1, 0, 0, 0),
(49, 'time_project_reports', 'Time - Project Reports', 1, 0, 0, 0),
(50, 'time_employee_reports', 'Time - Employee Reports', 1, 0, 0, 0),
(51, 'attendance_summary', 'Time - Attendance Summary', 1, 0, 0, 0),
(52, 'leave_period', 'Leave - Leave Period', 1, 0, 1, 0),
(53, 'leave_types', 'Leave - Leave Types', 1, 1, 1, 1),
(54, 'work_week', 'Leave - Work Week', 1, 0, 1, 0),
(55, 'holidays', 'Leave - Holidays', 1, 1, 1, 1),
(56, 'recruitment_vacancies', 'Recruitment - Vacancies', 1, 1, 1, 1),
(57, 'recruitment_candidates', 'Recruitment - Candidates', 1, 1, 1, 1),
(58, 'time_employee_timesheets', 'Time - Employee Timesheets', 1, 0, 0, 0),
(59, 'leave_list', 'Leave - Leave List', 1, 0, 0, 0),
(60, 'leave_list_comments', 'Leave - Leave List - Comments', 0, 1, 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_data_group_screen`
--

CREATE TABLE IF NOT EXISTS `ohrm_data_group_screen` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `data_group_id` int(11) DEFAULT NULL,
  `screen_id` int(11) DEFAULT NULL,
  `permission` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `data_group_id` (`data_group_id`),
  KEY `screen_id` (`screen_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=76 ;

--
-- Contenu de la table `ohrm_data_group_screen`
--

INSERT INTO `ohrm_data_group_screen` (`id`, `data_group_id`, `screen_id`, `permission`) VALUES
(1, 40, 69, 1),
(2, 40, 72, 2),
(3, 40, 73, 3),
(4, 40, 71, 4),
(5, 41, 78, 1),
(6, 42, 23, 1),
(7, 42, 80, 1),
(8, 42, 80, 2),
(9, 42, 80, 3),
(10, 42, 81, 4),
(11, 43, 24, 1),
(12, 43, 82, 1),
(13, 43, 82, 2),
(14, 43, 82, 3),
(15, 43, 83, 4),
(16, 43, 84, 3),
(17, 43, 85, 3),
(18, 42, 74, 1),
(19, 43, 74, 1),
(20, 44, 36, 1),
(21, 44, 86, 2),
(22, 44, 86, 3),
(23, 44, 87, 4),
(24, 45, 37, 1),
(25, 45, 88, 1),
(26, 45, 88, 2),
(27, 45, 88, 3),
(28, 45, 89, 4),
(29, 45, 90, 2),
(30, 45, 90, 3),
(31, 45, 91, 2),
(32, 45, 91, 3),
(33, 46, 45, 1),
(34, 46, 45, 4),
(35, 46, 92, 2),
(36, 46, 92, 3),
(37, 46, 93, 1),
(38, 47, 56, 1),
(39, 47, 56, 3),
(40, 48, 55, 1),
(41, 49, 57, 1),
(42, 49, 102, 1),
(43, 50, 58, 1),
(44, 51, 59, 1),
(45, 51, 101, 1),
(46, 52, 47, 1),
(47, 52, 47, 3),
(48, 53, 7, 1),
(49, 53, 8, 1),
(50, 53, 8, 2),
(51, 53, 8, 3),
(52, 53, 9, 2),
(53, 53, 10, 4),
(54, 54, 14, 1),
(55, 54, 14, 3),
(56, 55, 11, 1),
(57, 55, 12, 2),
(58, 55, 12, 3),
(59, 55, 13, 4),
(60, 56, 61, 1),
(61, 56, 94, 1),
(62, 56, 94, 2),
(63, 56, 94, 3),
(64, 56, 95, 4),
(65, 57, 60, 1),
(66, 57, 96, 1),
(67, 57, 96, 2),
(68, 57, 96, 3),
(69, 57, 97, 4),
(70, 56, 76, 1),
(71, 57, 76, 1),
(72, 58, 52, 1),
(73, 59, 16, 1),
(74, 59, 98, 1),
(75, 59, 99, 1);

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_display_field`
--

CREATE TABLE IF NOT EXISTS `ohrm_display_field` (
  `display_field_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `report_group_id` bigint(20) NOT NULL,
  `name` varchar(255) NOT NULL,
  `label` varchar(255) NOT NULL,
  `field_alias` varchar(255) DEFAULT NULL,
  `is_sortable` varchar(10) NOT NULL,
  `sort_order` varchar(255) DEFAULT NULL,
  `sort_field` varchar(255) DEFAULT NULL,
  `element_type` varchar(255) NOT NULL,
  `element_property` varchar(1000) NOT NULL,
  `width` varchar(255) NOT NULL,
  `is_exportable` varchar(10) DEFAULT NULL,
  `text_alignment_style` varchar(20) DEFAULT NULL,
  `is_value_list` tinyint(1) NOT NULL DEFAULT '0',
  `display_field_group_id` int(10) unsigned DEFAULT NULL,
  `default_value` varchar(255) DEFAULT NULL,
  `is_encrypted` tinyint(1) NOT NULL DEFAULT '0',
  `is_meta` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`display_field_id`),
  KEY `report_group_id` (`report_group_id`),
  KEY `display_field_group_id` (`display_field_group_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=122 ;

--
-- Contenu de la table `ohrm_display_field`
--

INSERT INTO `ohrm_display_field` (`display_field_id`, `report_group_id`, `name`, `label`, `field_alias`, `is_sortable`, `sort_order`, `sort_field`, `element_type`, `element_property`, `width`, `is_exportable`, `text_alignment_style`, `is_value_list`, `display_field_group_id`, `default_value`, `is_encrypted`, `is_meta`) VALUES
(1, 1, 'ohrm_project.name', 'Project Name', 'projectname', 'false', NULL, NULL, 'label', '<xml><getter>projectname</getter></xml>', '200', '0', NULL, 0, NULL, NULL, 0, 0),
(2, 1, 'ohrm_project_activity.name', 'Activity Name', 'activityname', 'false', NULL, NULL, 'link', '<xml><labelGetter>activityname</labelGetter><placeholderGetters><id>activity_id</id><total>totalduration</total><projectId>projectId</projectId><from>fromDate</from><to>toDate</to><approved>onlyIncludeApprovedTimesheets</approved></placeholderGetters><urlPattern>../../displayProjectActivityDetailsReport?reportId=3#activityId={id}#total={total}#from={from}#to={to}#projectId={projectId}#onlyIncludeApprovedTimesheets={approved}</urlPattern></xml>', '200', '0', NULL, 0, NULL, NULL, 0, 0),
(3, 1, 'ohrm_project_activity.project_id', 'Project Id', NULL, 'false', NULL, NULL, 'label', '<xml><getter>project_id</getter></xml>', '75', '0', 'right', 0, NULL, NULL, 0, 1),
(4, 1, 'ohrm_project_activity.activity_id', 'Activity Id', NULL, 'false', NULL, NULL, 'label', '<xml><getter>activity_id</getter></xml>', '75', '0', 'right', 0, NULL, NULL, 0, 1),
(5, 1, 'ohrm_timesheet_item.duration', 'Time (hours)', NULL, 'false', NULL, NULL, 'label', '<xml><getter>duration</getter></xml>', '75', '0', 'right', 0, NULL, NULL, 0, 0),
(6, 1, 'hs_hr_employee.emp_firstname', 'Employee First Name', NULL, 'false', NULL, NULL, 'label', '<xml><getter>emp_firstname</getter></xml>', '200', '0', NULL, 0, NULL, NULL, 0, 0),
(7, 1, 'hs_hr_employee.emp_lastname', 'Employee Last Name', NULL, 'false', NULL, NULL, 'label', '<xml><getter>emp_lastname</getter></xml>', '200', '0', NULL, 0, NULL, NULL, 0, 0),
(8, 1, 'ohrm_project_activity.name', 'Activity Name', 'activityname', 'false', NULL, NULL, 'label', '<xml><getter>activityname</getter></xml>', '200', '0', NULL, 0, NULL, NULL, 0, 0),
(9, 3, 'hs_hr_employee.employee_id', 'Employee Id', 'employeeId', 'false', NULL, NULL, 'label', '<xml><getter>employeeId</getter></xml>', '100', '0', NULL, 0, 1, '---', 0, 0),
(10, 3, 'hs_hr_employee.emp_lastname', 'Employee Last Name', 'employeeLastname', 'false', NULL, NULL, 'label', '<xml><getter>employeeLastname</getter></xml>', '200', '0', NULL, 0, 1, '---', 0, 0),
(11, 3, 'hs_hr_employee.emp_firstname', 'Employee First Name', 'employeeFirstname', 'false', NULL, NULL, 'label', '<xml><getter>employeeFirstname</getter></xml>', '200', '0', NULL, 0, 1, '---', 0, 0),
(12, 3, 'hs_hr_employee.emp_middle_name', 'Employee Middle Name', 'employeeMiddlename', 'false', NULL, NULL, 'label', '<xml><getter>employeeMiddlename</getter></xml>', '200', '0', NULL, 0, 1, '---', 0, 0),
(13, 3, 'hs_hr_employee.emp_birthday', 'Date of Birth', 'empBirthday', 'false', NULL, NULL, 'labelDate', '<xml><getter>empBirthday</getter></xml>', '100', '0', NULL, 0, 1, '---', 0, 0),
(14, 3, 'ohrm_nationality.name', 'Nationality', 'nationality', 'false', NULL, NULL, 'label', '<xml><getter>nationality</getter></xml>', '200', '0', NULL, 0, 1, '---', 0, 0),
(15, 3, 'CASE hs_hr_employee.emp_gender WHEN 1 THEN "Male" WHEN 2 THEN "Female" WHEN 3 THEN "Other" END', 'Gender', 'empGender', 'false', NULL, NULL, 'label', '<xml><getter>empGender</getter></xml>', '80', '0', NULL, 0, 1, '---', 0, 0),
(17, 3, 'hs_hr_employee.emp_marital_status', 'Marital Status', 'maritalStatus', 'false', NULL, NULL, 'label', '<xml><getter>maritalStatus</getter></xml>', '100', '0', NULL, 0, 1, '---', 0, 0),
(18, 3, 'hs_hr_employee.emp_dri_lice_num', 'Driver License Number', 'driversLicenseNumber', 'false', NULL, NULL, 'label', '<xml><getter>driversLicenseNumber</getter></xml>', '240', '0', NULL, 0, 1, '---', 0, 0),
(19, 3, 'hs_hr_employee.emp_dri_lice_exp_date', 'License Expiry Date', 'licenseExpiryDate', 'false', NULL, NULL, 'labelDate', '<xml><getter>licenseExpiryDate</getter></xml>', '135', '0', NULL, 0, 1, '---', 0, 0),
(20, 3, 'CONCAT_WS(", ", NULLIF(hs_hr_employee.emp_street1, ""), NULLIF(hs_hr_employee.emp_street2, ""), NULLIF(hs_hr_employee.city_code, ""), NULLIF(hs_hr_employee.provin_code,""), NULLIF(hs_hr_employee.emp_zipcode,""), NULLIF(hs_hr_country.cou_name,""))', 'Address', 'address', 'false', NULL, NULL, 'label', '<xml><getter>address</getter></xml>', '200', '0', NULL, 0, 2, '---', 0, 0),
(21, 3, 'hs_hr_employee.emp_hm_telephone', 'Home Telephone', 'homeTelephone', 'false', NULL, NULL, 'label', '<xml><getter>homeTelephone</getter></xml>', '130', '0', NULL, 0, 2, '---', 0, 0),
(22, 3, 'hs_hr_employee.emp_mobile', 'Mobile', 'mobile', 'false', NULL, NULL, 'label', '<xml><getter>mobile</getter></xml>', '100', '0', NULL, 0, 2, '---', 0, 0),
(23, 3, 'hs_hr_employee.emp_work_telephone', 'Work Telephone', 'workTelephone', 'false', NULL, NULL, 'label', '<xml><getter>workTelephone</getter></xml>', '100', '0', NULL, 0, 2, '---', 0, 0),
(24, 3, 'hs_hr_employee.emp_work_email', 'Work Email', 'workEmail', 'false', NULL, NULL, 'label', '<xml><getter>workEmail</getter></xml>', '200', '0', NULL, 0, 2, '---', 0, 0),
(25, 3, 'hs_hr_employee.emp_oth_email', 'Other Email', 'otherEmail', 'false', NULL, NULL, 'label', '<xml><getter>otherEmail</getter></xml>', '200', '0', NULL, 0, 2, '---', 0, 0),
(26, 3, 'hs_hr_emp_emergency_contacts.eec_name', 'Name', 'ecname', 'false', NULL, NULL, 'label', '<xml><getter>ecname</getter></xml>', '200', '0', NULL, 1, 3, '---', 0, 0),
(27, 3, 'hs_hr_emp_emergency_contacts.eec_home_no', 'Home Telephone', 'ecHomeTelephone', 'false', NULL, NULL, 'label', '<xml><getter>ecHomeTelephone</getter></xml>', '130', '0', NULL, 1, 3, '---', 0, 0),
(28, 3, 'hs_hr_emp_emergency_contacts.eec_office_no', 'Work Telephone', 'ecWorkTelephone', 'false', NULL, NULL, 'label', '<xml><getter>ecWorkTelephone</getter></xml>', '100', '0', NULL, 1, 3, '---', 0, 0),
(29, 3, 'hs_hr_emp_emergency_contacts.eec_relationship', 'Relationship', 'ecRelationship', 'false', NULL, NULL, 'label', '<xml><getter>ecRelationship</getter></xml>', '200', '0', NULL, 1, 3, '---', 0, 0),
(30, 3, 'hs_hr_emp_emergency_contacts.eec_mobile_no', 'Mobile', 'ecMobile', 'false', NULL, NULL, 'label', '<xml><getter>ecMobile</getter></xml>', '100', '0', NULL, 1, 3, '---', 0, 0),
(31, 3, 'hs_hr_emp_dependents.ed_name', 'Name', 'dependentName', 'false', NULL, NULL, 'label', '<xml><getter>dependentName</getter></xml>', '200', '0', NULL, 1, 4, '---', 0, 0),
(32, 3, 'IF (hs_hr_emp_dependents.ed_relationship_type = ''other'', hs_hr_emp_dependents.ed_relationship, hs_hr_emp_dependents.ed_relationship_type)', 'Relationship', 'dependentRelationship', 'false', NULL, NULL, 'label', '<xml><getter>dependentRelationship</getter></xml>', '200', '0', NULL, 1, 4, '---', 0, 0),
(33, 3, 'hs_hr_emp_dependents.ed_date_of_birth', 'Date of Birth', 'dependentDateofBirth', 'false', NULL, NULL, 'labelDate', '<xml><getter>dependentDateofBirth</getter></xml>', '100', '0', NULL, 1, 4, '---', 0, 0),
(35, 3, 'ohrm_membership.name', 'Membership', 'name', 'false', NULL, NULL, 'label', '<xml><getter>name</getter></xml>', '200', '0', NULL, 1, 15, '---', 0, 0),
(36, 3, 'hs_hr_emp_member_detail.ememb_subscript_ownership', 'Subscription Paid By', 'subscriptionPaidBy', 'false', NULL, NULL, 'label', '<xml><getter>subscriptionPaidBy</getter></xml>', '200', '0', NULL, 1, 15, '---', 0, 0),
(37, 3, 'hs_hr_emp_member_detail.ememb_subscript_amount', 'Subscription Amount', 'subscriptionAmount', 'false', NULL, NULL, 'label', '<xml><getter>subscriptionAmount</getter></xml>', '200', '0', NULL, 1, 15, '---', 0, 0),
(38, 3, 'hs_hr_emp_member_detail.ememb_subs_currency', 'Currency', 'membershipCurrency', 'false', NULL, NULL, 'label', '<xml><getter>membershipCurrency</getter></xml>', '200', '0', NULL, 1, 15, '---', 0, 0),
(39, 3, 'hs_hr_emp_member_detail.ememb_commence_date', 'Subscription Commence Date', 'subscriptionCommenceDate', 'false', NULL, NULL, 'labelDate', '<xml><getter>subscriptionCommenceDate</getter></xml>', '200', '0', NULL, 1, 15, '---', 0, 0),
(40, 3, 'hs_hr_emp_member_detail.ememb_renewal_date', 'Subscription Renewal Date', 'subscriptionRenewalDate', 'false', NULL, NULL, 'labelDate', '<xml><getter>subscriptionRenewalDate</getter></xml>', '200', '0', NULL, 1, 15, '---', 0, 0),
(41, 3, 'hs_hr_emp_work_experience.eexp_employer', 'Company', 'expCompany', 'false', NULL, NULL, 'label', '<xml><getter>expCompany</getter></xml>', '200', '0', NULL, 1, 10, '---', 0, 0),
(42, 3, 'hs_hr_emp_work_experience.eexp_jobtit', 'Job Title', 'expJobTitle', 'false', NULL, NULL, 'label', '<xml><getter>expJobTitle</getter></xml>', '200', '0', NULL, 1, 10, '---', 0, 0),
(43, 3, 'hs_hr_emp_work_experience.eexp_from_date', 'From', 'expFrom', 'false', NULL, NULL, 'labelDate', '<xml><getter>expFrom</getter></xml>', '100', '0', NULL, 1, 10, '---', 0, 0),
(44, 3, 'hs_hr_emp_work_experience.eexp_to_date', 'To', 'expTo', 'false', NULL, NULL, 'labelDate', '<xml><getter>expTo</getter></xml>', '100', '0', NULL, 1, 10, '---', 0, 0),
(45, 3, 'hs_hr_emp_work_experience.eexp_comments', 'Comment', 'expComment', 'false', NULL, NULL, 'label', '<xml><getter>expComment</getter></xml>', '200', '0', NULL, 1, 10, '---', 0, 0),
(47, 3, 'ohrm_education.name', 'Level', 'eduProgram', 'false', NULL, NULL, 'label', '<xml><getter>eduProgram</getter></xml>', '200', '0', NULL, 1, 11, '---', 0, 0),
(48, 3, 'ohrm_emp_education.year', 'Year', 'eduYear', 'false', NULL, NULL, 'label', '<xml><getter>eduYear</getter></xml>', '100', '0', NULL, 1, 11, '---', 0, 0),
(49, 3, 'ohrm_emp_education.score', 'Score', 'eduGPAOrScore', 'false', NULL, NULL, 'label', '<xml><getter>eduGPAOrScore</getter></xml>', '80', '0', NULL, 1, 11, '---', 0, 0),
(52, 3, 'ohrm_skill.name', 'Skill', 'skill', 'false', NULL, NULL, 'label', '<xml><getter>skill</getter></xml>', '200', '0', NULL, 1, 12, '---', 0, 0),
(53, 3, 'hs_hr_emp_skill.years_of_exp', 'Years of Experience', 'skillYearsOfExperience', 'false', NULL, NULL, 'label', '<xml><getter>skillYearsOfExperience</getter></xml>', '135', '0', NULL, 1, 12, '---', 0, 0),
(54, 3, 'hs_hr_emp_skill.comments', 'Comments', 'skillComments', 'false', NULL, NULL, 'label', '<xml><getter>skillComments</getter></xml>', '200', '0', NULL, 1, 12, '---', 0, 0),
(55, 3, 'ohrm_language.name', 'Language', 'langName', 'false', NULL, NULL, 'label', '<xml><getter>langName</getter></xml>', '200', '0', NULL, 1, 13, '---', 0, 0),
(57, 3, 'CASE hs_hr_emp_language.competency WHEN 1 THEN "Poor" WHEN 2 THEN "Basic" WHEN 3 THEN "Good" WHEN 4 THEN "Mother Tongue" END', 'Competency', 'langCompetency', 'false', NULL, NULL, 'label', '<xml><getter>langCompetency</getter></xml>', '130', '0', NULL, 1, 13, '---', 0, 0),
(58, 3, 'hs_hr_emp_language.comments', 'Comments', 'langComments', 'false', NULL, NULL, 'label', '<xml><getter>langComments</getter></xml>', '200', '0', NULL, 1, 13, '---', 0, 0),
(59, 3, 'ohrm_license.name', 'License Type', 'empLicenseType', 'false', NULL, NULL, 'label', '<xml><getter>empLicenseType</getter></xml>', '200', '0', NULL, 1, 14, '---', 0, 0),
(60, 3, 'ohrm_emp_license.license_issued_date', 'Issued Date', 'empLicenseIssuedDate', 'false', NULL, NULL, 'labelDate', '<xml><getter>empLicenseIssuedDate</getter></xml>', '100', '0', NULL, 1, 14, '---', 0, 0),
(61, 3, 'ohrm_emp_license.license_expiry_date', 'Expiry Date', 'empLicenseExpiryDate', 'false', NULL, NULL, 'labelDate', '<xml><getter>empLicenseExpiryDate</getter></xml>', '100', '0', NULL, 1, 14, '---', 0, 0),
(62, 3, 'supervisor.emp_firstname', 'First Name', 'supervisorFirstName', 'false', NULL, NULL, 'label', '<xml><getter>supervisorFirstName</getter></xml>', '200', '0', NULL, 1, 9, '---', 0, 0),
(63, 3, 'subordinate.emp_firstname', 'First Name', 'subordinateFirstName', 'false', NULL, NULL, 'label', '<xml><getter>subordinateFirstName</getter></xml>', '200', '0', NULL, 1, 8, '---', 0, 0),
(64, 3, 'supervisor.emp_lastname', 'Last Name', 'supervisorLastName', 'false', NULL, NULL, 'label', '<xml><getter>supervisorLastName</getter></xml>', '200', '0', NULL, 1, 9, '---', 0, 0),
(65, 3, 'ohrm_pay_grade.name', 'Pay Grade', 'salPayGrade', 'false', NULL, NULL, 'label', '<xml><getter>salPayGrade</getter></xml>', '200', '0', NULL, 1, 7, '---', 0, 0),
(66, 3, 'hs_hr_emp_basicsalary.salary_component', 'Salary Component', 'salSalaryComponent', 'false', NULL, NULL, 'label', '<xml><getter>salSalaryComponent</getter></xml>', '200', '0', NULL, 1, 7, '---', 0, 0),
(67, 3, 'hs_hr_emp_basicsalary.ebsal_basic_salary', 'Amount', 'salAmount', 'false', NULL, NULL, 'label', '<xml><getter>salAmount</getter></xml>', '200', '0', NULL, 1, 7, '---', 1, 0),
(68, 3, 'hs_hr_emp_basicsalary.comments', 'Comments', 'salComments', 'false', NULL, NULL, 'label', '<xml><getter>salComments</getter></xml>', '200', '0', NULL, 1, 7, '---', 0, 0),
(69, 3, 'hs_hr_payperiod.payperiod_name', 'Pay Frequency', 'salPayFrequency', 'false', NULL, NULL, 'label', '<xml><getter>salPayFrequency</getter></xml>', '200', '0', NULL, 1, 7, '---', 0, 0),
(70, 3, 'hs_hr_currency_type.currency_name', 'Currency', 'salCurrency', 'false', NULL, NULL, 'label', '<xml><getter>salCurrency</getter></xml>', '200', '0', NULL, 1, 7, '---', 0, 0),
(71, 3, 'hs_hr_emp_directdebit.dd_account', 'Direct Deposit Account Number', 'ddAccountNumber', 'false', NULL, NULL, 'label', '<xml><getter>ddAccountNumber</getter></xml>', '200', '0', NULL, 1, 7, '---', 0, 0),
(72, 3, 'hs_hr_emp_directdebit.dd_account_type', 'Direct Deposit Account Type', 'ddAccountType', 'false', NULL, NULL, 'label', '<xml><getter>ddAccountType</getter></xml>', '200', '0', NULL, 1, 7, '---', 0, 0),
(73, 3, 'hs_hr_emp_directdebit.dd_routing_num', 'Direct Deposit Routing Number', 'ddRoutingNumber', 'false', NULL, NULL, 'label', '<xml><getter>ddRoutingNumber</getter></xml>', '200', '0', NULL, 1, 7, '---', 0, 0),
(74, 3, 'hs_hr_emp_directdebit.dd_amount', 'Direct Deposit Amount', 'ddAmount', 'false', NULL, NULL, 'label', '<xml><getter>ddAmount</getter></xml>', '200', '0', NULL, 1, 7, '---', 0, 0),
(75, 3, 'hs_hr_emp_contract_extend.econ_extend_start_date', 'Contract Start Date', 'empContStartDate', 'false', NULL, NULL, 'labelDate', '<xml><getter>empContStartDate</getter></xml>', '200', '0', NULL, 1, 6, '---', 0, 0),
(76, 3, 'hs_hr_emp_contract_extend.econ_extend_end_date', 'Contract End Date', 'empContEndDate', 'false', NULL, NULL, 'labelDate', '<xml><getter>empContEndDate</getter></xml>', '200', '0', NULL, 1, 6, '---', 0, 0),
(77, 3, 'ohrm_job_title.job_title', 'Job Title', 'empJobTitle', 'false', NULL, NULL, 'label', '<xml><getter>empJobTitle</getter></xml>', '200', '0', NULL, 1, 6, '---', 0, 0),
(78, 3, 'ohrm_employment_status.name', 'Employment Status', 'empEmploymentStatus', 'false', NULL, NULL, 'label', '<xml><getter>empEmploymentStatus</getter></xml>', '200', '0', NULL, 1, 6, '---', 0, 0),
(80, 3, 'ohrm_job_category.name', 'Job Category', 'empJobCategory', 'false', NULL, NULL, 'label', '<xml><getter>empJobCategory</getter></xml>', '200', '0', NULL, 1, 6, '---', 0, 0),
(81, 3, 'hs_hr_employee.joined_date', 'Joined Date', 'empJoinedDate', 'false', NULL, NULL, 'labelDate', '<xml><getter>empJoinedDate</getter></xml>', '100', '0', NULL, 1, 6, '---', 0, 0),
(82, 3, 'ohrm_subunit.name', 'Sub Unit', 'empSubUnit', 'false', NULL, NULL, 'label', '<xml><getter>empSubUnit</getter></xml>', '200', '0', NULL, 1, 6, '---', 0, 0),
(83, 3, 'ohrm_location.name', 'Location', 'empLocation', 'false', NULL, NULL, 'label', '<xml><getter>empLocation</getter></xml>', '200', '0', NULL, 1, 6, '---', 0, 0),
(84, 3, 'hs_hr_emp_passport.ep_passport_num', 'Number', 'empPassportNo', 'false', NULL, NULL, 'label', '<xml><getter>empPassportNo</getter></xml>', '200', '0', NULL, 1, 5, '---', 0, 0),
(85, 3, 'hs_hr_emp_passport.ep_passportissueddate', 'Issued Date', 'empPassportIssuedDate', 'false', NULL, NULL, 'labelDate', '<xml><getter>empPassportIssuedDate</getter></xml>', '100', '0', NULL, 1, 5, '---', 0, 0),
(86, 3, 'hs_hr_emp_passport.ep_passportexpiredate', 'Expiry Date', 'empPassportExpiryDate', 'false', NULL, NULL, 'labelDate', '<xml><getter>empPassportExpiryDate</getter></xml>', '100', '0', NULL, 1, 5, '---', 0, 0),
(87, 3, 'hs_hr_emp_passport.ep_i9_status', 'Eligibility Status', 'empPassportEligibleStatus', 'false', NULL, NULL, 'label', '<xml><getter>empPassportEligibleStatus</getter></xml>', '200', '0', NULL, 1, 5, '---', 0, 0),
(88, 3, 'hs_hr_emp_passport.cou_code', 'Issued By', 'empPassportIssuedBy', 'false', NULL, NULL, 'label', '<xml><getter>empPassportIssuedBy</getter></xml>', '200', '0', NULL, 1, 5, '---', 0, 0),
(89, 3, 'hs_hr_emp_passport.ep_i9_review_date', 'Eligibility Review Date', 'empPassportEligibleReviewDate', 'false', NULL, NULL, 'labelDate', '<xml><getter>empPassportEligibleReviewDate</getter></xml>', '200', '0', NULL, 1, 5, '---', 0, 0),
(90, 3, 'hs_hr_emp_passport.ep_comments', 'Comments', 'empPassportComments', 'false', NULL, NULL, 'label', '<xml><getter>empPassportComments</getter></xml>', '200', '0', NULL, 1, 5, '---', 0, 0),
(91, 3, 'subordinate.emp_lastname', 'Last Name', 'subordinateLastName', 'false', NULL, NULL, 'label', '<xml><getter>subordinateLastName</getter></xml>', '200', '0', NULL, 1, 8, '---', 0, 0),
(92, 3, 'CASE hs_hr_emp_language.fluency WHEN 1 THEN "Writing" WHEN 2 THEN "Speaking" WHEN 3 THEN "Reading" END', 'Fluency', 'langFluency', 'false', NULL, NULL, 'label', '<xml><getter>langFluency</getter></xml>', '200', '0', NULL, 1, 13, '---', 0, 0),
(93, 3, 'supervisor_reporting_method.reporting_method_name', 'Reporting Method', 'supReportingMethod', 'false', NULL, NULL, 'label', '<xml><getter>supReportingMethod</getter></xml>', '200', '0', NULL, 1, 9, '---', 0, 0),
(94, 3, 'subordinate_reporting_method.reporting_method_name', 'Reporting Method', 'subReportingMethod', 'false', NULL, NULL, 'label', '<xml><getter>subReportingMethod</getter></xml>', '200', '0', NULL, 1, 8, '---', 0, 0),
(95, 3, 'CASE hs_hr_emp_passport.ep_passport_type_flg WHEN 1 THEN "Passport" WHEN 2 THEN "Visa" END', 'Document Type', 'documentType', 'false', NULL, NULL, 'label', '<xml><getter>documentType</getter></xml>', '200', '0', NULL, 1, 5, '---', 0, 0),
(97, 3, 'hs_hr_employee.emp_other_id', 'Other Id', 'otherId', 'false', NULL, NULL, 'label', '<xml><getter>otherId</getter></xml>', '100', '0', NULL, 0, 1, '---', 0, 0),
(98, 3, 'hs_hr_emp_emergency_contacts.eec_seqno', 'ecSeqNo', 'ecSeqNo', 'false', NULL, NULL, 'label', '<xml><getter>ecMobile</getter></xml>', '100', '0', NULL, 1, 3, '---', 0, 1),
(99, 3, 'hs_hr_emp_dependents.ed_seqno', 'SeqNo', 'edSeqNo', 'false', NULL, NULL, 'label', '<xml><getter>ecMobile</getter></xml>', '100', '0', NULL, 1, 4, '---', 0, 1),
(100, 3, 'hs_hr_emp_passport.ep_seqno', 'SeqNo', 'epSeqNo', 'false', NULL, NULL, 'label', '<xml><getter>ecMobile</getter></xml>', '100', '0', NULL, 1, 5, '---', 0, 1),
(101, 3, 'hs_hr_emp_basicsalary.id', 'salaryId', 'salaryId', 'false', NULL, NULL, 'label', '<xml><getter>ecMobile</getter></xml>', '100', '0', NULL, 1, 7, '---', 0, 1),
(102, 3, 'subordinate.emp_number', 'subordinateId', 'subordinateId', 'false', NULL, NULL, 'label', '<xml><getter>ecMobile</getter></xml>', '100', '0', NULL, 1, 8, '---', 0, 1),
(103, 3, 'supervisor.emp_number', 'supervisorId', 'supervisorId', 'false', NULL, NULL, 'label', '<xml><getter>ecMobile</getter></xml>', '100', '0', NULL, 1, 9, '---', 0, 1),
(104, 3, 'hs_hr_emp_work_experience.eexp_seqno', 'workExpSeqNo', 'workExpSeqNo', 'false', NULL, NULL, 'label', '<xml><getter>ecMobile</getter></xml>', '100', '0', NULL, 1, 10, '---', 0, 1),
(105, 3, 'ohrm_emp_education.education_id', 'empEduCode', 'empEduCode', 'false', NULL, NULL, 'label', '<xml><getter>ecMobile</getter></xml>', '100', '0', NULL, 1, 11, '---', 0, 1),
(106, 3, 'hs_hr_emp_skill.skill_id', 'empSkillCode', 'empSkillCode', 'false', NULL, NULL, 'label', '<xml><getter>ecMobile</getter></xml>', '100', '0', NULL, 1, 12, '---', 0, 1),
(107, 3, 'hs_hr_emp_language.lang_id', 'empLangCode', 'empLangCode', 'false', NULL, NULL, 'label', '<xml><getter>ecMobile</getter></xml>', '100', '0', NULL, 1, 13, '---', 0, 1),
(108, 3, 'hs_hr_emp_language.fluency', 'empLangType', 'empLangType', 'false', NULL, NULL, 'label', '<xml><getter>ecMobile</getter></xml>', '100', '0', NULL, 1, 13, '---', 0, 1),
(109, 3, 'ohrm_emp_license.license_id', 'empLicenseCode', 'empLicenseCode', 'false', NULL, NULL, 'label', '<xml><getter>ecMobile</getter></xml>', '100', '0', NULL, 1, 14, '---', 0, 1),
(110, 3, 'hs_hr_emp_member_detail.membship_code', 'membershipCode', 'membershipCode', 'false', NULL, NULL, 'label', '<xml><getter>ecMobile</getter></xml>', '100', '0', NULL, 1, 15, '---', 0, 1),
(112, 3, 'ROUND(DATEDIFF(hs_hr_emp_work_experience.eexp_to_date, hs_hr_emp_work_experience.eexp_from_date)/365,1)', 'Duration', 'expDuration', 'false', NULL, NULL, 'label', '<xml><getter>expDuration</getter></xml>', '100', '0', NULL, 1, 10, '---', 0, 0),
(113, 3, 'ohrm_emp_termination.termination_date', 'Termination Date', 'terminationDate', 'false', NULL, NULL, 'labelDate', '<xml><getter>terminationDate</getter></xml>', '100', '0', NULL, 1, 6, '---', 0, 0),
(114, 3, 'ohrm_emp_termination_reason.name', 'Termination Reason', 'terminationReason', 'false', NULL, NULL, 'label', '<xml><getter>terminationReason</getter></xml>', '100', '0', NULL, 1, 6, '---', 0, 0),
(115, 3, 'ohrm_emp_education.institute', 'Institute', 'getInstitute', 'false', NULL, NULL, 'label', '<xml><getter>getInstitute</getter></xml>', '80', '0', NULL, 1, 11, '---', 0, 0),
(116, 3, 'ohrm_emp_education.major', 'Major/Specialization', 'getMajor', 'false', NULL, NULL, 'label', '<xml><getter>getMajor</getter></xml>', '80', '0', NULL, 1, 11, '---', 0, 0),
(117, 3, 'ohrm_emp_education.start_date', 'Start Date', 'getStartDate', 'false', NULL, NULL, 'labelDate', '<xml><getter>getStartDate</getter></xml>', '80', '0', NULL, 1, 11, '---', 0, 0),
(118, 3, 'ohrm_emp_education.end_date', 'End Date', 'getEndDate', 'false', NULL, NULL, 'labelDate', '<xml><getter>getEndDate</getter></xml>', '80', '0', NULL, 1, 11, '---', 0, 0),
(119, 3, 'ohrm_emp_license.license_no', 'License Number', 'getLicenseNo', 'false', NULL, NULL, 'label', '<xml><getter>getLicenseNo</getter></xml>', '200', '0', NULL, 1, 14, '---', 0, 0),
(120, 3, 'ohrm_emp_termination.note', 'Termination Note', 'getNote', 'false', NULL, NULL, 'label', '<xml><getter>getNote</getter></xml>', '100', '0', NULL, 1, 6, '---', 0, 0),
(121, 3, 'hs_hr_employee.custom1', 'Tel', 'customField1', 'false', NULL, NULL, 'label', '<xml><getter>customField1</getter></xml>', '200', '1', NULL, 0, 16, '---', 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_display_field_group`
--

CREATE TABLE IF NOT EXISTS `ohrm_display_field_group` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `report_group_id` bigint(20) NOT NULL,
  `name` varchar(255) NOT NULL,
  `is_list` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `report_group_id` (`report_group_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=17 ;

--
-- Contenu de la table `ohrm_display_field_group`
--

INSERT INTO `ohrm_display_field_group` (`id`, `report_group_id`, `name`, `is_list`) VALUES
(1, 3, 'Personal', 0),
(2, 3, 'Contact Details', 0),
(3, 3, 'Emergency Contacts', 1),
(4, 3, 'Dependents', 1),
(5, 3, 'Immigration', 1),
(6, 3, 'Job', 0),
(7, 3, 'Salary', 1),
(8, 3, 'Subordinates', 1),
(9, 3, 'Supervisors', 1),
(10, 3, 'Work Experience', 1),
(11, 3, 'Education', 1),
(12, 3, 'Skills', 1),
(13, 3, 'Languages', 1),
(14, 3, 'License', 1),
(15, 3, 'Memberships', 1),
(16, 3, 'Custom Fields', 0);

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_education`
--

CREATE TABLE IF NOT EXISTS `ohrm_education` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_email`
--

CREATE TABLE IF NOT EXISTS `ohrm_email` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `ohrm_email_name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Contenu de la table `ohrm_email`
--

INSERT INTO `ohrm_email` (`id`, `name`) VALUES
(1, 'leave.apply'),
(3, 'leave.approve'),
(2, 'leave.assign'),
(4, 'leave.cancel'),
(6, 'leave.change'),
(5, 'leave.reject');

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_email_configuration`
--

CREATE TABLE IF NOT EXISTS `ohrm_email_configuration` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `mail_type` varchar(50) DEFAULT NULL,
  `sent_as` varchar(250) NOT NULL,
  `sendmail_path` varchar(250) DEFAULT NULL,
  `smtp_host` varchar(250) DEFAULT NULL,
  `smtp_port` int(10) DEFAULT NULL,
  `smtp_username` varchar(250) DEFAULT NULL,
  `smtp_password` varchar(250) DEFAULT NULL,
  `smtp_auth_type` varchar(50) DEFAULT NULL,
  `smtp_security_type` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_email_notification`
--

CREATE TABLE IF NOT EXISTS `ohrm_email_notification` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `is_enable` int(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Contenu de la table `ohrm_email_notification`
--

INSERT INTO `ohrm_email_notification` (`id`, `name`, `is_enable`) VALUES
(1, 'Leave Applications', 0),
(2, 'Leave Assignments', 0),
(3, 'Leave Approvals', 0),
(4, 'Leave Cancellations', 0),
(5, 'Leave Rejections', 0);

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_email_processor`
--

CREATE TABLE IF NOT EXISTS `ohrm_email_processor` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `email_id` int(6) NOT NULL,
  `class_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `email_id` (`email_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Contenu de la table `ohrm_email_processor`
--

INSERT INTO `ohrm_email_processor` (`id`, `email_id`, `class_name`) VALUES
(1, 1, 'LeaveEmailProcessor'),
(2, 2, 'LeaveEmailProcessor'),
(3, 3, 'LeaveEmailProcessor'),
(4, 4, 'LeaveEmailProcessor'),
(5, 5, 'LeaveEmailProcessor'),
(6, 6, 'LeaveChangeMailProcessor');

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_email_subscriber`
--

CREATE TABLE IF NOT EXISTS `ohrm_email_subscriber` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `notification_id` int(6) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `notification_id` (`notification_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_email_template`
--

CREATE TABLE IF NOT EXISTS `ohrm_email_template` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `email_id` int(6) NOT NULL,
  `locale` varchar(20) DEFAULT NULL,
  `performer_role` varchar(50) DEFAULT NULL,
  `recipient_role` varchar(50) DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `body` text,
  PRIMARY KEY (`id`),
  KEY `email_id` (`email_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=16 ;

--
-- Contenu de la table `ohrm_email_template`
--

INSERT INTO `ohrm_email_template` (`id`, `email_id`, `locale`, `performer_role`, `recipient_role`, `subject`, `body`) VALUES
(1, 1, 'en_US', NULL, 'supervisor', 'orangehrmLeavePlugin/modules/leave/templates/mail/en_US/apply/leaveApplicationSubject.txt', 'orangehrmLeavePlugin/modules/leave/templates/mail/en_US/apply/leaveApplicationBody.txt'),
(2, 1, 'en_US', NULL, 'subscriber', 'orangehrmLeavePlugin/modules/leave/templates/mail/en_US/apply/leaveApplicationSubject.txt', 'orangehrmLeavePlugin/modules/leave/templates/mail/en_US/apply/leaveApplicationSubscriberBody.txt'),
(3, 3, 'en_US', NULL, 'ess', 'orangehrmLeavePlugin/modules/leave/templates/mail/en_US/approve/leaveApprovalSubject.txt', 'orangehrmLeavePlugin/modules/leave/templates/mail/en_US/approve/leaveApprovalBody.txt'),
(4, 3, 'en_US', NULL, 'subscriber', 'orangehrmLeavePlugin/modules/leave/templates/mail/en_US/approve/leaveApprovalSubscriberSubject.txt', 'orangehrmLeavePlugin/modules/leave/templates/mail/en_US/approve/leaveApprovalSubscriberBody.txt'),
(5, 2, 'en_US', NULL, 'ess', 'orangehrmLeavePlugin/modules/leave/templates/mail/en_US/assign/leaveAssignmentSubject.txt', 'orangehrmLeavePlugin/modules/leave/templates/mail/en_US/assign/leaveAssignmentBody.txt'),
(6, 2, 'en_US', NULL, 'supervisor', 'orangehrmLeavePlugin/modules/leave/templates/mail/en_US/assign/leaveAssignmentSubjectForSupervisors.txt', 'orangehrmLeavePlugin/modules/leave/templates/mail/en_US/assign/leaveAssignmentBodyForSupervisors.txt'),
(7, 2, 'en_US', NULL, 'subscriber', 'orangehrmLeavePlugin/modules/leave/templates/mail/en_US/assign/leaveAssignmentSubscriberSubject.txt', 'orangehrmLeavePlugin/modules/leave/templates/mail/en_US/assign/leaveAssignmentSubscriberBody.txt'),
(8, 4, 'en_US', 'ess', 'supervisor', 'orangehrmLeavePlugin/modules/leave/templates/mail/en_US/cancel/leaveEmployeeCancellationSubject.txt', 'orangehrmLeavePlugin/modules/leave/templates/mail/en_US/cancel/leaveEmployeeCancellationBody.txt'),
(9, 4, 'en_US', 'ess', 'subscriber', 'orangehrmLeavePlugin/modules/leave/templates/mail/en_US/cancel/leaveEmployeeCancellationSubscriberSubject.txt', 'orangehrmLeavePlugin/modules/leave/templates/mail/en_US/cancel/leaveEmployeeCancellationSubscriberBody.txt'),
(10, 4, 'en_US', NULL, 'ess', 'orangehrmLeavePlugin/modules/leave/templates/mail/en_US/cancel/leaveCancellationSubject.txt', 'orangehrmLeavePlugin/modules/leave/templates/mail/en_US/cancel/leaveCancellationBody.txt'),
(11, 4, 'en_US', NULL, 'subscriber', 'orangehrmLeavePlugin/modules/leave/templates/mail/en_US/cancel/leaveCancellationSubscriberSubject.txt', 'orangehrmLeavePlugin/modules/leave/templates/mail/en_US/cancel/leaveCancellationSubscriberBody.txt'),
(12, 5, 'en_US', NULL, 'ess', 'orangehrmLeavePlugin/modules/leave/templates/mail/en_US/reject/leaveRejectionSubject.txt', 'orangehrmLeavePlugin/modules/leave/templates/mail/en_US/reject/leaveRejectionBody.txt'),
(13, 5, 'en_US', NULL, 'subscriber', 'orangehrmLeavePlugin/modules/leave/templates/mail/en_US/reject/leaveRejectionSubscriberSubject.txt', 'orangehrmLeavePlugin/modules/leave/templates/mail/en_US/reject/leaveRejectionSubscriberBody.txt'),
(14, 6, 'en_US', NULL, 'ess', 'orangehrmLeavePlugin/modules/leave/templates/mail/en_US/change/leaveChangeSubject.txt', 'orangehrmLeavePlugin/modules/leave/templates/mail/en_US/change/leaveChangeBody.txt'),
(15, 6, 'en_US', NULL, 'subscriber', 'orangehrmLeavePlugin/modules/leave/templates/mail/en_US/change/leaveChangeSubscriberSubject.txt', 'orangehrmLeavePlugin/modules/leave/templates/mail/en_US/change/leaveChangeSubscriberBody.txt');

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_employee_work_shift`
--

CREATE TABLE IF NOT EXISTS `ohrm_employee_work_shift` (
  `work_shift_id` int(11) NOT NULL AUTO_INCREMENT,
  `emp_number` int(11) NOT NULL,
  PRIMARY KEY (`work_shift_id`,`emp_number`),
  KEY `emp_number` (`emp_number`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_employment_status`
--

CREATE TABLE IF NOT EXISTS `ohrm_employment_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_emp_education`
--

CREATE TABLE IF NOT EXISTS `ohrm_emp_education` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `emp_number` int(11) NOT NULL,
  `education_id` int(11) NOT NULL,
  `institute` varchar(100) DEFAULT NULL,
  `major` varchar(100) DEFAULT NULL,
  `year` decimal(4,0) DEFAULT NULL,
  `score` varchar(25) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `emp_number` (`emp_number`),
  KEY `education_id` (`education_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_emp_license`
--

CREATE TABLE IF NOT EXISTS `ohrm_emp_license` (
  `emp_number` int(11) NOT NULL,
  `license_id` int(11) NOT NULL,
  `license_no` varchar(50) DEFAULT NULL,
  `license_issued_date` date DEFAULT NULL,
  `license_expiry_date` date DEFAULT NULL,
  PRIMARY KEY (`emp_number`,`license_id`),
  KEY `license_id` (`license_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_emp_reporting_method`
--

CREATE TABLE IF NOT EXISTS `ohrm_emp_reporting_method` (
  `reporting_method_id` int(7) NOT NULL AUTO_INCREMENT,
  `reporting_method_name` varchar(100) NOT NULL,
  PRIMARY KEY (`reporting_method_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Contenu de la table `ohrm_emp_reporting_method`
--

INSERT INTO `ohrm_emp_reporting_method` (`reporting_method_id`, `reporting_method_name`) VALUES
(1, 'Direct'),
(2, 'Indirect');

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_emp_termination`
--

CREATE TABLE IF NOT EXISTS `ohrm_emp_termination` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `emp_number` int(4) DEFAULT NULL,
  `reason_id` int(4) DEFAULT NULL,
  `termination_date` date NOT NULL,
  `note` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `reason_id` (`reason_id`),
  KEY `emp_number` (`emp_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_emp_termination_reason`
--

CREATE TABLE IF NOT EXISTS `ohrm_emp_termination_reason` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Contenu de la table `ohrm_emp_termination_reason`
--

INSERT INTO `ohrm_emp_termination_reason` (`id`, `name`) VALUES
(1, 'Other'),
(2, 'Retired'),
(3, 'Contract Not Renewed'),
(4, 'Resigned - Company Requested'),
(5, 'Resigned - Self Proposed'),
(6, 'Resigned'),
(7, 'Deceased'),
(8, 'Physically Disabled/Compensated'),
(9, 'Laid-off'),
(10, 'Dismissed');

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_filter_field`
--

CREATE TABLE IF NOT EXISTS `ohrm_filter_field` (
  `filter_field_id` bigint(20) NOT NULL,
  `report_group_id` bigint(20) NOT NULL,
  `name` varchar(255) NOT NULL,
  `where_clause_part` mediumtext NOT NULL,
  `filter_field_widget` varchar(255) DEFAULT NULL,
  `condition_no` int(20) NOT NULL,
  `required` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`filter_field_id`),
  KEY `report_group_id` (`report_group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `ohrm_filter_field`
--

INSERT INTO `ohrm_filter_field` (`filter_field_id`, `report_group_id`, `name`, `where_clause_part`, `filter_field_widget`, `condition_no`, `required`) VALUES
(1, 1, 'project_name', 'ohrm_project.project_id', 'ohrmWidgetProjectList', 2, 'true'),
(2, 1, 'activity_show_deleted', 'ohrm_project_activity.is_deleted', 'ohrmWidgetInputCheckbox', 2, 'false'),
(3, 1, 'project_date_range', 'date', 'ohrmWidgetDateRange', 1, 'false'),
(4, 1, 'employee', 'hs_hr_employee.emp_number', 'ohrmReportWidgetEmployeeListAutoFill', 2, 'true'),
(5, 1, 'activity_name', 'ohrm_project_activity.activity_id', 'ohrmWidgetProjectActivityList', 2, 'true'),
(6, 1, 'project_name', 'ohrm_project.project_id', 'ohrmWidgetProjectListWithAllOption', 2, 'true'),
(7, 1, 'only_include_approved_timesheets', 'ohrm_timesheet.state', 'ohrmWidgetApprovedTimesheetInputCheckBox', 2, NULL),
(8, 3, 'employee_name', 'hs_hr_employee.emp_number', 'ohrmReportWidgetEmployeeListAutoFill', 1, NULL),
(9, 3, 'pay_grade', 'hs_hr_emp_basicsalary.sal_grd_code', 'ohrmReportWidgetPayGradeDropDown', 1, NULL),
(10, 3, 'education', 'ohrm_emp_education.education_id', 'ohrmReportWidgetEducationtypeDropDown', 1, NULL),
(11, 3, 'employment_status', 'hs_hr_employee.emp_status', 'ohrmWidgetEmploymentStatusList', 1, NULL),
(12, 3, 'service_period', 'datediff(current_date(), hs_hr_employee.joined_date)/365', 'ohrmReportWidgetServicePeriod', 1, NULL),
(13, 3, 'joined_date', 'hs_hr_employee.joined_date', 'ohrmReportWidgetJoinedDate', 1, NULL),
(14, 3, 'job_title', 'hs_hr_employee.job_title_code', 'ohrmWidgetJobTitleList', 1, NULL),
(15, 3, 'language', 'hs_hr_emp_language.lang_id', 'ohrmReportWidgetLanguageDropDown', 1, NULL),
(16, 3, 'skill', 'hs_hr_emp_skill.skill_id', 'ohrmReportWidgetSkillDropDown', 1, NULL),
(17, 3, 'age_group', 'datediff(current_date(), hs_hr_employee.emp_birthday)/365', 'ohrmReportWidgetAgeGroup', 1, NULL),
(18, 3, 'sub_unit', 'hs_hr_employee.work_station', 'ohrmWidgetSubDivisionList', 1, NULL),
(19, 3, 'gender', 'hs_hr_employee.emp_gender', 'ohrmReportWidgetGenderDropDown', 1, NULL),
(20, 3, 'location', 'ohrm_location.id', 'ohrmReportWidgetOperationalCountryLocationDropDown', 1, NULL),
(21, 1, 'is_deleted', 'ohrm_project_activity.is_deleted', '', 2, NULL),
(22, 3, 'include', 'hs_hr_employee.termination_id', 'ohrmReportWidgetIncludedEmployeesDropDown', 1, 'true');

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_group_field`
--

CREATE TABLE IF NOT EXISTS `ohrm_group_field` (
  `group_field_id` bigint(20) NOT NULL,
  `name` varchar(255) NOT NULL,
  `group_by_clause` mediumtext NOT NULL,
  `group_field_widget` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`group_field_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `ohrm_group_field`
--

INSERT INTO `ohrm_group_field` (`group_field_id`, `name`, `group_by_clause`, `group_field_widget`) VALUES
(1, 'activity id', 'GROUP BY ohrm_project_activity.activity_id', NULL),
(2, 'employee number', 'GROUP BY hs_hr_employee.emp_number', NULL);

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_holiday`
--

CREATE TABLE IF NOT EXISTS `ohrm_holiday` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `description` text,
  `date` date DEFAULT NULL,
  `recurring` tinyint(3) unsigned DEFAULT '0',
  `length` int(10) unsigned DEFAULT NULL,
  `operational_country_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_ohrm_holiday_ohrm_operational_country` (`operational_country_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_home_page`
--

CREATE TABLE IF NOT EXISTS `ohrm_home_page` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_role_id` int(11) NOT NULL,
  `action` varchar(255) DEFAULT NULL,
  `enable_class` varchar(100) DEFAULT NULL,
  `priority` int(11) NOT NULL DEFAULT '0' COMMENT 'lowest priority 0',
  PRIMARY KEY (`id`),
  KEY `user_role_id` (`user_role_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Contenu de la table `ohrm_home_page`
--

INSERT INTO `ohrm_home_page` (`id`, `user_role_id`, `action`, `enable_class`, `priority`) VALUES
(1, 1, 'dashboard/index', NULL, 15),
(2, 2, 'dashboard/index', NULL, 5);

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_job_candidate`
--

CREATE TABLE IF NOT EXISTS `ohrm_job_candidate` (
  `id` int(13) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `middle_name` varchar(30) DEFAULT NULL,
  `last_name` varchar(30) NOT NULL,
  `email` varchar(100) NOT NULL,
  `contact_number` varchar(30) DEFAULT NULL,
  `status` int(4) NOT NULL,
  `comment` text,
  `mode_of_application` int(4) NOT NULL,
  `date_of_application` date NOT NULL,
  `cv_file_id` int(13) DEFAULT NULL,
  `cv_text_version` text,
  `keywords` varchar(255) DEFAULT NULL,
  `added_person` int(13) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `added_person` (`added_person`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_job_candidate_attachment`
--

CREATE TABLE IF NOT EXISTS `ohrm_job_candidate_attachment` (
  `id` int(13) NOT NULL AUTO_INCREMENT,
  `candidate_id` int(13) NOT NULL,
  `file_name` varchar(200) NOT NULL,
  `file_type` varchar(200) DEFAULT NULL,
  `file_size` int(11) NOT NULL,
  `file_content` mediumblob,
  `attachment_type` int(4) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `candidate_id` (`candidate_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_job_candidate_history`
--

CREATE TABLE IF NOT EXISTS `ohrm_job_candidate_history` (
  `id` int(13) NOT NULL AUTO_INCREMENT,
  `candidate_id` int(13) NOT NULL,
  `vacancy_id` int(13) DEFAULT NULL,
  `candidate_vacancy_name` varchar(255) DEFAULT NULL,
  `interview_id` int(13) DEFAULT NULL,
  `action` int(4) NOT NULL,
  `performed_by` int(13) DEFAULT NULL,
  `performed_date` datetime NOT NULL,
  `note` text,
  `interviewers` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `candidate_id` (`candidate_id`),
  KEY `vacancy_id` (`vacancy_id`),
  KEY `interview_id` (`interview_id`),
  KEY `performed_by` (`performed_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_job_candidate_vacancy`
--

CREATE TABLE IF NOT EXISTS `ohrm_job_candidate_vacancy` (
  `id` int(13) DEFAULT NULL,
  `candidate_id` int(13) NOT NULL,
  `vacancy_id` int(13) NOT NULL,
  `status` varchar(100) NOT NULL,
  `applied_date` date NOT NULL,
  PRIMARY KEY (`candidate_id`,`vacancy_id`),
  UNIQUE KEY `id` (`id`),
  KEY `vacancy_id` (`vacancy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_job_category`
--

CREATE TABLE IF NOT EXISTS `ohrm_job_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Contenu de la table `ohrm_job_category`
--

INSERT INTO `ohrm_job_category` (`id`, `name`) VALUES
(1, 'Officials and Managers'),
(2, 'Ingénieurs'),
(3, 'Techniciens'),
(4, 'Sales Workers'),
(5, 'Operatives'),
(6, 'Office and Clerical Workers'),
(7, 'Craft Workers'),
(8, 'Service Workers'),
(9, 'Laborers and Helpers');

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_job_interview`
--

CREATE TABLE IF NOT EXISTS `ohrm_job_interview` (
  `id` int(13) NOT NULL AUTO_INCREMENT,
  `candidate_vacancy_id` int(13) DEFAULT NULL,
  `candidate_id` int(13) DEFAULT NULL,
  `interview_name` varchar(100) NOT NULL,
  `interview_date` date DEFAULT NULL,
  `interview_time` time DEFAULT NULL,
  `note` text,
  PRIMARY KEY (`id`),
  KEY `candidate_vacancy_id` (`candidate_vacancy_id`),
  KEY `candidate_id` (`candidate_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_job_interview_attachment`
--

CREATE TABLE IF NOT EXISTS `ohrm_job_interview_attachment` (
  `id` int(13) NOT NULL AUTO_INCREMENT,
  `interview_id` int(13) NOT NULL,
  `file_name` varchar(200) NOT NULL,
  `file_type` varchar(200) DEFAULT NULL,
  `file_size` int(11) NOT NULL,
  `file_content` mediumblob,
  `attachment_type` int(4) DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `interview_id` (`interview_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_job_interview_interviewer`
--

CREATE TABLE IF NOT EXISTS `ohrm_job_interview_interviewer` (
  `interview_id` int(13) NOT NULL,
  `interviewer_id` int(13) NOT NULL,
  PRIMARY KEY (`interview_id`,`interviewer_id`),
  KEY `interviewer_id` (`interviewer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_job_specification_attachment`
--

CREATE TABLE IF NOT EXISTS `ohrm_job_specification_attachment` (
  `id` int(13) NOT NULL AUTO_INCREMENT,
  `job_title_id` int(13) NOT NULL,
  `file_name` varchar(200) NOT NULL,
  `file_type` varchar(200) DEFAULT NULL,
  `file_size` int(11) NOT NULL,
  `file_content` mediumblob,
  PRIMARY KEY (`id`),
  KEY `job_title_id` (`job_title_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_job_title`
--

CREATE TABLE IF NOT EXISTS `ohrm_job_title` (
  `id` int(13) NOT NULL AUTO_INCREMENT,
  `job_title` varchar(100) NOT NULL,
  `job_description` varchar(400) DEFAULT NULL,
  `note` varchar(400) DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Contenu de la table `ohrm_job_title`
--

INSERT INTO `ohrm_job_title` (`id`, `job_title`, `job_description`, `note`, `is_deleted`) VALUES
(1, 'Président', 'Président de l''université', '', 0),
(2, 'Sécrétaire générale', 'Sécrétaire générale', 'Sécrétaire générale', 0),
(3, 'Directeur Services communs', 'Directeur Services communs', 'Directeur Services communs', 0),
(4, 'Sous Directeur Services financières ', 'Sous Directeur Services financières', 'Sous Directeur Services financières', 0),
(5, 'Chef Service Budget de l''université', 'Chef Service Budget de l''université', 'Chef Service Budget de l''université', 0),
(6, 'Chef Service Comptabilité', 'Chef Service Comptabilité', 'Chef Service Comptabilité', 0);

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_job_vacancy`
--

CREATE TABLE IF NOT EXISTS `ohrm_job_vacancy` (
  `id` int(13) NOT NULL,
  `job_title_code` int(4) NOT NULL,
  `hiring_manager_id` int(13) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `description` text,
  `no_of_positions` int(13) DEFAULT NULL,
  `status` int(4) NOT NULL,
  `published_in_feed` tinyint(1) NOT NULL DEFAULT '0',
  `defined_time` datetime NOT NULL,
  `updated_time` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `job_title_code` (`job_title_code`),
  KEY `hiring_manager_id` (`hiring_manager_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_job_vacancy_attachment`
--

CREATE TABLE IF NOT EXISTS `ohrm_job_vacancy_attachment` (
  `id` int(13) NOT NULL AUTO_INCREMENT,
  `vacancy_id` int(13) NOT NULL,
  `file_name` varchar(200) NOT NULL,
  `file_type` varchar(200) DEFAULT NULL,
  `file_size` int(11) NOT NULL,
  `file_content` mediumblob,
  `attachment_type` int(4) DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `vacancy_id` (`vacancy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_kpi`
--

CREATE TABLE IF NOT EXISTS `ohrm_kpi` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `job_title_code` varchar(10) DEFAULT NULL,
  `kpi_indicators` varchar(255) DEFAULT NULL,
  `min_rating` int(7) DEFAULT '0',
  `max_rating` int(7) DEFAULT '0',
  `default_kpi` smallint(1) DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_language`
--

CREATE TABLE IF NOT EXISTS `ohrm_language` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(120) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_leave`
--

CREATE TABLE IF NOT EXISTS `ohrm_leave` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `length_hours` decimal(6,2) unsigned DEFAULT NULL,
  `length_days` decimal(6,4) unsigned DEFAULT NULL,
  `status` smallint(6) DEFAULT NULL,
  `comments` varchar(256) DEFAULT NULL,
  `leave_request_id` int(10) unsigned NOT NULL,
  `leave_type_id` int(10) unsigned NOT NULL,
  `emp_number` int(7) NOT NULL,
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `duration_type` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `leave_request_type_emp` (`leave_request_id`,`leave_type_id`,`emp_number`),
  KEY `request_status` (`leave_request_id`,`status`),
  KEY `leave_type_id` (`leave_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_leave_adjustment`
--

CREATE TABLE IF NOT EXISTS `ohrm_leave_adjustment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `emp_number` int(7) NOT NULL,
  `no_of_days` decimal(19,15) NOT NULL,
  `leave_type_id` int(10) unsigned NOT NULL,
  `from_date` datetime DEFAULT NULL,
  `to_date` datetime DEFAULT NULL,
  `credited_date` datetime DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  `adjustment_type` int(10) unsigned NOT NULL DEFAULT '0',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_by_id` int(10) DEFAULT NULL,
  `created_by_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `leave_type_id` (`leave_type_id`),
  KEY `emp_number` (`emp_number`),
  KEY `created_by_id` (`created_by_id`),
  KEY `adjustment_type` (`adjustment_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_leave_comment`
--

CREATE TABLE IF NOT EXISTS `ohrm_leave_comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `leave_id` int(11) NOT NULL,
  `created` datetime DEFAULT NULL,
  `created_by_name` varchar(255) NOT NULL,
  `created_by_id` int(10) DEFAULT NULL,
  `created_by_emp_number` int(7) DEFAULT NULL,
  `comments` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `leave_id` (`leave_id`),
  KEY `created_by_id` (`created_by_id`),
  KEY `created_by_emp_number` (`created_by_emp_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_leave_entitlement`
--

CREATE TABLE IF NOT EXISTS `ohrm_leave_entitlement` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `emp_number` int(7) NOT NULL,
  `no_of_days` decimal(19,15) NOT NULL,
  `days_used` decimal(8,4) NOT NULL DEFAULT '0.0000',
  `leave_type_id` int(10) unsigned NOT NULL,
  `from_date` datetime NOT NULL,
  `to_date` datetime DEFAULT NULL,
  `credited_date` datetime DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  `entitlement_type` int(10) unsigned NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_by_id` int(10) DEFAULT NULL,
  `created_by_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `leave_type_id` (`leave_type_id`),
  KEY `emp_number` (`emp_number`),
  KEY `entitlement_type` (`entitlement_type`),
  KEY `created_by_id` (`created_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_leave_entitlement_adjustment`
--

CREATE TABLE IF NOT EXISTS `ohrm_leave_entitlement_adjustment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adjustment_id` int(10) unsigned NOT NULL,
  `entitlement_id` int(10) unsigned NOT NULL,
  `length_days` decimal(4,2) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `entitlement_id` (`entitlement_id`),
  KEY `adjustment_id` (`adjustment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_leave_entitlement_type`
--

CREATE TABLE IF NOT EXISTS `ohrm_leave_entitlement_type` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `is_editable` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Contenu de la table `ohrm_leave_entitlement_type`
--

INSERT INTO `ohrm_leave_entitlement_type` (`id`, `name`, `is_editable`) VALUES
(1, 'Added', 1);

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_leave_leave_entitlement`
--

CREATE TABLE IF NOT EXISTS `ohrm_leave_leave_entitlement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `leave_id` int(11) NOT NULL,
  `entitlement_id` int(10) unsigned NOT NULL,
  `length_days` decimal(6,4) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `entitlement_id` (`entitlement_id`),
  KEY `leave_id` (`leave_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_leave_period_history`
--

CREATE TABLE IF NOT EXISTS `ohrm_leave_period_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `leave_period_start_month` int(11) NOT NULL,
  `leave_period_start_day` int(11) NOT NULL,
  `created_at` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_leave_request`
--

CREATE TABLE IF NOT EXISTS `ohrm_leave_request` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `leave_type_id` int(10) unsigned NOT NULL,
  `date_applied` date NOT NULL,
  `emp_number` int(7) NOT NULL,
  `comments` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `emp_number` (`emp_number`),
  KEY `leave_type_id` (`leave_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_leave_request_comment`
--

CREATE TABLE IF NOT EXISTS `ohrm_leave_request_comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `leave_request_id` int(10) unsigned NOT NULL,
  `created` datetime DEFAULT NULL,
  `created_by_name` varchar(255) NOT NULL,
  `created_by_id` int(10) DEFAULT NULL,
  `created_by_emp_number` int(7) DEFAULT NULL,
  `comments` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `leave_request_id` (`leave_request_id`),
  KEY `created_by_id` (`created_by_id`),
  KEY `created_by_emp_number` (`created_by_emp_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_leave_status`
--

CREATE TABLE IF NOT EXISTS `ohrm_leave_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` smallint(6) NOT NULL,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Contenu de la table `ohrm_leave_status`
--

INSERT INTO `ohrm_leave_status` (`id`, `status`, `name`) VALUES
(1, -1, 'REJECTED'),
(2, 0, 'CANCELLED'),
(3, 1, 'PENDING APPROVAL'),
(4, 2, 'SCHEDULED'),
(5, 3, 'TAKEN'),
(6, 4, 'WEEKEND'),
(7, 5, 'HOLIDAY');

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_leave_type`
--

CREATE TABLE IF NOT EXISTS `ohrm_leave_type` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `exclude_in_reports_if_no_entitlement` tinyint(1) NOT NULL DEFAULT '0',
  `operational_country_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `operational_country_id` (`operational_country_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_license`
--

CREATE TABLE IF NOT EXISTS `ohrm_license` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_location`
--

CREATE TABLE IF NOT EXISTS `ohrm_location` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(110) NOT NULL,
  `country_code` varchar(3) NOT NULL,
  `province` varchar(60) DEFAULT NULL,
  `city` varchar(60) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `zip_code` varchar(35) DEFAULT NULL,
  `phone` varchar(35) DEFAULT NULL,
  `fax` varchar(35) DEFAULT NULL,
  `notes` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `country_code` (`country_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_login`
--

CREATE TABLE IF NOT EXISTS `ohrm_login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  `user_role_name` text NOT NULL,
  `user_role_predefined` tinyint(1) NOT NULL,
  `login_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Contenu de la table `ohrm_login`
--

INSERT INTO `ohrm_login` (`id`, `user_id`, `user_name`, `user_role_name`, `user_role_predefined`, `login_time`) VALUES
(1, 1, 'Admin', 'Admin', 1, '2015-08-12 10:25:03'),
(2, 2, 'Mohamed', 'Supervisor', 1, '2015-08-12 11:16:17'),
(3, 1, 'Admin', 'Admin', 1, '2015-08-18 12:19:44'),
(4, 1, 'Admin', 'Admin', 1, '2015-08-18 13:06:07'),
(5, 1, 'Admin', 'Admin', 1, '2015-08-18 13:19:07'),
(6, 1, 'Admin', 'Admin', 1, '2015-08-19 07:34:18'),
(7, 3, 'Abdellatif', 'ESS', 1, '2015-08-19 07:40:47'),
(8, 1, 'Admin', 'Admin', 1, '2015-08-19 12:57:31'),
(9, 3, 'Abdellatif', 'ESS', 1, '2015-08-19 12:58:02');

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_membership`
--

CREATE TABLE IF NOT EXISTS `ohrm_membership` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_menu_item`
--

CREATE TABLE IF NOT EXISTS `ohrm_menu_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menu_title` varchar(255) NOT NULL,
  `screen_id` int(11) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `level` tinyint(4) NOT NULL,
  `order_hint` int(11) NOT NULL,
  `url_extras` varchar(255) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `screen_id` (`screen_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=95 ;

--
-- Contenu de la table `ohrm_menu_item`
--

INSERT INTO `ohrm_menu_item` (`id`, `menu_title`, `screen_id`, `parent_id`, `level`, `order_hint`, `url_extras`, `status`) VALUES
(1, 'Admin', 74, NULL, 1, 100, NULL, 1),
(2, 'User Management', NULL, 1, 2, 100, NULL, 1),
(3, 'Project Info', NULL, 52, 2, 400, NULL, 0),
(4, 'Customers', 36, 3, 3, 100, NULL, 1),
(5, 'Projects', 37, 3, 3, 200, NULL, 1),
(6, 'Job', NULL, 1, 2, 300, NULL, 1),
(7, 'Job Titles', 23, 6, 3, 100, NULL, 1),
(8, 'Pay Grades', 24, 6, 3, 200, NULL, 1),
(9, 'Employment Status', 25, 6, 3, 300, NULL, 1),
(10, 'Job Categories', 26, 6, 3, 400, NULL, 1),
(11, 'Work Shifts', 27, 6, 3, 500, NULL, 1),
(12, 'Organization', NULL, 1, 2, 400, NULL, 1),
(13, 'General Information', 20, 12, 3, 100, NULL, 1),
(14, 'Locations', 21, 12, 3, 200, NULL, 1),
(15, 'Structure', 22, 12, 3, 300, NULL, 1),
(16, 'Qualifications', NULL, 1, 2, 500, NULL, 1),
(17, 'Skills', 28, 16, 3, 100, NULL, 1),
(18, 'Education', 29, 16, 3, 200, NULL, 1),
(19, 'Licenses', 30, 16, 3, 300, NULL, 1),
(20, 'Languages', 31, 16, 3, 400, NULL, 1),
(21, 'Memberships', 32, 16, 3, 500, NULL, 1),
(22, 'Nationalities', 33, 1, 2, 700, NULL, 1),
(23, 'Configuration', NULL, 1, 2, 900, NULL, 1),
(24, 'Email Configuration', 34, 23, 3, 100, NULL, 1),
(25, 'Email Subscriptions', 35, 23, 3, 200, NULL, 1),
(27, 'Localization', 38, 23, 3, 300, NULL, 1),
(28, 'Modules', 39, 23, 3, 400, NULL, 1),
(30, 'PIM', 75, NULL, 1, 200, NULL, 1),
(31, 'Configuration', NULL, 30, 2, 100, NULL, 1),
(32, 'Optional Fields', 40, 31, 3, 100, NULL, 1),
(33, 'Custom Fields', 41, 31, 3, 200, NULL, 1),
(34, 'Data Import', 42, 31, 3, 300, NULL, 1),
(35, 'Reporting Methods', 43, 31, 3, 400, NULL, 1),
(36, 'Termination Reasons', 44, 31, 3, 500, NULL, 1),
(37, 'Employee List', 5, 30, 2, 200, '/reset/1', 1),
(38, 'Add Employee', 4, 30, 2, 300, NULL, 1),
(39, 'Reports', 45, 30, 2, 400, '/reportGroup/3/reportType/PIM_DEFINED', 1),
(40, 'My Info', 46, NULL, 1, 700, NULL, 1),
(41, 'Leave', 68, NULL, 1, 300, NULL, 1),
(42, 'Configure', NULL, 41, 2, 500, NULL, 0),
(43, 'Leave Period', 47, 42, 3, 100, NULL, 0),
(44, 'Leave Types', 7, 42, 3, 200, NULL, 0),
(45, 'Work Week', 14, 42, 3, 300, NULL, 0),
(46, 'Holidays', 11, 42, 3, 400, NULL, 0),
(48, 'Leave List', 16, 41, 2, 600, '/reset/1', 0),
(49, 'Assign Leave', 17, 41, 2, 700, NULL, 0),
(50, 'My Leave', 48, 41, 2, 200, '/reset/1', 0),
(51, 'Apply', 49, 41, 2, 100, NULL, 0),
(52, 'Time', 67, NULL, 1, 400, NULL, 1),
(53, 'Timesheets', NULL, 52, 2, 100, NULL, 1),
(54, 'My Timesheets', 51, 53, 3, 100, NULL, 1),
(55, 'Employee Timesheets', 52, 53, 3, 200, NULL, 1),
(56, 'Attendance', NULL, 52, 2, 200, NULL, 1),
(57, 'My Records', 53, 56, 3, 100, NULL, 1),
(58, 'Punch In/Out', 54, 56, 3, 200, NULL, 1),
(59, 'Employee Records', 55, 56, 3, 300, NULL, 1),
(60, 'Configuration', 56, 56, 3, 400, NULL, 1),
(61, 'Reports', NULL, 52, 2, 300, NULL, 1),
(62, 'Project Reports', 57, 61, 3, 100, '?reportId=1', 1),
(63, 'Employee Reports', 58, 61, 3, 200, '?reportId=2', 1),
(64, 'Attendance Summary', 59, 61, 3, 300, '?reportId=4', 1),
(65, 'Recruitment', 76, NULL, 1, 500, NULL, 1),
(66, 'Candidates', 60, 65, 2, 100, NULL, 1),
(67, 'Vacancies', 61, 65, 2, 200, NULL, 1),
(74, 'Entitlements', NULL, 41, 2, 300, NULL, 0),
(75, 'Add Entitlements', 72, 74, 3, 100, NULL, 0),
(76, 'My Entitlements', 70, 74, 3, 300, '/reset/1', 0),
(77, 'Employee Entitlements', 69, 74, 3, 200, '/reset/1', 0),
(78, 'Reports', NULL, 41, 2, 400, NULL, 0),
(79, 'Leave Entitlements and Usage Report', 78, 78, 3, 100, NULL, 0),
(80, 'My Leave Entitlements and Usage Report', 79, 78, 3, 200, NULL, 0),
(81, 'Users', 1, 2, 3, 100, NULL, 1),
(82, 'Dashboard', 103, NULL, 1, 800, NULL, 1),
(83, 'Performance', NULL, NULL, 1, 700, '', 1),
(84, 'Configure', NULL, 83, 2, 100, '', 1),
(85, 'Manage Reviews', NULL, 83, 2, 200, '', 1),
(86, 'KPIs', 105, 84, 3, 100, '', 1),
(87, 'Manage Reviews', 111, 85, 3, 100, '', 1),
(88, 'My Reviews', 106, 85, 3, 200, '', 1),
(89, 'Review List', 110, 85, 3, 300, '', 1),
(90, 'Trackers', 112, 84, 3, 200, NULL, 1),
(91, 'Employee Trackers', 113, 83, 2, 800, NULL, 1),
(92, 'My Trackers', 114, 83, 2, 700, NULL, 1),
(93, 'Directory', 116, NULL, 1, 1000, '/reset/1', 1),
(94, 'Social Media Authentication', 117, 23, 3, 500, NULL, 1);

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_module`
--

CREATE TABLE IF NOT EXISTS `ohrm_module` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(120) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

--
-- Contenu de la table `ohrm_module`
--

INSERT INTO `ohrm_module` (`id`, `name`, `status`) VALUES
(1, 'core', 1),
(2, 'admin', 1),
(3, 'pim', 1),
(4, 'leave', 0),
(5, 'time', 0),
(6, 'attendance', 0),
(7, 'recruitment', 0),
(8, 'recruitmentApply', 0),
(9, 'communication', 1),
(10, 'dashboard', 1),
(11, 'performance', 0),
(12, 'directory', 0);

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_module_default_page`
--

CREATE TABLE IF NOT EXISTS `ohrm_module_default_page` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `module_id` int(11) NOT NULL,
  `user_role_id` int(11) NOT NULL,
  `action` varchar(255) DEFAULT NULL,
  `enable_class` varchar(100) DEFAULT NULL,
  `priority` int(11) NOT NULL DEFAULT '0' COMMENT 'lowest priority 0',
  PRIMARY KEY (`id`),
  KEY `user_role_id` (`user_role_id`),
  KEY `module_id` (`module_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=17 ;

--
-- Contenu de la table `ohrm_module_default_page`
--

INSERT INTO `ohrm_module_default_page` (`id`, `module_id`, `user_role_id`, `action`, `enable_class`, `priority`) VALUES
(1, 2, 1, 'admin/viewSystemUsers', NULL, 20),
(2, 3, 1, 'pim/viewEmployeeList', NULL, 20),
(3, 3, 3, 'pim/viewEmployeeList', NULL, 10),
(4, 3, 2, 'pim/viewMyDetails', NULL, 0),
(5, 4, 1, 'leave/viewLeaveList/reset/1', NULL, 20),
(6, 4, 3, 'leave/viewLeaveList/reset/1', NULL, 10),
(7, 4, 2, 'leave/viewMyLeaveList', NULL, 0),
(8, 4, 1, 'leave/defineLeavePeriod', 'LeavePeriodDefinedHomePageEnabler', 100),
(9, 4, 2, 'leave/showLeavePeriodNotDefinedWarning', 'LeavePeriodDefinedHomePageEnabler', 90),
(10, 5, 1, 'time/viewEmployeeTimesheet', NULL, 20),
(11, 5, 2, 'time/viewMyTimesheet', NULL, 0),
(12, 5, 1, 'time/defineTimesheetPeriod', 'TimesheetPeriodDefinedHomePageEnabler', 100),
(13, 5, 2, 'time/timesheetPeriodNotDefined', 'TimesheetPeriodDefinedHomePageEnabler', 100),
(14, 7, 1, 'recruitment/viewCandidates', NULL, 20),
(15, 7, 5, 'recruitment/viewCandidates', NULL, 10),
(16, 7, 6, 'recruitment/viewCandidates', NULL, 5);

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_nationality`
--

CREATE TABLE IF NOT EXISTS `ohrm_nationality` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=194 ;

--
-- Contenu de la table `ohrm_nationality`
--

INSERT INTO `ohrm_nationality` (`id`, `name`) VALUES
(1, 'Afghan'),
(2, 'Albanian'),
(3, 'Algerian'),
(4, 'American'),
(5, 'Andorran'),
(6, 'Angolan'),
(7, 'Antiguans'),
(8, 'Argentinean'),
(9, 'Armenian'),
(10, 'Australian'),
(11, 'Austrian'),
(12, 'Azerbaijani'),
(13, 'Bahamian'),
(14, 'Bahraini'),
(15, 'Bangladeshi'),
(16, 'Barbadian'),
(17, 'Barbudans'),
(18, 'Batswana'),
(19, 'Belarusian'),
(20, 'Belgian'),
(21, 'Belizean'),
(22, 'Beninese'),
(23, 'Bhutanese'),
(24, 'Bolivian'),
(25, 'Bosnian'),
(26, 'Brazilian'),
(27, 'British'),
(28, 'Bruneian'),
(29, 'Bulgarian'),
(30, 'Burkinabe'),
(31, 'Burmese'),
(32, 'Burundian'),
(33, 'Cambodian'),
(34, 'Cameroonian'),
(35, 'Canadian'),
(36, 'Cape Verdean'),
(37, 'Central African'),
(38, 'Chadian'),
(39, 'Chilean'),
(40, 'Chinese'),
(41, 'Colombian'),
(42, 'Comoran'),
(43, 'Congolese'),
(44, 'Costa Rican'),
(45, 'Croatian'),
(46, 'Cuban'),
(47, 'Cypriot'),
(48, 'Czech'),
(49, 'Danish'),
(50, 'Djibouti'),
(51, 'Dominican'),
(52, 'Dutch'),
(53, 'East Timorese'),
(54, 'Ecuadorean'),
(55, 'Egyptian'),
(56, 'Emirian'),
(57, 'Equatorial Guinean'),
(58, 'Eritrean'),
(59, 'Estonian'),
(60, 'Ethiopian'),
(61, 'Fijian'),
(62, 'Filipino'),
(63, 'Finnish'),
(64, 'French'),
(65, 'Gabonese'),
(66, 'Gambian'),
(67, 'Georgian'),
(68, 'German'),
(69, 'Ghanaian'),
(70, 'Greek'),
(71, 'Grenadian'),
(72, 'Guatemalan'),
(73, 'Guinea-Bissauan'),
(74, 'Guinean'),
(75, 'Guyanese'),
(76, 'Haitian'),
(77, 'Herzegovinian'),
(78, 'Honduran'),
(79, 'Hungarian'),
(80, 'I-Kiribati'),
(81, 'Icelander'),
(82, 'Indian'),
(83, 'Indonesian'),
(84, 'Iranian'),
(85, 'Iraqi'),
(86, 'Irish'),
(87, 'Israeli'),
(88, 'Italian'),
(89, 'Ivorian'),
(90, 'Jamaican'),
(91, 'Japanese'),
(92, 'Jordanian'),
(93, 'Kazakhstani'),
(94, 'Kenyan'),
(95, 'Kittian and Nevisian'),
(96, 'Kuwaiti'),
(97, 'Kyrgyz'),
(98, 'Laotian'),
(99, 'Latvian'),
(100, 'Lebanese'),
(101, 'Liberian'),
(102, 'Libyan'),
(103, 'Liechtensteiner'),
(104, 'Lithuanian'),
(105, 'Luxembourger'),
(106, 'Macedonian'),
(107, 'Malagasy'),
(108, 'Malawian'),
(109, 'Malaysian'),
(110, 'Maldivan'),
(111, 'Malian'),
(112, 'Maltese'),
(113, 'Marshallese'),
(114, 'Mauritanian'),
(115, 'Mauritian'),
(116, 'Mexican'),
(117, 'Micronesian'),
(118, 'Moldovan'),
(119, 'Monacan'),
(120, 'Mongolian'),
(121, 'Moroccan'),
(122, 'Mosotho'),
(123, 'Motswana'),
(124, 'Mozambican'),
(125, 'Namibian'),
(126, 'Nauruan'),
(127, 'Nepalese'),
(128, 'New Zealander'),
(129, 'Nicaraguan'),
(130, 'Nigerian'),
(131, 'Nigerien'),
(132, 'North Korean'),
(133, 'Northern Irish'),
(134, 'Norwegian'),
(135, 'Omani'),
(136, 'Pakistani'),
(137, 'Palauan'),
(138, 'Panamanian'),
(139, 'Papua New Guinean'),
(140, 'Paraguayan'),
(141, 'Peruvian'),
(142, 'Polish'),
(143, 'Portuguese'),
(144, 'Qatari'),
(145, 'Romanian'),
(146, 'Russian'),
(147, 'Rwandan'),
(148, 'Saint Lucian'),
(149, 'Salvadoran'),
(150, 'Samoan'),
(151, 'San Marinese'),
(152, 'Sao Tomean'),
(153, 'Saudi'),
(154, 'Scottish'),
(155, 'Senegalese'),
(156, 'Serbian'),
(157, 'Seychellois'),
(158, 'Sierra Leonean'),
(159, 'Singaporean'),
(160, 'Slovakian'),
(161, 'Slovenian'),
(162, 'Solomon Islander'),
(163, 'Somali'),
(164, 'South African'),
(165, 'South Korean'),
(166, 'Spanish'),
(167, 'Sri Lankan'),
(168, 'Sudanese'),
(169, 'Surinamer'),
(170, 'Swazi'),
(171, 'Swedish'),
(172, 'Swiss'),
(173, 'Syrian'),
(174, 'Taiwanese'),
(175, 'Tajik'),
(176, 'Tanzanian'),
(177, 'Thai'),
(178, 'Togolese'),
(179, 'Tongan'),
(180, 'Trinidadian or Tobagonian'),
(181, 'Tunisian'),
(182, 'Turkish'),
(183, 'Tuvaluan'),
(184, 'Ugandan'),
(185, 'Ukrainian'),
(186, 'Uruguayan'),
(187, 'Uzbekistani'),
(188, 'Venezuelan'),
(189, 'Vietnamese'),
(190, 'Welsh'),
(191, 'Yemenite'),
(192, 'Zambian'),
(193, 'Zimbabwean');

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_oauth_access_token`
--

CREATE TABLE IF NOT EXISTS `ohrm_oauth_access_token` (
  `access_token` varchar(40) NOT NULL,
  `client_id` varchar(80) NOT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `expires` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `scope` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`access_token`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_oauth_authorization_code`
--

CREATE TABLE IF NOT EXISTS `ohrm_oauth_authorization_code` (
  `authorization_code` varchar(40) NOT NULL,
  `client_id` varchar(80) NOT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `redirect_uri` varchar(2000) NOT NULL,
  `expires` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `scope` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`authorization_code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_oauth_client`
--

CREATE TABLE IF NOT EXISTS `ohrm_oauth_client` (
  `client_id` varchar(80) NOT NULL,
  `client_secret` varchar(80) NOT NULL,
  `redirect_uri` varchar(2000) NOT NULL,
  PRIMARY KEY (`client_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_oauth_refresh_token`
--

CREATE TABLE IF NOT EXISTS `ohrm_oauth_refresh_token` (
  `refresh_token` varchar(40) NOT NULL,
  `client_id` varchar(80) NOT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `expires` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `scope` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`refresh_token`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_oauth_user`
--

CREATE TABLE IF NOT EXISTS `ohrm_oauth_user` (
  `username` varchar(255) NOT NULL,
  `password` varchar(2000) DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_openid_provider`
--

CREATE TABLE IF NOT EXISTS `ohrm_openid_provider` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `provider_name` varchar(40) DEFAULT NULL,
  `provider_url` varchar(255) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_openid_user_identity`
--

CREATE TABLE IF NOT EXISTS `ohrm_openid_user_identity` (
  `user_id` int(10) DEFAULT NULL,
  `provider_id` int(10) DEFAULT NULL,
  `user_identity` varchar(255) DEFAULT NULL,
  KEY `ohrm_user_identity_ibfk_1` (`user_id`),
  KEY `ohrm_user_identity_ibfk_2` (`provider_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_operational_country`
--

CREATE TABLE IF NOT EXISTS `ohrm_operational_country` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `country_code` char(2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_ohrm_operational_country_hs_hr_country` (`country_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_organization_gen_info`
--

CREATE TABLE IF NOT EXISTS `ohrm_organization_gen_info` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `tax_id` varchar(30) DEFAULT NULL,
  `registration_number` varchar(30) DEFAULT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `fax` varchar(30) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `country` varchar(30) DEFAULT NULL,
  `province` varchar(30) DEFAULT NULL,
  `city` varchar(30) DEFAULT NULL,
  `zip_code` varchar(30) DEFAULT NULL,
  `street1` varchar(100) DEFAULT NULL,
  `street2` varchar(100) DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Contenu de la table `ohrm_organization_gen_info`
--

INSERT INTO `ohrm_organization_gen_info` (`id`, `name`, `tax_id`, `registration_number`, `phone`, `fax`, `email`, `country`, `province`, `city`, `zip_code`, `street1`, `street2`, `note`) VALUES
(1, 'Université Virtuelle de Tunis', '', '', '', '', '', 'TN', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_pay_grade`
--

CREATE TABLE IF NOT EXISTS `ohrm_pay_grade` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Contenu de la table `ohrm_pay_grade`
--

INSERT INTO `ohrm_pay_grade` (`id`, `name`) VALUES
(1, 'A1'),
(2, 'A2');

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_pay_grade_currency`
--

CREATE TABLE IF NOT EXISTS `ohrm_pay_grade_currency` (
  `pay_grade_id` int(11) NOT NULL,
  `currency_id` varchar(6) NOT NULL DEFAULT '',
  `min_salary` double DEFAULT NULL,
  `max_salary` double DEFAULT NULL,
  PRIMARY KEY (`pay_grade_id`,`currency_id`),
  KEY `currency_id` (`currency_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `ohrm_pay_grade_currency`
--

INSERT INTO `ohrm_pay_grade_currency` (`pay_grade_id`, `currency_id`, `min_salary`, `max_salary`) VALUES
(1, 'TND', 1100, 1100),
(2, 'TND', 750, 750);

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_performance_review`
--

CREATE TABLE IF NOT EXISTS `ohrm_performance_review` (
  `id` int(7) NOT NULL AUTO_INCREMENT,
  `status_id` int(7) DEFAULT NULL,
  `employee_number` int(7) DEFAULT NULL,
  `work_period_start` date DEFAULT NULL,
  `work_period_end` date DEFAULT NULL,
  `job_title_code` int(7) DEFAULT NULL,
  `department_id` int(7) DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `completed_date` date DEFAULT NULL,
  `activated_date` datetime DEFAULT NULL,
  `final_comment` text CHARACTER SET utf8 COLLATE utf8_bin,
  `final_rate` decimal(18,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `employee_number` (`employee_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_performance_track`
--

CREATE TABLE IF NOT EXISTS `ohrm_performance_track` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `emp_number` int(7) NOT NULL,
  `tracker_name` varchar(200) NOT NULL,
  `added_date` timestamp NULL DEFAULT NULL,
  `added_by` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ohrm_performance_track_fk1_idx` (`emp_number`),
  KEY `ohrm_performance_track_fk2_idx` (`added_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_performance_tracker_log`
--

CREATE TABLE IF NOT EXISTS `ohrm_performance_tracker_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `performance_track_id` int(11) DEFAULT NULL,
  `log` varchar(150) DEFAULT NULL,
  `comment` varchar(3000) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `added_date` timestamp NULL DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  `reviewer_id` int(7) DEFAULT NULL,
  `achievement` varchar(45) DEFAULT NULL,
  `user_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ohrm_performance_tracker_log_fk1_idx` (`performance_track_id`),
  KEY `ohrm_performance_tracker_log_fk2_idx` (`reviewer_id`),
  KEY `fk_ohrm_performance_tracker_log_1` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_performance_tracker_reviewer`
--

CREATE TABLE IF NOT EXISTS `ohrm_performance_tracker_reviewer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `performance_track_id` int(11) NOT NULL,
  `reviewer_id` int(7) NOT NULL,
  `added_date` timestamp NULL DEFAULT NULL,
  `status` int(2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ohrm_performance_tracker_reviewer_fk1_idx` (`performance_track_id`),
  KEY `ohrm_performance_tracker_reviewer_fk2_idx` (`reviewer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_plugin`
--

CREATE TABLE IF NOT EXISTS `ohrm_plugin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `version` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_project`
--

CREATE TABLE IF NOT EXISTS `ohrm_project` (
  `project_id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `description` varchar(256) DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`project_id`,`customer_id`),
  KEY `customer_id` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_project_activity`
--

CREATE TABLE IF NOT EXISTS `ohrm_project_activity` (
  `activity_id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `name` varchar(110) DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`activity_id`),
  KEY `project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_project_admin`
--

CREATE TABLE IF NOT EXISTS `ohrm_project_admin` (
  `project_id` int(11) NOT NULL,
  `emp_number` int(11) NOT NULL,
  PRIMARY KEY (`project_id`,`emp_number`),
  KEY `emp_number` (`emp_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_report`
--

CREATE TABLE IF NOT EXISTS `ohrm_report` (
  `report_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `report_group_id` bigint(20) NOT NULL,
  `use_filter_field` tinyint(1) NOT NULL,
  `type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`report_id`),
  KEY `report_group_id` (`report_group_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Contenu de la table `ohrm_report`
--

INSERT INTO `ohrm_report` (`report_id`, `name`, `report_group_id`, `use_filter_field`, `type`) VALUES
(1, 'Project Report', 1, 1, NULL),
(2, 'Employee Report', 1, 1, NULL),
(3, 'Project Activity Details', 1, 1, NULL),
(4, 'Attendance Total Summary Report', 2, 0, NULL),
(5, 'PIM Sample Report', 3, 1, 'PIM_DEFINED');

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_report_group`
--

CREATE TABLE IF NOT EXISTS `ohrm_report_group` (
  `report_group_id` bigint(20) NOT NULL,
  `name` varchar(255) NOT NULL,
  `core_sql` mediumtext NOT NULL,
  PRIMARY KEY (`report_group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `ohrm_report_group`
--

INSERT INTO `ohrm_report_group` (`report_group_id`, `name`, `core_sql`) VALUES
(1, 'timesheet', 'SELECT selectCondition FROM ohrm_project_activity LEFT JOIN (SELECT * FROM ohrm_timesheet_item WHERE whereCondition1) AS ohrm_timesheet_item  ON (ohrm_timesheet_item.activity_id = ohrm_project_activity.activity_id) LEFT JOIN ohrm_project ON (ohrm_project.project_id = ohrm_project_activity.project_id) LEFT JOIN hs_hr_employee ON (hs_hr_employee.emp_number = ohrm_timesheet_item.employee_id) LEFT JOIN ohrm_timesheet ON (ohrm_timesheet.timesheet_id = ohrm_timesheet_item.timesheet_id) LEFT JOIN ohrm_customer ON (ohrm_customer.customer_id = ohrm_project.customer_id) WHERE whereCondition2 groupByClause ORDER BY ohrm_customer.name, ohrm_project.name, ohrm_project_activity.name, hs_hr_employee.emp_lastname, hs_hr_employee.emp_firstname'),
(2, 'attendance', 'SELECT selectCondition FROM hs_hr_employee LEFT JOIN (SELECT * FROM ohrm_attendance_record WHERE ( ( ohrm_attendance_record.punch_in_user_time BETWEEN "#@fromDate@,@1970-01-01@#" AND #@"toDate"@,@CURDATE()@# ) AND ( ohrm_attendance_record.punch_out_user_time BETWEEN "#@fromDate@,@1970-01-01@#" AND #@"toDate"@,@CURDATE()@# ) ) ) AS ohrm_attendance_record ON (hs_hr_employee.emp_number = ohrm_attendance_record.employee_id) WHERE hs_hr_employee.emp_number = #@employeeId@,@hs_hr_employee.emp_number AND (hs_hr_employee.termination_id is null) @# AND (hs_hr_employee.job_title_code = #@"jobTitle")@,@hs_hr_employee.job_title_code OR hs_hr_employee.job_title_code is null)@# AND (hs_hr_employee.work_station IN (#@subUnit)@,@SELECT id FROM ohrm_subunit) OR hs_hr_employee.work_station is null@#) AND (hs_hr_employee.emp_status = #@"employeeStatus")@,@hs_hr_employee.emp_status OR hs_hr_employee.emp_status is null)@# groupByClause ORDER BY hs_hr_employee.emp_lastname, hs_hr_employee.emp_firstname'),
(3, 'pim', 'SELECT selectCondition FROM hs_hr_employee \n                    LEFT JOIN hs_hr_emp_emergency_contacts ON \n                        (hs_hr_employee.emp_number = hs_hr_emp_emergency_contacts.emp_number) \n                    LEFT JOIN ohrm_subunit ON \n                        (hs_hr_employee.work_station = ohrm_subunit.id) \n                    LEFT JOIN ohrm_employment_status ON \n                        (hs_hr_employee.emp_status = ohrm_employment_status.id) \n                    LEFT JOIN ohrm_job_title ON\n                        (hs_hr_employee.job_title_code = ohrm_job_title.id)\n                    LEFT JOIN ohrm_job_category ON \n                        (hs_hr_employee.eeo_cat_code = ohrm_job_category.id) \n                    LEFT JOIN ohrm_nationality ON\n                        (hs_hr_employee.nation_code = ohrm_nationality.id)\n                    LEFT JOIN hs_hr_emp_dependents ON \n                        (hs_hr_employee.emp_number = hs_hr_emp_dependents.emp_number)\n                    LEFT JOIN hs_hr_emp_locations AS emp_location ON\n                        (hs_hr_employee.emp_number = emp_location.emp_number)\n                    LEFT JOIN ohrm_location ON\n                        (emp_location.location_id = ohrm_location.id)\n                    LEFT JOIN hs_hr_emp_contract_extend ON \n                        (hs_hr_employee.emp_number = hs_hr_emp_contract_extend.emp_number) \n                    LEFT JOIN hs_hr_emp_basicsalary ON \n                        (hs_hr_employee.emp_number = hs_hr_emp_basicsalary.emp_number) \n                    LEFT JOIN ohrm_pay_grade ON \n                        (hs_hr_emp_basicsalary.sal_grd_code = ohrm_pay_grade.id) \n                    LEFT JOIN hs_hr_currency_type ON \n                        (hs_hr_emp_basicsalary.currency_id = hs_hr_currency_type.currency_id) \n                    LEFT JOIN hs_hr_payperiod ON \n                        (hs_hr_emp_basicsalary.payperiod_code = hs_hr_payperiod.payperiod_code) \n                    LEFT JOIN hs_hr_emp_passport ON \n                        (hs_hr_employee.emp_number = hs_hr_emp_passport.emp_number) \n                    LEFT JOIN hs_hr_emp_reportto AS subordinate_list ON \n                        (hs_hr_employee.emp_number = subordinate_list.erep_sup_emp_number) \n                    LEFT JOIN hs_hr_employee AS subordinate ON\n                        (subordinate.emp_number = subordinate_list.erep_sub_emp_number)\n                    LEFT JOIN ohrm_emp_reporting_method AS subordinate_reporting_method ON \n                        (subordinate_list.erep_reporting_mode = subordinate_reporting_method.reporting_method_id) \n                    LEFT JOIN hs_hr_emp_work_experience ON \n                        (hs_hr_employee.emp_number = hs_hr_emp_work_experience.emp_number) \n                    LEFT JOIN ohrm_emp_education ON \n                        (hs_hr_employee.emp_number = ohrm_emp_education.emp_number) \n                    LEFT JOIN ohrm_education ON \n                        (ohrm_emp_education.education_id = ohrm_education.id) \n                    LEFT JOIN hs_hr_emp_skill ON \n                        (hs_hr_employee.emp_number = hs_hr_emp_skill.emp_number) \n                    LEFT JOIN ohrm_skill ON \n                        (hs_hr_emp_skill.skill_id = ohrm_skill.id) \n                    LEFT JOIN hs_hr_emp_language ON \n                        (hs_hr_employee.emp_number = hs_hr_emp_language.emp_number) \n                    LEFT JOIN ohrm_language ON \n                        (hs_hr_emp_language.lang_id = ohrm_language.id) \n                    LEFT JOIN ohrm_emp_license ON \n                        (hs_hr_employee.emp_number = ohrm_emp_license.emp_number) \n                    LEFT JOIN ohrm_license ON \n                        (ohrm_emp_license.license_id = ohrm_license.id) \n                    LEFT JOIN hs_hr_emp_member_detail ON \n                        (hs_hr_employee.emp_number = hs_hr_emp_member_detail.emp_number) \n                    LEFT JOIN ohrm_membership ON\n                        (hs_hr_emp_member_detail.membship_code = ohrm_membership.id)\n                    LEFT JOIN hs_hr_country ON \n                        (hs_hr_employee.coun_code = hs_hr_country.cou_code) \n                    LEFT JOIN hs_hr_emp_directdebit ON \n                        (hs_hr_emp_basicsalary.id = hs_hr_emp_directdebit.salary_id) \n                    LEFT JOIN hs_hr_emp_reportto AS supervisor_list ON \n                        (hs_hr_employee.emp_number = supervisor_list.erep_sub_emp_number) \n                    LEFT JOIN hs_hr_employee AS supervisor ON\n                        (supervisor.emp_number = supervisor_list.erep_sup_emp_number)\n                    LEFT JOIN ohrm_emp_reporting_method AS supervisor_reporting_method ON \n                        (supervisor_list.erep_reporting_mode = supervisor_reporting_method.reporting_method_id) \n                    LEFT JOIN ohrm_emp_termination ON\n                        (hs_hr_employee.termination_id = ohrm_emp_termination.id)\n                    LEFT JOIN ohrm_emp_termination_reason ON\n                        (ohrm_emp_termination.reason_id = ohrm_emp_termination_reason.id)\n                WHERE hs_hr_employee.emp_number in (\n                    SELECT hs_hr_employee.emp_number FROM hs_hr_employee\n                        LEFT JOIN hs_hr_emp_basicsalary ON \n                            (hs_hr_employee.emp_number = hs_hr_emp_basicsalary.emp_number) \n                        LEFT JOIN ohrm_emp_education ON \n                            (hs_hr_employee.emp_number = ohrm_emp_education.emp_number) \n                        LEFT JOIN hs_hr_emp_skill ON \n                            (hs_hr_employee.emp_number = hs_hr_emp_skill.emp_number) \n                        LEFT JOIN hs_hr_emp_language ON \n                            (hs_hr_employee.emp_number = hs_hr_emp_language.emp_number) \n                    WHERE whereCondition1\n                )\n                GROUP BY \n                     hs_hr_employee.emp_number,\n                     hs_hr_employee.emp_lastname,\n                     hs_hr_employee.emp_firstname,\n                     hs_hr_employee.emp_middle_name,\n                     hs_hr_employee.emp_birthday,\n                     ohrm_nationality.name,\n                     hs_hr_employee.emp_gender,\n                     hs_hr_employee.emp_marital_status,\n                     hs_hr_employee.emp_dri_lice_num,\n                     hs_hr_employee.emp_dri_lice_exp_date,\n                     hs_hr_employee.emp_street1,\n                     hs_hr_employee.emp_street2,\n                     hs_hr_employee.city_code,\n                     hs_hr_employee.provin_code,\n                     hs_hr_employee.emp_zipcode,\n                     hs_hr_country.cou_code,\n                     hs_hr_employee.emp_hm_telephone,\n                     hs_hr_employee.emp_mobile,\n                     hs_hr_employee.emp_work_telephone,\n                     hs_hr_employee.emp_work_email,\n                     hs_hr_employee.emp_oth_email\n\nORDER BY hs_hr_employee.emp_lastname\n');

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_reviewer`
--

CREATE TABLE IF NOT EXISTS `ohrm_reviewer` (
  `id` int(7) NOT NULL AUTO_INCREMENT,
  `review_id` int(7) DEFAULT NULL,
  `employee_number` int(7) DEFAULT NULL,
  `status` int(7) DEFAULT NULL,
  `reviewer_group_id` int(7) DEFAULT NULL,
  `completed_date` datetime DEFAULT NULL,
  `comment` text CHARACTER SET utf8 COLLATE utf8_bin,
  PRIMARY KEY (`id`),
  KEY `review_id` (`review_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_reviewer_group`
--

CREATE TABLE IF NOT EXISTS `ohrm_reviewer_group` (
  `id` int(7) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `piority` int(7) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Contenu de la table `ohrm_reviewer_group`
--

INSERT INTO `ohrm_reviewer_group` (`id`, `name`, `piority`) VALUES
(1, 'Supervisor', 1),
(2, 'Employee', 2);

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_reviewer_rating`
--

CREATE TABLE IF NOT EXISTS `ohrm_reviewer_rating` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rating` decimal(18,2) DEFAULT NULL,
  `kpi_id` int(7) DEFAULT NULL,
  `review_id` int(7) DEFAULT NULL,
  `reviewer_id` int(7) NOT NULL,
  `comment` text CHARACTER SET utf8 COLLATE utf8_bin,
  PRIMARY KEY (`id`),
  KEY `review_id` (`review_id`),
  KEY `reviewer_id` (`reviewer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_role_user_selection_rule`
--

CREATE TABLE IF NOT EXISTS `ohrm_role_user_selection_rule` (
  `user_role_id` int(10) NOT NULL,
  `selection_rule_id` int(10) NOT NULL,
  `configurable_params` text,
  PRIMARY KEY (`user_role_id`,`selection_rule_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_screen`
--

CREATE TABLE IF NOT EXISTS `ohrm_screen` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `module_id` int(11) NOT NULL,
  `action_url` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `module_id` (`module_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=118 ;

--
-- Contenu de la table `ohrm_screen`
--

INSERT INTO `ohrm_screen` (`id`, `name`, `module_id`, `action_url`) VALUES
(1, 'User List', 2, 'viewSystemUsers'),
(2, 'Add/Edit System User', 2, 'saveSystemUser'),
(3, 'Delete System Users', 2, 'deleteSystemUsers'),
(4, 'Add Employee', 3, 'addEmployee'),
(5, 'View Employee List', 3, 'viewEmployeeList'),
(6, 'Delete Employees', 3, 'deleteEmployees'),
(7, 'Leave Type List', 4, 'leaveTypeList'),
(8, 'Define Leave Type', 4, 'defineLeaveType'),
(9, 'Undelete Leave Type', 4, 'undeleteLeaveType'),
(10, 'Delete Leave Type', 4, 'deleteLeaveType'),
(11, 'View Holiday List', 4, 'viewHolidayList'),
(12, 'Define Holiday', 4, 'defineHoliday'),
(13, 'Delete Holiday', 4, 'deleteHoliday'),
(14, 'Define WorkWeek', 4, 'defineWorkWeek'),
(16, 'Leave List', 4, 'viewLeaveList'),
(17, 'Assign Leave', 4, 'assignLeave'),
(18, 'View Leave Summary', 4, 'viewLeaveSummary'),
(19, 'Save Leave Entitlements', 4, 'saveLeaveEntitlements'),
(20, 'General Information', 2, 'viewOrganizationGeneralInformation'),
(21, 'Location List', 2, 'viewLocations'),
(22, 'View Company Structure', 2, 'viewCompanyStructure'),
(23, 'Job Title List', 2, 'viewJobTitleList'),
(24, 'Pay Grade List', 2, 'viewPayGrades'),
(25, 'Employment Status List', 2, 'employmentStatus'),
(26, 'Job Category List', 2, 'jobCategory'),
(27, 'Work Shift List', 2, 'workShift'),
(28, 'Skill List', 2, 'viewSkills'),
(29, 'Education List', 2, 'viewEducation'),
(30, 'License List', 2, 'viewLicenses'),
(31, 'Language List', 2, 'viewLanguages'),
(32, 'Membership List', 2, 'membership'),
(33, 'Nationality List', 2, 'nationality'),
(34, 'Add/Edit Mail Configuration', 2, 'listMailConfiguration'),
(35, 'Notification List', 2, 'viewEmailNotification'),
(36, 'Customer List', 2, 'viewCustomers'),
(37, 'Project List', 2, 'viewProjects'),
(38, 'Localization', 2, 'localization'),
(39, 'Module Configuration', 2, 'viewModules'),
(40, 'Configure PIM', 3, 'configurePim'),
(41, 'Custom Field List', 3, 'listCustomFields'),
(42, 'Data Import', 2, 'pimCsvImport'),
(43, 'Reporting Method List', 3, 'viewReportingMethods'),
(44, 'Termination Reason List', 3, 'viewTerminationReasons'),
(45, 'PIM Reports List', 1, 'viewDefinedPredefinedReports'),
(46, 'View MyInfo', 3, 'viewMyDetails'),
(47, 'Define Leave Period', 4, 'defineLeavePeriod'),
(48, 'View My Leave List', 4, 'viewMyLeaveList'),
(49, 'Apply Leave', 4, 'applyLeave'),
(50, 'Define Timesheet Start Date', 5, 'defineTimesheetPeriod'),
(51, 'View My Timesheet', 5, 'viewMyTimesheet'),
(52, 'View Employee Timesheet', 5, 'viewEmployeeTimesheet'),
(53, 'View My Attendance', 6, 'viewMyAttendanceRecord'),
(54, 'Punch In/Out', 6, 'punchIn'),
(55, 'View Employee Attendance', 6, 'viewAttendanceRecord'),
(56, 'Attendance Configuration', 6, 'configure'),
(57, 'View Project Report Criteria', 5, 'displayProjectReportCriteria'),
(58, 'View Employee Report Criteria', 5, 'displayEmployeeReportCriteria'),
(59, 'View Attendance Report Criteria', 5, 'displayAttendanceSummaryReportCriteria'),
(60, 'Candidate List', 7, 'viewCandidates'),
(61, 'Vacancy List', 7, 'viewJobVacancy'),
(67, 'View Time Module', 5, 'viewTimeModule'),
(68, 'View Leave Module', 4, 'viewLeaveModule'),
(69, 'Leave Entitlements', 4, 'viewLeaveEntitlements'),
(70, 'My Leave Entitlements', 4, 'viewMyLeaveEntitlements'),
(71, 'Delete Leave Entitlements', 4, 'deleteLeaveEntitlements'),
(72, 'Add Leave Entitlement', 4, 'addLeaveEntitlement'),
(73, 'Edit Leave Entitlement', 4, 'editLeaveEntitlement'),
(74, 'View Admin Module', 2, 'viewAdminModule'),
(75, 'View PIM Module', 3, 'viewPimModule'),
(76, 'View Recruitment Module', 7, 'viewRecruitmentModule'),
(78, 'Leave Balance Report', 4, 'viewLeaveBalanceReport'),
(79, 'My Leave Balance Report', 4, 'viewMyLeaveBalanceReport'),
(80, 'Save Job Title', 2, 'saveJobTitle'),
(81, 'Delete Job Title', 2, 'deleteJobTitle'),
(82, 'Save Pay Grade', 2, 'payGrade'),
(83, 'Delete Pay Grade', 2, 'deletePayGrades'),
(84, 'Save Pay Grade Currency', 2, 'savePayGradeCurrency'),
(85, 'Delete Pay Grade Currency', 2, 'deletePayGradeCurrency'),
(86, 'Add Customer', 2, 'addCustomer'),
(87, 'Delete Customer', 2, 'deleteCustomer'),
(88, 'Save Project', 2, 'saveProject'),
(89, 'Delete Project', 2, 'deleteProject'),
(90, 'Add Project Adtivity', 2, 'addProjectActivity'),
(91, 'Delete Project Adtivity', 2, 'deleteProjectActivity'),
(92, 'Define PIM reports', 1, 'definePredefinedReport'),
(93, 'Display PIM reports', 1, 'displayPredefinedReport'),
(94, 'Add Job Vacancy', 7, 'addJobVacancy'),
(95, 'Delete Job Vacancy', 7, 'deleteJobVacancy'),
(96, 'Add Candidate', 7, 'addCandidate'),
(97, 'Delete Candidate', 7, 'deleteCandidateVacancies'),
(98, 'View Leave Request', 4, 'viewLeaveRequest'),
(99, 'Change Leave Status', 4, 'changeLeaveStatus'),
(100, 'Terminate Employment', 3, 'terminateEmployement'),
(101, 'View Attendance Summary Report', 5, 'displayAttendanceSummaryReport'),
(102, 'View Project Activity Details Report', 5, 'displayProjectActivityDetailsReport'),
(103, 'Dashboard', 10, 'index'),
(104, 'Save KPI', 11, 'saveKpi'),
(105, 'Saearch KPI', 11, 'searchKpi'),
(106, 'My Reviews', 11, 'myPerformanceReview'),
(107, 'Add Review', 11, 'saveReview'),
(108, 'Review Evaluate', 11, 'reviewEvaluate'),
(109, 'Review Evaluate By Admin', 11, 'reviewEvaluateByAdmin'),
(110, 'Search Evaluate Performance', 11, 'searchEvaluatePerformancReview'),
(111, 'Search Performance Review', 11, 'searchPerformancReview'),
(112, 'Manage_Trackers', 11, 'addPerformanceTracker'),
(113, 'Employee_Trackers', 11, 'viewEmployeePerformanceTrackerList'),
(114, 'My_Trackers', 11, 'viewMyPerformanceTrackerList'),
(115, 'Employee_Tracker_Logs', 11, 'addPerformanceTrackerLog'),
(116, 'Directory', 12, 'viewDirectory'),
(117, 'Manage OpenId', 2, 'openIdProvider');

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_selected_composite_display_field`
--

CREATE TABLE IF NOT EXISTS `ohrm_selected_composite_display_field` (
  `id` bigint(20) NOT NULL,
  `composite_display_field_id` bigint(20) NOT NULL,
  `report_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`,`composite_display_field_id`,`report_id`),
  KEY `composite_display_field_id` (`composite_display_field_id`),
  KEY `report_id` (`report_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `ohrm_selected_composite_display_field`
--

INSERT INTO `ohrm_selected_composite_display_field` (`id`, `composite_display_field_id`, `report_id`) VALUES
(1, 1, 3),
(2, 1, 4),
(3, 2, 2);

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_selected_display_field`
--

CREATE TABLE IF NOT EXISTS `ohrm_selected_display_field` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `display_field_id` bigint(20) NOT NULL,
  `report_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`,`display_field_id`,`report_id`),
  KEY `display_field_id` (`display_field_id`),
  KEY `report_id` (`report_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=94 ;

--
-- Contenu de la table `ohrm_selected_display_field`
--

INSERT INTO `ohrm_selected_display_field` (`id`, `display_field_id`, `report_id`) VALUES
(2, 2, 1),
(4, 8, 2),
(5, 9, 5),
(6, 10, 5),
(7, 11, 5),
(8, 12, 5),
(9, 13, 5),
(10, 14, 5),
(11, 15, 5),
(13, 17, 5),
(14, 18, 5),
(15, 19, 5),
(16, 20, 5),
(17, 21, 5),
(18, 22, 5),
(19, 23, 5),
(20, 24, 5),
(21, 25, 5),
(22, 26, 5),
(23, 27, 5),
(24, 28, 5),
(25, 29, 5),
(26, 30, 5),
(27, 31, 5),
(28, 32, 5),
(29, 33, 5),
(31, 35, 5),
(32, 36, 5),
(33, 37, 5),
(34, 38, 5),
(35, 39, 5),
(36, 40, 5),
(37, 41, 5),
(38, 42, 5),
(39, 43, 5),
(40, 44, 5),
(41, 45, 5),
(43, 47, 5),
(44, 48, 5),
(45, 49, 5),
(48, 52, 5),
(49, 53, 5),
(50, 54, 5),
(51, 55, 5),
(53, 57, 5),
(54, 58, 5),
(55, 59, 5),
(56, 60, 5),
(57, 61, 5),
(58, 62, 5),
(59, 63, 5),
(60, 64, 5),
(61, 65, 5),
(62, 66, 5),
(63, 67, 5),
(64, 68, 5),
(65, 69, 5),
(66, 70, 5),
(67, 71, 5),
(68, 72, 5),
(69, 73, 5),
(70, 74, 5),
(71, 75, 5),
(72, 76, 5),
(73, 77, 5),
(74, 78, 5),
(76, 80, 5),
(77, 81, 5),
(78, 82, 5),
(79, 83, 5),
(80, 84, 5),
(81, 85, 5),
(82, 86, 5),
(83, 87, 5),
(84, 88, 5),
(85, 89, 5),
(86, 90, 5),
(87, 91, 5),
(88, 92, 5),
(89, 93, 5),
(90, 94, 5),
(91, 95, 5),
(93, 97, 5);

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_selected_display_field_group`
--

CREATE TABLE IF NOT EXISTS `ohrm_selected_display_field_group` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `report_id` bigint(20) NOT NULL,
  `display_field_group_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `report_id` (`report_id`),
  KEY `display_field_group_id` (`display_field_group_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=16 ;

--
-- Contenu de la table `ohrm_selected_display_field_group`
--

INSERT INTO `ohrm_selected_display_field_group` (`id`, `report_id`, `display_field_group_id`) VALUES
(1, 5, 1),
(2, 5, 2),
(3, 5, 3),
(4, 5, 4),
(5, 5, 5),
(6, 5, 6),
(7, 5, 7),
(8, 5, 8),
(9, 5, 9),
(10, 5, 10),
(11, 5, 11),
(12, 5, 12),
(13, 5, 13),
(14, 5, 14),
(15, 5, 15);

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_selected_filter_field`
--

CREATE TABLE IF NOT EXISTS `ohrm_selected_filter_field` (
  `report_id` bigint(20) NOT NULL,
  `filter_field_id` bigint(20) NOT NULL,
  `filter_field_order` bigint(20) NOT NULL,
  `value1` varchar(255) DEFAULT NULL,
  `value2` varchar(255) DEFAULT NULL,
  `where_condition` varchar(255) DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  PRIMARY KEY (`report_id`,`filter_field_id`),
  KEY `report_id` (`report_id`),
  KEY `filter_field_id` (`filter_field_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `ohrm_selected_filter_field`
--

INSERT INTO `ohrm_selected_filter_field` (`report_id`, `filter_field_id`, `filter_field_order`, `value1`, `value2`, `where_condition`, `type`) VALUES
(1, 1, 1, NULL, NULL, NULL, 'Runtime'),
(1, 3, 2, NULL, NULL, NULL, 'Runtime'),
(1, 7, 3, NULL, NULL, NULL, 'Runtime'),
(1, 21, 4, '0', NULL, '=', 'Predefined'),
(2, 3, 4, NULL, NULL, NULL, 'Runtime'),
(2, 4, 1, NULL, NULL, NULL, 'Runtime'),
(2, 5, 3, NULL, NULL, NULL, 'Runtime'),
(2, 6, 2, NULL, NULL, NULL, 'Runtime'),
(2, 7, 5, NULL, NULL, NULL, 'Runtime'),
(3, 3, 2, NULL, NULL, NULL, 'Runtime'),
(3, 5, 1, NULL, NULL, NULL, 'Runtime'),
(3, 7, 3, NULL, NULL, NULL, 'Runtime'),
(5, 22, 1, NULL, NULL, 'IS NULL', 'Predefined');

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_selected_group_field`
--

CREATE TABLE IF NOT EXISTS `ohrm_selected_group_field` (
  `group_field_id` bigint(20) NOT NULL,
  `summary_display_field_id` bigint(20) NOT NULL,
  `report_id` bigint(20) NOT NULL,
  PRIMARY KEY (`group_field_id`,`summary_display_field_id`,`report_id`),
  KEY `group_field_id` (`group_field_id`),
  KEY `summary_display_field_id` (`summary_display_field_id`),
  KEY `report_id` (`report_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `ohrm_selected_group_field`
--

INSERT INTO `ohrm_selected_group_field` (`group_field_id`, `summary_display_field_id`, `report_id`) VALUES
(1, 1, 1),
(1, 1, 2),
(2, 1, 3),
(2, 2, 4);

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_skill`
--

CREATE TABLE IF NOT EXISTS `ohrm_skill` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(120) DEFAULT NULL,
  `description` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Contenu de la table `ohrm_skill`
--

INSERT INTO `ohrm_skill` (`id`, `name`, `description`) VALUES
(1, 'PHP', 'PHP');

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_subunit`
--

CREATE TABLE IF NOT EXISTS `ohrm_subunit` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `unit_id` varchar(100) DEFAULT NULL,
  `description` varchar(400) DEFAULT NULL,
  `lft` smallint(6) unsigned DEFAULT NULL,
  `rgt` smallint(6) unsigned DEFAULT NULL,
  `level` smallint(6) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Contenu de la table `ohrm_subunit`
--

INSERT INTO `ohrm_subunit` (`id`, `name`, `unit_id`, `description`, `lft`, `rgt`, `level`) VALUES
(1, 'Université Virtuelle de Tunis', '', '', 1, 2, 0);

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_summary_display_field`
--

CREATE TABLE IF NOT EXISTS `ohrm_summary_display_field` (
  `summary_display_field_id` bigint(20) NOT NULL,
  `function` varchar(1000) NOT NULL,
  `label` varchar(255) NOT NULL,
  `field_alias` varchar(255) DEFAULT NULL,
  `is_sortable` varchar(10) NOT NULL,
  `sort_order` varchar(255) DEFAULT NULL,
  `sort_field` varchar(255) DEFAULT NULL,
  `element_type` varchar(255) NOT NULL,
  `element_property` varchar(1000) NOT NULL,
  `width` varchar(255) NOT NULL,
  `is_exportable` varchar(10) DEFAULT NULL,
  `text_alignment_style` varchar(20) DEFAULT NULL,
  `is_value_list` tinyint(1) NOT NULL DEFAULT '0',
  `display_field_group_id` int(10) unsigned DEFAULT NULL,
  `default_value` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`summary_display_field_id`),
  KEY `display_field_group_id` (`display_field_group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `ohrm_summary_display_field`
--

INSERT INTO `ohrm_summary_display_field` (`summary_display_field_id`, `function`, `label`, `field_alias`, `is_sortable`, `sort_order`, `sort_field`, `element_type`, `element_property`, `width`, `is_exportable`, `text_alignment_style`, `is_value_list`, `display_field_group_id`, `default_value`) VALUES
(1, 'ROUND(COALESCE(sum(duration)/3600, 0),2)', 'Time (Hours)', 'totalduration', 'false', NULL, NULL, 'label', '<xml><getter>totalduration</getter></xml>', '100', 'false', 'right', 0, NULL, NULL),
(2, 'ROUND(COALESCE(sum(TIMESTAMPDIFF(SECOND , ohrm_attendance_record.punch_in_utc_time , ohrm_attendance_record.punch_out_utc_time))/3600, 0),2)', 'Time (Hours)', 'totalduration', 'false', NULL, NULL, 'label', '<xml><getter>totalduration</getter></xml>', '100', 'false', 'right', 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_timesheet`
--

CREATE TABLE IF NOT EXISTS `ohrm_timesheet` (
  `timesheet_id` bigint(20) NOT NULL,
  `state` varchar(255) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `employee_id` bigint(20) NOT NULL,
  PRIMARY KEY (`timesheet_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `ohrm_timesheet`
--

INSERT INTO `ohrm_timesheet` (`timesheet_id`, `state`, `start_date`, `end_date`, `employee_id`) VALUES
(1, 'NOT SUBMITTED', '2015-08-10', '2015-08-16', 1);

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_timesheet_action_log`
--

CREATE TABLE IF NOT EXISTS `ohrm_timesheet_action_log` (
  `timesheet_action_log_id` bigint(20) NOT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `action` varchar(255) DEFAULT NULL,
  `date_time` date NOT NULL,
  `performed_by` int(20) NOT NULL,
  `timesheet_id` bigint(20) NOT NULL,
  PRIMARY KEY (`timesheet_action_log_id`),
  KEY `timesheet_id` (`timesheet_id`),
  KEY `performed_by` (`performed_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_timesheet_item`
--

CREATE TABLE IF NOT EXISTS `ohrm_timesheet_item` (
  `timesheet_item_id` bigint(20) NOT NULL,
  `timesheet_id` bigint(20) NOT NULL,
  `date` date NOT NULL,
  `duration` bigint(20) DEFAULT NULL,
  `comment` text,
  `project_id` bigint(20) NOT NULL,
  `employee_id` bigint(20) NOT NULL,
  `activity_id` bigint(20) NOT NULL,
  PRIMARY KEY (`timesheet_item_id`),
  KEY `timesheet_id` (`timesheet_id`),
  KEY `activity_id` (`activity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_upgrade_history`
--

CREATE TABLE IF NOT EXISTS `ohrm_upgrade_history` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `start_version` varchar(30) DEFAULT NULL,
  `end_version` varchar(30) DEFAULT NULL,
  `start_increment` int(11) NOT NULL,
  `end_increment` int(11) NOT NULL,
  `upgraded_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_user`
--

CREATE TABLE IF NOT EXISTS `ohrm_user` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `user_role_id` int(10) NOT NULL,
  `emp_number` int(13) DEFAULT NULL,
  `user_name` varchar(40) DEFAULT NULL,
  `user_password` varchar(255) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` int(10) DEFAULT NULL,
  `created_by` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_name` (`user_name`),
  KEY `user_role_id` (`user_role_id`),
  KEY `emp_number` (`emp_number`),
  KEY `modified_user_id` (`modified_user_id`),
  KEY `created_by` (`created_by`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Contenu de la table `ohrm_user`
--

INSERT INTO `ohrm_user` (`id`, `user_role_id`, `emp_number`, `user_name`, `user_password`, `deleted`, `status`, `date_entered`, `date_modified`, `modified_user_id`, `created_by`) VALUES
(1, 1, NULL, 'Admin', '$2a$12$NbLfiH3bCQWTwMAHASnmI.2KsouJaLkwunxhyOeW..5ntmYFITSi2', 0, 1, NULL, NULL, NULL, NULL),
(2, 3, 2, 'mohamed', '$2a$12$VVqV3iHMBx6sLd4pTj358.IZaNKYewwQmASk0Dq7pXHNQIKYGDJc.', 0, 1, '2015-08-12 11:16:05', NULL, NULL, 1),
(3, 2, 1, 'kortas', '$2a$12$gX02dYFGzeQvfIeKjvLF9eooUMj0DCaIfXXZdsMR2BCzSliriQGsa', 0, 1, '2015-08-19 07:40:10', NULL, NULL, 1);

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_user_role`
--

CREATE TABLE IF NOT EXISTS `ohrm_user_role` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `display_name` varchar(255) NOT NULL,
  `is_assignable` tinyint(1) DEFAULT '0',
  `is_predefined` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_role_name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Contenu de la table `ohrm_user_role`
--

INSERT INTO `ohrm_user_role` (`id`, `name`, `display_name`, `is_assignable`, `is_predefined`) VALUES
(1, 'Admin', 'Admin', 1, 1),
(2, 'ESS', 'ESS', 1, 1),
(3, 'Supervisor', 'Supervisor', 1, 1),
(4, 'ProjectAdmin', 'ProjectAdmin', 0, 1),
(5, 'Interviewer', 'Interviewer', 0, 1),
(6, 'HiringManager', 'HiringManager', 0, 1),
(7, 'Reviewer', 'Reviewer', 0, 1);

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_user_role_data_group`
--

CREATE TABLE IF NOT EXISTS `ohrm_user_role_data_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_role_id` int(11) DEFAULT NULL,
  `data_group_id` int(11) DEFAULT NULL,
  `can_read` tinyint(4) DEFAULT NULL,
  `can_create` tinyint(4) DEFAULT NULL,
  `can_update` tinyint(4) DEFAULT NULL,
  `can_delete` tinyint(4) DEFAULT NULL,
  `self` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_role_id` (`user_role_id`),
  KEY `data_group_id` (`data_group_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=227 ;

--
-- Contenu de la table `ohrm_user_role_data_group`
--

INSERT INTO `ohrm_user_role_data_group` (`id`, `user_role_id`, `data_group_id`, `can_read`, `can_create`, `can_update`, `can_delete`, `self`) VALUES
(1, 1, 1, 1, NULL, 1, NULL, 0),
(2, 1, 2, 1, 1, 1, 1, 0),
(3, 1, 3, 1, NULL, 1, NULL, 0),
(4, 1, 4, 1, NULL, 1, NULL, 0),
(5, 1, 5, 1, 1, 1, 1, 0),
(6, 1, 6, 1, NULL, 1, NULL, 0),
(7, 1, 7, 1, 1, 1, 1, 0),
(8, 1, 8, 1, 1, 1, 1, 0),
(9, 1, 9, 1, NULL, 1, NULL, 0),
(10, 1, 10, 1, 1, 1, 1, 0),
(11, 1, 11, 1, 1, 1, 1, 0),
(12, 1, 12, 1, NULL, 1, NULL, 0),
(13, 1, 13, 1, 1, 1, 1, 0),
(14, 1, 14, 1, 1, 1, 1, 0),
(15, 1, 15, 1, NULL, 1, NULL, 0),
(16, 1, 16, 1, NULL, 1, NULL, 0),
(17, 1, 17, 1, 1, 1, 1, 0),
(18, 1, 18, 1, NULL, 1, NULL, 0),
(19, 1, 19, 1, 1, 1, 1, 0),
(20, 1, 20, 1, 1, 1, 1, 0),
(21, 1, 21, 1, NULL, 1, NULL, 0),
(22, 1, 22, 1, NULL, 1, NULL, 0),
(23, 1, 23, 1, 1, 1, 1, 0),
(24, 1, 24, 1, NULL, 1, NULL, 0),
(25, 1, 25, 1, 1, 1, 1, 0),
(26, 1, 26, 1, 1, 1, 1, 0),
(27, 1, 27, 1, 1, 1, 1, 0),
(28, 1, 28, 1, NULL, 1, NULL, 0),
(29, 1, 29, 1, 1, 1, 1, 0),
(30, 1, 30, 1, 1, 1, 1, 0),
(31, 1, 31, 1, 1, 1, 1, 0),
(32, 1, 32, 1, 1, 1, 1, 0),
(33, 1, 33, 1, 1, 1, 1, 0),
(34, 1, 34, 1, 1, 1, 1, 0),
(35, 1, 35, 1, NULL, 1, NULL, 0),
(36, 1, 36, 1, 1, 1, 1, 0),
(37, 1, 37, 1, 1, 1, 1, 0),
(38, 1, 38, 1, NULL, 1, NULL, 0),
(39, 1, 39, 1, NULL, 1, 1, 0),
(40, 1, 40, 1, 1, 1, 1, 0),
(41, 1, 41, 1, NULL, NULL, NULL, 0),
(42, 1, 40, 1, 1, 1, 1, 1),
(43, 2, 1, 1, NULL, 1, NULL, 1),
(44, 2, 2, 1, 1, 1, 1, 1),
(45, 2, 3, 1, NULL, 1, NULL, 1),
(46, 2, 4, 1, NULL, 1, NULL, 1),
(47, 2, 5, 1, 1, 1, 1, 1),
(48, 2, 6, 1, NULL, 1, NULL, 1),
(49, 2, 7, 1, 1, 1, 1, 1),
(50, 2, 8, 1, 1, 1, 1, 1),
(51, 2, 9, 1, NULL, 1, NULL, 1),
(52, 2, 10, 1, 1, 1, 1, 1),
(53, 2, 11, 1, 1, 1, 1, 1),
(54, 2, 12, 1, NULL, 1, NULL, 1),
(55, 2, 13, 1, 1, 1, 1, 1),
(56, 2, 14, 1, 1, 1, 1, 1),
(57, 2, 15, 1, NULL, 1, NULL, 1),
(58, 2, 16, 1, NULL, NULL, NULL, 1),
(59, 2, 17, 1, 0, 0, 0, 1),
(60, 2, 18, 1, 0, 0, 0, 1),
(61, 2, 19, 1, NULL, NULL, NULL, 1),
(62, 2, 20, 1, 0, 0, 0, 1),
(63, 2, 21, 1, 0, 0, 0, 1),
(64, 2, 22, 1, NULL, NULL, NULL, 1),
(65, 2, 23, 1, 0, 0, 0, 1),
(66, 2, 24, 1, 0, 0, 0, 1),
(67, 2, 25, 1, NULL, NULL, NULL, 1),
(68, 2, 26, 1, NULL, NULL, NULL, 1),
(69, 2, 27, 1, 0, 0, 0, 1),
(70, 2, 28, 1, 0, 0, 0, 1),
(71, 2, 29, 1, 1, 1, 1, 1),
(72, 2, 30, 1, 1, 1, 1, 1),
(73, 2, 31, 1, 1, 1, 1, 1),
(74, 2, 32, 1, 1, 1, 1, 1),
(75, 2, 33, 1, 1, 1, 1, 1),
(76, 2, 34, 1, 1, 1, 1, 1),
(77, 2, 35, 1, NULL, 1, NULL, 1),
(78, 2, 36, 1, 1, 1, 1, 1),
(79, 2, 37, 1, 1, 1, 1, 1),
(80, 2, 38, 1, NULL, 1, NULL, 1),
(81, 2, 39, 1, NULL, 1, 1, 1),
(82, 2, 40, 1, 0, 0, 0, 1),
(83, 2, 41, 1, NULL, NULL, NULL, 1),
(84, 3, 1, 1, NULL, 1, NULL, 0),
(85, 3, 2, 1, 1, 1, 1, 0),
(86, 3, 3, 1, NULL, 1, NULL, 0),
(87, 3, 4, 1, NULL, 1, NULL, 0),
(88, 3, 5, 1, 1, 1, 1, 0),
(89, 3, 6, 1, NULL, 1, NULL, 0),
(90, 3, 7, 1, 1, 1, 1, 0),
(91, 3, 8, 1, 1, 1, 1, 0),
(92, 3, 9, 1, NULL, 1, NULL, 0),
(93, 3, 10, 1, 1, 1, 1, 0),
(94, 3, 11, 1, 1, 1, 1, 0),
(95, 3, 12, 1, NULL, 1, NULL, 0),
(96, 3, 13, 1, 1, 1, 1, 0),
(97, 3, 14, 1, 1, 1, 1, 0),
(98, 3, 15, 1, NULL, 1, NULL, 0),
(99, 3, 16, 1, NULL, NULL, NULL, 0),
(100, 3, 17, 1, 0, 0, 0, 0),
(101, 3, 18, 1, 0, 0, 0, 0),
(102, 3, 19, 0, 0, 0, 0, 0),
(103, 3, 20, 0, 0, 0, 0, 0),
(104, 3, 21, 0, 0, 0, 0, 0),
(105, 3, 22, 1, NULL, NULL, NULL, 0),
(106, 3, 23, 1, 0, 0, 0, 0),
(107, 3, 24, 1, 0, 0, 0, 0),
(108, 3, 25, 1, NULL, NULL, NULL, 0),
(109, 3, 26, 1, NULL, NULL, NULL, 0),
(110, 3, 27, 1, 0, 0, 0, 0),
(111, 3, 28, 1, 0, 0, 0, 0),
(112, 3, 29, 1, 1, 1, 1, 0),
(113, 3, 30, 1, 1, 1, 1, 0),
(114, 3, 31, 1, 1, 1, 1, 0),
(115, 3, 32, 1, 1, 1, 1, 0),
(116, 3, 33, 1, 1, 1, 1, 0),
(117, 3, 34, 1, 1, 1, 1, 0),
(118, 3, 35, 1, NULL, 1, NULL, 0),
(119, 3, 36, 1, 1, 1, 1, 0),
(120, 3, 37, 1, 1, 1, 1, 0),
(121, 3, 38, 1, NULL, 1, NULL, 0),
(122, 3, 39, 1, NULL, 1, 1, 0),
(123, 3, 40, 1, 0, 0, 0, 0),
(124, 3, 41, 1, NULL, NULL, NULL, 0),
(125, 3, 1, 1, NULL, 1, NULL, 1),
(126, 3, 2, 1, 1, 1, 1, 1),
(127, 3, 3, 1, NULL, 1, NULL, 1),
(128, 3, 4, 1, NULL, 1, NULL, 1),
(129, 3, 5, 1, 1, 1, 1, 1),
(130, 3, 6, 1, NULL, 1, NULL, 1),
(131, 3, 7, 1, 1, 1, 1, 1),
(132, 3, 8, 1, 1, 1, 1, 1),
(133, 3, 9, 1, NULL, 1, NULL, 1),
(134, 3, 10, 1, 1, 1, 1, 1),
(135, 3, 11, 1, 1, 1, 1, 1),
(136, 3, 12, 1, NULL, 1, NULL, 1),
(137, 3, 13, 1, 1, 1, 1, 1),
(138, 3, 14, 1, 1, 1, 1, 1),
(139, 3, 15, 1, NULL, 1, NULL, 1),
(140, 3, 16, 1, NULL, NULL, NULL, 1),
(141, 3, 17, 1, 0, 0, 0, 1),
(142, 3, 18, 1, 0, 0, 0, 1),
(143, 3, 19, 1, 0, 0, 0, 1),
(144, 3, 20, 1, 0, 0, 0, 1),
(145, 3, 21, 1, 0, 0, 0, 1),
(146, 3, 22, 1, NULL, NULL, NULL, 1),
(147, 3, 23, 1, 0, 0, 0, 1),
(148, 3, 24, 1, 0, 0, 0, 1),
(149, 3, 25, 1, NULL, NULL, NULL, 1),
(150, 3, 26, 1, NULL, NULL, NULL, 1),
(151, 3, 27, 1, 0, 0, 0, 1),
(152, 3, 28, 1, 0, 0, 0, 1),
(153, 3, 29, 1, 1, 1, 1, 1),
(154, 3, 30, 1, 1, 1, 1, 1),
(155, 3, 31, 1, 1, 1, 1, 1),
(156, 3, 32, 1, 1, 1, 1, 1),
(157, 3, 33, 1, 1, 1, 1, 1),
(158, 3, 34, 1, 1, 1, 1, 1),
(159, 3, 35, 1, NULL, 1, NULL, 1),
(160, 3, 36, 1, 1, 1, 1, 1),
(161, 3, 37, 1, 1, 1, 1, 1),
(162, 3, 38, 1, NULL, 1, NULL, 1),
(163, 3, 39, 1, NULL, 1, 1, 1),
(164, 3, 40, 1, 0, 0, 0, 1),
(165, 3, 41, 1, NULL, NULL, NULL, 1),
(166, 1, 42, 1, 1, 1, 1, 0),
(167, 2, 42, 0, 0, 0, 0, 0),
(168, 3, 42, 0, 0, 0, 0, 0),
(169, 1, 43, 1, 1, 1, 1, 0),
(170, 2, 43, 0, 0, 0, 0, 0),
(171, 3, 43, 0, 0, 0, 0, 0),
(172, 1, 44, 1, 1, 1, 1, 0),
(173, 2, 44, 0, 0, 0, 0, 0),
(174, 3, 44, 0, 0, 0, 0, 0),
(175, 1, 45, 1, 1, 1, 1, 0),
(176, 2, 45, 0, 0, 0, 0, 0),
(177, 3, 45, 0, 0, 0, 0, 0),
(178, 4, 45, 1, 0, 1, 0, 0),
(179, 1, 46, 1, 1, 1, 1, 0),
(180, 2, 46, 0, 0, 0, 0, 0),
(181, 3, 46, 0, 0, 0, 0, 0),
(182, 1, 47, 1, NULL, 1, NULL, 0),
(183, 2, 47, 0, 0, 0, 0, 0),
(184, 3, 47, 0, 0, 0, 0, 0),
(185, 1, 48, 1, 0, 0, 0, 0),
(186, 2, 48, 0, 0, 0, 0, 0),
(187, 2, 48, 1, 0, 0, 0, 1),
(188, 3, 48, 1, 0, 0, 0, 0),
(189, 1, 49, 1, 0, 0, 0, 0),
(190, 2, 49, 0, 0, 0, 0, 0),
(191, 3, 49, 0, 0, 0, 0, 0),
(192, 4, 49, 1, 0, 0, 0, 0),
(193, 1, 50, 1, 0, 0, 0, 0),
(194, 2, 50, 0, 0, 0, 0, 0),
(195, 3, 50, 1, 0, 0, 0, 0),
(196, 1, 51, 1, 0, 0, 0, 0),
(197, 2, 51, 0, 0, 0, 0, 0),
(198, 3, 51, 1, 0, 0, 0, 0),
(199, 1, 52, 1, NULL, 1, NULL, 0),
(200, 2, 52, 0, 0, 0, 0, 0),
(201, 3, 52, 0, 0, 0, 0, 0),
(202, 1, 53, 1, 1, 1, 1, 0),
(203, 2, 53, 0, 0, 0, 0, 0),
(204, 3, 53, 0, 0, 0, 0, 0),
(205, 1, 54, 1, 0, 1, 0, 0),
(206, 2, 54, 0, 0, 0, 0, 0),
(207, 3, 54, 0, 0, 0, 0, 0),
(208, 1, 55, 1, 1, 1, 1, 0),
(209, 2, 55, 0, 0, 0, 0, 0),
(210, 3, 55, 0, 0, 0, 0, 0),
(211, 1, 56, 1, 1, 1, 1, 0),
(212, 2, 56, 0, 0, 0, 0, 0),
(213, 3, 56, 0, 0, 0, 0, 0),
(214, 1, 57, 1, 1, 1, 1, 0),
(215, 6, 57, 1, 1, 1, 1, 0),
(216, 5, 57, 1, 0, 1, 0, 0),
(217, 1, 58, 1, 0, 0, 0, 0),
(218, 2, 58, 0, 0, 0, 0, 0),
(219, 2, 58, 1, 0, 0, 0, 1),
(220, 3, 58, 1, 0, 0, 0, 0),
(221, 1, 59, 1, 0, 0, 0, 0),
(222, 2, 59, 1, 0, 0, 0, 1),
(223, 3, 59, 1, 0, 0, 0, 0),
(224, 1, 60, 0, 1, 0, 0, 0),
(225, 2, 60, 0, 1, 0, 0, 1),
(226, 3, 60, 0, 1, 0, 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_user_role_screen`
--

CREATE TABLE IF NOT EXISTS `ohrm_user_role_screen` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_role_id` int(11) NOT NULL,
  `screen_id` int(11) NOT NULL,
  `can_read` tinyint(1) NOT NULL DEFAULT '0',
  `can_create` tinyint(1) NOT NULL DEFAULT '0',
  `can_update` tinyint(1) NOT NULL DEFAULT '0',
  `can_delete` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `user_role_id` (`user_role_id`),
  KEY `screen_id` (`screen_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=157 ;

--
-- Contenu de la table `ohrm_user_role_screen`
--

INSERT INTO `ohrm_user_role_screen` (`id`, `user_role_id`, `screen_id`, `can_read`, `can_create`, `can_update`, `can_delete`) VALUES
(1, 1, 1, 1, 1, 1, 1),
(2, 1, 2, 1, 1, 1, 1),
(3, 2, 2, 0, 0, 0, 0),
(4, 3, 2, 0, 0, 0, 0),
(5, 1, 3, 1, 1, 1, 1),
(6, 2, 3, 0, 0, 0, 0),
(7, 3, 3, 0, 0, 0, 0),
(8, 1, 4, 1, 1, 1, 1),
(9, 1, 5, 1, 1, 1, 1),
(10, 3, 5, 1, 0, 0, 0),
(11, 1, 6, 1, 0, 0, 1),
(12, 1, 7, 1, 1, 1, 1),
(13, 1, 8, 1, 1, 1, 1),
(14, 1, 9, 1, 1, 1, 1),
(15, 1, 10, 1, 1, 1, 1),
(16, 1, 11, 1, 1, 1, 1),
(17, 1, 12, 1, 1, 1, 1),
(18, 1, 13, 1, 1, 1, 1),
(19, 1, 14, 1, 1, 1, 1),
(20, 1, 16, 1, 1, 1, 0),
(21, 3, 16, 1, 1, 1, 0),
(22, 1, 17, 1, 1, 1, 0),
(23, 3, 17, 1, 1, 1, 0),
(24, 1, 18, 1, 1, 1, 0),
(25, 2, 18, 1, 0, 0, 0),
(26, 3, 18, 1, 0, 0, 0),
(27, 1, 19, 1, 1, 1, 1),
(28, 1, 20, 1, 1, 1, 1),
(29, 1, 21, 1, 1, 1, 1),
(30, 1, 22, 1, 1, 1, 1),
(31, 1, 23, 1, 1, 1, 1),
(32, 1, 24, 1, 1, 1, 1),
(33, 1, 25, 1, 1, 1, 1),
(34, 1, 26, 1, 1, 1, 1),
(35, 1, 27, 1, 1, 1, 1),
(36, 1, 28, 1, 1, 1, 1),
(37, 1, 29, 1, 1, 1, 1),
(38, 1, 30, 1, 1, 1, 1),
(39, 1, 31, 1, 1, 1, 1),
(40, 1, 32, 1, 1, 1, 1),
(41, 1, 33, 1, 1, 1, 1),
(42, 1, 34, 1, 1, 1, 1),
(43, 1, 35, 1, 1, 1, 1),
(44, 1, 36, 1, 1, 1, 1),
(45, 1, 37, 1, 1, 1, 1),
(46, 4, 37, 1, 0, 0, 0),
(47, 1, 38, 1, 1, 1, 1),
(48, 1, 39, 1, 1, 1, 1),
(49, 1, 40, 1, 1, 1, 1),
(50, 1, 41, 1, 1, 1, 1),
(51, 1, 42, 1, 1, 1, 1),
(52, 1, 43, 1, 1, 1, 1),
(53, 1, 44, 1, 1, 1, 1),
(54, 1, 45, 1, 1, 1, 1),
(55, 2, 46, 1, 1, 1, 1),
(56, 1, 47, 1, 1, 1, 1),
(57, 2, 48, 1, 1, 1, 0),
(58, 2, 49, 1, 1, 1, 1),
(59, 1, 50, 1, 1, 1, 1),
(60, 2, 51, 1, 1, 1, 1),
(61, 1, 52, 1, 1, 1, 1),
(62, 3, 52, 1, 1, 1, 1),
(63, 2, 53, 1, 1, 0, 0),
(64, 2, 54, 1, 1, 1, 1),
(65, 1, 55, 1, 1, 0, 1),
(66, 3, 55, 1, 1, 0, 0),
(67, 1, 56, 1, 1, 1, 1),
(68, 1, 57, 1, 1, 1, 1),
(69, 4, 57, 1, 1, 1, 1),
(70, 1, 58, 1, 1, 1, 1),
(71, 3, 58, 1, 1, 1, 1),
(72, 1, 59, 1, 1, 1, 1),
(73, 3, 59, 1, 1, 1, 1),
(74, 1, 60, 1, 1, 1, 1),
(75, 6, 60, 1, 1, 1, 1),
(76, 5, 60, 1, 0, 1, 0),
(77, 1, 61, 1, 1, 1, 1),
(78, 1, 67, 1, 1, 1, 1),
(79, 2, 67, 1, 0, 1, 0),
(80, 3, 67, 1, 0, 1, 0),
(81, 1, 68, 1, 1, 1, 1),
(82, 2, 68, 1, 0, 1, 0),
(83, 3, 68, 1, 0, 1, 0),
(84, 1, 69, 1, 1, 1, 1),
(85, 3, 69, 1, 0, 0, 0),
(86, 2, 70, 1, 0, 0, 0),
(87, 1, 71, 1, 0, 0, 1),
(88, 1, 72, 1, 1, 1, 0),
(89, 1, 73, 1, 0, 1, 0),
(90, 1, 74, 1, 1, 1, 1),
(91, 1, 75, 1, 1, 1, 1),
(92, 3, 75, 1, 1, 1, 1),
(93, 1, 76, 1, 1, 1, 1),
(94, 5, 76, 1, 1, 1, 1),
(95, 6, 76, 1, 1, 1, 1),
(96, 1, 78, 1, 0, 0, 0),
(97, 3, 78, 1, 0, 0, 0),
(98, 2, 79, 1, 0, 0, 0),
(99, 1, 80, 1, 1, 1, 1),
(100, 1, 81, 1, 1, 1, 1),
(101, 1, 82, 1, 1, 1, 1),
(102, 1, 83, 1, 1, 1, 1),
(103, 1, 84, 1, 1, 1, 1),
(104, 1, 85, 1, 1, 1, 1),
(105, 1, 86, 1, 1, 1, 1),
(106, 1, 87, 1, 1, 1, 1),
(107, 1, 88, 1, 1, 1, 1),
(108, 4, 88, 1, 1, 1, 1),
(109, 1, 89, 1, 1, 1, 1),
(110, 1, 90, 1, 1, 1, 1),
(111, 4, 90, 1, 1, 1, 1),
(112, 1, 91, 1, 1, 1, 1),
(113, 4, 91, 1, 1, 1, 1),
(114, 1, 92, 1, 1, 1, 1),
(115, 1, 93, 1, 1, 1, 1),
(116, 1, 94, 1, 1, 1, 1),
(117, 1, 95, 1, 1, 1, 1),
(118, 1, 96, 1, 1, 1, 1),
(119, 5, 96, 1, 1, 1, 1),
(120, 6, 96, 1, 1, 1, 1),
(121, 1, 97, 1, 1, 1, 1),
(122, 6, 97, 1, 1, 1, 1),
(123, 1, 98, 1, 1, 1, 1),
(124, 2, 98, 1, 1, 1, 1),
(125, 3, 98, 1, 1, 1, 1),
(126, 1, 99, 1, 0, 1, 0),
(127, 2, 99, 1, 0, 1, 0),
(128, 3, 99, 1, 0, 1, 0),
(129, 1, 100, 1, 0, 0, 0),
(130, 1, 101, 1, 1, 1, 1),
(131, 3, 101, 1, 1, 1, 1),
(132, 1, 102, 1, 1, 1, 1),
(133, 4, 102, 1, 1, 1, 1),
(134, 1, 103, 1, 0, 0, 0),
(135, 2, 103, 1, 0, 0, 0),
(136, 1, 104, 1, 1, 1, 0),
(137, 1, 105, 1, 1, 1, 1),
(138, 1, 107, 1, 1, 1, 0),
(139, 1, 109, 1, 1, 1, 0),
(140, 1, 111, 1, 1, 1, 1),
(141, 2, 110, 1, 0, 1, 0),
(142, 2, 108, 1, 1, 1, 0),
(143, 2, 106, 1, 0, 1, 0),
(144, 3, 109, 1, 1, 1, 0),
(145, 2, 109, 1, 1, 1, 0),
(146, 1, 112, 1, 1, 1, 1),
(147, 2, 112, 0, 0, 0, 0),
(148, 1, 113, 1, 1, 1, 1),
(149, 2, 113, 1, 1, 1, 0),
(150, 1, 114, 0, 0, 0, 0),
(151, 2, 114, 1, 0, 1, 0),
(152, 1, 115, 1, 1, 1, 0),
(153, 2, 115, 1, 0, 0, 0),
(154, 1, 116, 1, 1, 1, 1),
(155, 2, 116, 1, 1, 1, 1),
(156, 1, 117, 1, 1, 1, 0);

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_user_selection_rule`
--

CREATE TABLE IF NOT EXISTS `ohrm_user_selection_rule` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `implementation_class` varchar(255) NOT NULL,
  `rule_xml_data` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_workflow_state_machine`
--

CREATE TABLE IF NOT EXISTS `ohrm_workflow_state_machine` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `workflow` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL,
  `action` varchar(255) NOT NULL,
  `resulting_state` varchar(255) NOT NULL,
  `roles_to_notify` text,
  `priority` int(11) NOT NULL DEFAULT '0' COMMENT 'lowest priority 0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=107 ;

--
-- Contenu de la table `ohrm_workflow_state_machine`
--

INSERT INTO `ohrm_workflow_state_machine` (`id`, `workflow`, `state`, `role`, `action`, `resulting_state`, `roles_to_notify`, `priority`) VALUES
(1, '0', 'INITIAL', 'SYSTEM', '7', 'NOT SUBMITTED', '', 0),
(2, '0', 'SUBMITTED', 'ADMIN', '2', 'APPROVED', '', 0),
(3, '0', 'SUBMITTED', 'ADMIN', '3', 'REJECTED', '', 0),
(4, '0', 'SUBMITTED', 'ADMIN', '0', 'SUBMITTED', '', 0),
(5, '0', 'SUBMITTED', 'ADMIN', '5', 'SUBMITTED', '', 0),
(6, '0', 'SUBMITTED', 'SUPERVISOR', '2', 'APPROVED', '', 0),
(7, '0', 'SUBMITTED', 'SUPERVISOR', '3', 'REJECTED', '', 0),
(8, '0', 'SUBMITTED', 'SUPERVISOR', '5', 'SUBMITTED', '', 0),
(9, '0', 'SUBMITTED', 'SUPERVISOR', '0', 'SUBMITTED', '', 0),
(10, '0', 'SUBMITTED', 'ESS USER', '0', 'SUBMITTED', '', 0),
(11, '0', 'SUBMITTED', 'ESS USER', '5', 'SUBMITTED', '', 0),
(12, '0', 'NOT SUBMITTED', 'ESS USER', '1', 'SUBMITTED', '', 0),
(13, '0', 'NOT SUBMITTED', 'ESS USER', '5', 'NOT SUBMITTED', '', 0),
(15, '0', 'NOT SUBMITTED', 'ESS USER', '0', 'NOT SUBMITTED', '', 0),
(16, '0', 'NOT SUBMITTED', 'SUPERVISOR', '0', 'NOT SUBMITTED', '', 0),
(17, '0', 'NOT SUBMITTED', 'SUPERVISOR', '5', 'NOT SUBMITTED', '', 0),
(18, '0', 'NOT SUBMITTED', 'SUPERVISOR', '1', 'SUBMITTED', '', 0),
(19, '0', 'NOT SUBMITTED', 'ADMIN', '0', 'NOT SUBMITTED', '', 0),
(20, '0', 'NOT SUBMITTED', 'ADMIN', '5', 'NOT SUBMITTED', '', 0),
(21, '0', 'NOT SUBMITTED', 'ADMIN', '1', 'SUBMITTED', '', 0),
(22, '0', 'REJECTED', 'ESS USER', '1', 'SUBMITTED', '', 0),
(23, '0', 'REJECTED', 'ESS USER', '0', 'REJECTED', '', 0),
(24, '0', 'REJECTED', 'ESS USER', '5', 'REJECTED', '', 0),
(25, '0', 'REJECTED', 'SUPERVISOR', '1', 'SUBMITTED', '', 0),
(26, '0', 'REJECTED', 'SUPERVISOR', '0', 'REJECTED', '', 0),
(27, '0', 'REJECTED', 'SUPERVISOR', '5', 'REJECTED', '', 0),
(28, '0', 'REJECTED', 'ADMIN', '0', 'REJECTED', '', 0),
(29, '0', 'REJECTED', 'ADMIN', '5', 'SUBMITTED', '', 0),
(30, '0', 'REJECTED', 'ADMIN', '1', 'SUBMITTED', '', 0),
(31, '0', 'APPROVED', 'ESS USER', '0', 'APPROVED', '', 0),
(32, '0', 'APPROVED', 'SUPERVISOR', '0', 'APPROVED', '', 0),
(33, '0', 'APPROVED', 'ADMIN', '0', 'APPROVED', '', 0),
(34, '0', 'APPROVED', 'ADMIN', '4', 'SUBMITTED', '', 0),
(35, '1', 'PUNCHED IN', 'ESS USER', '1', 'PUNCHED OUT', '', 0),
(36, '1', 'INITIAL', 'ESS USER', '0', 'PUNCHED IN', '', 0),
(37, '2', 'INITIAL', 'ADMIN', '1', 'APPLICATION INITIATED', '', 0),
(38, '2', 'APPLICATION INITIATED', 'ADMIN', '2', 'SHORTLISTED', '', 0),
(39, '2', 'APPLICATION INITIATED', 'ADMIN', '3', 'REJECTED', '', 0),
(40, '2', 'SHORTLISTED', 'ADMIN', '4', 'INTERVIEW SCHEDULED', '', 0),
(41, '2', 'SHORTLISTED', 'ADMIN', '3', 'REJECTED', '', 0),
(42, '2', 'INTERVIEW SCHEDULED', 'ADMIN', '3', 'REJECTED', '', 0),
(43, '2', 'INTERVIEW SCHEDULED', 'ADMIN', '5', 'INTERVIEW PASSED', '', 0),
(44, '2', 'INTERVIEW SCHEDULED', 'ADMIN', '6', 'INTERVIEW FAILED', '', 0),
(45, '2', 'INTERVIEW PASSED', 'ADMIN', '4', 'INTERVIEW SCHEDULED', '', 0),
(46, '2', 'INTERVIEW PASSED', 'ADMIN', '7', 'JOB OFFERED', '', 0),
(47, '2', 'INTERVIEW PASSED', 'ADMIN', '3', 'REJECTED', '', 0),
(48, '2', 'INTERVIEW FAILED', 'ADMIN', '3', 'REJECTED', '', 0),
(49, '2', 'JOB OFFERED', 'ADMIN', '8', 'OFFER DECLINED', '', 0),
(50, '2', 'JOB OFFERED', 'ADMIN', '3', 'REJECTED', '', 0),
(51, '2', 'JOB OFFERED', 'ADMIN', '9', 'HIRED', '', 0),
(52, '2', 'OFFER DECLINED', 'ADMIN', '3', 'REJECTED', '', 0),
(53, '2', 'INITIAL', 'HIRING MANAGER', '1', 'APPLICATION INITIATED', '', 0),
(54, '2', 'APPLICATION INITIATED', 'HIRING MANAGER', '2', 'SHORTLISTED', '', 0),
(55, '2', 'APPLICATION INITIATED', 'HIRING MANAGER', '3', 'REJECTED', '', 0),
(56, '2', 'SHORTLISTED', 'HIRING MANAGER', '4', 'INTERVIEW SCHEDULED', '', 0),
(57, '2', 'SHORTLISTED', 'HIRING MANAGER', '3', 'REJECTED', '', 0),
(58, '2', 'INTERVIEW SCHEDULED', 'HIRING MANAGER', '3', 'REJECTED', '', 0),
(59, '2', 'INTERVIEW SCHEDULED', 'HIRING MANAGER', '5', 'INTERVIEW PASSED', '', 0),
(60, '2', 'INTERVIEW SCHEDULED', 'HIRING MANAGER', '6', 'INTERVIEW FAILED', '', 0),
(61, '2', 'INTERVIEW PASSED', 'HIRING MANAGER', '4', 'INTERVIEW SCHEDULED', '', 0),
(62, '2', 'INTERVIEW PASSED', 'HIRING MANAGER', '7', 'JOB OFFERED', '', 0),
(63, '2', 'INTERVIEW PASSED', 'HIRING MANAGER', '3', 'REJECTED', '', 0),
(64, '2', 'INTERVIEW FAILED', 'HIRING MANAGER', '3', 'REJECTED', '', 0),
(65, '2', 'JOB OFFERED', 'HIRING MANAGER', '8', 'OFFER DECLINED', '', 0),
(66, '2', 'JOB OFFERED', 'HIRING MANAGER', '3', 'REJECTED', '', 0),
(67, '2', 'JOB OFFERED', 'HIRING MANAGER', '9', 'HIRED', '', 0),
(68, '2', 'OFFER DECLINED', 'HIRING MANAGER', '3', 'REJECTED', '', 0),
(69, '2', 'INTERVIEW SCHEDULED', 'INTERVIEWER', '5', 'INTERVIEW PASSED', '', 0),
(70, '2', 'INTERVIEW SCHEDULED', 'INTERVIEWER', '6', 'INTERVIEW FAILED', '', 0),
(71, '1', 'INITIAL', 'ADMIN', '5', 'PUNCHED IN', '', 0),
(72, '1', 'PUNCHED IN', 'ADMIN', '6', 'PUNCHED OUT', '', 0),
(73, '1', 'PUNCHED IN', 'ADMIN', '2', 'PUNCHED IN', '', 0),
(74, '1', 'PUNCHED IN', 'ADMIN', '7', 'N/A', '', 0),
(75, '1', 'PUNCHED OUT', 'ADMIN', '2', 'PUNCHED OUT', '', 0),
(76, '1', 'PUNCHED OUT', 'ADMIN', '3', 'PUNCHED OUT', '', 0),
(77, '1', 'PUNCHED OUT', 'ADMIN', '7', 'N/A', '', 0),
(78, '0', 'INITIAL', 'ADMIN', '7', 'NOT SUBMITTED', '', 0),
(79, '0', 'INITIAL', 'ESS USER', '7', 'NOT SUBMITTED', '', 0),
(80, '0', 'INITIAL', 'SUPERVISOR', '7', 'NOT SUBMITTED', '', 0),
(81, '3', 'NOT_EXIST', 'ADMIN', '1', 'ACTIVE', '', 0),
(82, '3', 'ACTIVE', 'ADMIN', '2', 'NOT_EXIST', '', 0),
(83, '3', 'ACTIVE', 'ADMIN', '3', 'TERMINATED', '', 0),
(84, '3', 'TERMINATED', 'ADMIN', '4', 'ACTIVE', '', 0),
(85, '3', 'TERMINATED', 'ADMIN', '5', 'NOT_EXIST', '', 0),
(86, '4', 'INITIAL', 'ESS', 'APPLY', 'PENDING APPROVAL', 'supervisor,subscriber', 0),
(87, '4', 'INITIAL', 'ADMIN', 'ASSIGN', 'SCHEDULED', 'ess,supervisor,subscriber', 0),
(88, '4', 'INITIAL', 'SUPERVISOR', 'ASSIGN', 'SCHEDULED', 'ess,supervisor,subscriber', 0),
(89, '4', 'PENDING APPROVAL', 'ADMIN', 'APPROVE', 'SCHEDULED', 'ess,subscriber', 0),
(90, '4', 'PENDING APPROVAL', 'SUPERVISOR', 'APPROVE', 'SCHEDULED', 'ess,subscriber', 0),
(91, '4', 'PENDING APPROVAL', 'ESS', 'CANCEL', 'CANCELLED', 'supervisor,subscriber', 0),
(92, '4', 'PENDING APPROVAL', 'ADMIN', 'CANCEL', 'CANCELLED', 'ess,subscriber', 0),
(93, '4', 'PENDING APPROVAL', 'SUPERVISOR', 'CANCEL', 'CANCELLED', 'ess,subscriber', 0),
(94, '4', 'PENDING APPROVAL', 'ADMIN', 'REJECT', 'REJECTED', 'ess,subscriber', 0),
(95, '4', 'PENDING APPROVAL', 'SUPERVISOR', 'REJECT', 'REJECTED', 'ess,subscriber', 0),
(96, '4', 'SCHEDULED', 'ESS', 'CANCEL', 'CANCELLED', 'supervisor,subscriber', 0),
(97, '4', 'SCHEDULED', 'ADMIN', 'CANCEL', 'CANCELLED', 'ess,subscriber', 0),
(98, '4', 'SCHEDULED', 'SUPERVISOR', 'CANCEL', 'CANCELLED', 'ess,subscriber', 0),
(99, '4', 'TAKEN', 'ADMIN', 'CANCEL', 'CANCELLED', 'ess,subscriber', 0),
(100, '4', 'LEAVE TYPE DELETED PENDING APPROVAL', 'ESS', 'CANCEL', 'CANCELLED', 'supervisor,subscriber', 0),
(101, '4', 'LEAVE TYPE DELETED PENDING APPROVAL', 'ADMIN', 'CANCEL', 'CANCELLED', 'ess,subscriber', 0),
(102, '4', 'LEAVE TYPE DELETED PENDING APPROVAL', 'SUPERVISOR', 'CANCEL', 'CANCELLED', 'ess,subscriber', 0),
(103, '4', 'LEAVE TYPE DELETED SCHEDULED', 'ESS', 'CANCEL', 'CANCELLED', 'supervisor,subscriber', 0),
(104, '4', 'LEAVE TYPE DELETED SCHEDULED', 'ADMIN', 'CANCEL', 'CANCELLED', 'ess,subscriber', 0),
(105, '4', 'LEAVE TYPE DELETED SCHEDULED', 'SUPERVISOR', 'CANCEL', 'CANCELLED', 'ess,subscriber', 0),
(106, '4', 'LEAVE TYPE DELETED TAKEN', 'ADMIN', 'CANCEL', 'CANCELLED', 'ess,subscriber', 0);

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_work_shift`
--

CREATE TABLE IF NOT EXISTS `ohrm_work_shift` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `hours_per_day` decimal(4,2) NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Contenu de la table `ohrm_work_shift`
--

INSERT INTO `ohrm_work_shift` (`id`, `name`, `hours_per_day`, `start_time`, `end_time`) VALUES
(1, 'Séance été', '6.50', '07:30:00', '14:00:00'),
(2, 'Séance Hiver', '9.00', '08:30:00', '17:30:00');

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_work_week`
--

CREATE TABLE IF NOT EXISTS `ohrm_work_week` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `operational_country_id` int(10) unsigned DEFAULT NULL,
  `mon` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `tue` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `wed` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `thu` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `fri` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `sat` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `sun` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_ohrm_work_week_ohrm_operational_country` (`operational_country_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Contenu de la table `ohrm_work_week`
--

INSERT INTO `ohrm_work_week` (`id`, `operational_country_id`, `mon`, `tue`, `wed`, `thu`, `fri`, `sat`, `sun`) VALUES
(1, NULL, 0, 0, 0, 0, 0, 8, 8);

-- --------------------------------------------------------

--
-- Structure de la table `ohrm_ws_consumer`
--

CREATE TABLE IF NOT EXISTS `ohrm_ws_consumer` (
  `app_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `app_token` varchar(10) NOT NULL,
  `app_name` varchar(50) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`app_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `hs_hr_employee`
--
ALTER TABLE `hs_hr_employee`
  ADD CONSTRAINT `hs_hr_employee_ibfk_6` FOREIGN KEY (`termination_id`) REFERENCES `ohrm_emp_termination` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `hs_hr_employee_ibfk_1` FOREIGN KEY (`work_station`) REFERENCES `ohrm_subunit` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `hs_hr_employee_ibfk_2` FOREIGN KEY (`nation_code`) REFERENCES `ohrm_nationality` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `hs_hr_employee_ibfk_3` FOREIGN KEY (`job_title_code`) REFERENCES `ohrm_job_title` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `hs_hr_employee_ibfk_4` FOREIGN KEY (`emp_status`) REFERENCES `ohrm_employment_status` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `hs_hr_employee_ibfk_5` FOREIGN KEY (`eeo_cat_code`) REFERENCES `ohrm_job_category` (`id`) ON DELETE SET NULL;

--
-- Contraintes pour la table `hs_hr_emp_attachment`
--
ALTER TABLE `hs_hr_emp_attachment`
  ADD CONSTRAINT `hs_hr_emp_attachment_ibfk_1` FOREIGN KEY (`emp_number`) REFERENCES `hs_hr_employee` (`emp_number`) ON DELETE CASCADE;

--
-- Contraintes pour la table `hs_hr_emp_basicsalary`
--
ALTER TABLE `hs_hr_emp_basicsalary`
  ADD CONSTRAINT `hs_hr_emp_basicsalary_ibfk_4` FOREIGN KEY (`payperiod_code`) REFERENCES `hs_hr_payperiod` (`payperiod_code`) ON DELETE CASCADE,
  ADD CONSTRAINT `hs_hr_emp_basicsalary_ibfk_1` FOREIGN KEY (`sal_grd_code`) REFERENCES `ohrm_pay_grade` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `hs_hr_emp_basicsalary_ibfk_2` FOREIGN KEY (`currency_id`) REFERENCES `hs_hr_currency_type` (`currency_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `hs_hr_emp_basicsalary_ibfk_3` FOREIGN KEY (`emp_number`) REFERENCES `hs_hr_employee` (`emp_number`) ON DELETE CASCADE;

--
-- Contraintes pour la table `hs_hr_emp_children`
--
ALTER TABLE `hs_hr_emp_children`
  ADD CONSTRAINT `hs_hr_emp_children_ibfk_1` FOREIGN KEY (`emp_number`) REFERENCES `hs_hr_employee` (`emp_number`) ON DELETE CASCADE;

--
-- Contraintes pour la table `hs_hr_emp_contract_extend`
--
ALTER TABLE `hs_hr_emp_contract_extend`
  ADD CONSTRAINT `hs_hr_emp_contract_extend_ibfk_1` FOREIGN KEY (`emp_number`) REFERENCES `hs_hr_employee` (`emp_number`) ON DELETE CASCADE;

--
-- Contraintes pour la table `hs_hr_emp_dependents`
--
ALTER TABLE `hs_hr_emp_dependents`
  ADD CONSTRAINT `hs_hr_emp_dependents_ibfk_1` FOREIGN KEY (`emp_number`) REFERENCES `hs_hr_employee` (`emp_number`) ON DELETE CASCADE;

--
-- Contraintes pour la table `hs_hr_emp_directdebit`
--
ALTER TABLE `hs_hr_emp_directdebit`
  ADD CONSTRAINT `hs_hr_emp_directdebit_ibfk_1` FOREIGN KEY (`salary_id`) REFERENCES `hs_hr_emp_basicsalary` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `hs_hr_emp_emergency_contacts`
--
ALTER TABLE `hs_hr_emp_emergency_contacts`
  ADD CONSTRAINT `hs_hr_emp_emergency_contacts_ibfk_1` FOREIGN KEY (`emp_number`) REFERENCES `hs_hr_employee` (`emp_number`) ON DELETE CASCADE;

--
-- Contraintes pour la table `hs_hr_emp_history_of_ealier_pos`
--
ALTER TABLE `hs_hr_emp_history_of_ealier_pos`
  ADD CONSTRAINT `hs_hr_emp_history_of_ealier_pos_ibfk_1` FOREIGN KEY (`emp_number`) REFERENCES `hs_hr_employee` (`emp_number`) ON DELETE CASCADE;

--
-- Contraintes pour la table `hs_hr_emp_language`
--
ALTER TABLE `hs_hr_emp_language`
  ADD CONSTRAINT `hs_hr_emp_language_ibfk_2` FOREIGN KEY (`lang_id`) REFERENCES `ohrm_language` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `hs_hr_emp_language_ibfk_1` FOREIGN KEY (`emp_number`) REFERENCES `hs_hr_employee` (`emp_number`) ON DELETE CASCADE;

--
-- Contraintes pour la table `hs_hr_emp_locations`
--
ALTER TABLE `hs_hr_emp_locations`
  ADD CONSTRAINT `hs_hr_emp_locations_ibfk_1` FOREIGN KEY (`location_id`) REFERENCES `ohrm_location` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `hs_hr_emp_locations_ibfk_2` FOREIGN KEY (`emp_number`) REFERENCES `hs_hr_employee` (`emp_number`) ON DELETE CASCADE;

--
-- Contraintes pour la table `hs_hr_emp_member_detail`
--
ALTER TABLE `hs_hr_emp_member_detail`
  ADD CONSTRAINT `hs_hr_emp_member_detail_ibfk_2` FOREIGN KEY (`emp_number`) REFERENCES `hs_hr_employee` (`emp_number`) ON DELETE CASCADE,
  ADD CONSTRAINT `hs_hr_emp_member_detail_ibfk_1` FOREIGN KEY (`membship_code`) REFERENCES `ohrm_membership` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `hs_hr_emp_passport`
--
ALTER TABLE `hs_hr_emp_passport`
  ADD CONSTRAINT `hs_hr_emp_passport_ibfk_1` FOREIGN KEY (`emp_number`) REFERENCES `hs_hr_employee` (`emp_number`) ON DELETE CASCADE;

--
-- Contraintes pour la table `hs_hr_emp_picture`
--
ALTER TABLE `hs_hr_emp_picture`
  ADD CONSTRAINT `hs_hr_emp_picture_ibfk_1` FOREIGN KEY (`emp_number`) REFERENCES `hs_hr_employee` (`emp_number`) ON DELETE CASCADE;

--
-- Contraintes pour la table `hs_hr_emp_reportto`
--
ALTER TABLE `hs_hr_emp_reportto`
  ADD CONSTRAINT `hs_hr_emp_reportto_ibfk_3` FOREIGN KEY (`erep_reporting_mode`) REFERENCES `ohrm_emp_reporting_method` (`reporting_method_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `hs_hr_emp_reportto_ibfk_1` FOREIGN KEY (`erep_sup_emp_number`) REFERENCES `hs_hr_employee` (`emp_number`) ON DELETE CASCADE,
  ADD CONSTRAINT `hs_hr_emp_reportto_ibfk_2` FOREIGN KEY (`erep_sub_emp_number`) REFERENCES `hs_hr_employee` (`emp_number`) ON DELETE CASCADE;

--
-- Contraintes pour la table `hs_hr_emp_skill`
--
ALTER TABLE `hs_hr_emp_skill`
  ADD CONSTRAINT `hs_hr_emp_skill_ibfk_2` FOREIGN KEY (`skill_id`) REFERENCES `ohrm_skill` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `hs_hr_emp_skill_ibfk_1` FOREIGN KEY (`emp_number`) REFERENCES `hs_hr_employee` (`emp_number`) ON DELETE CASCADE;

--
-- Contraintes pour la table `hs_hr_emp_us_tax`
--
ALTER TABLE `hs_hr_emp_us_tax`
  ADD CONSTRAINT `hs_hr_emp_us_tax_ibfk_1` FOREIGN KEY (`emp_number`) REFERENCES `hs_hr_employee` (`emp_number`) ON DELETE CASCADE;

--
-- Contraintes pour la table `hs_hr_emp_work_experience`
--
ALTER TABLE `hs_hr_emp_work_experience`
  ADD CONSTRAINT `hs_hr_emp_work_experience_ibfk_1` FOREIGN KEY (`emp_number`) REFERENCES `hs_hr_employee` (`emp_number`) ON DELETE CASCADE;

--
-- Contraintes pour la table `hs_hr_jobtit_empstat`
--
ALTER TABLE `hs_hr_jobtit_empstat`
  ADD CONSTRAINT `hs_hr_jobtit_empstat_ibfk_2` FOREIGN KEY (`estat_code`) REFERENCES `ohrm_employment_status` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `hs_hr_jobtit_empstat_ibfk_1` FOREIGN KEY (`jobtit_code`) REFERENCES `ohrm_job_title` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `hs_hr_mailnotifications`
--
ALTER TABLE `hs_hr_mailnotifications`
  ADD CONSTRAINT `hs_hr_mailnotifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `ohrm_user` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `ohrm_auth_provider_extra_details`
--
ALTER TABLE `ohrm_auth_provider_extra_details`
  ADD CONSTRAINT `ohrm_auth_provider_extra_details_ibfk_1` FOREIGN KEY (`provider_id`) REFERENCES `ohrm_openid_provider` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `ohrm_available_group_field`
--
ALTER TABLE `ohrm_available_group_field`
  ADD CONSTRAINT `ohrm_available_group_field_ibfk_1` FOREIGN KEY (`group_field_id`) REFERENCES `ohrm_group_field` (`group_field_id`);

--
-- Contraintes pour la table `ohrm_composite_display_field`
--
ALTER TABLE `ohrm_composite_display_field`
  ADD CONSTRAINT `ohrm_composite_display_field_ibfk_2` FOREIGN KEY (`display_field_group_id`) REFERENCES `ohrm_display_field_group` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `ohrm_composite_display_field_ibfk_1` FOREIGN KEY (`report_group_id`) REFERENCES `ohrm_report_group` (`report_group_id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `ohrm_datapoint`
--
ALTER TABLE `ohrm_datapoint`
  ADD CONSTRAINT `ohrm_datapoint_ibfk_1` FOREIGN KEY (`datapoint_type_id`) REFERENCES `ohrm_datapoint_type` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `ohrm_data_group_screen`
--
ALTER TABLE `ohrm_data_group_screen`
  ADD CONSTRAINT `ohrm_data_group_screen_ibfk_2` FOREIGN KEY (`screen_id`) REFERENCES `ohrm_screen` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `ohrm_data_group_screen_ibfk_1` FOREIGN KEY (`data_group_id`) REFERENCES `ohrm_data_group` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `ohrm_display_field`
--
ALTER TABLE `ohrm_display_field`
  ADD CONSTRAINT `ohrm_display_field_ibfk_2` FOREIGN KEY (`display_field_group_id`) REFERENCES `ohrm_display_field_group` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `ohrm_display_field_ibfk_1` FOREIGN KEY (`report_group_id`) REFERENCES `ohrm_report_group` (`report_group_id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `ohrm_display_field_group`
--
ALTER TABLE `ohrm_display_field_group`
  ADD CONSTRAINT `ohrm_display_field_group_ibfk_1` FOREIGN KEY (`report_group_id`) REFERENCES `ohrm_report_group` (`report_group_id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `ohrm_email_processor`
--
ALTER TABLE `ohrm_email_processor`
  ADD CONSTRAINT `ohrm_email_processor_ibfk_1` FOREIGN KEY (`email_id`) REFERENCES `ohrm_email` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `ohrm_email_subscriber`
--
ALTER TABLE `ohrm_email_subscriber`
  ADD CONSTRAINT `ohrm_email_subscriber_ibfk_1` FOREIGN KEY (`notification_id`) REFERENCES `ohrm_email_notification` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `ohrm_email_template`
--
ALTER TABLE `ohrm_email_template`
  ADD CONSTRAINT `ohrm_email_template_ibfk_1` FOREIGN KEY (`email_id`) REFERENCES `ohrm_email` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `ohrm_employee_work_shift`
--
ALTER TABLE `ohrm_employee_work_shift`
  ADD CONSTRAINT `ohrm_employee_work_shift_ibfk_1` FOREIGN KEY (`work_shift_id`) REFERENCES `ohrm_work_shift` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `ohrm_employee_work_shift_ibfk_2` FOREIGN KEY (`emp_number`) REFERENCES `hs_hr_employee` (`emp_number`) ON DELETE CASCADE;

--
-- Contraintes pour la table `ohrm_emp_education`
--
ALTER TABLE `ohrm_emp_education`
  ADD CONSTRAINT `ohrm_emp_education_ibfk_2` FOREIGN KEY (`education_id`) REFERENCES `ohrm_education` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `ohrm_emp_education_ibfk_1` FOREIGN KEY (`emp_number`) REFERENCES `hs_hr_employee` (`emp_number`) ON DELETE CASCADE;

--
-- Contraintes pour la table `ohrm_emp_license`
--
ALTER TABLE `ohrm_emp_license`
  ADD CONSTRAINT `ohrm_emp_license_ibfk_2` FOREIGN KEY (`license_id`) REFERENCES `ohrm_license` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `ohrm_emp_license_ibfk_1` FOREIGN KEY (`emp_number`) REFERENCES `hs_hr_employee` (`emp_number`) ON DELETE CASCADE;

--
-- Contraintes pour la table `ohrm_emp_termination`
--
ALTER TABLE `ohrm_emp_termination`
  ADD CONSTRAINT `ohrm_emp_termination_ibfk_2` FOREIGN KEY (`emp_number`) REFERENCES `hs_hr_employee` (`emp_number`) ON DELETE CASCADE,
  ADD CONSTRAINT `ohrm_emp_termination_ibfk_1` FOREIGN KEY (`reason_id`) REFERENCES `ohrm_emp_termination_reason` (`id`) ON DELETE SET NULL;

--
-- Contraintes pour la table `ohrm_filter_field`
--
ALTER TABLE `ohrm_filter_field`
  ADD CONSTRAINT `ohrm_filter_field_ibfk_1` FOREIGN KEY (`report_group_id`) REFERENCES `ohrm_report_group` (`report_group_id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `ohrm_holiday`
--
ALTER TABLE `ohrm_holiday`
  ADD CONSTRAINT `fk_ohrm_holiday_ohrm_operational_country` FOREIGN KEY (`operational_country_id`) REFERENCES `ohrm_operational_country` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `ohrm_home_page`
--
ALTER TABLE `ohrm_home_page`
  ADD CONSTRAINT `ohrm_home_page_ibfk_1` FOREIGN KEY (`user_role_id`) REFERENCES `ohrm_user_role` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `ohrm_job_candidate`
--
ALTER TABLE `ohrm_job_candidate`
  ADD CONSTRAINT `ohrm_job_candidate_ibfk_1` FOREIGN KEY (`added_person`) REFERENCES `hs_hr_employee` (`emp_number`) ON DELETE SET NULL;

--
-- Contraintes pour la table `ohrm_job_candidate_attachment`
--
ALTER TABLE `ohrm_job_candidate_attachment`
  ADD CONSTRAINT `ohrm_job_candidate_attachment_ibfk_1` FOREIGN KEY (`candidate_id`) REFERENCES `ohrm_job_candidate` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `ohrm_job_candidate_history`
--
ALTER TABLE `ohrm_job_candidate_history`
  ADD CONSTRAINT `ohrm_job_candidate_history_ibfk_4` FOREIGN KEY (`performed_by`) REFERENCES `hs_hr_employee` (`emp_number`) ON DELETE SET NULL,
  ADD CONSTRAINT `ohrm_job_candidate_history_ibfk_1` FOREIGN KEY (`candidate_id`) REFERENCES `ohrm_job_candidate` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `ohrm_job_candidate_history_ibfk_2` FOREIGN KEY (`vacancy_id`) REFERENCES `ohrm_job_vacancy` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `ohrm_job_candidate_history_ibfk_3` FOREIGN KEY (`interview_id`) REFERENCES `ohrm_job_interview` (`id`) ON DELETE SET NULL;

--
-- Contraintes pour la table `ohrm_job_candidate_vacancy`
--
ALTER TABLE `ohrm_job_candidate_vacancy`
  ADD CONSTRAINT `ohrm_job_candidate_vacancy_ibfk_2` FOREIGN KEY (`vacancy_id`) REFERENCES `ohrm_job_vacancy` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `ohrm_job_candidate_vacancy_ibfk_1` FOREIGN KEY (`candidate_id`) REFERENCES `ohrm_job_candidate` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `ohrm_job_interview`
--
ALTER TABLE `ohrm_job_interview`
  ADD CONSTRAINT `ohrm_job_interview_ibfk_2` FOREIGN KEY (`candidate_id`) REFERENCES `ohrm_job_candidate` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `ohrm_job_interview_ibfk_1` FOREIGN KEY (`candidate_vacancy_id`) REFERENCES `ohrm_job_candidate_vacancy` (`id`) ON DELETE SET NULL;

--
-- Contraintes pour la table `ohrm_job_interview_attachment`
--
ALTER TABLE `ohrm_job_interview_attachment`
  ADD CONSTRAINT `ohrm_job_interview_attachment_ibfk_1` FOREIGN KEY (`interview_id`) REFERENCES `ohrm_job_interview` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `ohrm_job_interview_interviewer`
--
ALTER TABLE `ohrm_job_interview_interviewer`
  ADD CONSTRAINT `ohrm_job_interview_interviewer_ibfk_2` FOREIGN KEY (`interviewer_id`) REFERENCES `hs_hr_employee` (`emp_number`) ON DELETE CASCADE,
  ADD CONSTRAINT `ohrm_job_interview_interviewer_ibfk_1` FOREIGN KEY (`interview_id`) REFERENCES `ohrm_job_interview` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `ohrm_job_specification_attachment`
--
ALTER TABLE `ohrm_job_specification_attachment`
  ADD CONSTRAINT `ohrm_job_specification_attachment_ibfk_1` FOREIGN KEY (`job_title_id`) REFERENCES `ohrm_job_title` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `ohrm_job_vacancy`
--
ALTER TABLE `ohrm_job_vacancy`
  ADD CONSTRAINT `ohrm_job_vacancy_ibfk_2` FOREIGN KEY (`hiring_manager_id`) REFERENCES `hs_hr_employee` (`emp_number`) ON DELETE SET NULL,
  ADD CONSTRAINT `ohrm_job_vacancy_ibfk_1` FOREIGN KEY (`job_title_code`) REFERENCES `ohrm_job_title` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `ohrm_job_vacancy_attachment`
--
ALTER TABLE `ohrm_job_vacancy_attachment`
  ADD CONSTRAINT `ohrm_job_vacancy_attachment_ibfk_1` FOREIGN KEY (`vacancy_id`) REFERENCES `ohrm_job_vacancy` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `ohrm_leave`
--
ALTER TABLE `ohrm_leave`
  ADD CONSTRAINT `ohrm_leave_ibfk_2` FOREIGN KEY (`leave_type_id`) REFERENCES `ohrm_leave_type` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `ohrm_leave_ibfk_1` FOREIGN KEY (`leave_request_id`) REFERENCES `ohrm_leave_request` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `ohrm_leave_adjustment`
--
ALTER TABLE `ohrm_leave_adjustment`
  ADD CONSTRAINT `ohrm_leave_adjustment_ibfk_4` FOREIGN KEY (`adjustment_type`) REFERENCES `ohrm_leave_entitlement_type` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `ohrm_leave_adjustment_ibfk_1` FOREIGN KEY (`leave_type_id`) REFERENCES `ohrm_leave_type` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `ohrm_leave_adjustment_ibfk_2` FOREIGN KEY (`emp_number`) REFERENCES `hs_hr_employee` (`emp_number`) ON DELETE CASCADE,
  ADD CONSTRAINT `ohrm_leave_adjustment_ibfk_3` FOREIGN KEY (`created_by_id`) REFERENCES `ohrm_user` (`id`) ON DELETE SET NULL;

--
-- Contraintes pour la table `ohrm_leave_comment`
--
ALTER TABLE `ohrm_leave_comment`
  ADD CONSTRAINT `ohrm_leave_comment_ibfk_3` FOREIGN KEY (`created_by_emp_number`) REFERENCES `hs_hr_employee` (`emp_number`) ON DELETE CASCADE,
  ADD CONSTRAINT `ohrm_leave_comment_ibfk_1` FOREIGN KEY (`leave_id`) REFERENCES `ohrm_leave` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `ohrm_leave_comment_ibfk_2` FOREIGN KEY (`created_by_id`) REFERENCES `ohrm_user` (`id`) ON DELETE SET NULL;

--
-- Contraintes pour la table `ohrm_leave_entitlement`
--
ALTER TABLE `ohrm_leave_entitlement`
  ADD CONSTRAINT `ohrm_leave_entitlement_ibfk_4` FOREIGN KEY (`created_by_id`) REFERENCES `ohrm_user` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `ohrm_leave_entitlement_ibfk_1` FOREIGN KEY (`leave_type_id`) REFERENCES `ohrm_leave_type` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `ohrm_leave_entitlement_ibfk_2` FOREIGN KEY (`emp_number`) REFERENCES `hs_hr_employee` (`emp_number`) ON DELETE CASCADE,
  ADD CONSTRAINT `ohrm_leave_entitlement_ibfk_3` FOREIGN KEY (`entitlement_type`) REFERENCES `ohrm_leave_entitlement_type` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `ohrm_leave_entitlement_adjustment`
--
ALTER TABLE `ohrm_leave_entitlement_adjustment`
  ADD CONSTRAINT `ohrm_leave_entitlement_adjustment_ibfk_2` FOREIGN KEY (`adjustment_id`) REFERENCES `ohrm_leave_adjustment` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `ohrm_leave_entitlement_adjustment_ibfk_1` FOREIGN KEY (`entitlement_id`) REFERENCES `ohrm_leave_entitlement` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `ohrm_leave_leave_entitlement`
--
ALTER TABLE `ohrm_leave_leave_entitlement`
  ADD CONSTRAINT `ohrm_leave_leave_entitlement_ibfk_2` FOREIGN KEY (`leave_id`) REFERENCES `ohrm_leave` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `ohrm_leave_leave_entitlement_ibfk_1` FOREIGN KEY (`entitlement_id`) REFERENCES `ohrm_leave_entitlement` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `ohrm_leave_request`
--
ALTER TABLE `ohrm_leave_request`
  ADD CONSTRAINT `ohrm_leave_request_ibfk_2` FOREIGN KEY (`leave_type_id`) REFERENCES `ohrm_leave_type` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `ohrm_leave_request_ibfk_1` FOREIGN KEY (`emp_number`) REFERENCES `hs_hr_employee` (`emp_number`) ON DELETE CASCADE;

--
-- Contraintes pour la table `ohrm_leave_request_comment`
--
ALTER TABLE `ohrm_leave_request_comment`
  ADD CONSTRAINT `ohrm_leave_request_comment_ibfk_3` FOREIGN KEY (`created_by_emp_number`) REFERENCES `hs_hr_employee` (`emp_number`) ON DELETE CASCADE,
  ADD CONSTRAINT `ohrm_leave_request_comment_ibfk_1` FOREIGN KEY (`leave_request_id`) REFERENCES `ohrm_leave_request` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `ohrm_leave_request_comment_ibfk_2` FOREIGN KEY (`created_by_id`) REFERENCES `ohrm_user` (`id`) ON DELETE SET NULL;

--
-- Contraintes pour la table `ohrm_leave_type`
--
ALTER TABLE `ohrm_leave_type`
  ADD CONSTRAINT `ohrm_leave_type_ibfk_1` FOREIGN KEY (`operational_country_id`) REFERENCES `ohrm_operational_country` (`id`) ON DELETE SET NULL;

--
-- Contraintes pour la table `ohrm_location`
--
ALTER TABLE `ohrm_location`
  ADD CONSTRAINT `ohrm_location_ibfk_1` FOREIGN KEY (`country_code`) REFERENCES `hs_hr_country` (`cou_code`) ON DELETE CASCADE;

--
-- Contraintes pour la table `ohrm_menu_item`
--
ALTER TABLE `ohrm_menu_item`
  ADD CONSTRAINT `ohrm_menu_item_ibfk_1` FOREIGN KEY (`screen_id`) REFERENCES `ohrm_screen` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `ohrm_module_default_page`
--
ALTER TABLE `ohrm_module_default_page`
  ADD CONSTRAINT `ohrm_module_default_page_ibfk_1` FOREIGN KEY (`user_role_id`) REFERENCES `ohrm_user_role` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `ohrm_module_default_page_ibfk_2` FOREIGN KEY (`module_id`) REFERENCES `ohrm_module` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `ohrm_openid_user_identity`
--
ALTER TABLE `ohrm_openid_user_identity`
  ADD CONSTRAINT `ohrm_user_identity_ibfk_2` FOREIGN KEY (`provider_id`) REFERENCES `ohrm_openid_provider` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `ohrm_user_identity_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `ohrm_user` (`id`) ON DELETE SET NULL;

--
-- Contraintes pour la table `ohrm_operational_country`
--
ALTER TABLE `ohrm_operational_country`
  ADD CONSTRAINT `fk_ohrm_operational_country_hs_hr_country` FOREIGN KEY (`country_code`) REFERENCES `hs_hr_country` (`cou_code`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `ohrm_pay_grade_currency`
--
ALTER TABLE `ohrm_pay_grade_currency`
  ADD CONSTRAINT `ohrm_pay_grade_currency_ibfk_2` FOREIGN KEY (`pay_grade_id`) REFERENCES `ohrm_pay_grade` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `ohrm_pay_grade_currency_ibfk_1` FOREIGN KEY (`currency_id`) REFERENCES `hs_hr_currency_type` (`currency_id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `ohrm_performance_review`
--
ALTER TABLE `ohrm_performance_review`
  ADD CONSTRAINT `ohrm_performance_review_ibfk_1` FOREIGN KEY (`employee_number`) REFERENCES `hs_hr_employee` (`emp_number`) ON DELETE CASCADE;

--
-- Contraintes pour la table `ohrm_performance_track`
--
ALTER TABLE `ohrm_performance_track`
  ADD CONSTRAINT `ohrm_performance_track_fk1` FOREIGN KEY (`emp_number`) REFERENCES `hs_hr_employee` (`emp_number`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ohrm_performance_track_fk2` FOREIGN KEY (`added_by`) REFERENCES `hs_hr_employee` (`emp_number`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `ohrm_performance_tracker_log`
--
ALTER TABLE `ohrm_performance_tracker_log`
  ADD CONSTRAINT `fk_ohrm_performance_tracker_log_1` FOREIGN KEY (`user_id`) REFERENCES `ohrm_user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ohrm_performance_tracker_log_fk1` FOREIGN KEY (`performance_track_id`) REFERENCES `ohrm_performance_track` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ohrm_performance_tracker_log_fk2` FOREIGN KEY (`reviewer_id`) REFERENCES `hs_hr_employee` (`emp_number`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `ohrm_performance_tracker_reviewer`
--
ALTER TABLE `ohrm_performance_tracker_reviewer`
  ADD CONSTRAINT `ohrm_performance_tracker_reviewer_fk1` FOREIGN KEY (`performance_track_id`) REFERENCES `ohrm_performance_track` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ohrm_performance_tracker_reviewer_fk2` FOREIGN KEY (`reviewer_id`) REFERENCES `hs_hr_employee` (`emp_number`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `ohrm_project_activity`
--
ALTER TABLE `ohrm_project_activity`
  ADD CONSTRAINT `ohrm_project_activity_ibfk_1` FOREIGN KEY (`project_id`) REFERENCES `ohrm_project` (`project_id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `ohrm_project_admin`
--
ALTER TABLE `ohrm_project_admin`
  ADD CONSTRAINT `ohrm_project_admin_ibfk_1` FOREIGN KEY (`project_id`) REFERENCES `ohrm_project` (`project_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `ohrm_project_admin_ibfk_2` FOREIGN KEY (`emp_number`) REFERENCES `hs_hr_employee` (`emp_number`) ON DELETE CASCADE;

--
-- Contraintes pour la table `ohrm_report`
--
ALTER TABLE `ohrm_report`
  ADD CONSTRAINT `ohrm_report_ibfk_1` FOREIGN KEY (`report_group_id`) REFERENCES `ohrm_report_group` (`report_group_id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `ohrm_reviewer`
--
ALTER TABLE `ohrm_reviewer`
  ADD CONSTRAINT `ohrm_reviewer_ibfk_1` FOREIGN KEY (`review_id`) REFERENCES `ohrm_performance_review` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `ohrm_reviewer_rating`
--
ALTER TABLE `ohrm_reviewer_rating`
  ADD CONSTRAINT `ohrm_reviewer_rating_ibfk_2` FOREIGN KEY (`review_id`) REFERENCES `ohrm_performance_review` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `ohrm_reviewer_rating_ibfk_1` FOREIGN KEY (`reviewer_id`) REFERENCES `ohrm_reviewer` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `ohrm_screen`
--
ALTER TABLE `ohrm_screen`
  ADD CONSTRAINT `ohrm_screen_ibfk_1` FOREIGN KEY (`module_id`) REFERENCES `ohrm_module` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `ohrm_selected_composite_display_field`
--
ALTER TABLE `ohrm_selected_composite_display_field`
  ADD CONSTRAINT `ohrm_selected_composite_display_field_ibfk_2` FOREIGN KEY (`composite_display_field_id`) REFERENCES `ohrm_composite_display_field` (`composite_display_field_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `ohrm_selected_composite_display_field_ibfk_1` FOREIGN KEY (`report_id`) REFERENCES `ohrm_report` (`report_id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `ohrm_selected_display_field`
--
ALTER TABLE `ohrm_selected_display_field`
  ADD CONSTRAINT `ohrm_selected_display_field_ibfk_2` FOREIGN KEY (`display_field_id`) REFERENCES `ohrm_display_field` (`display_field_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `ohrm_selected_display_field_ibfk_1` FOREIGN KEY (`report_id`) REFERENCES `ohrm_report` (`report_id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `ohrm_selected_display_field_group`
--
ALTER TABLE `ohrm_selected_display_field_group`
  ADD CONSTRAINT `ohrm_selected_display_field_group_ibfk_2` FOREIGN KEY (`display_field_group_id`) REFERENCES `ohrm_display_field_group` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `ohrm_selected_display_field_group_ibfk_1` FOREIGN KEY (`report_id`) REFERENCES `ohrm_report` (`report_id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `ohrm_selected_filter_field`
--
ALTER TABLE `ohrm_selected_filter_field`
  ADD CONSTRAINT `ohrm_selected_filter_field_ibfk_2` FOREIGN KEY (`filter_field_id`) REFERENCES `ohrm_filter_field` (`filter_field_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `ohrm_selected_filter_field_ibfk_1` FOREIGN KEY (`report_id`) REFERENCES `ohrm_report` (`report_id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `ohrm_selected_group_field`
--
ALTER TABLE `ohrm_selected_group_field`
  ADD CONSTRAINT `ohrm_selected_group_field_ibfk_3` FOREIGN KEY (`summary_display_field_id`) REFERENCES `ohrm_summary_display_field` (`summary_display_field_id`),
  ADD CONSTRAINT `ohrm_selected_group_field_ibfk_1` FOREIGN KEY (`report_id`) REFERENCES `ohrm_report` (`report_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `ohrm_selected_group_field_ibfk_2` FOREIGN KEY (`group_field_id`) REFERENCES `ohrm_group_field` (`group_field_id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `ohrm_summary_display_field`
--
ALTER TABLE `ohrm_summary_display_field`
  ADD CONSTRAINT `ohrm_summary_display_field_ibfk_1` FOREIGN KEY (`display_field_group_id`) REFERENCES `ohrm_display_field_group` (`id`) ON DELETE SET NULL;

--
-- Contraintes pour la table `ohrm_timesheet_action_log`
--
ALTER TABLE `ohrm_timesheet_action_log`
  ADD CONSTRAINT `ohrm_timesheet_action_log_ibfk_1` FOREIGN KEY (`performed_by`) REFERENCES `ohrm_user` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `ohrm_user`
--
ALTER TABLE `ohrm_user`
  ADD CONSTRAINT `ohrm_user_ibfk_2` FOREIGN KEY (`user_role_id`) REFERENCES `ohrm_user_role` (`id`),
  ADD CONSTRAINT `ohrm_user_ibfk_1` FOREIGN KEY (`emp_number`) REFERENCES `hs_hr_employee` (`emp_number`) ON DELETE CASCADE;

--
-- Contraintes pour la table `ohrm_user_role_data_group`
--
ALTER TABLE `ohrm_user_role_data_group`
  ADD CONSTRAINT `ohrm_user_role_data_group_ibfk_2` FOREIGN KEY (`data_group_id`) REFERENCES `ohrm_data_group` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `ohrm_user_role_data_group_ibfk_1` FOREIGN KEY (`user_role_id`) REFERENCES `ohrm_user_role` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `ohrm_user_role_screen`
--
ALTER TABLE `ohrm_user_role_screen`
  ADD CONSTRAINT `ohrm_user_role_screen_ibfk_2` FOREIGN KEY (`screen_id`) REFERENCES `ohrm_screen` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `ohrm_user_role_screen_ibfk_1` FOREIGN KEY (`user_role_id`) REFERENCES `ohrm_user_role` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `ohrm_work_week`
--
ALTER TABLE `ohrm_work_week`
  ADD CONSTRAINT `fk_ohrm_work_week_ohrm_operational_country` FOREIGN KEY (`operational_country_id`) REFERENCES `ohrm_operational_country` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

DELIMITER $$
--
-- Événements
--
CREATE EVENT `leave_taken_status_change` ON SCHEDULE EVERY 1 HOUR STARTS '2015-08-12 00:00:00' ON COMPLETION NOT PRESERVE ENABLE DO BEGIN
                        UPDATE hs_hr_leave SET leave_status = 3 WHERE leave_status = 2 AND leave_date < DATE(NOW());
                      END$$

DELIMITER ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
